package com.example.baseapp.ui.models;

public class CostSheetModel {

    public int getDescriptionId() {
        return descriptionId;
    }

    public void setDescriptionId(int descriptionId) {
        this.descriptionId = descriptionId;
    }

    public String getDescriptionName() {
        return descriptionName;
    }

    public void setDescriptionName(String descriptionName) {
        this.descriptionName = descriptionName;
    }

    public int getUnit() {
        return unit;
    }

    public void setUnit(int unit) {
        this.unit = unit;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    private int descriptionId;
    private String descriptionName;
    private int unit;

    public CostSheetModel(int descriptionId, String descriptionName, int unit, double rate, double amount) {
        this.descriptionId = descriptionId;
        this.descriptionName = descriptionName;
        this.unit = unit;
        this.rate = rate;
        this.amount = amount;
    }

    private double rate;
    private double amount;


}