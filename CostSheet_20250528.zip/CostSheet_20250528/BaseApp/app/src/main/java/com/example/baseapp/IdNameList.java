package com.example.baseapp;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class IdNameList implements Serializable {

    public IdNameList(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @SerializedName("id")
    private String id;

    @SerializedName("name")
    private String name;

}
