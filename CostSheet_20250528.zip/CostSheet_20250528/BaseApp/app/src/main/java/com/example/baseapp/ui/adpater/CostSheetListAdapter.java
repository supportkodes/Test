package com.example.baseapp.ui.adpater;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.example.baseapp.CostSheetList;
import com.example.baseapp.R;

import java.util.ArrayList;
import java.util.List;

public class CostSheetListAdapter extends ArrayAdapter<CostSheetList> {

    private List<CostSheetList> costSheetList;
    private LayoutInflater mInflater;

    public CostSheetListAdapter( Context context,ArrayList<CostSheetList> costSheetList) {
        super(context, 0, costSheetList);
//        this.costSheetList = costSheetList;
//        this.mInflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        CostSheetList costSheetList = getItem(position);

        View view = convertView;
        if (view == null) {
            view = LayoutInflater.from(getContext()).inflate(R.layout.item_cost_sheet, parent, false);
        }

        TextView description_id_tv = (TextView) view.findViewById(R.id.description_id_tv);
        TextView description_name_tv = (TextView) view.findViewById(R.id.description_tv);
        EditText unit_et = (EditText) view.findViewById(R.id.unit_et);
        EditText  rate_et = (EditText) view.findViewById(R.id.rate_et);
        TextView amount_tv = (TextView) view.findViewById(R.id.amount_tv);

        description_id_tv.setText(costSheetList.getSECTIONID());
        description_name_tv.setText(costSheetList.getSECTION());

        String unit = costSheetList.getUnit();
        if (unit != null || unit != "null") {
            unit = "0.00";
        }

        String rate = costSheetList.getRate();
        if (rate != null || rate != "null") {
            rate = "0.00";
        }

        String amount = costSheetList.getAMOUNT();
        if (amount != null || amount != "null") {
            amount = "0.00";
        }

        unit_et.setText(unit);
        rate_et.setText(rate);
        amount_tv.setText(amount);

        unit_et.setText(unit);
        rate_et.setText(rate);
        amount_tv.setText(amount);

        unit_et.setTag(unit);
        rate_et.setTag(rate);
        amount_tv.setTag(amount);

        unit_et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                String _unit = unit_et.getText().toString();
                String _rate = rate_et.getText().toString();
                double unit_d = Double.parseDouble(_unit);
                double rate_d = Double.parseDouble(_rate);
                double amount_d = unit_d * rate_d;
                amount_tv.setText(amount_d + "");
                amount_tv.setTag(amount_d + "");
            }
        });


        rate_et.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                    String _unit = unit_et.getText().toString();
                    String _rate = rate_et.getText().toString();
                    double unit_d = Double.parseDouble(_unit);
                    double rate_d = Double.parseDouble(_rate);
                    double amount_d = unit_d * rate_d;
                    amount_tv.setText(amount_d + "");
                    amount_tv.setTag(amount_d + "");
                }
        });

        return  view;
    }
}