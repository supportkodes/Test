package com.example.baseapp;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.List;

public class CostSheetList implements Serializable {

    @SerializedName("SECTIONID")
    private String SECTIONID;

    @SerializedName("SECTION")
    private String SECTION;

    @SerializedName("SUBSECTIONID")
    private String SUBSECTIONID;

    @SerializedName("SUBSECTION")
    private String SUBSECTION;

    @SerializedName("Rock")
    private String Rock;

    @SerializedName("PMT")
    private String PMT;

    @SerializedName("Unit")
    private String Unit;

    @SerializedName("Rate")
    private String Rate;

    @SerializedName("AMOUNT")
    private String AMOUNT;

    @SerializedName("COMPONENT")
    private String COMPONENT;

    public String getSECTIONID() {
        return SECTIONID;
    }

    public void setSECTIONID(String SECTIONID) {
        this.SECTIONID = SECTIONID;
    }

    public String getSECTION() {
        return SECTION;
    }

    public void setSECTION(String SECTION) {
        this.SECTION = SECTION;
    }

    public String getSUBSECTIONID() {
        return SUBSECTIONID;
    }

    public void setSUBSECTIONID(String SUBSECTIONID) {
        this.SUBSECTIONID = SUBSECTIONID;
    }

    public String getSUBSECTION() {
        return SUBSECTION;
    }

    public void setSUBSECTION(String SUBSECTION) {
        this.SUBSECTION = SUBSECTION;
    }

    public String getRock() {
        return Rock;
    }

    public void setRock(String rock) {
        Rock = rock;
    }

    public String getPMT() {
        return PMT;
    }

    public void setPMT(String PMT) {
        this.PMT = PMT;
    }

    public String getUnit() {
        return Unit;
    }

    public void setUnit(String unit) {
        Unit = unit;
    }

    public String getRate() {
        return Rate;
    }

    public void setRate(String rate) {
        Rate = rate;
    }

    public String getAMOUNT() {
        return AMOUNT;
    }

    public void setAMOUNT(String AMOUNT) {
        this.AMOUNT = AMOUNT;
    }

    public String getEditable() {
        return Editable;
    }

    public void setEditable(String editable) {
        Editable = editable;
    }

    public String getHeader() {
        return Header;
    }

    public void setHeader(String header) {
        Header = header;
    }

    public String getComponent() {
        return COMPONENT;
    }

    public void setComponent(String component) {
        COMPONENT = component;
    }

    public CostSheetList(String SECTIONID, String SECTION, String SUBSECTIONID, String SUBSECTION, String rock
            , String PMT, String unit, String rate, String AMOUNT, String editable, String header,String component) {
        this.SECTIONID = SECTIONID;
        this.SECTION = SECTION;
        this.SUBSECTIONID = SUBSECTIONID;
        this.SUBSECTION = SUBSECTION;
        Rock = rock;
        this.PMT = PMT;
        Unit = unit;
        Rate = rate;
        this.AMOUNT = AMOUNT;
        Editable = editable;
        Header = header;
        COMPONENT = component;
    }

    @SerializedName("Editable")
    private String Editable;

    @SerializedName("Header")
    private String Header;


}
