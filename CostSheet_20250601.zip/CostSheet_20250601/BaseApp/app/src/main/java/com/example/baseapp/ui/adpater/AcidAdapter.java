package com.example.baseapp.ui.adpater;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.baseapp.CostSheetList;
import com.example.baseapp.KeyValueList;
import com.example.baseapp.R;

import java.util.ArrayList;
import java.util.List;

public class AcidAdapter extends RecyclerView.Adapter<AcidAdapter.ItemHolderView> {

    private List<CostSheetList> costSheetList;
    private LayoutInflater mInflater;
    private Context context;
    private RecyclerView costsheet_rcw;
    ArrayList<KeyValueList> branchkeyValueList;
    private SpinnerAdapter spinnerAdapter;

    public AcidAdapter(Context context, List<CostSheetList> costSheetList, RecyclerView costsheet_rcw
            , ArrayList<KeyValueList> branchkeyValueList) {
        this.costSheetList = costSheetList;
        this.mInflater = LayoutInflater.from(context);
        this.context = context;
        this.costsheet_rcw = costsheet_rcw;
        this.branchkeyValueList = branchkeyValueList;
    }

    @NonNull
    @Override
    public ItemHolderView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.item_acid, parent, false);
        return new ItemHolderView(view);
    }

    @Override
    public void onBindViewHolder(final ItemHolderView holder, @SuppressLint("RecyclerView") final int position) {
        holder.description_id_tv.setText(costSheetList.get(position).getSECTIONID());
        holder.description_name_tv.setText(costSheetList.get(position).getSUBSECTION());
        //holder.component_et.setText(costSheetList.get(position).getComponent());
        String subsection = costSheetList.get(position).getSUBSECTION();
        try {
            spinnerAdapter = new SpinnerAdapter(mInflater.getContext(), branchkeyValueList);
            holder.component_spinner.setAdapter(spinnerAdapter);
        } catch (Exception ex) {
        }
        String amount = costSheetList.get(position).getAMOUNT();
        if (amount != null || amount != "null") {
            amount = "";
        }

        holder.amount_tv.setText(amount);

        holder.amount_tv.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    Calculate(holder, position);
                }

            }
        });
    }

    @Override
    public int getItemCount() {
        if (costSheetList == null) return 0;
        return costSheetList.size();
    }

    public void Calculate(ItemHolderView holder, int position) {
        try {
            String valueEntered = TextUtils.isEmpty(holder.amount_tv.getText().toString()) ? "0" : holder.amount_tv.getText().toString();
            holder.amount_tv.setText(valueEntered);
            costSheetList.get(position).setAMOUNT(valueEntered);

            double amount_d = 0;
            int basicAcidPosition = GetSubsectionPosition("Basic Acid");
            int spentAcidConcentrationPosition = GetSubsectionPosition("Spent acid Concentration");
            int basicPriceofSAPosition = GetSubsectionPosition("Basic PRICE of SA");
            int transportRoadAvgPosition = GetSubsectionPosition("TRANSPORT-ROAD (avg).");
            int saLandedcostPosition = GetSubsectionPosition("SA Landed cost");
            int saConversionnormstoSSPPosition = GetSubsectionPosition("SA conversion norms to SSP");
            int saCostPMTPosition = GetSubsectionPosition("SA cost PMT");

            Double basicAcid = TextUtils.isEmpty(costSheetList.get(basicAcidPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(basicAcidPosition).getAMOUNT());
            Double spentAcidConcentration = TextUtils.isEmpty(costSheetList.get(spentAcidConcentrationPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(spentAcidConcentrationPosition).getAMOUNT());
            Double basicPriceofSA = TextUtils.isEmpty(costSheetList.get(basicPriceofSAPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(basicPriceofSAPosition).getAMOUNT());
            Double transportRoadAvg = TextUtils.isEmpty(costSheetList.get(transportRoadAvgPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(transportRoadAvgPosition).getAMOUNT());
            Double saLandedcost = TextUtils.isEmpty(costSheetList.get(saLandedcostPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(saLandedcostPosition).getAMOUNT());
            Double saConversionnormstoSSP = TextUtils.isEmpty(costSheetList.get(saConversionnormstoSSPPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(saConversionnormstoSSPPosition).getAMOUNT());

            if (spentAcidConcentration == 0) {
                basicPriceofSA = 0.0;
            } else {
                basicPriceofSA = (basicAcid / spentAcidConcentration) * 98;
            }
            saLandedcost = basicPriceofSA + transportRoadAvg;
            Double saCostPMT = saLandedcost * saConversionnormstoSSP;

            String formatted = "";
            try {
                RecyclerView.ViewHolder viewHolder = costsheet_rcw.findViewHolderForAdapterPosition(basicPriceofSAPosition);
                AcidAdapter.ItemHolderView myViewHolder = (AcidAdapter.ItemHolderView) viewHolder;
                formatted = String.format("%.2f", basicPriceofSA);
                myViewHolder.amount_tv.setText(formatted);
            } catch (Exception ex) {

            }

            try {
                RecyclerView.ViewHolder viewHolder = costsheet_rcw.findViewHolderForAdapterPosition(saLandedcostPosition);
                AcidAdapter.ItemHolderView myViewHolder = (AcidAdapter.ItemHolderView) viewHolder;
                formatted = String.format("%.2f", saLandedcost);
                myViewHolder.amount_tv.setText(formatted);
            } catch (Exception ex) {
            }


            try {
                RecyclerView.ViewHolder viewHolder = costsheet_rcw.findViewHolderForAdapterPosition(saCostPMTPosition);
                AcidAdapter.ItemHolderView myViewHolder = (AcidAdapter.ItemHolderView) viewHolder;
                formatted = String.format("%.2f", saCostPMT);
                myViewHolder.amount_tv.setText(formatted);
            } catch (Exception ex) {
            }

            costSheetList.get(basicAcidPosition).setAMOUNT(basicAcid.toString());
            costSheetList.get(spentAcidConcentrationPosition).setAMOUNT(spentAcidConcentration.toString());
            costSheetList.get(basicPriceofSAPosition).setAMOUNT(basicPriceofSA.toString());
            costSheetList.get(transportRoadAvgPosition).setAMOUNT(transportRoadAvg.toString());
            costSheetList.get(saLandedcostPosition).setAMOUNT(saLandedcost.toString());
            costSheetList.get(saConversionnormstoSSPPosition).setAMOUNT(saConversionnormstoSSP.toString());
            costSheetList.get(saCostPMTPosition).setAMOUNT(saCostPMT.toString());
        } catch (Exception ex) {
            String errorMessage = ex.getMessage();
        }
    }

    public int GetSubsectionPosition(String subsectionName) {
        int position = -1;
        for (int i = 0; i < costSheetList.size(); i++) {
            if (costSheetList.get(i).getSUBSECTION().equalsIgnoreCase(subsectionName)) {
                position = i;
                break;
            }
        }
        return position;
    }

    public class ItemHolderView extends RecyclerView.ViewHolder {
        public EditText amount_tv, component_et;
        public TextView description_id_tv, description_name_tv;
        public Spinner component_spinner;

        public ItemHolderView(View view) {
            super(view);
            description_id_tv = (TextView) view.findViewById(R.id.description_id_tv);
            description_name_tv = (TextView) view.findViewById(R.id.description_tv);
            amount_tv = (EditText) view.findViewById(R.id.amount_tv);
            component_spinner = (Spinner) view.findViewById(R.id.spn_branch);
        }
    }


}