package com.example.baseapp.ui.adpater;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.ColorInt;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.baseapp.CostSheetList;
import com.example.baseapp.R;
import com.example.baseapp.ui.models.CostSheetModel;

import java.util.List;

public class CostSheetAdapter extends RecyclerView.Adapter<CostSheetAdapter.ItemHolderView> {

    private List<CostSheetList> costSheetList;
    private LayoutInflater mInflater;
    private Double productionLevel;

    private Context context;
    private RecyclerView costsheet_rcw;

    public CostSheetAdapter(Context context, List<CostSheetList> costSheetList,RecyclerView costsheet_rcw) {
        this.costSheetList = costSheetList;
        this.mInflater = LayoutInflater.from(context);
        this.context = context;
        this.costsheet_rcw = costsheet_rcw;

        //        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ItemHolderView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.item_cost_sheet, parent, false);
        return new ItemHolderView(view);
    }

    @Override
    public void onBindViewHolder(final ItemHolderView holder, @SuppressLint("RecyclerView") final int position) {
        holder.description_id_tv.setText(costSheetList.get(position).getSECTIONID());
        holder.description_name_tv.setText(costSheetList.get(position).getSUBSECTION());
        String subsection = costSheetList.get(position).getSUBSECTION();
        String isHeaderVisible = costSheetList.get(position).getHeader();
        if(isHeaderVisible.toString().equals("Y") ){
            holder.unit_et.setVisibility(View.INVISIBLE);
            holder.rate_et.setVisibility(View.INVISIBLE);
            holder.description_name_tv.setTypeface(null, Typeface.BOLD);
        }
        //Toast.makeText(this, "Error1", Toast.LENGTH_SHORT).show();

        //holder.unit_et.removeTextChangedListener(holder.textWatcher);

        String unit = costSheetList.get(position).getUnit();
        if (unit != null || unit != "null") {
            unit = "";
        }

        String rate = costSheetList.get(position).getRate();
        if (rate != null || rate != "null") {
            rate = "";
        }

        String amount = costSheetList.get(position).getAMOUNT();
        if (amount != null || amount != "null") {
            amount = "";
        }

        holder.unit_et.setText(unit);
        holder.rate_et.setText(rate);
        holder.amount_tv.setText(amount);

        String editable = costSheetList.get(position).getEditable();
        if(isHeaderVisible.toString().equals("N")) {
            if (editable.toString().equalsIgnoreCase("N")) {
                holder.unit_et.setVisibility(View.VISIBLE);
                holder.rate_et.setVisibility(View.VISIBLE);
                holder.unit_et.setEnabled(false);
                holder.rate_et.setEnabled(false);
                holder.unit_et.setBackgroundColor(Color.parseColor("#ADD8E6"));
                holder.rate_et.setBackgroundColor(Color.parseColor("#ADD8E6"));
            }
        }

        //holder.unit_et.addTextChangedListener(holder.textWatcher);

        holder.unit_et.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    Calculate(holder,position);
                }

            }
        });

        holder.rate_et.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    Calculate(holder,position);
                }
            }
        });

    }

    @Override
    public int getItemCount() {
        return costSheetList.size();
    }

    public  void  Calculate(ItemHolderView holder,int position){
        try {

            String _unit_str = TextUtils.isEmpty(holder.unit_et.getText().toString()) ? "0" : holder.unit_et.getText().toString();
            String _rate_str = TextUtils.isEmpty(holder.rate_et.getText().toString()) ? "0" : holder.rate_et.getText().toString();

            double unit_d = Double.parseDouble(_unit_str);
            double rate_d = Double.parseDouble(_rate_str);
            double amount_d = 0;
            SharedPreferences editor = context.getSharedPreferences("CostSheet", 0);
            String sProdLevel = editor.getString("prodlevel", "");
            productionLevel = TextUtils.isEmpty(sProdLevel) ? 0 : Double.parseDouble(sProdLevel);
            String description = holder.description_name_tv.getText().toString();
            if (description.toString().equalsIgnoreCase("ToTal Stores & Consumables")
                    || description.toString().equalsIgnoreCase("ToTal Repair & Maintenance")
                    || description.toString().equalsIgnoreCase("ToTal JCB/Pockand/Dumper Hire Charges")
                    || description.toString().equalsIgnoreCase("ToTal Others/Water charegs")
                    || description.toString().equalsIgnoreCase("ToTal Salaries & Wages Fixed")
                    || description.toString().equalsIgnoreCase("ToTal Adminstrative Expenses Fixed")
                    || description.toString().equalsIgnoreCase("Professional / Consultancy")
                    || description.toString().equalsIgnoreCase("ToTal HO Expenses")
                    || description.toString().equalsIgnoreCase("ToTal Travelling Exp.")
                    || description.toString().equalsIgnoreCase("ToTal  Sales Promotion exp.")
                    || description.toString().equalsIgnoreCase("ToTal Others/Godown Exp.")
                    || description.toString().equalsIgnoreCase("ToTal Interest / Working Capital")
                    || description.toString().equalsIgnoreCase("ToTal Bank Charges/LC BG Charges")
                    || description.toString().equalsIgnoreCase("ToTal Depreciation")
            ) {
                amount_d = (unit_d * rate_d) / productionLevel;
                amount_d = Math.round(amount_d * 100.0) / 100.0;
            } else {
                amount_d = unit_d * rate_d;
            }
            String formatted = String.format("%.2f", amount_d);
            holder.amount_tv.setText(formatted);
            costSheetList.get(position).setAMOUNT(formatted);


            int rockCostPMTPosition = GetSubsectionPosition("Rock cost PMT");
            int saCostPMTPosition = GetSubsectionPosition("SA cost PMT");
            int fillerPosition = GetSubsectionPosition("Filler");
            int totalRawMaterialCostPosition = GetSubsectionPosition("Total Raw Material Cost (PMT)");
            int processingFuelPosition = GetSubsectionPosition("Processing Fuel");
            int processingPowerPosition = GetSubsectionPosition("Processing Power");
            int totalStoresConsumablesPosition = GetSubsectionPosition("Total Stores & Consumables");
            int totalRepairMaintenancePosition = GetSubsectionPosition("Total Repair & Maintenance");
            int totalJCBPockandDumperHireChargesPosition = GetSubsectionPosition("Total JCB/Pockand/Dumper Hire Charges");
            int totalOthersWaterCharegsPosition = GetSubsectionPosition("Total Others/Water charegs");
            int totalBagsPosition = GetSubsectionPosition("Total Bags");
            int totalThreadsPosition = GetSubsectionPosition("Total Threads");
            int totalPackingChargesPosition = GetSubsectionPosition("Total Packing Charges");
            int totalLoadingChargesPosition = GetSubsectionPosition("Total Loading charges");
            int totalOtherWagesPosition = GetSubsectionPosition("Total Other Wages");
            int totalProcessingCostPosition = GetSubsectionPosition("Total Processing Cost");
            int totalSalariesWagesFixedPosition = GetSubsectionPosition("Total Salaries & Wages Fixed");
            int totalAdminstrativeExpensesFixedPosition = GetSubsectionPosition("Total Adminstrative Expenses Fixed");
            int professionalConsultancyPosition = GetSubsectionPosition("Professional / Consultancy");
            int toTalHOExpensesPosition = GetSubsectionPosition("Total HO Expenses");
            int totalTravellingExpPosition = GetSubsectionPosition("Total Travelling Exp.");
            int totalSalesPromotionExpPosition = GetSubsectionPosition("Total  Sales Promotion exp.");
            int totalOthersGodownExpPosition = GetSubsectionPosition("Total Others/Godown Exp.");
            int totalInterestWorkingCapitalPosition = GetSubsectionPosition("Total Interest / Working Capital");
            int totalBankChargesLCBGChargesPosition = GetSubsectionPosition("Total Bank Charges/LC BG Charges");
            int totalDepreciationPosition = GetSubsectionPosition("Total Depreciation");
            int totalFixedCostPosition = GetSubsectionPosition("Total Fixed Cost");
            int totalCostfortheMonthPosition = GetSubsectionPosition("Total Cost for the Month");
            int lessSubsidyPosition = GetSubsectionPosition("Less: Subsidy");
            int exFactoryCostPosition = GetSubsectionPosition("Ex-Factory Cost");
            int gstPosition = GetSubsectionPosition("GST");
            int exFactoryCostGSTPosition = GetSubsectionPosition("Ex-Factory Cost+GST");
            int freightcostPosition = GetSubsectionPosition("Freight cost");
            int totalCostExfactoryGSTFreightPosition = GetSubsectionPosition("Total Cost (Exfactory+GST+Freight)");

            Double rockCostPMT = TextUtils.isEmpty(costSheetList.get(rockCostPMTPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(rockCostPMTPosition).getAMOUNT());
            Double saCostPMT = TextUtils.isEmpty(costSheetList.get(saCostPMTPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(saCostPMTPosition).getAMOUNT());
            Double filler = TextUtils.isEmpty(costSheetList.get(fillerPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(fillerPosition).getAMOUNT());
            Double totalRawMaterialCost = rockCostPMT + saCostPMT + filler;
            costSheetList.get(totalRawMaterialCostPosition).setAMOUNT(totalRawMaterialCost.toString());

            try {
                RecyclerView.ViewHolder viewHolder = costsheet_rcw.findViewHolderForAdapterPosition(totalRawMaterialCostPosition);
                ItemHolderView myViewHolder = (CostSheetAdapter.ItemHolderView) viewHolder;
                myViewHolder.amount_tv.setText(totalRawMaterialCost.toString());
            }catch(Exception ex)  {}

            Double processingFuel = TextUtils.isEmpty(costSheetList.get(processingFuelPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(processingFuelPosition).getAMOUNT());
            Double processingPower = TextUtils.isEmpty(costSheetList.get(processingPowerPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(processingPowerPosition).getAMOUNT());
            Double totalStoresConsumables = TextUtils.isEmpty(costSheetList.get(totalStoresConsumablesPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(totalStoresConsumablesPosition).getAMOUNT());
            Double totalRepairMaintenance = TextUtils.isEmpty(costSheetList.get(totalRepairMaintenancePosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(totalRepairMaintenancePosition).getAMOUNT());
            Double totalJCBPockandDumperHireCharges = TextUtils.isEmpty(costSheetList.get(totalJCBPockandDumperHireChargesPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(totalJCBPockandDumperHireChargesPosition).getAMOUNT());
            Double totalOthersWaterCharegs = TextUtils.isEmpty(costSheetList.get(totalOthersWaterCharegsPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(totalOthersWaterCharegsPosition).getAMOUNT());
            Double totalBags = TextUtils.isEmpty(costSheetList.get(totalBagsPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(totalBagsPosition).getAMOUNT());
            Double totalThreads = TextUtils.isEmpty(costSheetList.get(totalThreadsPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(totalThreadsPosition).getAMOUNT());
            Double totalPackingCharges = TextUtils.isEmpty(costSheetList.get(totalPackingChargesPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(totalPackingChargesPosition).getAMOUNT());
            Double totalLoadingCharges = TextUtils.isEmpty(costSheetList.get(totalLoadingChargesPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(totalLoadingChargesPosition).getAMOUNT());
            Double totalOtherWages = TextUtils.isEmpty(costSheetList.get(totalOtherWagesPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(totalOtherWagesPosition).getAMOUNT());

            Double totalProcessingCost = processingFuel + processingPower + totalStoresConsumables + totalRepairMaintenance + totalJCBPockandDumperHireCharges + totalOthersWaterCharegs+ totalBags + totalThreads+totalPackingCharges+totalLoadingCharges+totalOtherWages;
            costSheetList.get(totalProcessingCostPosition).setAMOUNT(totalProcessingCost.toString());

            try {
                RecyclerView.ViewHolder viewHolderProcessingCost = costsheet_rcw.findViewHolderForAdapterPosition(totalProcessingCostPosition);
                ItemHolderView itemHolderProcessingCost = (CostSheetAdapter.ItemHolderView) viewHolderProcessingCost;
                itemHolderProcessingCost.amount_tv.setText(totalProcessingCost.toString());
            }catch (Exception ex){}


            Double totalSalariesWagesFixed = TextUtils.isEmpty(costSheetList.get(totalSalariesWagesFixedPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(totalSalariesWagesFixedPosition).getAMOUNT());
            Double totalAdminstrativeExpensesFixed = TextUtils.isEmpty(costSheetList.get(totalAdminstrativeExpensesFixedPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(totalAdminstrativeExpensesFixedPosition).getAMOUNT());
            Double professionalConsultancy = TextUtils.isEmpty(costSheetList.get(professionalConsultancyPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(professionalConsultancyPosition).getAMOUNT());
            Double toTalHOExpenses = TextUtils.isEmpty(costSheetList.get(toTalHOExpensesPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(toTalHOExpensesPosition).getAMOUNT());
            Double totalTravellingExp = TextUtils.isEmpty(costSheetList.get(totalTravellingExpPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(totalTravellingExpPosition).getAMOUNT());

            Double totalSalesPromotionExp = TextUtils.isEmpty(costSheetList.get(totalSalesPromotionExpPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(totalSalesPromotionExpPosition).getAMOUNT());
            Double totalOthersGodownExp = TextUtils.isEmpty(costSheetList.get(totalOthersGodownExpPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(totalOthersGodownExpPosition).getAMOUNT());
            Double totalInterestWorkingCapital = TextUtils.isEmpty(costSheetList.get(totalInterestWorkingCapitalPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(totalInterestWorkingCapitalPosition).getAMOUNT());
            Double totalBankChargesLCBGCharges = TextUtils.isEmpty(costSheetList.get(totalBankChargesLCBGChargesPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(totalBankChargesLCBGChargesPosition).getAMOUNT());
            Double totalDepreciation = TextUtils.isEmpty(costSheetList.get(totalDepreciationPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(totalDepreciationPosition).getAMOUNT());

            Double totalFixedCost = totalSalariesWagesFixed+totalAdminstrativeExpensesFixed+professionalConsultancy+toTalHOExpenses+totalTravellingExp+totalSalesPromotionExp+totalOthersGodownExp+totalInterestWorkingCapital+totalBankChargesLCBGCharges+totalDepreciation;
            costSheetList.get(totalFixedCostPosition).setAMOUNT(totalFixedCost.toString());

            try {
                RecyclerView.ViewHolder viewHolderTotalFixedCost = costsheet_rcw.findViewHolderForAdapterPosition(totalFixedCostPosition);
                ItemHolderView itemHolderTotalFixedCost = (CostSheetAdapter.ItemHolderView) viewHolderTotalFixedCost;
                itemHolderTotalFixedCost.amount_tv.setText(totalFixedCost.toString());
            }catch (Exception ex){}

            Double totalCostfortheMonth = totalRawMaterialCost+totalProcessingCost+totalFixedCost;
            costSheetList.get(totalCostfortheMonthPosition).setAMOUNT(totalCostfortheMonth.toString());
            try {
                RecyclerView.ViewHolder viewHolderTotalCostfortheMonth = costsheet_rcw.findViewHolderForAdapterPosition(totalCostfortheMonthPosition);
                ItemHolderView itemHolderTotalCostfortheMonth = (CostSheetAdapter.ItemHolderView) viewHolderTotalCostfortheMonth;
                itemHolderTotalCostfortheMonth.amount_tv.setText(totalCostfortheMonth.toString());
            }catch (Exception ex){}

            Double lessSubsidy = TextUtils.isEmpty(costSheetList.get(lessSubsidyPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(lessSubsidyPosition).getAMOUNT());

            Double exFactoryCost = totalCostfortheMonth - lessSubsidy;
            costSheetList.get(exFactoryCostPosition).setAMOUNT(exFactoryCost.toString());
            try {
                RecyclerView.ViewHolder viewHolderExFactoryCost = costsheet_rcw.findViewHolderForAdapterPosition(exFactoryCostPosition);
                ItemHolderView itemHolderExFactoryCost = (CostSheetAdapter.ItemHolderView) viewHolderExFactoryCost;
                itemHolderExFactoryCost.amount_tv.setText(exFactoryCost.toString());
            }catch (Exception ex){}

            Double gst = TextUtils.isEmpty(costSheetList.get(gstPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(gstPosition).getAMOUNT());
            Double exFactoryCostGST = exFactoryCost +gst;
            costSheetList.get(exFactoryCostPosition).setAMOUNT(exFactoryCostGST.toString());
            try {
                RecyclerView.ViewHolder viewHolderExFactoryCostGST = costsheet_rcw.findViewHolderForAdapterPosition(exFactoryCostGSTPosition);
                ItemHolderView itemHolderExFactoryCostGST = (CostSheetAdapter.ItemHolderView) viewHolderExFactoryCostGST;
                itemHolderExFactoryCostGST.amount_tv.setText(exFactoryCostGST.toString());
            }catch (Exception ex){}

            Double freightcost = TextUtils.isEmpty(costSheetList.get(freightcostPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(freightcostPosition).getAMOUNT());
            Double totalCostExfactoryGSTFreight = exFactoryCostGST  + freightcost;
            costSheetList.get(totalCostExfactoryGSTFreightPosition).setAMOUNT(totalCostExfactoryGSTFreight.toString());
            try {
                RecyclerView.ViewHolder viewHoldertotalCostExfactoryGSTFreight = costsheet_rcw.findViewHolderForAdapterPosition(totalCostExfactoryGSTFreightPosition);
                ItemHolderView itemHoldertotalCostExfactoryGSTFreight = (CostSheetAdapter.ItemHolderView) viewHoldertotalCostExfactoryGSTFreight;
                itemHoldertotalCostExfactoryGSTFreight.amount_tv.setText(totalCostExfactoryGSTFreight.toString());
            }catch (Exception ex){}


        }
        catch(Exception ex)
        {
            String errorMessage= ex.getMessage();
        }
    }

    public int GetSubsectionPosition(String subsectionName)
    {
        int position = -1;
        for(int i=0;i<costSheetList.size();i++) {
            if (costSheetList.get(i).getSUBSECTION().equalsIgnoreCase(subsectionName)) {
                position = i;
                break;
            }
        }
        return position;
    }

    public class ItemHolderView extends RecyclerView.ViewHolder {
        public EditText unit_et, rate_et;
        public TextView description_id_tv, description_name_tv, amount_tv;

        public ItemHolderView(View view) {
            super(view);

            description_id_tv = (TextView) view.findViewById(R.id.description_id_tv);
            description_name_tv = (TextView) view.findViewById(R.id.description_tv);
            unit_et = (EditText) view.findViewById(R.id.unit_et);
            rate_et = (EditText) view.findViewById(R.id.rate_et);
            amount_tv = (TextView) view.findViewById(R.id.amount_tv);
        }
    }


}