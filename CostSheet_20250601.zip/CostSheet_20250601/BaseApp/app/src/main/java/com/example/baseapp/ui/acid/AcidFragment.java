package com.example.baseapp.ui.acid;

import static com.example.baseapp.NetworkDetails.isNetworkAvailable;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.baseapp.CostSheetList;
import com.example.baseapp.KeyValueList;
import com.example.baseapp.R;
import com.example.baseapp.databinding.FragmentNotificationsBinding;
import com.example.baseapp.ui.CostSheetService;
import com.example.baseapp.ui.RetrofitInstance;
import com.example.baseapp.ui.adpater.AcidAdapter;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AcidFragment extends Fragment {

    private FragmentNotificationsBinding binding;
    private RecyclerView costsheet_rcw;
    private AcidAdapter acidAdapter;
    ArrayList<KeyValueList> branchkeyValueList;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_notifications, container, false);
        costsheet_rcw = (RecyclerView) root.findViewById(R.id.costsheet_rcw);
        if (isNetworkAvailable(getActivity())) {
            CallService_AcidComponentsList();
            CallService_BudgetCostSheetList(10);
        } else {
            Toast.makeText(getActivity(), getString(R.string.no_working_internet_msg), Toast.LENGTH_LONG).show();
        }
        return root;
    }


    private void CallService_BudgetCostSheetList(int usdRate) {
        CostSheetService service = RetrofitInstance.getRetrofitInstance().create(CostSheetService.class);
        Call<ArrayList<CostSheetList>> call = service.GetBudgetCostSheetAcid(usdRate);
        call.enqueue(new Callback<ArrayList<CostSheetList>>() {
            @Override
            public void onResponse(Call<ArrayList<CostSheetList>> call, Response<ArrayList<CostSheetList>> response) {
                if (response.body() != null) {
                    ArrayList<CostSheetList> costSheetList = response.body();
                    GenerateCostSheetList(costSheetList);
                }
            }

            @Override
            public void onFailure(Call<ArrayList<CostSheetList>> call, Throwable t) {
                Toast.makeText(getActivity(), "Something went wrong. Please try later.", Toast.LENGTH_LONG).show();
            }
        });
    }


    private void GenerateCostSheetList(ArrayList<CostSheetList> costSheetList) {
        acidAdapter = new AcidAdapter(getActivity(), costSheetList,costsheet_rcw,branchkeyValueList);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        costsheet_rcw.setLayoutManager(layoutManager);
        costsheet_rcw.setAdapter(acidAdapter);
        costsheet_rcw.setItemViewCacheSize(costSheetList.size());
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }


    private void CallService_AcidComponentsList() {
        CostSheetService service = RetrofitInstance.getRetrofitInstance().create(CostSheetService.class);
        Call<ArrayList<KeyValueList>> call = service.GetAcidComponents();
        call.enqueue(new Callback<ArrayList<KeyValueList>>() {
            @Override
            public void onResponse(Call<ArrayList<KeyValueList>> call, Response<ArrayList<KeyValueList>> response) {
                if (response.body() != null) {
                    branchkeyValueList = response.body();
                }
            }

            @Override
            public void onFailure(Call<ArrayList<KeyValueList>> call, Throwable t) {
                Toast.makeText(getActivity(), "Something went wrong. Please try later.", Toast.LENGTH_LONG).show();
            }
        });
    }
}