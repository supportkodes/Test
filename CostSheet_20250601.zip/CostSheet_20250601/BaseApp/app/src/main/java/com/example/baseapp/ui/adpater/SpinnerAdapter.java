package com.example.baseapp.ui.adpater;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.baseapp.CostSheetList;
import com.example.baseapp.KeyValueList;
import com.example.baseapp.R;

import java.net.IDN;
import java.util.ArrayList;
import java.util.List;

public class SpinnerAdapter extends ArrayAdapter<KeyValueList> {

    public SpinnerAdapter(Context context, ArrayList<KeyValueList> list) {
        super(context, 0, list);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return initView(position, convertView, parent);
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return initView(position, convertView, parent);
    }

    private View initView(int position, View convertView, ViewGroup parent) {
        // Inflate the view only if it's null to optimize performance
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_spinner, parent, false);
        }

        // Find TextView and set the item name
        TextView textViewId = convertView.findViewById(R.id.txt_branch_id);
        TextView textViewName = convertView.findViewById(R.id.txt_branch_name);
        KeyValueList currentItem = getItem(position);

        if (currentItem != null) {
            textViewId.setText(currentItem.getKey());
            textViewName.setText(currentItem.getValue());
        }

        return convertView;
    }
}

