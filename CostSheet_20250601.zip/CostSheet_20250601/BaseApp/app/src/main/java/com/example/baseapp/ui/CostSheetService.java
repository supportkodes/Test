package com.example.baseapp.ui;

import com.example.baseapp.CostSheetList;
import com.example.baseapp.KeyValueList;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface CostSheetService {

    @GET("Values/GetBranches")
    Call<ArrayList<KeyValueList>> GetBranches();

    @GET("Values/GetBudgetCostSheet")
    Call<ArrayList<CostSheetList>> GetBudgetCostSheet(@Query("usdRate") int usdRate);

    @GET("Values/GetBudgetCostSheetAcid")
    Call<ArrayList<CostSheetList>> GetBudgetCostSheetAcid(@Query("usdRate") int usdRate);

    @GET("Values/GetBudgetCostSheetRock")
    Call<ArrayList<CostSheetList>> GetBudgetCostSheetRock(@Query("usdRate") int usdRate);

    @GET("Values/GetRockComponents")
    Call<ArrayList<KeyValueList>> GetRockComponents();


    @GET("Values/GetAcidComponents")
    Call<ArrayList<KeyValueList>> GetAcidComponents();
}
