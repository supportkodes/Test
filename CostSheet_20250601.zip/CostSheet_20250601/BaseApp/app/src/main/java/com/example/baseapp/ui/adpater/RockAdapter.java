package com.example.baseapp.ui.adpater;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.baseapp.CostSheetList;
import com.example.baseapp.KeyValueList;
import com.example.baseapp.R;
import com.example.baseapp.ui.CostSheetService;
import com.example.baseapp.ui.RetrofitInstance;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RockAdapter extends RecyclerView.Adapter<RockAdapter.ItemHolderView> {

    private List<CostSheetList> costSheetList;
    private LayoutInflater mInflater;
    private Context context;
    private RecyclerView costsheet_rcw;
    private Spinner spn_branch;
    private ArrayList<KeyValueList> branchkeyValueList;
    private SpinnerAdapter spinnerAdapter;

    public RockAdapter(Context context, List<CostSheetList> costSheetList,
                       RecyclerView costsheet_rcw,ArrayList<KeyValueList> branchkeyValueList) {
        this.costSheetList = costSheetList;
        this.mInflater = LayoutInflater.from(context);
        this.context = context;
        this.costsheet_rcw = costsheet_rcw;
        this.branchkeyValueList = branchkeyValueList;
    }

    @NonNull
    @Override
    public ItemHolderView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.item_rock, parent, false);
        return new ItemHolderView(view);
    }

    @Override
    public void onBindViewHolder(final ItemHolderView holder, @SuppressLint("RecyclerView") final int position) {
        holder.description_id_tv.setText(costSheetList.get(position).getSECTIONID());
        holder.description_name_tv.setText(costSheetList.get(position).getSUBSECTION());

        try
        {
            spinnerAdapter = new SpinnerAdapter(mInflater.getContext(), branchkeyValueList);
            holder.component_spinner.setAdapter(spinnerAdapter);
        }
        catch (Exception ex){}
        //String subsection = costSheetList.get(position).getSUBSECTION();
        //holder.component_spinner.setSelection(1);


        String amount = costSheetList.get(position).getAMOUNT();
        if (amount != null || amount != "null") {
            amount = "";
        }

        holder.amount_tv.setText(amount);

        holder.amount_tv.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    Calculate(holder,position);
                }

            }
        });
    }

    @Override
    public int getItemCount() {
        if(costSheetList==null) return 0;
        return costSheetList.size();
    }

    public  void  Calculate(ItemHolderView holder, int position){
        try {
            String valueEntered = TextUtils.isEmpty(holder.amount_tv.getText().toString()) ? "0" : holder.amount_tv.getText().toString();
            holder.amount_tv.setText(valueEntered);
            costSheetList.get(position).setAMOUNT(valueEntered);

            double amount_d = 0;
            int basicRatePosition = GetSubsectionPosition("Basic Rate");
            int usdConversionPosition = GetSubsectionPosition("USD $ (conversion)");
            int basicPriceINRPosition = GetSubsectionPosition("Basic PRICE in INR");
            int customCFANDPORTCHARGESLCCHARGESPosition = GetSubsectionPosition("CUSTOM, C&F AND PORT CHARGES, LC CHARGES");
            int transportRoadAvgPosition = GetSubsectionPosition("TRANSPORT-ROAD (avg).");
            int unloadingTRUCKDALASHIFTINGPosition = GetSubsectionPosition("UNLOADING/TRUCK DALA/SHIFTING");
            int moistureSHORTAGESPosition = GetSubsectionPosition("MOISTURE/SHORTAGES (2.00%)");
            int rockLandedCostPosition = GetSubsectionPosition("Rock Landed cost ");
            int rockConvertionNormstoSSPPosition = GetSubsectionPosition("Rock Convertion norms to SSP");
            int rockcostPMTPosition = GetSubsectionPosition("Rock cost PMT");

            Double basicRate = TextUtils.isEmpty(costSheetList.get(basicRatePosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(basicRatePosition).getAMOUNT());
            Double usdConversion = TextUtils.isEmpty(costSheetList.get(usdConversionPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(usdConversionPosition).getAMOUNT());
            Double basicPriceINR = TextUtils.isEmpty(costSheetList.get(basicPriceINRPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(basicPriceINRPosition).getAMOUNT());
            Double customCFANDPORTCHARGESLCCHARGES = TextUtils.isEmpty(costSheetList.get(customCFANDPORTCHARGESLCCHARGESPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(customCFANDPORTCHARGESLCCHARGESPosition).getAMOUNT());
            Double transportRoadAvg = TextUtils.isEmpty(costSheetList.get(transportRoadAvgPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(transportRoadAvgPosition).getAMOUNT());
            Double unloadingTRUCKDALASHIFTING = TextUtils.isEmpty(costSheetList.get(unloadingTRUCKDALASHIFTINGPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(unloadingTRUCKDALASHIFTINGPosition).getAMOUNT());
            Double moistureSHORTAGES = TextUtils.isEmpty(costSheetList.get(moistureSHORTAGESPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(moistureSHORTAGESPosition).getAMOUNT());
            Double rockLandedCost = TextUtils.isEmpty(costSheetList.get(rockLandedCostPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(rockLandedCostPosition).getAMOUNT());
            Double rockConvertionNormstoSSP = TextUtils.isEmpty(costSheetList.get(rockConvertionNormstoSSPPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(rockConvertionNormstoSSPPosition).getAMOUNT());
            Double rockcostPMT = TextUtils.isEmpty(costSheetList.get(rockcostPMTPosition).getAMOUNT()) ? 0 : Double.parseDouble(costSheetList.get(rockcostPMTPosition).getAMOUNT());

            basicPriceINR = basicRate * usdConversion;
            moistureSHORTAGES = (basicPriceINR+ customCFANDPORTCHARGESLCCHARGES+transportRoadAvg) * 0.02;
            rockLandedCost = basicPriceINR+ customCFANDPORTCHARGESLCCHARGES+transportRoadAvg+ unloadingTRUCKDALASHIFTING+moistureSHORTAGES;
            rockcostPMT = rockLandedCost * rockConvertionNormstoSSP;
            String formatted = "";
            try {
                RecyclerView.ViewHolder viewHolder = costsheet_rcw.findViewHolderForAdapterPosition(basicPriceINRPosition);
                RockAdapter.ItemHolderView myViewHolder = (RockAdapter.ItemHolderView) viewHolder;
                formatted = String.format("%.2f", basicPriceINR);
                myViewHolder.amount_tv.setText(formatted);
            }catch(Exception ex)  {}

            try {
                RecyclerView.ViewHolder viewHolder = costsheet_rcw.findViewHolderForAdapterPosition(moistureSHORTAGESPosition);
                RockAdapter.ItemHolderView myViewHolder = (RockAdapter.ItemHolderView) viewHolder;
                formatted = String.format("%.2f", moistureSHORTAGES);
                myViewHolder.amount_tv.setText(formatted);
            }catch(Exception ex)  {}

            try {
                RecyclerView.ViewHolder viewHolder = costsheet_rcw.findViewHolderForAdapterPosition(rockLandedCostPosition);
                RockAdapter.ItemHolderView myViewHolder = (RockAdapter.ItemHolderView) viewHolder;
                formatted = String.format("%.2f", rockLandedCost);
                myViewHolder.amount_tv.setText(formatted);
            }catch(Exception ex)  {}

            try {
                RecyclerView.ViewHolder viewHolder = costsheet_rcw.findViewHolderForAdapterPosition(rockcostPMTPosition);
                RockAdapter.ItemHolderView myViewHolder = (RockAdapter.ItemHolderView) viewHolder;
                formatted = String.format("%.2f", rockcostPMT);
                myViewHolder.amount_tv.setText(formatted);
            }catch(Exception ex)  {}

            costSheetList.get(basicPriceINRPosition).setAMOUNT(basicPriceINR.toString());
            costSheetList.get(moistureSHORTAGESPosition).setAMOUNT(moistureSHORTAGES.toString());
            costSheetList.get(rockLandedCostPosition).setAMOUNT(rockLandedCost.toString());
            costSheetList.get(rockcostPMTPosition).setAMOUNT(rockcostPMT.toString());
        }
        catch(Exception ex)
        {
            String errorMessage= ex.getMessage();
        }
    }


    public int GetSubsectionPosition(String subsectionName)
    {
        int position = -1;
        for(int i=0;i<costSheetList.size();i++) {
            if (costSheetList.get(i).getSUBSECTION().trim().equalsIgnoreCase(subsectionName.trim())) {
                position = i;
                break;
            }
        }
        return position;
    }

    public class ItemHolderView extends RecyclerView.ViewHolder {
        public EditText amount_tv, component_et;
        public TextView description_id_tv, description_name_tv;
        public  Spinner component_spinner;
        public ItemHolderView(View view) {
            super(view);
            description_id_tv = (TextView) view.findViewById(R.id.description_id_tv);
            description_name_tv = (TextView) view.findViewById(R.id.description_tv);
            amount_tv = (EditText) view.findViewById(R.id.amount_tv);
            //component_et = (EditText) view.findViewById(R.id.component_et);
            component_spinner =(Spinner) view.findViewById(R.id.spn_branch);
        }
    }
 
}