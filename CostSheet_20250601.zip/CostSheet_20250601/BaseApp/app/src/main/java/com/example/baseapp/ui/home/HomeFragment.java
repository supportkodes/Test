package com.example.baseapp.ui.home;

import static com.example.baseapp.NetworkDetails.isNetworkAvailable;

import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.baseapp.CostSheetList;
import com.example.baseapp.IdNameList;
import com.example.baseapp.KeyValueList;
import com.example.baseapp.KeyValueList;
import com.example.baseapp.R;
import com.example.baseapp.databinding.FragmentHomeBinding;
import com.example.baseapp.ui.CostSheetService;
import com.example.baseapp.ui.RetrofitInstance;
import com.example.baseapp.ui.adpater.CostSheetAdapter;
import com.example.baseapp.ui.adpater.CostSheetListAdapter;
import com.example.baseapp.ui.adpater.SpinnerAdapter;
import com.example.baseapp.ui.models.CostSheetModel;

import java.util.ArrayList;
import java.util.Calendar;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding binding;
    private TableLayout tbl_costsheet;
    private RecyclerView costsheet_rcw;
    private ListView costsheet_lst;
    private Spinner spn_branch;
    private EditText et_Date;
    private EditText et_production_level ;

    private CostSheetAdapter costSheetAdapter;
    private CostSheetListAdapter costSheetListAdapter;
    private SpinnerAdapter spinnerAdapter;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_home, container, false);
        et_Date = (EditText) root.findViewById(R.id.et_Date);
        et_production_level  = (EditText) root.findViewById(R.id.et_production_level);
        costsheet_rcw = (RecyclerView) root.findViewById(R.id.costsheet_rcw);
//        costsheet_lst = (ListView) root.findViewById(R.id.costsheet_lst);
        spn_branch = (Spinner) root.findViewById(R.id.spn_branch);

        if (isNetworkAvailable(getActivity())) {
            CallService_BranchList();
            CallService_BudgetCostSheetList(10);
        } else {
            Toast.makeText(getActivity(), getString(R.string.no_working_internet_msg), Toast.LENGTH_LONG).show();
        }

        //costsheet_rcw.post(new Runnable() {
         //   @Override
                    //public void run() {
                //costSheetAdapter.notifyDataSetChanged();
                //    }
        //});

        et_Date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // on below line we are getting
                // the instance of our calendar.
                final Calendar c = Calendar.getInstance();

                // on below line we are getting
                // our day, month and year.
                int year = c.get(Calendar.YEAR);
                int month = c.get(Calendar.MONTH);
                int day = c.get(Calendar.DAY_OF_MONTH);

                // on below line we are creating a variable for date picker dialog.
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        // on below line we are passing context.
                        getContext(), new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        // on below line we are setting date to our edit text.
                        et_Date.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                    }
                },
                        // on below line we are passing year,
                        // month and day for selected date in our date picker.
                        year, month, day);
                // at last we are calling show to
                // display our date picker dialog.
                datePickerDialog.show();
            }
        });

        et_production_level.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    String _unit_str = TextUtils.isEmpty(et_production_level.getText().toString()) ? "0" : et_production_level.getText().toString();
                    SharedPreferences.Editor editor = getActivity().getSharedPreferences("CostSheet", 0).edit();
                    editor.putString("prodlevel", _unit_str);
                    editor.apply();
                    //Toast.makeText(getActivity(), _unit_str, Toast.LENGTH_LONG).show();
                }
            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void GenerateBranchList(ArrayList<KeyValueList> keyValueLists) {
        spinnerAdapter = new SpinnerAdapter(getActivity(), keyValueLists);
        spn_branch.setAdapter(spinnerAdapter);
    }

    private void GenerateCostSheetList(ArrayList<CostSheetList> costSheetList) {
        String productionLevel = TextUtils.isEmpty(et_production_level.getText().toString()) ? "0" : et_production_level.getText().toString();

        costSheetAdapter = new CostSheetAdapter(getActivity(), costSheetList,costsheet_rcw);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);
        costsheet_rcw.setLayoutManager(layoutManager);
        costsheet_rcw.setAdapter(costSheetAdapter);
        costsheet_rcw.setItemViewCacheSize(costSheetList.size());
//        costsheet_rcw.scrollToPosition(costSheetList.size() - 1);
//        costsheet_rcw.post(() -> {
//            costsheet_rcw.scrollToPosition(0);
//        });
//        costSheetListAdapter = new CostSheetListAdapter(getActivity(), costSheetList);
//        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity());
//        costsheet_lst.setAdapter(costSheetListAdapter);

    }

    private void CallService_BranchList() {
        CostSheetService service = RetrofitInstance.getRetrofitInstance().create(CostSheetService.class);
        Call<ArrayList<KeyValueList>> call = service.GetBranches();
        call.enqueue(new Callback<ArrayList<KeyValueList>>() {
            @Override
            public void onResponse(Call<ArrayList<KeyValueList>> call, Response<ArrayList<KeyValueList>> response) {
                if (response.body() != null) {
                    ArrayList<KeyValueList> keyValueList = response.body();
//                    if (listVM.size() > 0) {
//                        for (KeyValueList item : keyValueList) {
//                            String s = item.getKey().toString();
//                            Toast.makeText(getActivity(), s, Toast.LENGTH_LONG).show();
//                        }
//                    }
                    GenerateBranchList(keyValueList);
                }
            }

            @Override
            public void onFailure(Call<ArrayList<KeyValueList>> call, Throwable t) {
                Toast.makeText(getActivity(), "Something went wrong. Please try later.", Toast.LENGTH_LONG).show();
            }
        });
    }

    private void CallService_BudgetCostSheetList(int usdRate) {
        CostSheetService service = RetrofitInstance.getRetrofitInstance().create(CostSheetService.class);
        Call<ArrayList<CostSheetList>> call = service.GetBudgetCostSheet(usdRate);
        call.enqueue(new Callback<ArrayList<CostSheetList>>() {
            @Override
            public void onResponse(Call<ArrayList<CostSheetList>> call, Response<ArrayList<CostSheetList>> response) {
                if (response.body() != null) {
                    ArrayList<CostSheetList> costSheetList = response.body();
//                    if (listVM.size() > 0) {
//                        for (CostSheetList item : costSheetList) {
//                            String s = item.getSECTION().toString();
//                            Toast.makeText(getActivity(), s, Toast.LENGTH_LONG).show();
//                        }
//                    }
                    GenerateCostSheetList(costSheetList);
                }
            }

            @Override
            public void onFailure(Call<ArrayList<CostSheetList>> call, Throwable t) {
                Toast.makeText(getActivity(), "Something went wrong. Please try later.", Toast.LENGTH_LONG).show();
            }
        });
    }



}