﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using WebDAL.Helper;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Logging;
using System.Net.Http;
using System.Net;
using CrystalDecisions.CrystalReports.Engine;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml.EMMA;
using System.Reflection;
using DocumentFormat.OpenXml.Wordprocessing;
using CrystalDecisions.ReportAppServer.Prompting;

namespace WebApp.Controllers
{
	public class SalesOrderController : Controller
	{
		public readonly ISalesOrderRepository _ISalesOrderRepository = null;
		public readonly ICommonRepository _ICommonRepository = null;
		public readonly IBOMRepository _IBOMRepository = null;
		private IHostingEnvironment _IHostingEnvironment;
		private readonly ILogger<SalesOrderController> _ILogger;
		public SalesOrderController(ISalesOrderRepository iSalesOrderRepository,
			ICommonRepository iCommonRepository, IBOMRepository iBOMRepository, IHostingEnvironment iHostingEnvironment
			, ILogger<SalesOrderController> iLogger
			)
		{
			_ISalesOrderRepository = iSalesOrderRepository;
			_IBOMRepository = iBOMRepository;
			_ICommonRepository = iCommonRepository;
			_IHostingEnvironment = iHostingEnvironment;
			_ILogger = iLogger;
		}
		[Authorize]
		[HttpGet]
		public IActionResult Index()
		{
			return View();
		}
		[HttpGet]
		public IActionResult GetAllSalesOrderData(string type)
		{
			var userId = HttpContext.User.Identity.Name;
			List<DocumentIndexModel> data = _ISalesOrderRepository.GetAll(userId, type);
			for (int i = 0; i < data.Count; i++)
			{
				data[i].EditLink = Url.Action("Edit", "SalesOrder", new { docEntry = data[i].DocEntry, type = type.ToUpper() });
			}
			return Json(new { aaData = data });
		}
		[Authorize]
		[HttpGet]
		public IActionResult Add(string? baseEntry, string lineNo)
		{
			try
			{
				var userId = HttpContext.User.Identity.Name;
				string ownerId = _ICommonRepository.GetEmpId(userId);
				DocumentModel salesOrderModel = new DocumentModel();
				salesOrderModel.SalesPersonCode = "-1";

				salesOrderModel.DocDate = DateTime.Now.ToString("dd-MM-yyyy");
				salesOrderModel.DocDueDate = DateTime.Now.ToString("dd-MM-yyyy");
				salesOrderModel.TaxDate = DateTime.Now.ToString("dd-MM-yyyy");

				salesOrderModel.NetAmount = 0;
				salesOrderModel.DiscountPercent = 0;
				salesOrderModel.RoundingDiffAmount = 0;
				salesOrderModel.DocumentTotal = 0;
				salesOrderModel.DocRate = "1";
				salesOrderModel.DocCurrency = "INR";
				salesOrderModel.DocumentsOwner = ownerId;

				DocumentRowsModel salesOrderRowsModel = new DocumentRowsModel();

				if (!string.IsNullOrEmpty(baseEntry))
				{
					salesOrderModel = _ICommonRepository.GetClientPOSOData(baseEntry, lineNo);
					salesOrderModel.DiscountPercent = 0;
					salesOrderModel.DocDate = DateTime.Now.ToString("dd-MM-yyyy");
					salesOrderModel.DocDueDate = DateTime.Now.ToString("dd-MM-yyyy");
					salesOrderModel.DocumentsOwner = ownerId;
				}

				if (salesOrderModel.DocumentLines == null)
				{
					#region Item Rows
					List<DocumentRowsModel> salesOrderRowsModelList = new List<DocumentRowsModel>();
					for (int i = 1; i <= 1; i++)
					{
						salesOrderRowsModel.Index = i;
						salesOrderRowsModel.ItemCode = "";
						salesOrderRowsModelList.Add(salesOrderRowsModel);
					}
					salesOrderModel.DocumentLines = salesOrderRowsModelList;
					#endregion
				}
				try
				{
					if (salesOrderModel.Attachments2_Lines == null || salesOrderModel.Attachments2_Lines.Count == 0)
					{
						#region Attachment Rows
						List<DocumentModel_Attachment> documentModel_AttachmentList = new List<DocumentModel_Attachment>();
						DocumentModel_Attachment documentModel_Attachment = new DocumentModel_Attachment();
						documentModel_Attachment.Index = 1;
						//documentModel_Attachment.Line = "1";
						documentModel_AttachmentList.Add(documentModel_Attachment);
						salesOrderModel.Attachments2_Lines = documentModel_AttachmentList;
						#endregion
					}
				}
				catch { }

				#region Expense Rows
				List<DocumentModel_Expenses> documentModel_ExpensesList = new List<DocumentModel_Expenses>();
				List<ExpenseModel> expenseModelsList = _ICommonRepository.GetAllExpenses();
				for (int i = 0; i < expenseModelsList.Count; i++)
				{
					DocumentModel_Expenses documentModel_Expenses = new DocumentModel_Expenses();
					documentModel_Expenses.Index = i + 1;
					documentModel_Expenses.ExpenseCode = expenseModelsList[i].ExpnsCode;
					documentModel_Expenses.ExpenseName = expenseModelsList[i].ExpnsName;
					documentModel_ExpensesList.Add(documentModel_Expenses);
				}
				salesOrderModel.DocumentAdditionalExpenses = documentModel_ExpensesList;
				#endregion

				ViewBag.CurrencyList = GetCurrencyList();
				ViewBag.BranchList = GetBranchList();
				ViewBag.ShippingTypeList = GetShippingTypeList();
				ViewBag.EmployeeList = GetEmployeeList();
				ViewBag.HSNList = GetHSNList();
				ViewBag.SalesEmployeeList = GetSalesEmployeeList(userId);
				ViewBag.CategoryList = GetCategoryList();
				ViewBag.WarehouseList = GetWarehouseList();
				return View(salesOrderModel);
			}
			catch (Exception ex)
			{
				return null;
			}
		}
		[HttpPost]
		[DisableRequestSizeLimit]
		//[RequestFormLimits(ValueLengthLimit = int.MaxValue, MultipartBodyLengthLimit = int.MaxValue)] //the fix
		public IActionResult Add(DocumentModel model)
		{
			try
			{
				var userId = HttpContext.User.Identity.Name;
				model.UserId = userId;
				ResponseModel responseModel = new ResponseModel();
				try
				{
					responseModel = Validate(model);
					if (responseModel.ResponseStatus == true)
					{
						string originator = _ICommonRepository.GetUserId(userId);
						model.U_CRBY = originator;
						responseModel = _ISalesOrderRepository.Add(model);
						if (responseModel.ResponseStatus == true)
						{
							string seriesremark = _ICommonRepository.GetSeriesRemark(model.Series);
							string slpcode = _ICommonRepository.GetSlpCodeFromEmailAddress(model.UserId);
							if (slpcode == model.SalesPersonCode)
							{

							}
							else
							{
								model.DocEntry = responseModel.ResponseEntry;
								SendMail(model);
							}
							TempData["Success"] = "1";
							TempData["Message"] = responseModel.ResponseText;
							return RedirectToAction("Index", "SalesOrder");
						}
					}
					ViewData["Error"] = "1";
					ViewData["Message"] = responseModel.ResponseText;
				}
				catch (Exception ex)
				{
					ViewData["Error"] = "1";
					ViewData["Message"] = ex.Message;
				}
				ViewBag.CurrencyList = GetCurrencyList();
				ViewBag.BranchList = GetBranchList();
				ViewBag.ShippingTypeList = GetShippingTypeList();
				ViewBag.EmployeeList = GetEmployeeList();
				ViewBag.SalesEmployeeList = GetSalesEmployeeList(userId);
				ViewBag.CategoryList = GetCategoryList();
				ViewBag.WarehouseList = GetWarehouseList();
			}
			catch (Exception ex)
			{
				return null;
			}
			return View(model);
		}

		[Authorize]
		[HttpGet]
		public IActionResult Edit(string docEntry, string type)
		{
			var userId = HttpContext.User.Identity.Name;
			DocumentModel data = _ISalesOrderRepository.Get(docEntry, userId, type);
			data.Type = type.ToUpper();
			ViewBag.CurrencyList = GetCurrencyList();
			ViewBag.BranchList = GetBranchList();
			ViewBag.ShippingTypeList = GetShippingTypeList();
			ViewBag.EmployeeList = GetEmployeeList();
			ViewBag.HSNList = GetHSNList();
			ViewBag.SalesEmployeeList = GetSalesEmployeeList(userId);
			ViewBag.YNList = GetYNList();
			ViewBag.CategoryList = GetCategoryList();
			ViewBag.WarehouseList = GetWarehouseList();

			return View(data);
		}
		[DisableRequestSizeLimit]
		[HttpPost]
		public IActionResult Edit(DocumentModel model)
		{
			var updateButtonAttribute = Request.Form["Update"];
			string buttonValue = string.Empty;
			if (updateButtonAttribute.Count > 0)
			{
				buttonValue = updateButtonAttribute[0];
			}
			else
			{
				buttonValue = "UpdateExcludeItems";
			}
			model.ButtonValue = buttonValue;
			var userId = HttpContext.User.Identity.Name;
			model.UserId = userId;
			ResponseModel responseModel = new ResponseModel();
			try
			{
				responseModel = _ISalesOrderRepository.Update(model);
			}
			catch (Exception ex)
			{
				responseModel.ResponseStatus = false;
				responseModel.ResponseText = ex.Message;
			}
			if (responseModel.ResponseStatus == true)
			{
				TempData["Success"] = "1";
				TempData["Message"] = responseModel.ResponseText;
				return RedirectToAction("Index", "SalesOrder");
			}
			else
			{
				ViewData["Error"] = "1";
				ViewData["Message"] = responseModel.ResponseText + ".";

				ViewBag.CurrencyList = GetCurrencyList();
				ViewBag.BranchList = GetBranchList();
				ViewBag.ShippingTypeList = GetShippingTypeList();
				ViewBag.EmployeeList = GetEmployeeList();
				ViewBag.HSNList = GetHSNList();
				ViewBag.CategoryList = GetCategoryList();
				ViewBag.SalesEmployeeList = GetSalesEmployeeList(userId);
				ViewBag.YNList = GetYNList();
				ViewBag.WarehouseList = GetWarehouseList();
				return View(model);
			}
		}
		[HttpPost]
		public ActionResult SalesOrderAddRow(int index)
		{
			index = index - 1;
			var newRow = new DocumentRowsModel() { Index = index + 1 };
			ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("DocumentLines[{0}]", index);
			ViewBag.CategoryList = GetCategoryList();
			ViewBag.WarehouseList = GetWarehouseList();
			return PartialView("~/Views/Shared/EditorTemplates/DocumentRowsModel.cshtml", newRow);
		}
		[HttpPost]
		public ActionResult AttachmentAddRow(int index)
		{
			index = index - 1;
			var newRow = new DocumentModel_Attachment() { Index = index + 1 };
			ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("Attachments2_Lines[{0}]", index);
			return PartialView("~/Views/Shared/EditorTemplates/DocumentModel_Attachment.cshtml", newRow);
		}
		private ResponseModel Validate(DocumentModel model)
		{
			ResponseModel responseModel = new ResponseModel();
			responseModel.ResponseStatus = true;
			try
			{
				if (string.IsNullOrEmpty(model.CardCode))
				{
					responseModel.ResponseText = "Please select business partner";
					responseModel.ResponseStatus = false;
					return responseModel;
				}
				else if (string.IsNullOrEmpty(model.WarehouseCode))
				{
					responseModel.ResponseText = "Please select warehouse";
					responseModel.ResponseStatus = false;
					return responseModel;
				}


				#region Address Extension
				AddressModel shipToAddressModel = _ICommonRepository.GetBPAddressDetails(model.CardCode, "S", model.ShipToCode);
				if (shipToAddressModel == null)
				{
					responseModel.ResponseText = "Ship to details are missing";
					responseModel.ResponseStatus = false;
					return responseModel;
				}
				AddressModel billToAddressModel = _ICommonRepository.GetBPAddressDetails(model.CardCode, "B", model.PayToCode);
				if (billToAddressModel == null)
				{
					responseModel.ResponseText = "bill to details are missing";
					responseModel.ResponseStatus = false;
					return responseModel;
				}
				#endregion

				string isIGST = _ICommonRepository.GetAddressIGST(model.CardCode, model.ShipToCode);
				bool isLocal = false;
				if (isIGST.ToLower() == "no" && model.boolImpORExp == false)
				{
					isLocal = true;
				}
				model.DocumentLines = model.DocumentLines.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
				//string docType = model.DocType;
				bool isCopyFromClientPO = false;
				for (int i = 0; i < model.DocumentLines.Count; i++)
				{
					try
					{

						string taxcode = model.DocumentLines[i].TaxCode;
						if (isLocal == true)
						{
							if (taxcode.Contains("IGST"))
							{
								responseModel.ResponseText = "Please select CGST/SGST Tax";
								responseModel.ResponseStatus = false;
								return responseModel;
							}
						}
						else
						{
							if (taxcode.Contains("CGST"))
							{
								responseModel.ResponseText = "Please select IGST Tax";
								responseModel.ResponseStatus = false;
								return responseModel;
							}
						}

						string itemcode = model.DocumentLines[i].ItemCode;
						string treeType = model.DocumentLines[i].TreeType;
						if (treeType == "Sales")
						{
							ValidateModel data = _ISalesOrderRepository.GetSOItemDetails(itemcode);
							string querygrp = data.QryGrp;
							string flexo = data.Flexo;
							string bomtype = data.BOMType;
							string itemgrpname = data.GroupName;
							if (querygrp == "Y" && flexo == "Flexo Yes" && bomtype == "S" && itemgrpname.ToUpper() == "FG - LABELS")
							{
								if (string.IsNullOrEmpty(model.DocumentLines[i].U_UnwDrctn) || string.IsNullOrEmpty(model.DocumentLines[i].U_Packng))
								{
									responseModel.ResponseText = "Unwinding Direction and Labels per Roll both the fields should not be blank or zero for the FLEXO ITEM: " + itemcode;
									responseModel.ResponseStatus = false;
								}
							}
						}
						if (string.IsNullOrEmpty(model.DocumentLines[i].ItemCode))
						{
							responseModel.ResponseText = "Please Check Item Code";
							responseModel.ResponseStatus = false;
						}

						//double unitprice = model.DocumentLines[i].UnitPrice.Value;
						string unitprice = (model.DocumentLines[i].UnitPrice.ToString());
						string SeriesName = model.SeriesName;

						string exp1 = model.DocumentLines[i].U_Exp1;
						if (!string.IsNullOrEmpty(exp1))
						{
							isCopyFromClientPO = true;
						}
						//if (unitprice == 0 &&
						//if (string.IsNullOrEmpty(unitprice) &&
						//(SeriesName == "ARSO24" || SeriesName == "JRSO24" || SeriesName == "TGSO24" || SeriesName == "ARFXR24"))
						//{
						//	responseMessage = "Please check Unit Price ";
						//	return false;
						//}
					}
					catch (Exception ex)
					{

					}
				}

				//Ashwini Validation 
				/*
                string seriesremark = _ICommonRepository.GetSeriesRemark(model.Series);
                if (!(seriesremark.ToUpper().Contains("INTERNAL") || model.CardName.ToUpper().Contains("AJANTA PRINT ARTS")
                 || seriesremark.ToUpper().Contains("PROOFING")))
                {
                    if (isCopyFromClientPO == false)
                    {
                        responseModel.ResponseText = "You can't create direct SO";
                        responseModel.ResponseStatus = false;
                    }
                }*/
			}
			catch (Exception ex)
			{

			}
			return responseModel;
		}
		[HttpGet]
		public JsonResult PaymentAdviceValidation(string cardcode, string slpcode)
		{
			// Pravin 01-12-24
			var userId = HttpContext.User.Identity.Name;
			string loginSlpcode = _ICommonRepository.GetSlpCodeFromEmailAddress(userId);
			ResponseModel responseModel = new ResponseModel();
			responseModel.ResponseStatus = true;
			if (slpcode == loginSlpcode)
			{
				responseModel = _ISalesOrderRepository.GetPendingInvoiceData(cardcode);
				if (responseModel.ResponseStatus == true)
				{
					responseModel = _ISalesOrderRepository.GetPendingAdviceData(cardcode);
				}
			}
			return Json(responseModel);
		}
		[HttpPost]
		public string UploadItemData(IFormFile postedFile)
		{
			if (postedFile != null)
			{
				string path = Path.Combine(_IHostingEnvironment.WebRootPath, "Uploads");
				if (!Directory.Exists(path))
				{
					Directory.CreateDirectory(path);
				}
				string fileName = Path.GetFileName(postedFile.FileName);
				string filePath = Path.Combine(path, fileName);
				using (FileStream stream = new FileStream(filePath, FileMode.Create))
				{
					postedFile.CopyTo(stream);
				}
				DataTable dt = new DataTable();
				using (XLWorkbook workBook = new XLWorkbook(filePath))
				{
					IXLWorksheet workSheet = workBook.Worksheet(1);
					bool firstRow = true;
					foreach (IXLRow row in workSheet.Rows())
					{
						if (firstRow)
						{
							foreach (IXLCell cell in row.Cells())
							{

								dt.Columns.Add(cell.Value.ToString());
							}
							firstRow = false;
						}
						else
						{
							dt.Rows.Add();
							int i = 0;
							foreach (IXLCell cell in row.Cells())
							{
								try
								{

									dt.Rows[dt.Rows.Count - 1][i] = cell.Value.ToString();
								}
								catch { }
								i++;
							}
						}
					}
				}
				ViewBag.Data = dt;
				dt = dt.Rows
				.Cast<DataRow>()
				.Where(row => !row.ItemArray.All(field => field is DBNull ||
												 string.IsNullOrWhiteSpace(field as string)))
				.CopyToDataTable();
				System.IO.File.Delete(filePath);
				dt.Columns.Add("HSNName", typeof(String));
				dt.Columns.Add("HSNEntry", typeof(String));
				dt.Columns.Add("TaxPercent", typeof(String));

				for (int i = 0; i < dt.Rows.Count; i++)
				{
					string itemcode = dt.Rows[i]["ItemCode"].ToString();
					string taxcode = dt.Rows[i]["TaxCode"].ToString();
					HSNModel hSNModel = _ICommonRepository.GetHSNDetails(itemcode);
					if (hSNModel != null)
					{
						dt.Rows[i]["HSNName"] = hSNModel.ChapterID;
						dt.Rows[i]["HSNEntry"] = hSNModel.Chapter;
					}
					string taxRate = _ICommonRepository.GetTaxRate(taxcode);
					dt.Rows[i]["TaxPercent"] = taxRate;
				}
				//return Json(new { aaData = dt });
				//int index = 5;
				//var newRow = new SalesOrderRowsModel() { Index = index + 1 };
				//ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("salesOrderRowsModels[{0}]", index);
				//return PartialView("~/Views/Shared/EditorTemplates/SalesOrderRowsModel.cshtml", newRow);
				var jsonData = JsonConvert.SerializeObject(dt);
				return jsonData;
			}
			else
			{
				return null;
			}
			//return JsonConvert.SerializeObject(new { result = jsonData });
		}
		[HttpPost]
		public JsonResult UpdateSalesOrderStatus(string docEntry, string status)
		{
			ResponseModel responseModel = new ResponseModel();
			try
			{
				string cardcode = "";
				responseModel.ResponseStatus = true;
				var userId = HttpContext.User.Identity.Name;
				if (status == "Y")
				{
					var designation = _ICommonRepository.GetEmployeePosition(userId);
					if (designation != "HEAD")
					{
						cardcode = _ISalesOrderRepository.GetDraftCardCode(docEntry);
						responseModel = _ISalesOrderRepository.GetPendingInvoiceData(cardcode);
						if (responseModel.ResponseStatus == true)
						{
							responseModel = _ISalesOrderRepository.GetPendingAdviceData(cardcode);
						}
						else
						{
							if (userId.Contains("vikas@") || userId.Contains("vivek@") || userId.Contains("manoj@"))
							{
								responseModel.ResponseStatus = true;
							}
						}
					}
				}
				if (responseModel.ResponseStatus == true)
				{
					userId = _ICommonRepository.GetUserId(userId);
					responseModel = _ISalesOrderRepository.UpdateStatus(docEntry, status, userId, "");
				}
				return Json(new { value = responseModel });
			}
			catch (Exception ex)
			{
				_ILogger.LogError(ex, ex.Message);
			}
			responseModel.ResponseText = "Error occured while processing UpdateSalesOrderStatus ";
			responseModel.ResponseStatus = false;
			return Json(new { value = responseModel });
		}
		public JsonResult Close(string docEntry)
		{
			ResponseModel responseModel = new ResponseModel();
			responseModel = _ISalesOrderRepository.Close(docEntry);
			return Json(new { value = responseModel });
		}
		[HttpPost]
		public JsonResult Cancel(string docEntry)
		{
			ResponseModel responseModel = new ResponseModel();
			int podocentry = _ICommonRepository.GetProductionOrder(docEntry);
			if (podocentry == 0)
			{
				responseModel = _ISalesOrderRepository.Cancel(docEntry);
			}
			else
			{
				responseModel.ResponseText = "Production order create agains Sales order";
				responseModel.ResponseStatus = false;
			}
			return Json(new { value = responseModel });
		}
		[HttpPost]
		public JsonResult UpdateLineStatus(string docEntry)
		{
			ResponseModel responseModel = new ResponseModel();
			int linenum = 0;
			string[] docEntry_Split = docEntry.Split('_');
			docEntry = docEntry_Split[0];
			linenum = int.Parse(docEntry_Split[1]);
			string soToBeClosed = docEntry_Split[2];
			if (soToBeClosed == "Y")
			{
				int documentRowsCount = _ISalesOrderRepository.GetOpenDocumentRowCount(docEntry);
				if (documentRowsCount == 1)
				{
					responseModel = _ISalesOrderRepository.Close(docEntry);
				}
				else
				{
					responseModel = _ISalesOrderRepository.UpdateLineStatus(docEntry, linenum);
				}
			}
			else
			{
				responseModel.ResponseStatus = false;
				responseModel.ResponseText = "You can't close SO. As SO to be closed is No.";
			}
			return Json(new { value = responseModel });
		}
		[HttpGet]
		public JsonResult GetSalesQuotationOpenRows(string sqdocEntry)
		{
			DocumentModel documentModel = new DocumentModel();
			documentModel = _ISalesOrderRepository.GetSalesQuotationOpenRows(sqdocEntry);
			return Json(new { value = documentModel });
		}
		public ResponseModel UploadAttachment(IFormFile postedFile)
		{
			ResponseModel responseModel = new ResponseModel();
			try
			{
				if (postedFile != null)
				{
					string path = Path.Combine(_IHostingEnvironment.WebRootPath, "Uploads\\" + DateTime.Now.ToString("dd_MM_yyyy"));
					//string path = Path.Combine("D:\\Project\\LFC\\Web Portal\\Vissco Web Portal\\WebApp\\wwwroot\\", "Uploads");
					if (!Directory.Exists(path))
					{
						Directory.CreateDirectory(path);
					}
					string seed = DateTime.Now.ToString("dd_MM_yyyy_hh_mm_tt");   //+ Convert.ToString((int)DateTime.Now.Ticks);
					string fileName = Path.GetFileName(postedFile.FileName);
					fileName = System.IO.Path.GetFileNameWithoutExtension(fileName);
					System.IO.FileInfo fi = new System.IO.FileInfo(postedFile.FileName);
					string fileExtension = fi.Extension;
					fileName = fileName + "_" + seed + fileExtension; //+ "_" + fileName;
					string filePath = Path.Combine(path, fileName);
					using (FileStream stream = new FileStream(filePath, FileMode.Create))
					{
						postedFile.CopyTo(stream);
					}
					responseModel.ResponseStatus = true;
					responseModel.ResponseText = filePath;
					return responseModel;
				}
			}
			catch (Exception ex)
			{
				responseModel.ResponseStatus = false;
				responseModel.ResponseText = ex.Message;
			}
			return responseModel;
		}

		#region Select List
		[NonAction]
		private SelectList GetCurrencyList()
		{
			return new SelectList(_ICommonRepository.GetAllCurrency(), "CurrCode", "CurrName");
		}
		[NonAction]
		private SelectList GetBranchList()
		{
			return new SelectList(_ICommonRepository.GetAllBranch(), "BPLId", "BPLName");
		}
		[NonAction]
		private SelectList GetWarehouseList()
		{
			return new SelectList(_ICommonRepository.GetAllWarehouse(), "WhsCode", "WhsName");
		}
		[NonAction]
		private SelectList GetShippingTypeList()
		{
			return new SelectList(_ICommonRepository.GetAllShippingType(), "TrnspCode", "TrnspName");
		}
		[NonAction]
		private SelectList GetHSNList()
		{
			return new SelectList(_ICommonRepository.GetAllHSN(), "Chapter", "ChapterID");
		}
		[NonAction]
		private SelectList GetCategoryList()
		{
			return new SelectList(_ICommonRepository.GetUDFValuesList("RDR1", "Category"), "ID", "Name");
		}
		[NonAction]
		private SelectList GetYNList()
		{
			var selectLists = new SelectList(
					new List<SelectListItem>
					{
						new SelectListItem { Value = "Y", Text = "Yes"},
						new SelectListItem { Value= "N", Text = "No"},
					}, "Value", "Text");

			return selectLists;
		}
		[NonAction]
		private SelectList GetEmployeeList()
		{
			return new SelectList(_ICommonRepository.GetAllEmployee(), "empID", "Name");
		}
		[NonAction]
		private SelectList GetSalesEmployeeList(string userId)
		{
			return new SelectList(_ICommonRepository.GetAllTeamSalesEmployee(userId), "SlpCode", "SlpName");
		}
		private ResponseModel SendMail(DocumentModel documentModel)
		{
			ResponseModel responseModel = new ResponseModel();
			try
			{
				Helpers helpers = new Helpers();
				SendMail _sendMail = new SendMail();
				string message = "";
				string subject = "Web Portal - Authorize Sales Order of Customer " + documentModel.CardName;
				DataTable dt = new DataTable();
				dt = helpers.ToDataTable(documentModel.DocumentLines);
				try
				{
					dt.Columns.Remove("Index");
					dt.Columns.Remove("LineId");
					dt.Columns.Remove("InStockQuantity");
					dt.Columns.Remove("DeliveredQuantity");
					dt.Columns.Remove("OpenQuantity");
					dt.Columns.Remove("IsDeleted");
					dt.Columns.Remove("HSNEntry");
					dt.Columns.Remove("WarehouseCode");
					dt.Columns.Remove("TaxCode");
					dt.Columns.Remove("UnitPrice");
					dt.Columns.Remove("Total");
					dt.Columns.Remove("TaxRate");
					dt.Columns.Remove("SupplierCatNum");
					dt.Columns.Remove("ShipDate");
				}
				catch { }
				string tableBody = helpers.ConvertToHtml(dt);
				string url = ConfigManager.GetWebSiteURL() + "SalesOrder/Edit?docEntry=" + documentModel.DocEntry + "&type=draft";
				string draftNo = _ICommonRepository.GetDraftNo(documentModel.DocEntry);
				StringBuilder sbBody = new StringBuilder();
				//sbBody.Replace("{OTP}", otp);
				sbBody.Append("<p> Dear Sir/Madam <p/>");
				sbBody.Append("<p> Draft No:" + draftNo + "<p/>");
				sbBody.Append("<p> Billing Address:" + documentModel.Address + "<p/>");
				sbBody.Append("<p> Delivery Address:" + documentModel.Address2 + "<p/>");
				sbBody.Append("<p> Please see below document product details<p/>");
				sbBody.Append(tableBody);
				sbBody.Append("<p> Plese approve or reject document using below link <br/>");
				sbBody.Append(url + " <p/>");
				sbBody.Append("<p> Regards <br/>");
				sbBody.Append("   Web Admin<p/>");
				string ccEmail = documentModel.UserId;
				string toEmail = _ICommonRepository.GetSalesEmployeeEmailAddress(documentModel.SalesPersonCode);
				string bccEmail = ConfigManager.GetEmail_BCCEmailAddress();
				//bccEmail = "pravinaug17@gmail.com";

				string from = ConfigManager.GetSMTP_UserName();

				List<string> attachmentList = new List<string>();
				try
				{
					attachmentList = documentModel.Attachments2_Lines.ToList().Select(a => a.trgtPath).ToList();
				}
				catch { }
				bool result = _sendMail.sendMail(from, toEmail, ccEmail, bccEmail, subject, sbBody.ToString(), attachmentList, out message);
				responseModel.ResponseStatus = result;
				responseModel.ResponseText = message;
			}
			catch
			{
			}
			return responseModel;

		}
		#endregion

		[HttpGet]//http get as it return file 
		public HttpResponseMessage PrintCrystal(string docEntry)
		{
			try
			{
				var rd = new ReportDocument();
				HttpResponseMessage response = null;
				string reportName = "";
				reportName = "SalesInvoice";
				string objType = "13";

				string path = Path.Combine(_IHostingEnvironment.WebRootPath, "Reports");
				string exportFolder = Path.Combine(_IHostingEnvironment.WebRootPath, "Reports//Export");
				path = path + "//SalesOrder.rpt";
				rd.Load(path);
				string localFolderPath = exportFolder + docEntry + ".pdf";
				if (!Directory.Exists(localFolderPath))
				{
					Directory.CreateDirectory(localFolderPath);
				}
				//clsReportsDAL _clsReportDAL = new clsReportsDAL();

				#region Get Data

				DataTable dt_Main = _ISalesOrderRepository.GetSalesOrderReportData(docEntry);
				string xmlPath_Main = Path.Combine(localFolderPath + "Web_Reports_SalesOrder.Xml");
				dt_Main.WriteXml(xmlPath_Main, XmlWriteMode.WriteSchema);

				#endregion

				#region Read Data From XML

				dt_Main = new DataTable();
				dt_Main.ReadXml(xmlPath_Main);

				#endregion

				#region Set Data To Reports

				rd.Database.Tables[0].SetDataSource(dt_Main);
				//rd.Subreports["BillToAddress"].Database.Tables[0].SetDataSource(dt_BillTo);

				#endregion
				try
				{
					string pdfFilePath = Path.Combine(localFolderPath + "SalesProforma" + docEntry + ".pdf");
					rd.ExportToDisk(CrystalDecisions.Shared.ExportFormatType.PortableDocFormat, pdfFilePath);
					if (!System.IO.File.Exists(pdfFilePath))
					{
						//	response = Request.CreateResponse(HttpStatusCode.Gone);
					}
					else
					{
						//if file present than read file 
						var fStream = new System.IO.FileStream(pdfFilePath, System.IO.FileMode.Open, System.IO.FileAccess.Read);
						//compose response and include file as content in it
						response = new HttpResponseMessage
						{
							StatusCode = HttpStatusCode.OK,
							Content = new StreamContent(fStream)
						};
						//set content header of reponse as file attached in reponse
						response.Content.Headers.ContentDisposition =
						new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment")
						{
							FileName = System.IO.Path.GetFileName(fStream.Name)
						};
						response.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");
					}
				}
				catch (Exception ex)
				{
					throw ex;
				}

				return response;
			}
			catch (Exception ex)
			{
				throw ex;
			}
		}
		[HttpGet]
		public JsonResult Print(string docEntry)
		{
			var data = _ICommonRepository.PDF(docEntry, PrintForm.SalesOrderLayout);
			return Json(new { aaData = data });
		}
	}
}
