﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using DocumentFormat.OpenXml.Bibliography;
using System.Globalization;
using DocumentFormat.OpenXml.Office.Word;
using DocumentFormat.OpenXml.EMMA;
using System.Text;
using WebDAL.Helper;
using System.Security.Policy;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml.VariantTypes;
using System.Data;
using ClosedXML.Excel;
using System.IO;

namespace WebApp.Controllers
{
	public class ReportsController : Controller
	{
		public readonly IReportsRepository _IReportRepository = null;
		public readonly ICommonRepository _ICommonRepository = null;

		public ReportsController(IReportsRepository iReportRepository, ICommonRepository iCommonRepository)
		{
			//Dependency Injection
			_IReportRepository = iReportRepository;
			_ICommonRepository = iCommonRepository;
		}

		#region Reports
		[HttpGet]
		public IActionResult BackOrderReport()
		{
			return View();
		}
		[HttpGet]
		public IActionResult InventoryReport()
		{
			return View();
		}

		[HttpGet]
		public IActionResult PORegister()
		{
			ViewBag.ItemGroupList = GetItemGroupList("");
			return View();
		}
		[HttpGet]
		public IActionResult PendingPOReport()
		{
			return View();
		}
		[HttpGet]
		public IActionResult GRPORegister()
		{
			ViewBag.ItemGroupList = GetItemGroupList("");
			return View();
		}
		[HttpGet]
		public IActionResult DispatchReport()
		{
			return View();
		}

		[HttpGet]
		public IActionResult ClientFerreroDispatchReport()
		{
			ViewBag.ItemGroupList = GetItemGroupList("Y");
			ViewBag.ItemBrandList = GetItemBrandList("Y");
			ViewBag.VariantList = GetAllVariantList();
			return View();
		}
		[HttpGet]
		public IActionResult PSSLayoutReport(string itemcode, string itemname)
		{
			PSSLayoutModel model = new PSSLayoutModel();
			model.ItemCode = itemcode;
			model.ItemName = itemname;
			ViewBag.ItemGroupList = GetItemGroupList("Y");
			ViewBag.ItemBrandList = GetItemBrandList("Y");
			ViewBag.VariantList = GetAllVariantList();
			return View(model);
		}

		[HttpGet]
		public JsonResult GetBackOrderReport(string fromDate, string toDate, string cardcode, string itemcode)
		{
			var userId = HttpContext.User.Identity.Name;
			List<BackOrderReportModel> data = _IReportRepository.GetBackOrderReport(userId, fromDate, toDate, cardcode, itemcode);
			return Json(new { aaData = data });
		}
		[HttpGet]
		public JsonResult GetDispatchReport(string fromDate, string toDate, string slpcode)
		{
			var userId = HttpContext.User.Identity.Name;
			List<DispatchDetailsReportModel> data = _IReportRepository.GetDispatchReport(fromDate, toDate, slpcode);
			return Json(new { aaData = data });
		}

		[HttpGet]
		public JsonResult GetInventoryTransferReport(string toDate)
		{
			List<InventoryTransferReportModel> data = _IReportRepository.GetInventoryTransferReport(toDate);
			return Json(new { aaData = data });
		}
		[HttpGet]
		public JsonResult GetPORegisterReport(string fromDate, string toDate, string itmsGrpName)
		{
			List<PORegisterReportModel> data = _IReportRepository.GetPORegisterReport(fromDate, toDate, itmsGrpName);
			return Json(new { aaData = data });
		}
		[HttpGet]
		public JsonResult GetPendingPOReport(string fromDate, string toDate, string cardcode, string itemcode)
		{
			List<PendingPOReportModel> data = _IReportRepository.GetPendingPOReport(fromDate, toDate, cardcode, itemcode);
			return Json(new { aaData = data });
		}
		[HttpGet]
		public JsonResult GetGRPORegisterReport(string fromDate, string toDate, string itmsGrpName)
		{
			List<GRPORegisterReportModel> data = _IReportRepository.GetGRPORegisterReport(fromDate, toDate, itmsGrpName);
			return Json(new { aaData = data });
		}
		[HttpGet]
		public JsonResult GetClientFerreroDispatchReport(string fromDate, string toDate, string cardname, string itmsGrpName, string brand, string variant)
		{
			var data = _IReportRepository.GetClientFerreroDispatchReport(fromDate, toDate, cardname, itmsGrpName, brand, variant);
			return Json(new { aaData = data });
		}

		[HttpGet]
		public JsonResult GetPSSLayoutReport(string itemcode)
		{
			var data = _IReportRepository.GetPSSLayoutReport(itemcode);
			return Json(new { aaData = data });
		}
		#endregion

		#region Supplied Material Report
		[HttpGet]
		public IActionResult DispatchDetailsReport()
		{
			return View();
		}

		[HttpGet]
		public JsonResult GetSuppliedMaterialReport(string fromDate, string toDate)
		{
			var userId = HttpContext.User.Identity.Name;
			var slpcode = _ICommonRepository.GetSlpCodeFromEmailAddress(userId);
			var data = _IReportRepository.GetSuppliedMaterialReport(slpcode, fromDate, toDate);
			return Json(new { aaData = data });
		}
		#endregion

		#region FG Stock Status Report
		[HttpGet]
		public IActionResult FGStockStatusReport()
		{
			var userId = HttpContext.User.Identity.Name;
			FGStockStatusReportModel model = new FGStockStatusReportModel();
			List<FGStockStatusReportRowsModel> listRows = new List<FGStockStatusReportRowsModel>();
			FGStockStatusReportRowsModel rowsModel = new FGStockStatusReportRowsModel();
			var slpcode = _ICommonRepository.GetSlpCodeFromEmailAddress(userId);
			var slpname = _ICommonRepository.GetSlpNameFromEmailAddress(userId);
			model.SlpCode = slpcode;
			model.SlpName = slpname;

			rowsModel.Index = 1;
			listRows.Add(rowsModel);
			model.FGStatusRows = listRows;

			return View(model);
		}

		[HttpGet]
		public JsonResult GetFGStockStatusReport(string cardcode)
		{
			var userId = HttpContext.User.Identity.Name;
			//var slpcode = _ICommonRepository.GetSlpCodeFromEmailAddress(userId);
			List<FGStockStatusReportRowsModel> data = _IReportRepository.GetFGStockStatusReport(userId, cardcode);
			return Json(new { aaData = data });
		}

		[HttpGet]
		public JsonResult GetFGStockStatusItemWiseReport(string itemcode)
		{
			List<FGStockStatusReportDetailRowsModel> data = _IReportRepository.GetFGStockStatusItemWiseReport(itemcode);
			return Json(new { aaData = data });
		}


		[HttpGet]
		public ActionResult ExportFGStockStatusItemWiseReport(string itemcode)
		{
			List<FGStockStatusReportDetailRowsModel> data = _IReportRepository.GetFGStockStatusItemWiseReport(itemcode);
			DataTable dt = new DataTable();
			Helpers helpers = new Helpers();
			dt = helpers.ToDataTable(data);
			dt.TableName = "data";

			string fileName = itemcode + ".xlsx";
			using (XLWorkbook wb = new XLWorkbook())
			{
				wb.Worksheets.Add(dt);
				using (MemoryStream stream = new MemoryStream())
				{
					wb.SaveAs(stream);
					//Return xlsx Excel File  
					return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
				}
			}
		}


		[HttpPost]
		public ActionResult FGStockStatusReportAddRow(int index)
		{
			index = index - 1;
			var newRow = new FGStockStatusReportRowsModel() { Index = index + 1 };
			ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("FGStatusRows[{0}]", index);
			return PartialView("~/Views/Shared/EditorTemplates/FGStockStatusReportRowsModel.cshtml", newRow);
		}

		#endregion

		#region Item Price Report
		[HttpGet]
		public IActionResult ItemPriceReport()
		{
			return View();
		}

		[HttpGet]
		public JsonResult GetItemPriceReport(string itemcode)
		{
			var userId = HttpContext.User.Identity.Name;
			List<ItemPriceReportModel> data = _IReportRepository.GetItemPriceReport(itemcode);
			return Json(new { aaData = data });
		}
		#endregion

		#region Payment Projection
		[Authorize]
		[HttpGet]
		public IActionResult PaymentProjection()
		{
			PaymentProjectionModel model = new PaymentProjectionModel();
			WeekModel weekModel = new WeekModel();
			var userId = HttpContext.User.Identity.Name;
			bool role = _ICommonRepository.IsUserLeader(userId);
			//if (role == "L")
			if (role == true)
			{
				try
				{
					model.SlpCode = _ICommonRepository.GetSlpCodeFromEmailAddress(userId);
					model.SlpName = _ICommonRepository.GetSlpNameFromEmailAddress(userId);
					model.U_Year = DateTime.Now.Year.ToString();
					List<PaymentProjectionRowsModel> listRows = new List<PaymentProjectionRowsModel>();
					PaymentProjectionRowsModel rowsModel = new PaymentProjectionRowsModel();

					rowsModel.Index = 1;
					listRows.Add(rowsModel);
					model.PaymentProjectionRows = listRows;

					List<WeekModel> list = GetWeekData(DateTime.Now.Year, 0);
					weekModel = list.Where(a => DateTime.Now.Date >= a.FromDateTime && DateTime.Now.Date <= a.ToDateTime).FirstOrDefault();
					model.U_WeekNo = weekModel.WeekNo.ToString();
					model.FromDate = weekModel.FromDate;
					model.ToDate = weekModel.ToDate;
				}
				catch (Exception ex)
				{

				}
				return View(model);
			}
			else
			{
				TempData["Error"] = "1";
				TempData["Message"] = "You are not authorized";
				return RedirectToAction("Index", "Dashboard");
			}
		}


		[Authorize]
		[HttpPost]
		[DisableRequestSizeLimit]
		public IActionResult PaymentProjection(PaymentProjectionModel model)
		{
			var buttonAttribute = Request.Form["C"];
			string buttonValue = "";
			if (buttonAttribute.Count > 0)
			{
				buttonValue = "C";
				model.PaymentProjectionRows.ToList().ForEach(i => i.U_IsConfirm = "Y");
			}
			//model.SlpCode = HttpContext.User.Identity.Name;
			string responseText = string.Empty;
			ResponseModel responseModel = _IReportRepository.AddPaymentProjection(model);
			if (responseModel.ResponseStatus == true)
			{
				TempData["Success"] = "1";
				TempData["Message"] = responseModel.ResponseText;
				#region Send Mail when confirm button is clicked
				if (buttonValue == "C")
				{
					Helpers helpers = new Helpers();
					DataTable dt = new DataTable();
					dt = helpers.ToDataTable(model.PaymentProjectionRows);
					DataRow dr = dt.NewRow();
					dr["CardName"] = "Total";
					dr["U_OverDue"] = model.TotalOverDue;
					dr["U_ProAmt"] = model.TotalProjection;
					dt.Rows.Add(dr);
					try
					{
						dt.Columns.Remove("SlpCode");
						dt.Columns.Remove("U_IsConfirm");
						dt.Columns.Remove("U_AmtRecd");
						dt.Columns.Remove("Balance");
						dt.Columns.Remove("CollProj");
						dt.Columns.Remove("CollOD");

						dt.Columns["U_CardCode"].ColumnName = "CardCode";
						dt.Columns["U_AccBal"].ColumnName = "Account Balance";
						dt.Columns["U_OverDue"].ColumnName = "Over Due";
						dt.Columns["U_ProAmt"].ColumnName = "Current Week Projection";
					}
					catch { }

					DateTime dtFromDate = DateTime.ParseExact(model.FromDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
					DateTime dtToDate = DateTime.ParseExact(model.ToDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
					DateTime dtCurrentDate = DateTime.Now;
					var datesThatAreFriday = Enumerable
					.Range(dtFromDate.DayOfYear, dtToDate.Subtract(dtFromDate).Days + 1)
					.Select(n => dtFromDate.AddDays(n - dtFromDate.DayOfYear))
					.Where(d => d.DayOfWeek == DayOfWeek.Friday).FirstOrDefault();

					DateTime dtFridayDateTime = Convert.ToDateTime(datesThatAreFriday);
					dtFridayDateTime = dtFridayDateTime.AddHours(18);
					var hours = (dtCurrentDate - dtFridayDateTime).TotalHours;

					string tableBody = helpers.ConvertToHtml(dt);

					string slpName = _ICommonRepository.GetSlpNameFromSlpCode(model.SlpCode);
					string slpNameEmailAddress = _ICommonRepository.GetSalesEmployeeEmailAddress(model.SlpCode);
					string toEmail = model.UserId;
					string ccEmail = ConfigManager.GetEmail_ProjectionEmailAddress();
					string bccEmail = ConfigManager.GetEmail_BCCEmailAddress();
					string subject = "Projection Confirmation From " + slpName + " For Week No: " + model.U_WeekNo;
					StringBuilder sbBody = new StringBuilder();
					sbBody.Append("<p> Hi, <p/>");
					sbBody.Append("<p> Projection of week no:" + model.U_WeekNo + "  confirmed by " + slpName + " ");
					if (hours > 0)
					{
						sbBody.Append("<b style=\"color:red;font-size:160%\"> delayed by: " + Convert.ToString((int)hours) + " hours </b> ");
					}
					else
					{
						sbBody.Append(" on time ");
					}
					sbBody.Append("<p/>");
					sbBody.Append("<p> From Date: " + model.FromDate + "  To Date: " + model.ToDate + "<p/>");
					sbBody.Append("<p> Please see below details<p/>");
					sbBody.Append(tableBody);
					sbBody.Append("<p> Regards <br/>");
					sbBody.Append("   Web Admin<p/>");
					SendMail _sendMail = new SendMail();
					//toEmail = "pravinaug17@gmail.com";
					string from = ConfigManager.GetSMTP_UserName();
					bool result = _sendMail.sendMail(from, toEmail, ccEmail, bccEmail, subject, sbBody.ToString(), null, out string message);
				}
				#endregion
				return RedirectToAction("PaymentProjection", "Reports");
			}
			else
			{
				responseText = responseModel.ResponseText;
			}
			ViewData["Error"] = "1";
			ViewData["Message"] = responseText;
			return View(model);
		}

		[HttpGet]
		public JsonResult GetPaymentProjection(string slpcode,string fromDate, string toDate, string year, string weekNo)
		{
			var userId = HttpContext.User.Identity.Name;
			List<PaymentProjectionRowsModel> data = _IReportRepository.GetPaymentProjection(slpcode, fromDate, toDate, year, weekNo);
			string isUserSuperUser = _ICommonRepository.IsUserSuperUser(userId);
			return Json(new { aaData = data, superUser = isUserSuperUser });
		}
		#endregion


		[HttpGet]
		public JsonResult ConfirmProjection(string slpcode,string year, string weekNo, string fromDate, string toDate)
		{
			var userId = HttpContext.User.Identity.Name;
			ResponseModel data = _IReportRepository.ConfirmProjection(slpcode, year, weekNo);
			if (data.ResponseStatus == true)
			{
				string slpName = _ICommonRepository.GetSlpNameFromSlpCode(slpcode);
				string toEmail = userId;
				string ccEmail = ConfigManager.GetEmail_ProjectionEmailAddress();
				string bccEmail = ConfigManager.GetEmail_BCCEmailAddress();
				string subject = "Projection Confirmation From " + slpName + " For Week No: " + weekNo;
				StringBuilder sbBody = new StringBuilder();
				sbBody.Append("<p> Hi, <p/>");
				sbBody.Append("<p> Projection of week no:" + weekNo + "  confirmed by " + slpName + "<p/>");
				sbBody.Append("<p> From Date: " + fromDate + "  To Date: " + toDate + "<p/>");
				sbBody.Append("<p> Regards <br/>");
				sbBody.Append("   Web Admin<p/>");
				SendMail _sendMail = new SendMail();
				string from = ConfigManager.GetSMTP_UserName();
				bool result = _sendMail.sendMail(from, toEmail, ccEmail, bccEmail, subject, sbBody.ToString(), null, out string message);
			}
			return Json(new { aaData = data });
		}


		[HttpPost]
		public ActionResult PaymentProjectionAddRow(int index)
		{
			index = index - 1;
			var newRow = new PaymentProjectionRowsModel() { Index = index + 1 };
			ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("PaymentProjectionRows[{0}]", index);
			return PartialView("~/Views/Shared/EditorTemplates/PaymentProjectionRowsModel.cshtml", newRow);
		}


		[HttpGet]
		public JsonResult ExportSalesQuotation(string docEntry)
		{
			var userId = HttpContext.User.Identity.Name;
			ResponseModel data = _IReportRepository.ExportSalesQuotation(docEntry);
			return Json(new { aaData = data });
		}

		[HttpGet]
		public JsonResult TestGet(string docEntry)
		{
			var userId = HttpContext.User.Identity.Name;
			ResponseModel data = _IReportRepository.TestGet(docEntry);
			return Json(new { aaData = data });
		}

		[HttpGet]
		public JsonResult GetWeekList(int year)
		{
			List<WeekModel> data = GetWeekData(year, 0);
			return Json(new { aaData = data });
		}

		[HttpGet]
		public JsonResult GetWeekDetailsList(int year, int weekNo)
		{
			List<WeekModel> list = GetWeekData(year, weekNo);
			WeekModel weekModel = list[0];
			return Json(new { aaData = weekModel });
		}

		private List<WeekModel> GetWeekData(int year, int weekNo)
		{
			List<WeekModel> data = new List<WeekModel>();
			DateTimeFormatInfo dfi = DateTimeFormatInfo.CurrentInfo;
			DateTime date1 = new DateTime(year, 12, 31);
			Calendar cal = dfi.Calendar;
			int weeks = cal.GetWeekOfYear(date1, dfi.CalendarWeekRule,
												dfi.FirstDayOfWeek);
			int iStart = 1;
			if (weekNo > 0)
			{
				iStart = weekNo;
				weeks = weekNo;
			}
			else
			{

			}
			for (int i = iStart; i <= weeks; i++)
			{
				WeekModel model = new WeekModel();
				model.WeekNo = i;
				DateTime jan1 = new DateTime(year, 1, 1);
				int daysOffset = DayOfWeek.Friday - jan1.DayOfWeek;
				DateTime firstThursday = jan1.AddDays(daysOffset);
				//var cal = CultureInfo.CurrentCulture.Calendar;
				int firstWeek = cal.GetWeekOfYear(firstThursday, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);
				var weekNum = i;
				if (firstWeek == 1)
				{
					weekNum -= 1;
				}
				var result = firstThursday.AddDays(weekNum * 7);
				// Subtract 3 days from Thursday to get Monday, which is the first weekday in ISO8601
				DateTime dt = result.AddDays(0);
				string fromDate = dt.ToString("d");
				model.FromDate = dt.ToString("dd-MM-yyyy");// dt.ToString("d");
				model.FromDateTime = dt;

				dt = dt.AddDays(6);
				model.ToDate = dt.ToString("dd-MM-yyyy"); //dt.ToString("d"); 
				model.ToDateTime = dt;

				data.Add(model);
			}
			return data;
		}

		[NonAction]
		private SelectList GetItemGroupList(string showNameInID)
		{
			if (showNameInID == "Y")
			{
				return new SelectList(_ICommonRepository.GetAllItemGroup(), "Name", "Name");
			}
			else
			{
				return new SelectList(_ICommonRepository.GetAllItemGroup(), "ID", "Name");
			}
		}
		[NonAction]
		private SelectList GetItemBrandList(string showNameInID)
		{
			if (showNameInID == "Y")
			{
				return new SelectList(_ICommonRepository.GetAllItemBrand(), "Name", "Name");
			}
			else
			{
				return new SelectList(_ICommonRepository.GetAllItemBrand(), "ID", "Name");
			}
		}
		[NonAction]
		private SelectList GetAllVariantList()
		{
			return new SelectList(_ICommonRepository.GetAllVariant(), "Name", "Name");
		}

		[HttpPost]
		[DisableRequestSizeLimit]
		public JsonResult UpdateRemarkData(string lotno, string remark)
		{
			ResponseModel responseModel = _IReportRepository.UpdateRemarkData(lotno, remark);
			return Json(new { value = responseModel });
		}

		[HttpGet]
		public IActionResult ItemChapterTaxCodeReport()
		{
			return View();
		}

		[HttpGet]
		public JsonResult GetItemChapterTaxCodeReport()
		{
			List<ItemChapterTaxCodeReportModel> data = _IReportRepository.GetItemChapterTaxCodeReport();
			return Json(new { aaData = data });
		}

		[HttpGet]
		public IActionResult ItemWiseWarehouseStockReport()
		{
			return View();
		}

		[HttpGet]
		public JsonResult GetItemWiseWarehouseStock(string itemCode)
		{
			List<ItemModel> data = _IReportRepository.GetItemWiseWarehouseStock(itemCode);
			return Json(new { aaData = data });
		}

		
	}
}
