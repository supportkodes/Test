﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using WebDAL.Helper;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Logging;
using System.Net.Http;
using System.Net;
using CrystalDecisions.CrystalReports.Engine;
using static WebDAL.Models.PurchaseOrderModel;

namespace WebApp.Controllers
{
	public class IssueForProductionController : Controller
	{
		public readonly IIssueForProductionRepository _IIssueForProductionRepository = null;
		public readonly ICommonRepository _ICommonRepository = null;
		private IHostingEnvironment _IHostingEnvironment;
		private readonly ILogger<IssueForProductionController> _ILogger;

		public IssueForProductionController(IIssueForProductionRepository iIssueForProductionRepository,
			ICommonRepository iCommonRepository, IHostingEnvironment iHostingEnvironment
			, ILogger<IssueForProductionController> iLogger
			)
		{
            _IIssueForProductionRepository = iIssueForProductionRepository;
			_ICommonRepository = iCommonRepository;
			_IHostingEnvironment = iHostingEnvironment;
			_ILogger = iLogger;
		}

		[Authorize]
		[HttpGet]
		public IActionResult Index()
		{
			return View();
		}

		[HttpGet]
		public IActionResult GetAll(string type)
		{
			var userId = HttpContext.User.Identity.Name;
			List<IssueForProductionModel> data = _IIssueForProductionRepository.GetAll(userId, type);
			for (int i = 0; i < data.Count; i++)
			{
				data[i].EditLink = Url.Action("Edit", "IssueForProduction", new { docnum = data[i].DocNum, type = type.ToUpper() });
			}
			return Json(new { aaData = data });
		}

		[Authorize]
		[HttpGet]
		public IActionResult Add()
		{

			var userId = HttpContext.User.Identity.Name;
			string ownerId = _ICommonRepository.GetEmpId(userId);
            IssueForProductionModel issueForProductionModel = new IssueForProductionModel();
			issueForProductionModel.DocDate = DateTime.Now.ToString("dd-MM-yyyy");

			#region IssueForProduction Rows
			List<IssueForProductionRowsModel> issueForProductionModelList = new List<IssueForProductionRowsModel>();
			for (int i = 1; i <= 1; i++)
			{
				IssueForProductionRowsModel issueForProductionRowsModel = new IssueForProductionRowsModel();
                issueForProductionRowsModel.Index = i;
                issueForProductionModelList.Add(issueForProductionRowsModel);
			}
			issueForProductionModel.DocumentLines = issueForProductionModelList;
			#endregion

			ViewBag.ShiftList = GetAllShiftMaster();
            return View(issueForProductionModel);
		}

		[HttpPost]
		[DisableRequestSizeLimit]
		public IActionResult Add(IssueForProductionModel model)
		{
			string responseText = string.Empty;
			var userId = HttpContext.User.Identity.Name;
			ResponseModel responseModel = new ResponseModel();
			model.UserId = userId;
		
				responseModel = _IIssueForProductionRepository.Add(model);
				if (responseModel.ResponseStatus == true)
				{

					TempData["Success"] = "1";
					TempData["Message"] = responseModel.ResponseText;
					return RedirectToAction("Index", "IssueForProduction");
				}
				else
				{
					responseText = responseModel.ResponseText;
				}
			ViewData["Error"] = "1";
			ViewData["Message"] = responseText;

            ViewBag.ShiftList = GetAllShiftMaster();
            return View(model);
		}

		[Authorize]
		[HttpGet]
		public IActionResult Edit(string docEntry, string type)
		{
			var userId = HttpContext.User.Identity.Name;
			userId = _ICommonRepository.GetUserId(userId);

            IssueForProductionModel data = _IIssueForProductionRepository.Get(docEntry, userId, type);
			data.Type = type.ToUpper();
            ViewBag.ShiftList = GetAllShiftMaster();
            return View(data);
		}

		[DisableRequestSizeLimit]
		[HttpPost]
		public IActionResult Edit(IssueForProductionModel model)
		{
			var updateButtonAttribute = Request.Form["Update"];
			string buttonValue = string.Empty;
			if (updateButtonAttribute.Count > 0)
			{
				buttonValue = updateButtonAttribute[0];
			}
			else
			{
				buttonValue = "UpdateExcludeItems";
			}
			model.ButtonValue = buttonValue;
			var userId = HttpContext.User.Identity.Name;
			userId = _ICommonRepository.GetUserId(userId);
			model.UserId = userId;
			ResponseModel responseModel = new ResponseModel();
			try
			{
				responseModel = _IIssueForProductionRepository.Update(model);
			}
			catch (Exception ex)
			{
				responseModel.ResponseStatus = false;
				responseModel.ResponseText = ex.Message;
			}
			if (responseModel.ResponseStatus == true)
			{
				TempData["Success"] = "1";
				TempData["Message"] = responseModel.ResponseText;
				return RedirectToAction("Index", "IssueForProduction");
			}
			else
			{
				ViewData["Error"] = "1";
				ViewData["Message"] = responseModel.ResponseText + ". ";

                ViewBag.ShiftList = GetAllShiftMaster();
                return View(model);
			}
		}

		[HttpPost]
		public ActionResult IssueForProductionAddRow(int index)
		{
			index = index - 1;
			var newRow = new IssueForProductionRowsModel() { Index = index + 1 };
			ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("DocumentLines[{0}]", index);
			return PartialView("~/Views/Shared/EditorTemplates/IssueForProductionRowsModel.cshtml", newRow);
		}

		private bool Validate(IssueForProductionModel model, out string responseMessage)
		{
			responseMessage = string.Empty;
			try
			{
				//if (string.IsNullOrEmpty(model.CardCode))
				//{
				//	responseMessage = "Please select business partner";
				//	return false;
				//}
				//else if (string.IsNullOrEmpty(model.WarehouseCode))
				//{
				//	responseMessage = "Please select warehouse";
				//	return false;
				//}
			}
			catch (Exception ex)
			{

			}
			return true;
		}

        #region Select List
        [NonAction]
        private SelectList GetAllShiftMaster()
        {
            return new SelectList(_ICommonRepository.GetAllShiftMaster(), "ID", "Name");
        }
        #endregion

    }
}
