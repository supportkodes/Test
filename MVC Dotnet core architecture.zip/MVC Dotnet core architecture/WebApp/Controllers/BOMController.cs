﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using WebDAL.Helper;
using Microsoft.AspNetCore.Authorization;

namespace WebApp.Controllers
{
    public class BOMController : Controller
    {
        public readonly IBOMRepository _IBOMRepository = null;
        public readonly ICommonRepository _ICommonRepository = null;
        private IHostingEnvironment _IHostingEnvironment;
        public BOMController(IBOMRepository iIBOMRepository, ICommonRepository iCommonRepository
            , IHostingEnvironment iHostingEnvironment)
        {
            _IBOMRepository = iIBOMRepository;
            _ICommonRepository = iCommonRepository;
            _IHostingEnvironment = iHostingEnvironment;
        }

        [Authorize]
        [HttpGet]
        public IActionResult Index(string bomType)
        {
            BOMMasterModel model = new BOMMasterModel();
            model.TreeType = bomType;
            model.TreeType_Disabled = bomType;
            return View(model);
        }

        [HttpGet]
        public IActionResult GetAll(string bomType)
        {
            DataTable dataTable = new DataTable();
            List<BOMMasterModel> data = _IBOMRepository.GetAll(bomType, out dataTable);
            for (int i = 0; i < data.Count; i++)
            {
                string bomTypeName = bomType;
                data[i].EditLink = Url.Action("Edit", "BOM", new { itemcode = data[i].Code, bomType = bomTypeName });
                data[i].DuplicateLink = Url.Action("Add", "BOM", new { itemcode = data[i].Code, bomType = bomTypeName });
            }
            return Json(new { aaData = data });
        }
        [HttpGet]
        public IActionResult Add(string bomType, string itemcode)
        {
            BOMMasterModel bomModel = new BOMMasterModel();
            bomModel.TreeType = bomType;
            bomModel.Quantity = "1";
            bomModel.PriceList = "1";

            int rows = 1;
            if (bomType == "P")
            {
                rows = 25;
            }
            #region BOMMaster Rows
            List<BOMMasterModelRow> BOMRowsModelList = new List<BOMMasterModelRow>();
            for (int i = 0; i < rows; i++)
            {
                BOMMasterModelRow BOMRowsModel = new BOMMasterModelRow();
                BOMRowsModel.Index = i + 1;
                BOMRowsModel.PriceList = "1";
                BOMRowsModelList.Add(BOMRowsModel);
            }
            bomModel.ProductTreeLines = BOMRowsModelList;

            #endregion

            ViewBag.PriceListData = GetPriceList();
            ViewBag.WarehouseData = GetWarehouseList(bomType);

            if (!string.IsNullOrEmpty(itemcode))
            {
                bomModel = _IBOMRepository.Get(itemcode);
                bomModel.TreeCode = "";
                bomModel.ItemName = "";
                bomModel.Quantity = "1";
                bomModel.PriceList = "1";

                return View(bomModel);
            }
            else
            {
                return View(bomModel);
            }
        }

        [HttpPost]
        public IActionResult Add(BOMMasterModel model)
        {
            string responseText = string.Empty;
            var userId = HttpContext.User.Identity.Name;
            //model.UserId = userId;
            if (Validate(model, out responseText) == true)
            {
                ResponseModel responseModel = _IBOMRepository.Add(model);
                if (responseModel.ResponseStatus == true)
                {
                    TempData["Success"] = "1";
                    TempData["Message"] = responseModel.ResponseText;
                    return RedirectToAction("Index", "BOM", new { bomType = model.TreeType });
                }
                else
                {
                    responseText = responseModel.ResponseText;
                }
            }

            ViewBag.PriceListData = GetPriceList();
            ViewBag.WarehouseData = GetWarehouseList(model.TreeType);

            ViewData["Error"] = "1";
            ViewData["Message"] = responseText;
            return View(model);

        }

        [HttpPost]
        public ActionResult BOMAddRow(int index)
        {
            index = index - 1;
            var newRow = new BOMMasterModelRow() { Index = index + 1 };
            ViewBag.PriceListData = GetPriceList();
            ViewBag.WarehouseData = GetWarehouseList("S");
            ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("ProductTreeLines[{0}]", index);
            return PartialView("~/Views/Shared/EditorTemplates/BOMMasterModelRow.cshtml", newRow);

        }

        [HttpGet]
        public IActionResult Edit(string itemcode, string bomType)
        {
            BOMMasterModel data = _IBOMRepository.Get(itemcode);
            //data.Code = itemcode;
            ViewBag.PriceListData = GetPriceList();
            ViewBag.WarehouseData = GetWarehouseList(bomType);
            return View(data);
        }

        [DisableRequestSizeLimit]
        [HttpPost]
        public IActionResult Edit(BOMMasterModel model)
        {
            var userId = HttpContext.User.Identity.Name;
            string responseText = "";
            if (Validate(model, out responseText) == true)
            {
                ResponseModel responseModel = _IBOMRepository.Update(model);
                if (responseModel.ResponseStatus == true)
                {
                    TempData["Success"] = "1";
                    TempData["Message"] = responseModel.ResponseText;
                    //   return RedirectToAction("Index", "BOM");
                    return RedirectToAction("Index", "BOM", new { bomType = model.TreeType });
                }
            }

            ViewData["Error"] = "1";
            ViewData["Message"] = responseText;
            ViewData["Message"] = responseText;
            ViewBag.PriceListData = GetPriceList();
            ViewBag.WarehouseData = GetWarehouseList(model.TreeType);
            return View(model);
        }

        private bool Validate(BOMMasterModel model, out string responseMessage)
        {
            responseMessage = string.Empty;
            if (string.IsNullOrEmpty(model.TreeCode))
            {
                responseMessage = "Please select header itemcode";
                return false;
            }
            if (model.TreeType == "S")
            {
                string headerItemUOMEntry = _ICommonRepository.GetItemUOMEntry(model.TreeCode);
                // If Header item code UOM Group is Thd. Then child UOM Group should be Thd
                if (headerItemUOMEntry == "3")
                {
                    for (int i = 0; i < model.ProductTreeLines.Count; i++)
                    {
                        string rowItemUOMEntry = _ICommonRepository.GetItemUOMEntry(model.ProductTreeLines[i].ItemCode);
                        if (headerItemUOMEntry != rowItemUOMEntry)
                        {
                            responseMessage = "Row itemcode: " + model.ProductTreeLines[i].ItemCode + " should be in thousand";
                            return false;
                        }
                    }
                }

            }
            return true;
        }

        public ActionResult ExportToExcel(string bomType)
        {
            DataTable dataTable = new DataTable();
            _IBOMRepository.GetAll(bomType, out dataTable);
            // Name of File
            string fileName = "BOM.xlsx";
            using (XLWorkbook wb = new XLWorkbook())
            {
                dataTable.TableName = "BOM";
                // Add DataTable in worksheet
                wb.Worksheets.Add(dataTable);
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    // Return xlsx Excel File
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
                }
            }
        }

        #region Select List
        private SelectList GetPriceList()
        {
            return new SelectList(_ICommonRepository.GetAllPriceList(), "ID", "Name");
        }
        private SelectList GetWarehouseList(string type)
        {
            if (type == "S")
            {
                return new SelectList(_ICommonRepository.GetAllWarehouseList(), "ID", "Name");
            }
            else
            {
                //return new SelectList(_ICommonRepository.GetAllWarehouseList(), "ID", "Name");
                return new SelectList(_ICommonRepository.GetAllBOMWarehouseList(), "ID", "Name");
            }
        }
        #endregion
    }
}
