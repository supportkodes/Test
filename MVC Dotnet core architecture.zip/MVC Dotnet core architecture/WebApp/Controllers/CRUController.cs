﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using WebDAL.IRepository;
using WebDAL.Models;

namespace WebApp.Controllers
{
    public class CRUController : Controller
    {
        public readonly ICRURepository _ICRURepository = null;
        public readonly ICommonRepository _ICommonRepository = null;
        private IHostingEnvironment _IHostingEnvironment;
        public CRUController(ICRURepository iCRURepository, ICommonRepository iCommonRepository
            , IHostingEnvironment iHostingEnvironment)
        {
            _ICRURepository = iCRURepository;
            _ICommonRepository = iCommonRepository;
            _IHostingEnvironment = iHostingEnvironment;
        }

        [Authorize]
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            List<CRUModel> data = _ICRURepository.GetAll();
            for (int i = 0; i < data.Count; i++)
            {
                //data[i].EditLink = Url.Action("Edit", "CRU", new { docEntry = data[i].DocEntry });
				data[i].EditLink = Url.Action("Edit", "CRU", new { code = data[i].Code });

			}
			return Json(new { aaData = data });
        }

        [HttpGet]
        public IActionResult Add()
        {
            var userId = HttpContext.User.Identity.Name;
            string ownerId = _ICommonRepository.GetEmpId(userId);
            CRUModel model = new CRUModel();
			model.U_Date = DateTime.Now.ToString("dd-MM-yyyy");

			//#region Rows
			//List<FLEXOUPModelRow> rowsModelList = new List<FLEXOUPModelRow>();
			//FLEXOUPModelRow rowModel = new FLEXOUPModelRow();
			//rowModel.Index = 1;
			//rowsModelList.Add(rowModel);
			//model.APAFUP1Collection = rowsModelList;
			//#endregion

			//ViewBag.SalesEmployeeList = GetSalesEmployeeList(userId);
			return View(model);
        }

        [HttpPost]
        public IActionResult Add(CRUModel model)
        {
            string responseText = string.Empty;
            var userId = HttpContext.User.Identity.Name;
			//model.UserId = userId;
			ResponseModel responseModel = new ResponseModel();
            responseModel = Validate(model);
			if (responseModel.ResponseStatus == true)
            {
                responseModel = _ICRURepository.Add(model);
                if (responseModel.ResponseStatus == true)
                {
                    TempData["Success"] = "1";
                    TempData["Message"] = responseModel.ResponseText;
                    return RedirectToAction("Add", "CRU");
                }
                else
                {
                    responseText = responseModel.ResponseText;
                }
            }
            ViewData["Error"] = "1";
            ViewData["Message"] = responseModel.ResponseText;
            return View(model);
        }

        [HttpGet]
        public IActionResult Edit(string code)
        {
            CRUModel data = _ICRURepository.Get(code);
            return View(data);
        }

        [DisableRequestSizeLimit]
        [HttpPost]
        public IActionResult Edit(CRUModel model)
        {
			string responseText = string.Empty;
			var userId = HttpContext.User.Identity.Name;
			ResponseModel responseModel = new ResponseModel();
			responseModel = Validate(model);
			if (responseModel.ResponseStatus == true)
			{
				responseModel = _ICRURepository.Update(model);
                if (responseModel.ResponseStatus == true)
                {
                    TempData["Success"] = "1";
                    TempData["Message"] = responseModel.ResponseText;
                    return RedirectToAction("Add", "CRU");
                }
                else
                {
                    ViewData["Error"] = "1";
                    ViewData["Message"] = responseModel.ResponseText + ".";
					return View(model);
				}
			}
			ViewData["Error"] = "1";
			ViewData["Message"] = responseModel.ResponseText;
			return View(model);

		}

        [HttpPost]
        public ActionResult FLEXOUPAddRow(int index)
        {
            index = index - 1;
            var newRow = new FLEXOUPModelRow() { Index = index + 1 };
            ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("APAFUP1Collection[{0}]", index);
            //ViewBag.HSNList = GetHSNList();
            return PartialView("~/Views/Shared/EditorTemplates/FLEXOUPModelRow.cshtml", newRow);
        }
        private ResponseModel Validate(CRUModel model)
        {
            ResponseModel responseModel = new ResponseModel();
            responseModel.ResponseStatus = true;
			try
            {
				if (string.IsNullOrEmpty(model.U_ConCode))
				{
					responseModel.ResponseText= "Please select Contractor Name";
                    responseModel.ResponseStatus = false;
                    return responseModel;
				}
				else if (string.IsNullOrEmpty(model.U_CardCode))
				{
					responseModel.ResponseText = "Please select Vendor Code";
					responseModel.ResponseStatus = false;
					return responseModel;
				}
				else if (string.IsNullOrEmpty(model.CardName))
				{
					responseModel.ResponseText = "Please select Vendor Name";
					responseModel.ResponseStatus = false;
					return responseModel;
				}
				else if (string.IsNullOrEmpty(model.U_Rate))
				{
					responseModel.ResponseText = "Please check Rate";
					responseModel.ResponseStatus = false;
					return responseModel;
				}
				else if (string.IsNullOrEmpty(model.U_KLDNo))
				{
					responseModel.ResponseText = "Please select KLD No";
					responseModel.ResponseStatus = false;
					return responseModel;
				}
				else if (string.IsNullOrEmpty(model.U_PrcType))
				{
					responseModel.ResponseText = "Please select Process Type";
					responseModel.ResponseStatus = false;
					return responseModel;
				}
				else if (string.IsNullOrEmpty(model.U_Status))
				{
					responseModel.ResponseText = "Please select Status";
					responseModel.ResponseStatus = false;
					return responseModel;
				}
				else if (string.IsNullOrEmpty(model.U_Date))
				{
					responseModel.ResponseText = "Please select Date";
					responseModel.ResponseStatus = false;
					return responseModel;
				}
				//else if (string.IsNullOrEmpty(model.U_Remarks))
				//{
				//	responseModel.ResponseText = "Please Enter Remark";
				//	responseModel.ResponseStatus = false;
				//	return responseModel;
				//}
			}
            catch(Exception ex)
            {
            }
            return responseModel;
        }

        #region Select List

        [NonAction]
        private SelectList GetSalesEmployeeList(string userId)
        {
            return new SelectList(_ICommonRepository.GetAllTeamSalesEmployee(userId), "SlpCode", "SlpName");
        }
		#endregion
        		
	}
}
