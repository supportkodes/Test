﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using WebDAL.Helper;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Logging;
using System.Net.Http;
using System.Net;
using CrystalDecisions.CrystalReports.Engine;
using static WebDAL.Models.PurchaseOrderModel;

namespace WebApp.Controllers
{
	public class InventoryTransferController : Controller
	{
		public readonly IInventoryTransferRepository _IInventoryTransferRepository = null;
		public readonly ICommonRepository _ICommonRepository = null;
		private IHostingEnvironment _IHostingEnvironment;
		private readonly ILogger<InventoryTransferController> _ILogger;

		public InventoryTransferController(IInventoryTransferRepository iInventoryTransferRepository,
			ICommonRepository iCommonRepository, IHostingEnvironment iHostingEnvironment
			, ILogger<InventoryTransferController> iLogger
			)
		{
			_IInventoryTransferRepository = iInventoryTransferRepository;
			_ICommonRepository = iCommonRepository;
			_IHostingEnvironment = iHostingEnvironment;
			_ILogger = iLogger;
		}

		[Authorize]
		[HttpGet]
		public IActionResult Index()
		{
			return View();
		}

		[HttpGet]
		public IActionResult GetAll()
		{
			var userId = HttpContext.User.Identity.Name;
			List<InventoryTransferModel> data = _IInventoryTransferRepository.GetAll(userId);
			for (int i = 0; i < data.Count; i++)
			{
				data[i].EditLink = Url.Action("Edit", "InventoryTransfer", new { docEntry = data[i].DocEntry });
			}
			return Json(new { aaData = data });
		}

		[Authorize]
		[HttpGet]
		public IActionResult Add()
		{

			var userId = HttpContext.User.Identity.Name;
			string ownerId = _ICommonRepository.GetEmpId(userId);
			InventoryTransferModel inventoryTransferModel = new InventoryTransferModel();
			inventoryTransferModel.DocDate = DateTime.Now.ToString("dd-MM-yyyy");
			inventoryTransferModel.TaxDate = DateTime.Now.ToString("dd-MM-yyyy");

			#region Inventory Rows
			List<InventoryTransferRowsModel> inventoryTransferRowsModelList = new List<InventoryTransferRowsModel>();
			for (int i = 1; i <= 1; i++)
			{
				InventoryTransferRowsModel inventoryTransferRowsModel = new InventoryTransferRowsModel();
				inventoryTransferRowsModel.Index = i;
				//inventoryTransferRowsModel.ItemCode = "1140000001800284";
				inventoryTransferRowsModel.Quantity = "1";
				//inventoryTransferRowsModel.FromWhsCod= "SFA - 01";
				//inventoryTransferRowsModel.WhsCode = "RMA - 01";
				inventoryTransferRowsModelList.Add(inventoryTransferRowsModel);
			}
			inventoryTransferModel.StockTransferLines = inventoryTransferRowsModelList;
			#endregion

			//#region Expense Rows
			//List<POModel_Expenses> POModel_ExpensesList = new List<POModel_Expenses>();
			//List<ExpenseModel> expenseModelsList = _ICommonRepository.GetAllExpenses();
			//for (int i = 0; i < expenseModelsList.Count; i++)
			//{
			//	POModel_Expenses poModel_Expenses = new POModel_Expenses();
			//	poModel_Expenses.Index = i + 1;
			//	poModel_Expenses.ExpenseCode = expenseModelsList[i].ExpnsCode;
			//	poModel_Expenses.ExpenseName = expenseModelsList[i].ExpnsName;
			//	POModel_ExpensesList.Add(poModel_Expenses);
			//}

			//purchaseOrderModel.POAdditionalExpenses = POModel_ExpensesList;
			//#endregion


			//	#region Attachment Rows
			//	List<POModel_Attachment> documentModel_AttachmentList = new List<POModel_Attachment>();
			//	POModel_Attachment documentModel_Attachment = new POModel_Attachment();
			//	documentModel_Attachment.Index = 1;
			//	documentModel_AttachmentList.Add(documentModel_Attachment);
			//	purchaseOrderModel.Attachments2_Lines = documentModel_AttachmentList;
			//	#endregion

			ViewBag.BranchList = GetBranchList();
			ViewBag.WarehouseData = GetWarehouseList();
			return View(inventoryTransferModel);
		}

		[HttpPost]
		[DisableRequestSizeLimit]
		public IActionResult Add(InventoryTransferModel model)
		{
			string responseText = string.Empty;
			var userId = HttpContext.User.Identity.Name;
			ResponseModel responseModel = new ResponseModel();
			model.UserId = userId;
			if (Validate(model, out responseText) == true)
			{
				responseModel = _IInventoryTransferRepository.Add(model);
				if (responseModel.ResponseStatus == true)
				{

					TempData["Success"] = "1";
					TempData["Message"] = responseModel.ResponseText;
					return RedirectToAction("Index", "InventoryTransfer");
				}
				else
				{
					responseText = responseModel.ResponseText;
				}
			}
			ViewBag.BranchList = GetBranchList();
			ViewBag.WarehouseData = GetWarehouseList();
			ViewData["Error"] = "1";
			ViewData["Message"] = responseText;
			return View(model);
		}

		[Authorize]
		[HttpGet]
		public IActionResult Edit(string docEntry, string type)
		{
			var userId = HttpContext.User.Identity.Name;
			userId = _ICommonRepository.GetUserId(userId);

			InventoryTransferModel data = _IInventoryTransferRepository.Get(docEntry, userId, type);
			data.Type = type.ToUpper();

			ViewBag.BranchList = GetBranchList();
			ViewBag.WarehouseData = GetWarehouseList();

			return View(data);
		}

		[DisableRequestSizeLimit]
		[HttpPost]
		public IActionResult Edit(InventoryTransferModel model)
		{
			var updateButtonAttribute = Request.Form["Update"];
			string buttonValue = string.Empty;
			if (updateButtonAttribute.Count > 0)
			{
				buttonValue = updateButtonAttribute[0];
			}
			else
			{
				buttonValue = "UpdateExcludeItems";
			}
			model.ButtonValue = buttonValue;
			var userId = HttpContext.User.Identity.Name;
			userId = _ICommonRepository.GetUserId(userId);
			model.UserId = userId;
			ResponseModel responseModel = new ResponseModel();
			try
			{
				responseModel = _IInventoryTransferRepository.Update(model);
			}
			catch (Exception ex)
			{
				responseModel.ResponseStatus = false;
				responseModel.ResponseText = ex.Message;
			}
			if (responseModel.ResponseStatus == true)
			{
				TempData["Success"] = "1";
				TempData["Message"] = responseModel.ResponseText;
				return RedirectToAction("Index", "InventoryTransfer");
			}
			else
			{
				ViewData["Error"] = "1";
				ViewData["Message"] = responseModel.ResponseText + ".";

				ViewBag.BranchList = GetBranchList();
				ViewBag.WarehouseData = GetWarehouseList();
				return View(model);
			}
		}

		private bool Validate(InventoryTransferModel model, out string responseMessage)
		{
			responseMessage = string.Empty;
			try
			{
				if (string.IsNullOrEmpty(model.FromWarehouse))
				{
					responseMessage = "Please select from warehouse";
					return false;
				}
				else if (string.IsNullOrEmpty(model.ToWarehouse))
				{
					responseMessage = "Please select to warehouse";
					return false;
				}
				model.StockTransferLines = model.StockTransferLines.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
				for (int i = 0; i < model.StockTransferLines.Count; i++)
				{
					List<InventoryTransferBatchNumbersModel> batchNumbersList = new List<InventoryTransferBatchNumbersModel>();
					string itemcode = model.StockTransferLines[i].ItemCode;
					string batches = model.StockTransferLines[i].SelectedBatchQty;
					try
					{
						string[] batchList = batches.Split(";");
						for (int j = 0; j < batchList.Length; j++)
						{
							string[] batchQuantityList = batchList[i].Split("{}");

							InventoryTransferBatchNumbersModel batchNumberModel = new InventoryTransferBatchNumbersModel();
							batchNumberModel.BaseLineNumber = i;
							batchNumberModel.ItemCode = itemcode;
							batchNumberModel.BatchNumber = batchQuantityList[0];
							batchNumberModel.Quantity = double.Parse(batchQuantityList[1]);
							batchNumbersList.Add(batchNumberModel);
						}
					}
					catch(Exception ex) { }
					model.StockTransferLines[i].BatchNumbers = batchNumbersList;
				}
			}
			catch (Exception ex)
			{

			}
			return true;
		}


		[HttpPost]
		public ActionResult InventoryTransferAddRow(int index)
		{
			index = index - 1;
			var newRow = new InventoryTransferRowsModel() { Index = index + 1 };
			ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("StockTransferLines[{0}]", index);
			ViewBag.CategoryList = GetCategoryList();
			return PartialView("~/Views/Shared/EditorTemplates/InventoryTransferRowsModel.cshtml", newRow);
		}


		[HttpPost]
		public ActionResult AttachmentAddRow(int index)
		{
			index = index - 1;
			var newRow = new POModel_Attachment() { Index = index + 1 };
			ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("Attachments2_Lines[{0}]", index);
			return PartialView("~/Views/Shared/EditorTemplates/POModel_Attachment.cshtml", newRow);
		}

		private bool Validate(PurchaseOrderModel model, out string responseMessage)
		{
			responseMessage = string.Empty;
			try
			{
				if (string.IsNullOrEmpty(model.CardCode))
				{
					responseMessage = "Please select business partner";
					return false;
				}
				//else if (string.IsNullOrEmpty(model.WarehouseCode))
				//{
				//	responseMessage = "Please select warehouse";
				//	return false;
				//}
				//else if (model.DutyStatus == "Y")
				//{
				//	bool isIGST0 = model.DocumentLines.Any(a => a.TaxCode == "IGST0");
				//	if (isIGST0 == true)
				//	{
				//		responseMessage = "You have selected export, You should be select Without Payment of Duty. Sandeep Jha!!";
				//		return false;
				//	}
				//}
				//else if (model.DutyStatus == "N")
				//{
				//	bool isIGST0 = model.DocumentLines.Any(a => a.TaxCode == "IGST0");
				//	if (isIGST0 == false)
				//	{
				//		responseMessage = "You have selected export, You should be select Without Payment of Duty. Sandeep Jha!!";
				//		return false;
				//	}
				//}
			}
			catch (Exception ex)
			{

			}
			return true;
		}

		[HttpGet]
		public JsonResult GetITROpenRows(string itdocEntry)
		{
			DocumentModel documentModel = new DocumentModel();
			documentModel = _IInventoryTransferRepository.GetITROpenRows(itdocEntry);
			return Json(new { value = documentModel });
		}
		#region Select List

		[NonAction]
		private SelectList GetPaymentTermsList()
		{
			return new SelectList(_ICommonRepository.GetAllPaymentTermsList(), "GroupNum", "PymntGroup");
		}

		[NonAction]
		private SelectList GetPlaceOfSupplyList()
		{
			return new SelectList(_ICommonRepository.GetPlaceOfSupply(), "ID", "Name");
		}

		[NonAction]
		private SelectList GetLocationList()
		{
			return new SelectList(_ICommonRepository.GetLocationList(), "ID", "Name");
		}

		[NonAction]
		private SelectList GetWarehouseList()
		{
			return new SelectList(_ICommonRepository.GetAllWarehouse(), "WhsCode", "WhsName");
		}
		[NonAction]
		private SelectList GetCurrencyList()
		{
			return new SelectList(_ICommonRepository.GetAllCurrency(), "CurrCode", "CurrName");
		}

		[NonAction]
		private SelectList GetBranchList()
		{
			return new SelectList(_ICommonRepository.GetAllBranch(), "BPLId", "BPLName");
		}


		[NonAction]
		private SelectList GetShippingTypeList()
		{
			return new SelectList(_ICommonRepository.GetAllShippingType(), "TrnspCode", "TrnspName");
		}

		[NonAction]
		private SelectList GetHSNList()
		{
			return new SelectList(_ICommonRepository.GetAllHSN(), "Chapter", "ChapterID");
		}

		[NonAction]
		private SelectList GetCategoryList()
		{
			return new SelectList(_ICommonRepository.GetUDFValuesList("RDR1", "Category"), "ID", "Name");
		}

		[NonAction]
		private SelectList GetYNList()
		{
			var selectLists = new SelectList(
					new List<SelectListItem>
					{
						new SelectListItem { Value = "Y", Text = "Yes"},
						new SelectListItem { Value= "N", Text = "No"},
					}, "Value", "Text");

			return selectLists;
		}

		[NonAction]
		private SelectList GetEmployeeList()
		{
			return new SelectList(_ICommonRepository.GetAllEmployee(), "empID", "Name");
		}

		[NonAction]
		private SelectList GetSalesEmployeeList(string userId)
		{
			return new SelectList(_ICommonRepository.GetAllTeamSalesEmployee(userId), "SlpCode", "SlpName");
		}

		[NonAction]
		private SelectList GetSalesEmployeeList()
		{
			return new SelectList(_ICommonRepository.GetAllSalesEmployee(), "SlpCode", "SlpName");
		}

		private ResponseModel SendMail(DocumentModel documentModel)
		{
			ResponseModel responseModel = new ResponseModel();
			Helpers helpers = new Helpers();
			SendMail _sendMail = new SendMail();
			string message = "";
			string subject = "Web Portal - Authorize Sales Order of Customer " + documentModel.CardName;
			DataTable dt = new DataTable();
			dt = helpers.ToDataTable(documentModel.DocumentLines);
			try
			{
				dt.Columns.Remove("Index");
				dt.Columns.Remove("LineId");
				dt.Columns.Remove("InStockQuantity");
				dt.Columns.Remove("DeliveredQuantity");
				dt.Columns.Remove("OpenQuantity");
				dt.Columns.Remove("IsDeleted");
				dt.Columns.Remove("HSNEntry");
				dt.Columns.Remove("WarehouseCode");
				dt.Columns.Remove("TaxCode");
				dt.Columns.Remove("UnitPrice");
				dt.Columns.Remove("Total");
				dt.Columns.Remove("TaxRate");
				dt.Columns.Remove("SupplierCatNum");
				dt.Columns.Remove("ShipDate");
			}
			catch { }
			string tableBody = helpers.ConvertToHtml(dt);
			string url = ConfigManager.GetWebSiteURL() + "SalesOrder/Edit?docEntry=" + documentModel.DocEntry + "&type=draft";
			string draftNo = _ICommonRepository.GetDraftNo(documentModel.DocEntry);
			StringBuilder sbBody = new StringBuilder();
			//sbBody.Replace("{OTP}", otp);
			sbBody.Append("<p> Dear Sir/Madam <p/>");
			sbBody.Append("<p> Draft No:" + draftNo + "<p/>");
			sbBody.Append("<p> Billing Address:" + documentModel.Address + "<p/>");
			sbBody.Append("<p> Delivery Address:" + documentModel.Address2 + "<p/>");
			sbBody.Append("<p> Please see below document product details<p/>");
			sbBody.Append(tableBody);
			sbBody.Append("<p> Plese approve or reject document using below link <br/>");
			sbBody.Append(url + " <p/>");
			sbBody.Append("<p> Regards <br/>");
			sbBody.Append("   Web Admin<p/>");
			string ccEmail = documentModel.UserId;
			string toEmail = _ICommonRepository.GetSalesEmployeeEmailAddress(documentModel.SalesPersonCode);
			string bccEmail = ConfigManager.GetEmail_BCCEmailAddress();
			//bccEmail = "pravinaug17@gmail.com";
			List<string> attachmentList = documentModel.Attachments2_Lines.ToList().Select(a => a.trgtPath).ToList();
			string from = ConfigManager.GetSMTP_UserName();
			bool result = _sendMail.sendMail(from,toEmail, ccEmail, bccEmail, subject, sbBody.ToString(), attachmentList, out message);
			responseModel.ResponseStatus = result;
			responseModel.ResponseText = message;
			return responseModel;
		}
		#endregion
	}
}
