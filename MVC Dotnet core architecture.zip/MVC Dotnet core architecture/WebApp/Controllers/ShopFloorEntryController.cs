﻿using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Repository;

namespace WebApp.Controllers
{
    public class ShopFloorEntryController : Controller
    {
        public readonly IShopFloorEntryRepository _IShopFloorEntryRepository = null;

        public readonly ICommonRepository _ICommonRepository = null;

        private IHostingEnvironment _IHostingEnvironment;

        private readonly ILogger<ShopFloorEntryController> _ILogger;

        public ShopFloorEntryController(IShopFloorEntryRepository iShopFloorEntryRepository, ICommonRepository iCommonRepository, IHostingEnvironment iHostingEnvironment, ILogger<ShopFloorEntryController> iLogger)
        {
            _IShopFloorEntryRepository = iShopFloorEntryRepository;
            _ICommonRepository = iCommonRepository;
            _IHostingEnvironment = iHostingEnvironment;
            _ILogger = iLogger;
        }

        [Authorize]
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            var userId = HttpContext.User.Identity.Name;
            List<ShopFloorEntryModel> data = _IShopFloorEntryRepository.GetAll();
            for (int i = 0; i < data.Count; i++)
            {
                data[i].EditLink = Url.Action("Edit", "ShopFloorEntry", new { docEntry = data[i].DocEntry });
            }
            return Json(new { aaData = data });
        }

        [Authorize]
        [HttpGet]
        public IActionResult Add()
        {
            string userId = base.HttpContext.User.Identity.Name;
            string ownerId = _ICommonRepository.GetEmpId(userId);
            ShopFloorEntryModel shopFloorEntryModel = new ShopFloorEntryModel();
            shopFloorEntryModel.U_DocDt = DateTime.Now.ToString("dd-MM-yyyy");
            List<ShopFloorEntryRowsModel> shopFloorEntryRowsModelList = new List<ShopFloorEntryRowsModel>();
            for (int i = 1; i <= 1; i++)
            {
                ShopFloorEntryRowsModel shopFloorEntryRowsModel = new ShopFloorEntryRowsModel();
                shopFloorEntryRowsModel.Index = i;
                shopFloorEntryRowsModelList.Add(shopFloorEntryRowsModel);
            }
            shopFloorEntryModel.VCDPDCollection = shopFloorEntryRowsModelList;
            base.ViewBag.ShiftList = GetAllShiftMaster();
            return View(shopFloorEntryModel);
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public IActionResult Add(ShopFloorEntryModel model)
        {
            string responseText = string.Empty;
            string userId = base.HttpContext.User.Identity.Name;
            ResponseModel responseModel = new ResponseModel();
            model.UserId = userId;
            responseModel = _IShopFloorEntryRepository.Add(model);
            if (responseModel.ResponseStatus)
            {
                base.TempData["Success"] = "1";
                base.TempData["Message"] = responseModel.ResponseText;
                return RedirectToAction("Index", "ShopFloorEntry");
            }
            responseText = responseModel.ResponseText;
            base.ViewData["Error"] = "1";
            base.ViewData["Message"] = responseText;
            base.ViewBag.ShiftList = GetAllShiftMaster();
            return View(model);
        }

        [Authorize]
        [HttpGet]
        public IActionResult Edit(string docEntry)
        {
            string userId = base.HttpContext.User.Identity.Name;
            userId = _ICommonRepository.GetUserId(userId);
            ShopFloorEntryModel data = _IShopFloorEntryRepository.Get(docEntry, userId);
            //data.Type = type.ToUpper();
            base.ViewBag.ShiftList = GetAllShiftMaster();
            return View(data);
        }

        [DisableRequestSizeLimit]
        [HttpPost]
        public IActionResult Edit(ShopFloorEntryModel model)
        {
            StringValues updateButtonAttribute = base.Request.Form["Update"];
            string buttonValue = string.Empty;
            buttonValue = ((updateButtonAttribute.Count <= 0) ? "UpdateExcludeItems" : updateButtonAttribute[0]);
            model.ButtonValue = buttonValue;
            string userId = base.HttpContext.User.Identity.Name;
            userId = _ICommonRepository.GetUserId(userId);
            model.UserId = userId;
            ResponseModel responseModel = new ResponseModel();
            try
            {
                responseModel = _IShopFloorEntryRepository.Update(model);
            }
            catch (Exception ex)
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = ex.Message;
            }
            if (responseModel.ResponseStatus)
            {
                base.TempData["Success"] = "1";
                base.TempData["Message"] = responseModel.ResponseText;
                return RedirectToAction("Index", "ShopFloorEntry");
            }
            base.ViewData["Error"] = "1";
            base.ViewData["Message"] = responseModel.ResponseText + ".";
            base.ViewBag.ShiftList = GetAllShiftMaster();
            return View(model);
        }

        [HttpGet]
        public JsonResult GetPlanKey(string mcode)
        {
            List<PlanKeyModel> list = _IShopFloorEntryRepository.GetPlanKey(mcode);
            return Json(new
            {
                aaData = list
            });
        }

        [HttpPost]
        public ActionResult ShopFloorEntryAddRow(int index)
        {
            index = index - 1;
            var newRow = new InventoryTransferRowsModel() { Index = index + 1 };
            ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("VCDPDCollection[{0}]", index);
            return PartialView("~/Views/Shared/EditorTemplates/ShopFloorEntryRowsModel.cshtml", newRow);
        }
        private bool Validate(PurchaseOrderModel model, out string responseMessage)
        {
            responseMessage = string.Empty;
            try
            {
                if (string.IsNullOrEmpty(model.CardCode))
                {
                    responseMessage = "Please select business partner";
                    return false;
                }
            }
            catch (Exception)
            {
            }
            return true;
        }

        [NonAction]
        private SelectList GetAllShiftMaster()
        {
            return new SelectList(_ICommonRepository.GetAllShiftMaster(), "ID", "Name");
        }
    }
}
