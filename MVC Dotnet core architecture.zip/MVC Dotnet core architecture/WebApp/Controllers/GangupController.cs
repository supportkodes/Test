﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Repository;

namespace WebApp.Controllers
{
    public class GangupController : Controller
    {
        public readonly IGangupRepository _IGangupRepository = null;

        public readonly ICommonRepository _ICommonRepository = null;

        private IHostingEnvironment _IHostingEnvironment;

        private readonly ILogger<GangupController> _ILogger;

        public GangupController(IGangupRepository iGangupRepository, ICommonRepository iCommonRepository, IHostingEnvironment iHostingEnvironment, ILogger<GangupController> iLogger)
        {
            _IGangupRepository = iGangupRepository;
            _ICommonRepository = iCommonRepository;
            _IHostingEnvironment = iHostingEnvironment;
            _ILogger = iLogger;
        }

        [Authorize]
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            List<GangupModel> data = _IGangupRepository.GetAll();
            for (int i = 0; i < data.Count; i++)
            {
                data[i].EditLink = Url.Action("Edit", "Gangup", new { docEntry = data[i].DocEntry });
            }
            return Json(new { aaData = data });
        }

        [Authorize]
        [HttpGet]
        public IActionResult Add(string? baseEntry, string lineNo)
        {
            var userId = HttpContext.User.Identity.Name;
            GangupModel model = new GangupModel();
            if (!string.IsNullOrEmpty(baseEntry))
            {
                model = _IGangupRepository.GetClientPOGangupData(baseEntry , lineNo);
            }
            #region Gangup Rows
            if (model.WEB_GANGUP1Collection == null)
            {
                List<GangupRowsModel> GangupRowsModellList = new List<GangupRowsModel>();
                GangupRowsModel gangupRowsModel = new GangupRowsModel();
                gangupRowsModel.Index = 1;
                GangupRowsModellList.Add(gangupRowsModel);
                model.WEB_GANGUP1Collection = GangupRowsModellList;
            }
            #endregion

            string ownerId = _ICommonRepository.GetEmpId(userId);
            model.U_DocDate = DateTime.Now.ToString("dd-MM-yyyy");

            ViewBag.SalesEmployeeList = GetSalesEmployeeList(userId);
            ViewBag.ItemGroupList = GetItemGroupList();
            return View(model);
        }
        [HttpPost]
        [DisableRequestSizeLimit]
        public IActionResult Add(GangupModel model)
        {
            string responseText = string.Empty;
            string userId = base.HttpContext.User.Identity.Name;
            ResponseModel responseModel = new ResponseModel();
            model.UserId = userId;
            responseModel = Validate(model);
            if (responseModel.ResponseStatus)
            {
                responseModel = _IGangupRepository.Add(model);
                if (responseModel.ResponseStatus)
                {
                    TempData["Success"] = "1";
                    TempData["Message"] = responseModel.ResponseText;
                    return RedirectToAction("Index", "Gangup");
                }
            }
            ViewData["Error"] = "1";
            ViewData["Message"] = responseModel.ResponseText;
            ViewBag.SalesEmployeeList = GetSalesEmployeeList(userId);
            ViewBag.ItemGroupList = GetItemGroupList();
            return View(model);
        }

        private ResponseModel Validate(GangupModel model)
        {
            ResponseModel responseModel = new ResponseModel();
            responseModel.ResponseStatus = true;
            if (string.IsNullOrEmpty(model.U_SlpCode))
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Please select sales employee";
                return responseModel;
            }
            else if (string.IsNullOrEmpty(model.U_CardCode))
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Please select customer";
                return responseModel;
            }
            else if (model.U_TNoOfUPS == 0)
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Please enter total no of ups";
                return responseModel;
            }
            var totalNofOfUPS = model.WEB_GANGUP1Collection.Sum(a => a.U_NoOfUPS);
            if (model.U_TNoOfUPS != totalNofOfUPS)
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Total no of ups should match with sum of no of ups";
            }
            return responseModel;
        }

        [Authorize]
        [HttpGet]
        public IActionResult Edit(string docEntry)
        {
            GangupModel data = _IGangupRepository.Get(docEntry);
            ViewBag.ItemGroupList = GetItemGroupList();
            return View(data);
        }

        [DisableRequestSizeLimit]
        [HttpPost]
        public IActionResult Edit(GangupModel model)
        {
            string userId = HttpContext.User.Identity.Name;
            ResponseModel responseModel = new ResponseModel();
            try
            {

                responseModel = Validate(model);
                if (responseModel.ResponseStatus == true)
                {
                    responseModel = _IGangupRepository.Update(model);
                }
            }
            catch (Exception ex)
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = ex.Message;
            }
            if (responseModel.ResponseStatus == true)
            {
                TempData["Success"] = "1";
                TempData["Message"] = responseModel.ResponseText;
                return RedirectToAction("Index", "Gangup");
            }
            ViewData["Error"] = "1";
            ViewData["Message"] = responseModel.ResponseText;
            ViewBag.ItemGroupList = GetItemGroupList();
            return View(model);
        }

        [HttpPost]
        public ActionResult GangupAddRow(int index)
        {
            index = index - 1;
            var newRow = new GangupRowsModel() { Index = index + 1 };
            ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("WEB_GANGUP1Collection[{0}]", index);
            return PartialView("~/Views/Shared/EditorTemplates/GangupRowsModel.cshtml", newRow);
        }

        [HttpGet]
        public JsonResult GetGangupData(string cardcode)
        {
            List<CopyDocumentModel> list = _IGangupRepository.GetGangupData(cardcode);
            return Json(new { aaData = list });
        }
        [HttpGet]
        public JsonResult GetGangupSelectedData(string docEntry)
        {
            List<GangupRowsModel> list = _IGangupRepository.GetGangupSelectedData(docEntry);
            return Json(new { aaData = list });
        }
        [HttpGet]
        public IActionResult GetAllChildItemDetails(string itemcode)
        {
            var data = _IGangupRepository.GetAllChildItemDetails(itemcode);
            return Json(new { aaData = data });
        }

        [HttpGet]
        public IActionResult GetTotalNoofInk(string itemcodes)
        {
            var data = _IGangupRepository.GetTotalNoofInk(itemcodes);
            return Json(data);
        }

        [HttpGet]
        public IActionResult GetAllChildItemDetailsColor(string itemcode)
        {
            var data = _IGangupRepository.GetAllChildItemDetailsColor(itemcode);
            return Json(data);
        }

        [NonAction]
        private SelectList GetSalesEmployeeList(string userId)
        {
            return new SelectList(_ICommonRepository.GetAllTeamSalesEmployee(userId), "SlpCode", "SlpName");
        }

        [NonAction]
        private SelectList GetItemGroupList()
        {
            return new SelectList(_ICommonRepository.GetAllGangupItemGroup(), "ID", "Name");
        }
    }
}
