﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using WebDAL.IRepository;
using WebDAL.Models;

namespace WebApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        public readonly ICommonRepository _ICommonRepository = null;

        public HomeController(ILogger<HomeController> logger, ICommonRepository iCommonRepository)
        {
            _logger = logger;
            _ICommonRepository = iCommonRepository;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }


        [Authorize]
        [HttpGet]
        public ActionResult UploadMissingAttachment()
        {
            string attachmentPath = _ICommonRepository.GetAttachmentPath();
            List<DocumentModel_Attachment> list = _ICommonRepository.GetEmptyFileNameList();
            for (int i = 0; i < list.Count; i++)
            {
                try
                {
                    string filePath = list[i].srcPath;
                    string fileName = Path.GetFileName(filePath);
                    string destFilePath = attachmentPath + fileName;
                    string fileNameToUpdate = Path.GetFileNameWithoutExtension(filePath);
                    System.IO.File.Copy(filePath, destFilePath, true);
                    _ICommonRepository.UpdateAttachementFileName(list[i].AbsEntry, fileNameToUpdate);
                }
                catch { }
            }
            return View();
        }
    }
}
