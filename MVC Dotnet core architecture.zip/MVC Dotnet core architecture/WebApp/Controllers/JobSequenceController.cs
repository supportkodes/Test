﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using WebDAL.Helper;
using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Repository;

namespace WebApp.Controllers
{
public class JobSequenceController : Controller
{
    public readonly IJobSequenceRepository _IJobSequenceRepository = null;

    public readonly ICommonRepository _ICommonRepository = null;

    private IHostingEnvironment _IHostingEnvironment;

    private readonly ILogger<JobSequenceController> _ILogger;

    public JobSequenceController(IJobSequenceRepository iJobSequenceRepository, ICommonRepository iCommonRepository, IHostingEnvironment iHostingEnvironment, ILogger<JobSequenceController> iLogger)
    {
        _IJobSequenceRepository = iJobSequenceRepository;
        _ICommonRepository = iCommonRepository;
        _IHostingEnvironment = iHostingEnvironment;
        _ILogger = iLogger;
    }

    [Authorize]
    [HttpGet]
    public IActionResult Index()
    {
        return View();
    }

    [HttpGet]
    public IActionResult GetAll()
    {
        var userId = HttpContext.User.Identity.Name;
        List<JobSequenceModel> data = _IJobSequenceRepository.GetAll();
        for (int i = 0; i < data.Count; i++)
        {
            data[i].EditLink = Url.Action("Edit", "JobSequence", new { docentry = data[i].DocEntry });
        }
        return Json(new { aaData = data });
    }

    [Authorize]
    [HttpGet]
    public IActionResult Add()
    {
        string userId = base.HttpContext.User.Identity.Name;
        string ownerId = _ICommonRepository.GetEmpId(userId);
        JobSequenceModel jobSequenceModel = new JobSequenceModel();
        jobSequenceModel.U_DocDt = DateTime.Now.ToString("dd-MM-yyyy");
        List<JobSequenceRowsModel> jobSequenceRowsModelList = new List<JobSequenceRowsModel>();
        JobSequenceRowsModel jobSequenceRowsModel = new JobSequenceRowsModel();
        jobSequenceRowsModel.Index = 1;
        jobSequenceRowsModelList.Add(jobSequenceRowsModel);
        jobSequenceModel.VCJBSDCollection = jobSequenceRowsModelList;
        base.ViewBag.EmployeeList = GetEmployeeList();
        return View(jobSequenceModel);
    }

    [HttpPost]
    [DisableRequestSizeLimit]
    public IActionResult Add(JobSequenceModel model)
    {
        string responseText = string.Empty;
        string userId = base.HttpContext.User.Identity.Name;
        ResponseModel responseModel = new ResponseModel();
        model.UserId = userId;
        responseModel = _IJobSequenceRepository.Add(model);
        if (responseModel.ResponseStatus)
        {
            base.TempData["Success"] = "1";
            base.TempData["Message"] = responseModel.ResponseText;
            return RedirectToAction("Index", "JobSequence");
        }
        responseText = responseModel.ResponseText;
        base.ViewBag.EmployeeList = GetEmployeeList();
        base.ViewData["Error"] = "1";
        base.ViewData["Message"] = responseText;
        return View(model);
    }

    [Authorize]
    [HttpGet]
    public IActionResult Edit(string docEntry)
    {
        string userId = base.HttpContext.User.Identity.Name;
        userId = _ICommonRepository.GetUserId(userId);
        JobSequenceModel data = _IJobSequenceRepository.Get(docEntry,userId);
        base.ViewBag.EmployeeList = GetEmployeeList();
        return View(data);
    }

    [DisableRequestSizeLimit]
    [HttpPost]
    public IActionResult Edit(JobSequenceModel model)
    {
        StringValues updateButtonAttribute = base.Request.Form["Update"];
        string buttonValue = string.Empty;
        buttonValue = ((updateButtonAttribute.Count <= 0) ? "UpdateExcludeItems" : updateButtonAttribute[0]);
        model.ButtonValue = buttonValue;
        string userId = base.HttpContext.User.Identity.Name;
        userId = _ICommonRepository.GetUserId(userId);
        model.UserId = userId;
        ResponseModel responseModel = new ResponseModel();
        try
        {
            responseModel = _IJobSequenceRepository.Update(model);
        }
        catch (Exception ex)
        {
            responseModel.ResponseStatus = false;
            responseModel.ResponseText = ex.Message;
        }
        if (responseModel.ResponseStatus)
        {
            base.TempData["Success"] = "1";
            base.TempData["Message"] = responseModel.ResponseText;
            return RedirectToAction("Index", "JobSequence");
        }
        base.ViewData["Error"] = "1";
        base.ViewData["Message"] = responseModel.ResponseText + ".";
        base.ViewBag.EmployeeList = GetEmployeeList();
        return View(model);
    }

    [HttpPost]
    public ActionResult JobSequenceAddRow(int index)
    {
        index--;
        JobSequenceRowsModel newRow = new JobSequenceRowsModel
        {
            Index = index + 1
        };
        base.ViewData.TemplateInfo.HtmlFieldPrefix = $"DocumentLines[{index}]";
        base.ViewBag.CategoryList = GetCategoryList();
        return PartialView("~/Views/Shared/EditorTemplates/JobSequenceRowsModel.cshtml", newRow);
    }

    [HttpPost]
    public ActionResult AttachmentAddRow(int index)
    {
        index--;
        POModel_Attachment newRow = new POModel_Attachment
        {
            Index = index + 1
        };
        base.ViewData.TemplateInfo.HtmlFieldPrefix = $"Attachments2_Lines[{index}]";
        return PartialView("~/Views/Shared/EditorTemplates/POModel_Attachment.cshtml", newRow);
    }

    private bool Validate(PurchaseOrderModel model, out string responseMessage)
    {
        responseMessage = string.Empty;
        try
        {
            if (string.IsNullOrEmpty(model.CardCode))
            {
                responseMessage = "Please select business partner";
                return false;
            }
        }
        catch (Exception)
        {
        }
        return true;
    }

		[HttpGet]
		public JsonResult GetJCNo(string mcode, string jobNo)
		{
			var userId = HttpContext.User.Identity.Name;
			List<JCModel> list = _IJobSequenceRepository.GetJCNo(mcode, jobNo);
			return Json(new { aaData = list });
		}

		[HttpGet]
		public JsonResult GetOPNo(string planno, string mcode)
		{
			List<JCModel> list = _IJobSequenceRepository.GetOPNo(planno , mcode);
			return Json(new { aaData = list });
		}

		[NonAction]
    private SelectList GetPaymentTermsList()
    {
        return new SelectList(_ICommonRepository.GetAllPaymentTermsList(), "GroupNum", "PymntGroup");
    }

    [NonAction]
    private SelectList GetPlaceOfSupplyList()
    {
        return new SelectList(_ICommonRepository.GetPlaceOfSupply(), "ID", "Name");
    }

    [NonAction]
    private SelectList GetLocationList()
    {
        return new SelectList(_ICommonRepository.GetLocationList(), "ID", "Name");
    }

    [NonAction]
    private SelectList GetWarehouseList()
    {
        return new SelectList(_ICommonRepository.GetAllWarehouse(), "WhsCode", "WhsName");
    }

    [NonAction]
    private SelectList GetCurrencyList()
    {
        return new SelectList(_ICommonRepository.GetAllCurrency(), "CurrCode", "CurrName");
    }

    [NonAction]
    private SelectList GetBranchList()
    {
        return new SelectList(_ICommonRepository.GetAllBranch(), "BPLId", "BPLName");
    }

    [NonAction]
    private SelectList GetShippingTypeList()
    {
        return new SelectList(_ICommonRepository.GetAllShippingType(), "TrnspCode", "TrnspName");
    }

    [NonAction]
    private SelectList GetHSNList()
    {
        return new SelectList(_ICommonRepository.GetAllHSN(), "Chapter", "ChapterID");
    }

    [NonAction]
    private SelectList GetCategoryList()
    {
        return new SelectList(_ICommonRepository.GetUDFValuesList("RDR1", "Category"), "ID", "Name");
    }

    [NonAction]
    private SelectList GetYNList()
    {
        return new SelectList(new List<SelectListItem>
        {
            new SelectListItem
            {
                Value = "Y",
                Text = "Yes"
            },
            new SelectListItem
            {
                Value = "N",
                Text = "No"
            }
        }, "Value", "Text");
    }

    [NonAction]
    private SelectList GetEmployeeList()
    {
        return new SelectList(_ICommonRepository.GetAllEmployee(), "empID", "Name");
    }

    [NonAction]
    private SelectList GetSalesEmployeeList(string userId)
    {
        return new SelectList(_ICommonRepository.GetAllTeamSalesEmployee(userId), "SlpCode", "SlpName");
    }

    [NonAction]
    private SelectList GetSalesEmployeeList()
    {
        return new SelectList(_ICommonRepository.GetAllSalesEmployee(), "SlpCode", "SlpName");
    }

   }
}
