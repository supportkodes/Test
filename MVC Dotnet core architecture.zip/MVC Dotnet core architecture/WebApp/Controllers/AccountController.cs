﻿using DocumentFormat.OpenXml.EMMA;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Security.Claims;
using System.Text;
using WebDAL.Helper;
using WebDAL.IRepository;
using WebDAL.Models;

namespace WebApp.Controllers
{
    public class AccountController : Controller
    {
        public readonly IAccountRepository _IAccountRepository = null;
        private readonly ILogger<AccountController> _ILogger;

        public AccountController(IAccountRepository iAccountRepository, ILogger<AccountController> iLogger)
        {
            //Dependency Injection
            _IAccountRepository = iAccountRepository;
            _ILogger = iLogger;
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Login(string returnUrl)
        {
            var userAgent = HttpContext.Request.Headers["User-Agent"].ToString();
            TempData["Success"] = "1";
            //TempData["Message"] = "Your MAC IP is : " + userAgent;

            //var remoteIpAddress = HttpContext.Request.Host;
            //string clientIpAddress = HttpContext.RequestServices.use;

            //var remoteIpAddress = HttpContext.Request.Headers["X-Forwarded-For"].ToString();
            //TempData["Success"] = "1";
            //TempData["Message"] = "Your MAC IP is : " + remoteIpAddress;

            ViewBag.ReturnUrl = returnUrl;
            _ILogger.LogDebug("Account logged");
            //ViewBag.UserTypeList = GetUserTypeList();
            return View();
        }

        [NonAction]
        private SelectList GetUserTypeList()
        {
            List<SelectListItem> userList = new List<SelectListItem>();
            userList.Add(new SelectListItem() { Text = "E", Value = "Employee" });
            userList.Add(new SelectListItem() { Text = "C", Value = "Customer" });
            return new SelectList(userList, "Text", "Value");
        }

        [HttpPost]
        public IActionResult Login(LoginModel loginModel, string returnUrl)
        {
            if (ModelState.IsValid)
            {
                ResponseModel responseModel = _IAccountRepository.ValidateLogin(loginModel);
                if (responseModel.ResponseStatus == true)
                {
                    LoginData(loginModel);
                    if (!String.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                    {
                        return Redirect(returnUrl);
                    }
                    else
                    {
                        return RedirectToAction("Index", "Home");
                    }
                }
                else
                {
                    TempData["Error"] = "1";
                    TempData["Message"] = responseModel.ResponseText;
                    return View(loginModel);
                }
            }
            return View(loginModel);
            //ViewBag.UserTypeList = GetUserTypeList();
            //return View();
        }

        [HttpGet]
        public JsonResult GenerateOTP(string userId)
        {
            ResponseModel model = new ResponseModel();
            if (string.IsNullOrEmpty(userId))
            {
                model.ResponseText = "Please enter user id";
                model.ResponseStatus = false;
            }
            else
            {
                UserModel userModel = _IAccountRepository.GetUserDetails(userId);
                if (userModel.ResponseMessage == "1")
                {
                    string empId = userModel.empID;
                    if (string.IsNullOrEmpty(empId))
                    {
                        model.ResponseText = "Email address does not exist";
                    }
                    else
                    {
                        Helpers _helpers = new Helpers();
                        string otp = _helpers.GenerateOTP();
                        model = _IAccountRepository.UpdateOTP(userId, otp);
                        model = SendOTP(userId, otp);
                        if (model.ResponseStatus == true)
                        {
                            model.ResponseText = "OTP sent to your mail";
                        }
                        else
                        {
                            model.ResponseText = "OTP Generation Failed: " + model.ResponseText;
                        }
                    }
                }
                else
                {
                    model.ResponseText = userModel.ResponseMessage;
                }
            }
            return Json(new { model = model });
        }

        private ResponseModel SendOTP(string userId, string otp)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                //UserModel userModel = _IAccountRepository.GetUserDetails(userId);
                string userEmailAddress = userId;
                SendMail _sendMail = new SendMail();
                string message = "";
                string subject = "Web Portal OTP";
                StringBuilder sbBody = new StringBuilder();
                //sbBody.Replace("{OTP}", otp);
                sbBody.Append("<p> Dear Sir/Madam <p/>");
                sbBody.Append("<p> Please find otp : " + otp + "<p/>");
                sbBody.Append("<p> Regards <br/>");
                sbBody.Append("   Web Admin<p/>");
                string from = ConfigManager.GetSMTP_UserName();
                bool result = _sendMail.sendMail(from, userEmailAddress, "", "", subject, sbBody.ToString(), null, out message);
                responseModel.ResponseStatus = result;
                responseModel.ResponseText = message;
            }
            catch (Exception ex)
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = ex.Message;
            }
            return responseModel;
        }
        public IActionResult LogOut()
        {
            HttpContext.SignOutAsync(
               CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login", "Account");
        }


        [HttpGet]   
        public JsonResult GetUserDeptFormList()
        {
            var userId = HttpContext.User.Identity.Name;
            var list = _IAccountRepository.GetUserDeptFormList(userId);
            return Json(new { model = list });
        }

        private void LoginData(LoginModel loginModel)
        {
            UserModel userModel = _IAccountRepository.GetUserDetails(loginModel.UserCode);
            HttpContext.Session.SetString("UserCode", loginModel.UserCode);
            TempData["UserCode"] = loginModel.UserCode;
            var claims = new List<Claim>
                    {
                        new Claim(ClaimTypes.Name, loginModel.UserCode),
                        new Claim("FullName", loginModel.UserCode),
                        new Claim("Department", userModel.Department),
                        new Claim("DepartmentId", userModel.DepartmentId),
                        new Claim("EmpId", userModel.empID),
                        new Claim(ClaimTypes.Role, "Administrator"),
                    };
            var claimsIdentity = new ClaimsIdentity(
                                claims, CookieAuthenticationDefaults.AuthenticationScheme);
            HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                new ClaimsPrincipal(claimsIdentity),
                new AuthenticationProperties
                {
                    IsPersistent = true
                }
            );

        }


        [HttpGet]
        public IActionResult InstanceLogin(string id, string data)
        {
            string passphrase = "b14ca5898a4e4133bbce2ea2315a1916";
            if (!string.IsNullOrEmpty(data))
            {
                string plainText = StringCipher.DecryptHexToString(data);
                DateTime dt = DateTime.ParseExact(plainText, "yyyyMMddhhmmtt", CultureInfo.InvariantCulture);
                DateTime dtExpiry = dt.AddMinutes(5);
                if (dtExpiry.Date == DateTime.Now.Date && dtExpiry > DateTime.Now)
                {
                    string emailAddress = _IAccountRepository.GetEmailFromMacID(id);
                    LoginModel   userModel = new LoginModel();
                    userModel.UserCode = emailAddress;
                    LoginData(userModel);
                    return RedirectToAction("Index", "Home");
                }
            }
            return View();
        }
    }
}
