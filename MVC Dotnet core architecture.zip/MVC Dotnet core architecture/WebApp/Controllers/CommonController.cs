﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using System.Net;
using DocumentFormat.OpenXml.EMMA;
using DocumentFormat.OpenXml.Spreadsheet;
using static WebDAL.Models.PPCDetailsModel;
using Microsoft.AspNetCore.Authorization;

namespace WebApp.Controllers
{
    public class CommonController : Controller
    {
        public readonly ICommonRepository _ICommonRepository = null;

        public CommonController(ICommonRepository iCommonRepository)
        {
            _ICommonRepository = iCommonRepository;
        }

        [HttpGet]
        public JsonResult GetAllBP(string cardType)
        {
            var userId = HttpContext.User.Identity.Name;
            List<BusinessPartnerModel> list = _ICommonRepository.GetAllBP(userId, cardType);
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetCardCodeList()
        {
            var userId = HttpContext.User.Identity.Name;
            List<BusinessPartnerModel> list = _ICommonRepository.GetCardCodeList();
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetBP_SalesEmployeeWise(string slpcode, string cardType)
        {
            var userId = HttpContext.User.Identity.Name;
            List<BusinessPartnerModel> list = _ICommonRepository.GetBP_SalesEmployeeWise(slpcode, cardType);
            return Json(new { aaData = list });
        }
        [HttpGet]
        public JsonResult GetBP_VendorWise()
        {
            var userId = HttpContext.User.Identity.Name;
            List<BusinessPartnerModel> list = _ICommonRepository.GetBP_VendorWise();
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetAllBP_VendorWise()
        {
            var userId = HttpContext.User.Identity.Name;
            List<BusinessPartnerModel> list = _ICommonRepository.GetAllBP_VendorWise();
            return Json(new { aaData = list });
        }


        [HttpGet]
        public JsonResult GetAllContractorVandorWise()
        {
            var userId = HttpContext.User.Identity.Name;
            List<BusinessPartnerModel> list = _ICommonRepository.GetAllContractorVandorWise();
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetAllMachineGrpCode()
        {
            var userId = HttpContext.User.Identity.Name;
            List<MachineGrpCodeModel> list = _ICommonRepository.GetAllMachineGrpCode();
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetMachineCodeBasedGrpCode(string macmrp)
        {
            var userId = HttpContext.User.Identity.Name;
            List<MachineGrpCodeModel> list = _ICommonRepository.GetMachineCodeBasedGrpCode(macmrp);
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetAllMachineCode()
        {
            var userId = HttpContext.User.Identity.Name;
            List<MachineGrpCodeModel> list = _ICommonRepository.GetAllMachineCode();
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetAllAccount()
        {
            var userId = HttpContext.User.Identity.Name;
            List<CommonValueModel> list = _ICommonRepository.GetAllAccount();
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetAllProjectData()
        {
            var userId = HttpContext.User.Identity.Name;
            List<CommonValueModel> list = _ICommonRepository.GetAllProjectData();
            return Json(new { aaData = list });
        }


        [HttpGet]
        public JsonResult GetSQData(string cardcode)
        {
            List<CopyDocumentModel> list = _ICommonRepository.GetSQData(cardcode);
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetSOData(string cardcode)
        {
            List<CopyDocumentModel> list = _ICommonRepository.GetSOData(cardcode);
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetCopyFromITRData(string whscode)
        {
            List<CopyDocumentModel> list = _ICommonRepository.GetCopyFromITRData(whscode);
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetContractorData()
        {
            List<InventoryTransferModel> list = _ICommonRepository.GetContractorData();
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetWhsBinQuantity(string whscode)
        {
            List<InventoryTransferModel> list = _ICommonRepository.GetWhsBinQuantity(whscode);
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetWhsBinLocation(string whscode)
        {
            InventoryTransferModel model = _ICommonRepository.GetWhsBinLocation(whscode);
            return Json(new { aaData = model });
        }


        [HttpGet]
        public JsonResult GetAllItem(string series, string cardcode)
        {
            List<ItemModel> list = _ICommonRepository.GetAllItem(series, cardcode);
            return Json(new { aaData = list });
        }


        [HttpGet]
        public JsonResult GetAllInksItem(string group)
        {
            List<ItemModel> list = _ICommonRepository.GetAllInksItem(group);
            return Json(new { aaData = list });
        }


        [HttpGet]
        public JsonResult GetAllPurchaseItem()
        {
            List<ItemModel> list = _ICommonRepository.GetAllPurchaseItem();
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetAllItemList()
        {
            List<ItemModel> list = _ICommonRepository.GetAllItemList();
            return Json(new { aaData = list });
        }

        //[HttpGet]
        //public JsonResult GetAllItem()
        //{
        //    List<ItemModel> list = _ICommonRepository.GetAllItem();
        //    return Json(new { aaData = list });
        //}

        [HttpGet]
        public JsonResult GetClientPOItemList(string docdate)
        {
            List<ItemModel> list = _ICommonRepository.GetClientPOItemList(docdate);
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetClientPORefItemList(string cardcode)
        {
            List<ItemModel> list = _ICommonRepository.GetClientPORefItemList(cardcode);
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetNoofUpsList(string KLDNo)
        {
            List<ItemModel> list = _ICommonRepository.GetNoofUpsList(KLDNo);
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetClientPOPunchKLDList(string kldno)
        {
            List<PunchMasterModel> list = _ICommonRepository.GetClientPOPunchKLDList(kldno);
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetItemsBasedOnItemGroup(string itemgroup)
        {
            List<ItemModel> list = _ICommonRepository.GetItemsBasedOnItemGroup(itemgroup);
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetAllSOList(string cardcode)
        {
            List<SoModel> list = _ICommonRepository.GetAllSOList(cardcode);
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetSOSelectedData(string soUniqueID)
        {
            SoModel model = _ICommonRepository.GetSOSelectedData(soUniqueID);
            return Json(new { aaData = model });
        }

        [HttpGet]
        public JsonResult GetItemSelectedData(string itemcode)
        {
            ItemMasterModel model = _ICommonRepository.GetItemSelectedData(itemcode);
            return Json(new { aaData = model });
        }

        [HttpGet]
        public JsonResult GetAllRouteStagesList()
        {
            List<RouteModel> list = _ICommonRepository.GetAllRouteStagesList();
            return Json(new { aaData = list });
        }
        [HttpGet]
        public JsonResult GetAllInvoiceList(string cardcode)
        {
            List<ItemModel> list = _ICommonRepository.GetAllInvoiceList(cardcode);
            return Json(new { aaData = list });
        }

        public JsonResult GetAllWarehouseList()
        {
            List<CommonValueModel> list = _ICommonRepository.GetAllWarehouseList();
            return Json(new { aaData = list });
        }
        [HttpGet]
        public JsonResult GetItemDetails(string series, string cardcode, string itemcode)
        {
            List<ItemModel> list = _ICommonRepository.GetItemDetails(series, cardcode, itemcode);
            return Json(new { aaData = list });
        }


        [HttpGet]
        public JsonResult GetItemDetails_ItemCode(string itemcode)
        {
            ItemModel list = _ICommonRepository.GetItemDetails_ItemCode(itemcode);
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetItem_FlexoDetails(string cardcode, string address, string itemcode)
        {
            FlexoModel model = _ICommonRepository.GetItem_FlexoDetails(cardcode, address, itemcode);
            return Json(new { aaData = model });
        }

        [HttpGet]
        public JsonResult GetPriceofSheetDetails(string cardcode, string itemcode)
        {
            FlexoModel model = _ICommonRepository.GetPriceofSheetDetails(cardcode, itemcode);
            return Json(new { aaData = model });
        }

        [HttpGet]
        public JsonResult GetTaxRate(string taxcode)
        {
            var data = _ICommonRepository.GetTaxRate(taxcode);
            return Json(new { aaData = data });
        }

        [HttpGet]
        public JsonResult GetAllSQItem()
        {
            List<ItemModel> list = _ICommonRepository.GetAllSQItem();
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetWarehouse_BranchWise(string bplId)
        {
            List<WarehouseModel> list = _ICommonRepository.GetWarehouse_BranchWise(bplId);
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetAllWarehouse_BranchWise(string bplId)
        {
            List<WarehouseModel> list = _ICommonRepository.GetAllWarehouse_BranchWise(bplId);
            return Json(new { aaData = list });
        }
        [HttpGet]
        public JsonResult GetBranchDefaultWarehouse(string bplId)
        {
            string data = _ICommonRepository.GetBranchDefaultWarehouse(bplId);
            return Json(data);
        }

        [HttpGet]
        public JsonResult GetSeries_BranchWise(string bplId, string objCode)
        {
            List<SeriesModel> list = _ICommonRepository.GetSeries_BranchWise(bplId, objCode);
            return Json(new { aaData = list });
        }


        [HttpGet]
        public JsonResult GetSeries_WarehouseWise(string whscode, string objCode)
        {
            List<SeriesModel> list = _ICommonRepository.GetSeries_WarehouseWise(whscode, objCode);
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetWarehouseDefaultBinCode(string whscode)
        {
            string data = _ICommonRepository.GetWarehouseDefaultBinCode(whscode);
            return Json(data);
        }

        [HttpGet]
        public JsonResult GetItemWarehouseStock(string itemcode, string whscode)
        {
            string data = _ICommonRepository.GetItemWarehouseStock(itemcode, whscode);
            return Json(data);
        }


        [HttpGet]
        public JsonResult GetWarehouseLocation(string whscode)
        {
            var data = _ICommonRepository.GetWarehouseLocation(whscode);
            return Json(new { aaData = data });
        }

        [HttpGet]
        public JsonResult GetLocationAddress(string location)
        {
            var data = _ICommonRepository.GetLocationAddress(location);
            return Json(new { aaData = data });
        }

        [HttpGet]
        public JsonResult GetLocationAddressBasedOnName(string location)
        {
            var data = _ICommonRepository.GetLocationAddressBasedOnName(location);
            return Json(new { aaData = data });
        }


        [HttpGet]
        public JsonResult GetObjectTypeWiseSeries(string objCode)
        {
            List<SeriesModel> list = _ICommonRepository.GetObjectTypeWiseSeries(objCode);
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetNextDocNum(string series)
        {
            string docNum = _ICommonRepository.GetNextDocNum(series);
            return Json(new { aaData = docNum });
        }

        [HttpGet]
        public JsonResult GetWebSeriesNextNumber(string objectType, string type)
        {
            string docNum = _ICommonRepository.GetWebSeriesNextNumber(objectType, type);
            return Json(docNum);
        }


        [HttpGet]
        public JsonResult GetAllTaxCode(string documentType, string address)
        {
            List<TaxCodeModel> list = _ICommonRepository.GetAllTaxCode(documentType, address);
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetAllTaxCodeItem(string cardcode, string address, string itemcode, string doctype)
        {
            List<TaxCodeModel> list = _ICommonRepository.GetAllTaxCodeItem(cardcode, address, itemcode, doctype);
            return Json(new { aaData = list });
        }


        [HttpGet]
        public JsonResult GetAllPurchaseTaxCode(string cardcode, string address)
        {
            List<TaxCodeModel> list = _ICommonRepository.GetAllPurchaseTaxCode(cardcode, address);
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetItemTaxCode(string itemcode, string state)
        {
            List<TaxCodeModel> list = _ICommonRepository.GetItemTaxCode(itemcode, state);
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetAllHSN()
        {
            List<HSNModel> list = _ICommonRepository.GetAllHSN();
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetAllSAC()
        {
            List<HSNModel> list = _ICommonRepository.GetAllSAC();
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetAllCurrency()
        {
            List<CurrencyModel> list = _ICommonRepository.GetAllCurrency();
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetBPAddresses(string cardcode, string adresType)
        {
            List<AddressModel> list = _ICommonRepository.GetBPAddresses(cardcode, adresType);
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetDefaultBPAddresses(string cardcode)
        {
            DefaultAddressModel address = _ICommonRepository.GetDefaultBPAddresses(cardcode);
            return Json(new { aaData = address });
        }

        [HttpGet]
        public JsonResult GetBPAddressDetails(string cardcode, string adresType, string addressId)
        {
            AddressModel data = _ICommonRepository.GetBPAddressDetails(cardcode, adresType, addressId);
            return Json(new { aaData = data });
        }

        [HttpGet]
        public JsonResult GetPrice(string cardcode, string itemcode, string docdate, double? quantity)
        {
            string price = _ICommonRepository.GetPrice(cardcode, itemcode, docdate, quantity);
            return Json(new { aaData = price });
        }

        [HttpGet]
        public JsonResult GetItemwiseKLDNo(string itemcode)
        {
            string kldno = _ICommonRepository.GetItemwiseKLDNo(itemcode);
            return Json(new { aaData = kldno });
        }
        [HttpGet]
        public JsonResult GetItemBinQuantity(string itemcode, string whscode)
        {
            string value = _ICommonRepository.GetItemBinQuantity(itemcode, whscode);
            return Json(new { aaData = value });
        }

        [HttpGet]
        public JsonResult GetDocRate(string currency, string docdate)
        {
            string price = _ICommonRepository.GetDocRate(currency, docdate);
            return Json(new { aaData = price });
        }

        [HttpGet]
        public JsonResult GetBPPaymentTerm(string cardcode)
        {
            string price = _ICommonRepository.GetBPPaymentTerm(cardcode);
            return Json(new { aaData = price });
        }
        public ActionResult BusinessPartnerModal()
        {
            return PartialView();
        }
        public ActionResult VendorModal()
        {
            return PartialView();
        }
        public ActionResult SalesEmpModal()
        {
            return PartialView();
        }

        public ActionResult WarehouseModal()
        {
            return PartialView();
        }

        [HttpPost]
        public JsonResult RemoveDraft(string docEntry)
        {
            ResponseModel responseModel = new ResponseModel();
            responseModel = _ICommonRepository.RemoveDraft(docEntry);
            return Json(new { value = responseModel });
        }


        [HttpPost]
        public JsonResult AddBrand(string name, string type)
        {
            BrandModel model = new BrandModel();
            model.U_Desc = name;
            model.U_Btype = type;
            ResponseModel responseModel = new ResponseModel();
            responseModel = _ICommonRepository.AddBrand(model);
            return Json(new { aaData = responseModel });
        }

        [HttpPost]
        public JsonResult AddVariant(string code, string name)
        {
            VariantModel model = new VariantModel();
            model.U_Code = code;
            model.U_Desc = name;
            ResponseModel responseModel = new ResponseModel();
            responseModel = _ICommonRepository.AddVariant(model);
            return Json(new { aaData = responseModel });
        }


        [HttpPost]
        public JsonResult AddProfile(string code, string name)
        {
            VariantModel model = new VariantModel();
            model.U_Code = code;
            model.U_Desc = name;
            ResponseModel responseModel = new ResponseModel();
            responseModel = _ICommonRepository.AddProfile(model);
            return Json(new { aaData = responseModel });
        }

        [HttpPost]
        public JsonResult AddSize(string code, string name)
        {
            VariantModel model = new VariantModel();
            model.U_Code = code;
            model.U_Desc = name;
            ResponseModel responseModel = new ResponseModel();
            responseModel = _ICommonRepository.AddSize(model);
            return Json(new { aaData = responseModel });
        }


        [HttpPost]
        public JsonResult AddTypeOfSubstrate(string code, string name)
        {
            VariantModel model = new VariantModel();
            model.U_Code = code;
            model.U_Desc = name;
            ResponseModel responseModel = new ResponseModel();
            responseModel = _ICommonRepository.AddTypeOfSubstrate(model);
            return Json(new { aaData = responseModel });
        }

        [HttpPost]
        public JsonResult AddVarnish(string code, string name)
        {
            VariantModel model = new VariantModel();
            model.U_Code = code;
            model.U_Desc = name;
            ResponseModel responseModel = new ResponseModel();
            responseModel = _ICommonRepository.AddVarnish(model);
            return Json(new { aaData = responseModel });
        }
        public ActionResult ItemModal()
        {
            return PartialView();
        }

        [HttpGet]
        public JsonResult GetAllPOCustomer()
        {
            List<BusinessPartnerModel> list = _ICommonRepository.GetAllPOCustomer();
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetAllCustomer()
        {
            List<CommonValueModel> list = _ICommonRepository.GetAllCustomer();
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetAllKLDItem()
        {
            List<ItemModel> list = _ICommonRepository.GetAllKLDItem();
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetAllKLDNo()
        {
            List<CommonValueModel> list = _ICommonRepository.GetAllKLDNo();
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetAllBrand(string itemgroupcode)
        {
            List<CommonValueModel> list = _ICommonRepository.GetAllItemBrand(itemgroupcode);
            return Json(new { aaData = list });
        }

        //[HttpGet]
        //public JsonResult GetAllItemBrand()
        //{
        //    List<CommonValueModel> list = _ICommonRepository.GetAllItemBrand();
        //    return Json(new { aaData = list });
        //}

        [HttpGet]
        public JsonResult GetAllUOMCode(string ugpEntry)
        {
            List<CommonValueModel> list = _ICommonRepository.GetAllUOMCode(ugpEntry);
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetAllPricingUnit(string ugpEntry)
        {
            List<CommonValueModel> list = _ICommonRepository.GetAllPricingUnit(ugpEntry);
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetAllTypeOfSubstrate()
        {
            List<CommonValueModel> list = _ICommonRepository.GetAllTypeOfSubstrate();
            return Json(new { aaData = list });
        }


        [HttpGet]
        public JsonResult GetAllVariant()
        {
            List<CommonValueModel> list = _ICommonRepository.GetAllVariant();
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetAllProfile()
        {
            List<CommonValueModel> list = _ICommonRepository.GetAllProfileCode();
            return Json(new { aaData = list });
        }
        [HttpGet]
        public JsonResult GetAllVarnish()
        {
            List<CommonValueModel> list = _ICommonRepository.GetAllVarnish();
            return Json(new { aaData = list });
        }


        [HttpGet]
        public JsonResult GetAllSalesEmployee()
        {
            List<SalesEmployeeModel> list = _ICommonRepository.GetAllSalesEmployee();
            return Json(new { aaData = list });
        }
        //[HttpGet]
        //public JsonResult GetAllECRSalesEmployee()
        //{
        //	List<SalesEmployeeModel> list = _ICommonRepository.GetAllECRSalesEmployee();
        //	return Json(new { aaData = list });
        //}


        //[HttpGet]
        //public JsonResult GetAllHSN()
        //{
        //	List<CommonValueModel> list = _ICommonRepository.GetAllHSN();
        //	return Json(new { aaData = list });
        //}

        [HttpGet]
        public JsonResult GetAllSize()
        {
            List<CommonValueModel> list = _ICommonRepository.GetAllSizeCode();
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetAllMill()
        {
            List<CommonValueModel> list = _ICommonRepository.GetAllMill();
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetBOMComponents(string itemcode, string cardcode, string address)
        {
            List<BOMModel> list = _ICommonRepository.GetBOMComponents(itemcode);
            for (int i = 0; i < list.Count; i++)
            {
                try
                {
                    FlexoModel model = _ICommonRepository.GetItem_FlexoDetails(cardcode, address, list[i].ItemCode);
                    list[i].RollDirection = model.RollDirection;
                    list[i].Packing = model.Packing;


                }
                catch (Exception ex)
                {

                }
                try
                {

                    string isArtworkedApproved = _ICommonRepository.GetArtworkApproved(list[i].ItemCode);
                    list[i].ArtworkApproved = isArtworkedApproved == string.Empty ? "N" : isArtworkedApproved;
                }
                catch { }
            }
            return Json(new { aaData = list });
        }


        [HttpGet]
        public JsonResult GetItemBrand(string itemgroupcode)
        {
            var value = _ICommonRepository.GetItemBrand(itemgroupcode);
            return Json(new { aaData = value });
        }


        public FileResult DownloadFile(string filePath)
        {
            //Build the File Path.
            //Read the File data into Byte Array.
            byte[] bytes = System.IO.File.ReadAllBytes(filePath);
            string fileName = Path.GetFileName(filePath);
            //Send the File to Download.
            return File(bytes, "application/octet-stream", fileName);
        }

        [HttpGet]
        public JsonResult GetAllEmployee()
        {
            List<EmployeeModel> list = _ICommonRepository.GetAllEmployee();
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetAllPrepressEmployee()
        {
            List<CommonValueModel> list = _ICommonRepository.GetAllPrepressEmployee();
            return Json(new { aaData = list });
        }

        public FileResult ShowPDF(string filePath)
        {
            var fileStream = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Read);
            return File(fileStream, "application/pdf");
        }
        [HttpGet]
        public JsonResult GetUserId()
        {
            var userId = HttpContext.User.Identity.Name;
            return Json(userId);
        }

        [HttpGet]
        public IActionResult GetDraftApprovalUserIDs(string docEntry)
        {
            var data = _ICommonRepository.GetDraftApprovalUserIDs(docEntry);
            return Json(new { aaData = data });
        }

        [HttpGet]
        public JsonResult GetItemAvailableStock(string itemcode, string whscode)
        {
            var list = _ICommonRepository.GetItemAvailableStock(itemcode, whscode);
            return Json(new { aaData = list });
        }
        [HttpGet]
        public JsonResult GetItemAvailableStock_AutoBatchQty(string itemcode, string whscode, double requiredQty)
        {
            var model = _ICommonRepository.GetItemAvailableStock_AutoBatchQty(itemcode, whscode, requiredQty);
            return Json(new { aaData = model });
        }

        [HttpGet]
        public JsonResult GetKLDNo()
        {
            var list = _ICommonRepository.GetKLDNo();
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetECRAssignTo(string previousStage)
        {
            List<CommonValueModel> list = new List<CommonValueModel>();
            var userId = HttpContext.User.Identity.Name;
            if (string.IsNullOrEmpty(previousStage))
            {
                if (userId == "manoj@ajantaprintarts.com")
                {
                    list.Add(new CommonValueModel { ID = "11", Name = "QC" });
                }
                else
                {
                    list.Add(new CommonValueModel { ID = "1", Name = "Sales Employee" });
                }
            }
            else if (previousStage == "1")
            {
                list.Add(new CommonValueModel { ID = "31", Name = "Approval MKT" });
            }
            else if (previousStage == "31")
            {
                list.Add(new CommonValueModel { ID = "11", Name = "QC" });
                list.Add(new CommonValueModel { ID = "10", Name = "Account" });
                list.Add(new CommonValueModel { ID = "1", Name = "Sales Employee" });
            }
            else if (previousStage == "11")
            {
                if (userId == "manoj@ajantaprintarts.com" || userId == "pranav.sathe@ajantaprintarts.com")
                {
                    list.Add(new CommonValueModel { ID = "10", Name = "Account" });
                }
                list.Add(new CommonValueModel { ID = "6", Name = "Purchase" });
                list.Add(new CommonValueModel { ID = "8", Name = "Dispatch" });
                list.Add(new CommonValueModel { ID = "9", Name = "Store Ink" });
                list.Add(new CommonValueModel { ID = "14", Name = "Lamination/Die Punch/Printing" });
                list.Add(new CommonValueModel { ID = "21", Name = "Pre-Press" });
                list.Add(new CommonValueModel { ID = "22", Name = "Post Press" });
                list.Add(new CommonValueModel { ID = "28", Name = "Flexo Printing" });
                list.Add(new CommonValueModel { ID = "31", Name = "Approval MKT" });
                list.Add(new CommonValueModel { ID = "30", Name = "Approval Operation" });
                list.Add(new CommonValueModel { ID = "35", Name = "Approval Operation 2" });
                list.Add(new CommonValueModel { ID = "39", Name = "Talegaon QC" });
                list.Add(new CommonValueModel { ID = "40", Name = "Talegaon Production" });
                list.Add(new CommonValueModel { ID = "41", Name = "Talegaon Dispatch" });
                list.Add(new CommonValueModel { ID = "36", Name = "Taloja QC" });
                list.Add(new CommonValueModel { ID = "37", Name = "Taloja Production" });
                list.Add(new CommonValueModel { ID = "38", Name = "Taloja Dispatch" });
            }
            else if (previousStage == "6" || previousStage == "8" || previousStage == "9" || previousStage == "14" || previousStage == "21" || previousStage == "22" || previousStage == "28")
            {
                list.Add(new CommonValueModel { ID = "11", Name = "QC" });
            }
            else if (previousStage == "30")
            {
                list.Add(new CommonValueModel { ID = "11", Name = "QC" });
                list.Add(new CommonValueModel { ID = "35", Name = "Approval Operation 2" });
                list.Add(new CommonValueModel { ID = "10", Name = "Account" });
            }
            else if (previousStage == "35")
            {
                list.Add(new CommonValueModel { ID = "11", Name = "QC" });
                list.Add(new CommonValueModel { ID = "30", Name = "Approval Operation" });
            }
            else if (previousStage == "10")
            {
                list.Add(new CommonValueModel { ID = "30", Name = "Approval Operation" });
            }
            else if (previousStage == "36" || previousStage == "39")
            {
                list.Add(new CommonValueModel { ID = "35", Name = "Approval Operation 2" });
            }
            return Json(new { aaData = list });
        }

        /*   ECR Assign to old logic
                [HttpGet]
                public JsonResult GetECRAssignTo(string previousStage)
                {
                    List<CommonValueModel> list = new List<CommonValueModel>();
                    var userId = HttpContext.User.Identity.Name;

                    if (string.IsNullOrEmpty(previousStage))
                    {
                        if (userId == "manoj@ajantaprintarts.com")
                        {
                            list.Add(new CommonValueModel { ID = "11", Name = "QC" });
                        }
                        else
                        {
                            list.Add(new CommonValueModel { ID = "1", Name = "Sales Employee" });
                        }
                    }
                    else if (previousStage == "1")
                    {
                        list.Add(new CommonValueModel { ID = "31", Name = "Approval MKT" });
                    }
                    else if (previousStage == "11" && userId == "manoj@ajantaprintarts.com")
                    {
                        list.Add(new CommonValueModel { ID = "10", Name = "Account" });
                    }
                    else if (previousStage == "11")
                    {
                        list.Add(new CommonValueModel { ID = "1", Name = "Sales Employee" });
                        list.Add(new CommonValueModel { ID = "31", Name = "Approval MKT" });
                        list.Add(new CommonValueModel { ID = "30", Name = "Approval Operation" });
                        list.Add(new CommonValueModel { ID = "35", Name = "Approval Operation 2" });
                        list.Add(new CommonValueModel { ID = "21", Name = "Pre-Press" });
                        list.Add(new CommonValueModel { ID = "14", Name = "Lamination/Die Punch/Printing" });
                        list.Add(new CommonValueModel { ID = "22", Name = "Post Press" });
                        list.Add(new CommonValueModel { ID = "6", Name = "Purchase" });
                        list.Add(new CommonValueModel { ID = "9", Name = "Store Ink" });
                        list.Add(new CommonValueModel { ID = "8", Name = "Dispatch" });
                        list.Add(new CommonValueModel { ID = "28", Name = "Flexo Printing" });
                    }
                    else
                    {
                        if (userId == "pranav.sathe@ajantaprintarts.com")
                        {
                            list.Add(new CommonValueModel { ID = "10", Name = "Account" });
                        }
                        list.Add(new CommonValueModel { ID = "11", Name = "QC" });
                        list.Add(new CommonValueModel { ID = "21", Name = "Pre-Press" });
                        list.Add(new CommonValueModel { ID = "14", Name = "Lamination/Die Punch/Printing" });
                        list.Add(new CommonValueModel { ID = "22", Name = "Post Press" });
                        list.Add(new CommonValueModel { ID = "6", Name = "Purchase" });
                        list.Add(new CommonValueModel { ID = "9", Name = "Store Ink" });
                        list.Add(new CommonValueModel { ID = "8", Name = "Dispatch" });
                        //list.Add(new CommonValueModel { ID = "30", Name = "Approval Operation" });
                        list.Add(new CommonValueModel { ID = "28", Name = "Flexo Printing" });
                        //list.Add(new CommonValueModel { ID = "35", Name = "Approval Operation 2" });
                    }
                    return Json(new { aaData = list });
                }
           */

        public JsonResult GetPunchType()
        {
            List<CommonValueModel> list = new List<CommonValueModel>();

            list.Add(new CommonValueModel { ID = "SM74", Name = "SM74" });
            list.Add(new CommonValueModel { ID = "ROTARY DIE", Name = "ROTARY DIE" });
            list.Add(new CommonValueModel { ID = "FLAT BED", Name = "FLAT BED" });
            list.Add(new CommonValueModel { ID = "HAND PUNCH", Name = "HAND PUNCH" });
            list.Add(new CommonValueModel { ID = "BOBST PUNCH", Name = "BOBST PUNCH" });
            list.Add(new CommonValueModel { ID = "CUT PRO X", Name = "CUT PRO X" });
            list.Add(new CommonValueModel { ID = "GTO", Name = "GTO" });

            return Json(new { aaData = list });
        }


        [HttpGet]
        public JsonResult CreditNoteCardCodeWise(string cardcode)
        {
            List<CopyDocumentModel> list = _ICommonRepository.CreditNoteCardCodeWise(cardcode);
            return Json(new { aaData = list });
        }
        public JsonResult GetSampleRefData()
        {
            List<CommonValueModel> list = _ICommonRepository.GetDropDownList("REFSAMPLE");
            return Json(new { aaData = list });
        }

        public JsonResult GetInkTypeData()
        {
            List<CommonValueModel> list = _ICommonRepository.GetDropDownList("INKTYPE");
            return Json(new { aaData = list });
        }


        [HttpGet]
        public void UpdateDocumentItemChildTaxCode(string docEntry)
        {
            _ICommonRepository.UpdateDocumentItemChildTaxCode("DRF1", docEntry);
        }

        [HttpGet]
        public JsonResult GetLeaderSalesEmployee()
        {
            var userId = HttpContext.User.Identity.Name;
            var isSuper = _ICommonRepository.IsUserSuperUser(userId);
            if (isSuper == "Y")
            {
                List<CommonValueModel> data = _ICommonRepository.GetLeaderSalesEmployee();
                return Json(new { aaData = data });
            }
            else
            {
                List<CommonValueModel> data = new List<CommonValueModel>();
                return Json(data);
            }
        }

        [HttpGet]
        public JsonResult IsUserSuperUser()
        {
            var userId = HttpContext.User.Identity.Name;
            var data = _ICommonRepository.IsUserSuperUser(userId);
            return Json(data);
        }


        [HttpGet]
        public JsonResult GetArtworkApprovedDate(string itemcode)
        {
            var value = _ICommonRepository.GetArtworkApprovedDate(itemcode);
            return Json(value);
        }


        [HttpGet]
        public JsonResult GetArtworkApproved(string itemcode)
        {
            var value = _ICommonRepository.GetArtworkApproved(itemcode);
            return Json(value);
        }

        [HttpGet]
        public JsonResult GetAllKLDData()
        {
            List<CommonValueModel> list = _ICommonRepository.GetAllKLDData();
            return Json(new { aaData = list });
        }


        [HttpGet]
        public JsonResult GetAllBOMWarehouseList(string bomType, string fgWarehousecode)
        {
            List<CommonValueModel> list = new List<CommonValueModel>();
            if (bomType == "S")
            {
                list = _ICommonRepository.GetAllWarehouseList();
            }
            else
            {
                list = _ICommonRepository.GetBOMUDTRowWarehouse(fgWarehousecode);
            }
            return Json(new { aaData = list });
        }

        [HttpGet]
        public void InsertLog()
        {
            ErrorLogModel model = new ErrorLogModel();
            model.U_Form = "SO";
            model.U_User = "1";
            model.U_Desc = "test";
            _ICommonRepository.InsertInLog(model);
        }

    }
}
