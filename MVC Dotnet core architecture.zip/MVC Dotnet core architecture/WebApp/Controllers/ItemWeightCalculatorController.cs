﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Repository;

namespace WebApp.Controllers
{
    public class ItemWeightCalculatorController : Controller
    {
        public readonly IItemWeightCalculatorRepository _IItemWeightCalculatorRepository = null;
        public readonly ICommonRepository _ICommonRepository = null;
        private IHostingEnvironment _IHostingEnvironment;
        public ItemWeightCalculatorController(IItemWeightCalculatorRepository iItemWeightCalculatorRepository, ICommonRepository iCommonRepository
            , IHostingEnvironment iHostingEnvironment)
        {
            _IItemWeightCalculatorRepository = iItemWeightCalculatorRepository;
            _ICommonRepository = iCommonRepository;
            _IHostingEnvironment = iHostingEnvironment;
        }

        [Authorize]
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            List<ItemWeightCalculatorModel> data = _IItemWeightCalculatorRepository.GetAll();
            for (int i = 0; i < data.Count; i++)
            {
				data[i].EditLink = Url.Action("Edit", "ItemWeightCalculator", new { code = data[i].Code });
			}
			return Json(new { aaData = data });
        }

        [HttpGet]
        public IActionResult Add()
        {
			return View();
        }

        [HttpPost]
        public IActionResult Add(ItemWeightCalculatorModel model)
        {
            string responseText = string.Empty;
            var userId = HttpContext.User.Identity.Name;
			//model.UserId = userId;
			ResponseModel responseModel = new ResponseModel();
            responseModel = Validate(model);
			if (responseModel.ResponseStatus == true)
            {
                responseModel = _IItemWeightCalculatorRepository.Add(model);
                if (responseModel.ResponseStatus == true)
                {
                    TempData["Success"] = "1";
                    TempData["Message"] = responseModel.ResponseText;
                    return RedirectToAction("Add", "ItemWeightCalculator");
                }
                else
                {
                    responseText = responseModel.ResponseText;
                }
            }
            ViewData["Error"] = "1";
            ViewData["Message"] = responseModel.ResponseText;
            return View(model);
        }

        [HttpGet]
        public IActionResult Edit(string code)
        {
            var data = _IItemWeightCalculatorRepository.Get(code);
            return View(data);
        }

        [DisableRequestSizeLimit]
        [HttpPost]
        public IActionResult Edit(ItemWeightCalculatorModel model)
        {
			string responseText = string.Empty;
			var userId = HttpContext.User.Identity.Name;
			ResponseModel responseModel = new ResponseModel();
			responseModel = Validate(model);
			if (responseModel.ResponseStatus == true)
			{
				responseModel = _IItemWeightCalculatorRepository.Update(model);
                if (responseModel.ResponseStatus == true)
                {
                    TempData["Success"] = "1";
                    TempData["Message"] = responseModel.ResponseText;
                    return RedirectToAction("Add", "ItemWeightCalculator");
                }
                else
                {
                    ViewData["Error"] = "1";
                    ViewData["Message"] = responseModel.ResponseText + ".";
					return View(model);
				}
			}
			ViewData["Error"] = "1";
			ViewData["Message"] = responseModel.ResponseText;
			return View(model);

		}
         
        private ResponseModel Validate(ItemWeightCalculatorModel model)
        {
            ResponseModel responseModel = new ResponseModel();
            responseModel.ResponseStatus = true;
			try
            {
				if (string.IsNullOrEmpty(model.U_ItemCode))
				{
					responseModel.ResponseText= "Please select item code";
                    responseModel.ResponseStatus = false;
                    return responseModel;
				}
			}
            catch(Exception ex)
            {
            }
            return responseModel;
        }

        #region Select List

        [NonAction]
        private SelectList GetSalesEmployeeList(string userId)
        {
            return new SelectList(_ICommonRepository.GetAllTeamSalesEmployee(userId), "SlpCode", "SlpName");
        }
		#endregion
        		
	}
}
