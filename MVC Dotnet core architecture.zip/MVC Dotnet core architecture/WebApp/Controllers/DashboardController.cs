﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;

namespace WebApp.Controllers
{
    public class DashboardController : Controller
    {
        public readonly IDashboardRepository _IDashboardRepository = null;
        public readonly ICommonRepository _ICommonRepository = null;

        public DashboardController(IDashboardRepository iDashboardRepository, ICommonRepository iCommonRepository)
        {
            //Dependency Injection
            _IDashboardRepository = iDashboardRepository;
            _ICommonRepository = iCommonRepository;
        }

		[Authorize]
		[SessionExpire]
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public JsonResult GetRole()
        {
            var userId = HttpContext.User.Identity.Name;
            string role = _ICommonRepository.GetUserType(userId);
            return Json(new { value = role });
        }


		[HttpGet]
		public string GetDepartment()
		{
			var identity = (System.Security.Claims.ClaimsIdentity)HttpContext.User.Identity;
			string userType = identity.Claims.FirstOrDefault(c => c.Type == "Department").Value;
			return userType;
		}

		[SessionExpire]
        [HttpGet]
        public IActionResult NotificationData()
        {
            return View();
        }

        [HttpGet]
        public JsonResult GetPendingForApprovalSalesOrder()
        {
            var userId = HttpContext.User.Identity.Name;
            List<PendingForApprovalModel> data = _IDashboardRepository.GetPendingForApprovalSalesOrder(userId);
            for (int i = 0; i < data.Count; i++)
            {
                data[i].EditLink = Url.Action("Edit", "SalesOrder", new { docEntry = data[i].DocEntry,type="draft" });
            }
            return Json(new { aaData = data });
        }
        
        [HttpGet]
        public JsonResult GetPendingForApprovalSalesQuotation()
        {
            var userId = HttpContext.User.Identity.Name;
            List<PendingForApprovalModel> data = _IDashboardRepository.GetPendingForApprovalSalesQuotation(userId);
            for (int i = 0; i < data.Count; i++)
            {
                data[i].EditLink = Url.Action("Edit", "SalesQuotation", new { docEntry = data[i].DocEntry,type="draft" });
            }
            return Json(new { aaData = data });
        }
		[HttpGet]
		public JsonResult GetDraftSalesOrderItems(string docEntry)
		{
			List<PendingForApprovalItemModel> data = _IDashboardRepository.GetDraftSalesOrderItems(docEntry);
			return Json(new { aaData = data });
		}
        
        [HttpGet]
		public JsonResult GetDraftSalesQuatationItems(string docEntry)
		{
			List<PendingForApprovalItemModel> data = _IDashboardRepository.GetDraftSalesQuatationItems(docEntry);
			return Json(new { aaData = data });
		}

		[HttpGet]
        public JsonResult GetOpenSOCount()
        {
            int data = _IDashboardRepository.GetOpenSOCount();
            return Json(new { aaData = data });
        }

        [HttpGet]
        public JsonResult GetOpenSQCount()
        {
            int data = _IDashboardRepository.GetOpenSQCount();
            return Json(new { aaData = data });
        }
    }
}
