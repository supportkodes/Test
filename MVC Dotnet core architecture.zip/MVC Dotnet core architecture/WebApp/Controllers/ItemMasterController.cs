﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using WebDAL.Helper;
using Microsoft.AspNetCore.Authorization;

namespace WebApp.Controllers
{
	public class ItemMasterController : Controller
	{
		public readonly IItemMasterRepository _IItemMasterRepository = null;
		public readonly ICommonRepository _ICommonRepository = null;
		private IHostingEnvironment _IHostingEnvironment;
		public ItemMasterController(IItemMasterRepository iIItemMasterRepository, ICommonRepository iCommonRepository
			, IHostingEnvironment iHostingEnvironment)
		{
			_IItemMasterRepository = iIItemMasterRepository;
			_ICommonRepository = iCommonRepository;
			_IHostingEnvironment = iHostingEnvironment;
		}

		[Authorize]
		[HttpGet]
		public IActionResult Index()
		{
			return View();
		}

		[HttpGet]
		public IActionResult GetAll(int noofRows, string itembrand)
		{
			List<ItemModel> data = _IItemMasterRepository.GetAll(noofRows, itembrand);
			for (int i = 0; i < data.Count; i++)
			{
				data[i].EditLink = Url.Action("Edit", "ItemMaster", new { itemcode = data[i].ItemCode });
				data[i].DuplicateLink = Url.Action("Add", "ItemMaster", new { itemcode = data[i].ItemCode });
			}
			return Json(new { aaData = data });
		}

		[HttpGet]
		public IActionResult Add(string itemcode)
		{
			var userId = HttpContext.User.Identity.Name;
			string ownerId = _ICommonRepository.GetEmpId(userId);
			ItemMasterModel model = new ItemMasterModel();
			model.U_PaperGSM = "0";
			model.UoMGroupEntry = "-1";
			ViewBag.CurrencyList = GetCurrencyList();
			ViewBag.UOMGroupList = GetUOMGroupList();
			ViewBag.UOMList = GetAllUOMMaster();
			ViewBag.TypeOfSubstrateList = GetAllTypeOfSubstrate();
			ViewBag.VarnishList = GetAllVarnish();
			ViewBag.BranchList = GetBranchList();
			ViewBag.WarehouseList = GetWarehouseList();
			ViewBag.ItemGroupList = GetItemGroupList();
			ViewBag.ShippingTypeList = GetShippingTypeList();
			ViewBag.EmployeeList = GetEmployeeList();
			ViewBag.YNList = GetYNList();
			ViewBag.ActiveYNList = GetActiveYNList();

			if (!string.IsNullOrEmpty(itemcode))
			{
				model = _IItemMasterRepository.Get(itemcode);
				model.DocEntry = "";
				model.ItemCode = "";
				model.ItemName = "";
				model.U_PrintItemDesc = "";
				model.U_PaperGSM = "";
				return View(model);
			}
			else
			{
				return View();
			}
		}

		[HttpPost]
		public IActionResult Add(ItemMasterModel model)
		{
			string responseText = string.Empty;
			string userId = _ICommonRepository.GetUserId(HttpContext.User.Identity.Name);
			model.UserId = userId;

			ResponseModel responseModel = new ResponseModel();
			responseModel = Validate(model);
			if (responseModel.ResponseStatus == true)
			{
				responseModel = _IItemMasterRepository.Add(model);
				if (responseModel.ResponseStatus == true)
				{
					TempData["Success"] = "1";
					TempData["Message"] = responseModel.ResponseText;
					return RedirectToAction("Index", "ItemMaster");
				}
				else
				{
					responseText = responseModel.ResponseText;
				}
			}
			else
			{
				responseText = responseModel.ResponseText;
			}
			ViewBag.CurrencyList = GetCurrencyList();
			ViewBag.UOMGroupList = GetUOMGroupList();
			ViewBag.UOMList = GetAllUOMMaster();
			ViewBag.TypeOfSubstrateList = GetAllTypeOfSubstrate();
			ViewBag.VarnishList = GetAllVarnish();
			ViewBag.BranchList = GetBranchList();
			ViewBag.WarehouseList = GetWarehouseList();
			ViewBag.ItemGroupList = GetItemGroupList();
			ViewBag.ShippingTypeList = GetShippingTypeList();
			ViewBag.EmployeeList = GetEmployeeList();
			ViewBag.YNList = GetYNList();
			ViewBag.ActiveYNList = GetActiveYNList();
			ViewData["Error"] = "1";
			ViewData["Message"] = responseText;
			return View(model);

		}

		[HttpGet]
		public IActionResult Edit(string itemcode)
		{
			var userId = HttpContext.User.Identity.Name;
			//var userId = _ICommonRepository.GetEmpId(userId);
			ItemMasterModel data = _IItemMasterRepository.Get(itemcode);
			if (userId.ToLower().Contains("sandeep@ajantaprintarts.com"))
			{
				data.IsEditable = "Y";
			}
			ViewBag.CurrencyList = GetCurrencyList();
			ViewBag.UOMGroupList = GetUOMGroupList();
			ViewBag.UOMList = GetAllUOMMaster();
			ViewBag.TypeOfSubstrateList = GetAllTypeOfSubstrate();
			ViewBag.VarnishList = GetAllVarnish();
			ViewBag.BranchList = GetBranchList();
			ViewBag.WarehouseList = GetWarehouseList();
			ViewBag.ItemGroupList = GetItemGroupList();
			ViewBag.ShippingTypeList = GetShippingTypeList();
			ViewBag.EmployeeList = GetEmployeeList();
			ViewBag.YNList = GetYNList();
			ViewBag.ActiveYNList = GetActiveYNList();
			return View(data);
		}

		[HttpPost]
		public IActionResult Edit(ItemMasterModel model)
		{
			string userId = _ICommonRepository.GetUserId(HttpContext.User.Identity.Name);
			model.UserId = userId;
			ResponseModel responseModel = new ResponseModel();
			responseModel = Validate(model);
			if (responseModel.ResponseStatus == true)
			{
				responseModel = _IItemMasterRepository.Update(model);
				if (responseModel.ResponseStatus == true)
				{
					TempData["Success"] = "1";
					TempData["Message"] = responseModel.ResponseText;
					return RedirectToAction("Index", "ItemMaster");
				}
			}

			ViewData["Error"] = "1";
			ViewData["Message"] = responseModel.ResponseText;
			ViewBag.CurrencyList = GetCurrencyList();
			ViewBag.UOMGroupList = GetUOMGroupList();
			ViewBag.UOMList = GetAllUOMMaster();
			ViewBag.TypeOfSubstrateList = GetAllTypeOfSubstrate();
			ViewBag.VarnishList = GetAllVarnish();
			ViewBag.BranchList = GetBranchList();
			ViewBag.WarehouseList = GetWarehouseList();
			ViewBag.ItemGroupList = GetItemGroupList();
			ViewBag.ShippingTypeList = GetShippingTypeList();
			ViewBag.EmployeeList = GetEmployeeList();
			ViewBag.YNList = GetYNList();
			ViewBag.ActiveYNList = GetActiveYNList();
			return View(model);

		}
		private ResponseModel Validate(ItemMasterModel model)
		{
			ResponseModel responseModel = new ResponseModel();
			responseModel.ResponseStatus = true;
			if (string.IsNullOrEmpty(model.ItemCode))
			{
				responseModel.ResponseText = "Please enter item code";
				responseModel.ResponseStatus = false;
			}
			else if (string.IsNullOrEmpty(model.ItemName))
			{
				responseModel.ResponseText = "Please enter item name";
				responseModel.ResponseStatus = false;
			}
			else if (string.IsNullOrEmpty(model.U_Industry))
			{
				responseModel.ResponseText = "Sales Tab: Please select Industry";
				responseModel.ResponseStatus = false;
			}
			string itemGroupName = _ICommonRepository.GetItemGroupName(model.ItemsGroupCode);
			if (itemGroupName.ToUpper().Contains("FG"))
			{
				if (string.IsNullOrEmpty(model.U_MCODE))
				{
					responseModel.ResponseText = "Common Tab: Mill code is mandatory for FG Itemgroup";
					responseModel.ResponseStatus = false;
				}
			}
			string userName = _ICommonRepository.GetUserName(model.UserId);
			if (model.ItemsGroupCode == "165")
			{
				if (!(userName == "LOGI14" || userName == "LOGI15" || userName == "LOGI16" || userName == "LOGI1" || userName == "LOGI2" || userName == "LOGI29" || userName == "PRO2" || userName == "PRO3"))
				{
					responseModel.ResponseText = "You are not authorized person Other packing mat..";
					responseModel.ResponseStatus = false;
				}
			}
			return responseModel;
		}

		[HttpPost]
		public JsonResult GetAutoItemCode(ItemMasterModel itemMasterModel)
		{
			NewItemCodeModel model = _IItemMasterRepository.GetAutoItemCode(itemMasterModel);
			return Json(new { aaData = model });
		}

		//[HttpPost]
		//public JsonResult UserWiseItemGrpData(string itemcode)
		//{
		//	ResponseModel responseModel = new ResponseModel();
		//	try
		//	{
		//		responseModel.ResponseStatus = true;
		//		var userId = HttpContext.User.Identity.Name;
		//		if (responseModel.ResponseStatus == true)
		//		{
		//			responseModel = _IItemMasterRepository.UserWiseItemGrpData(itemcode);
		//		}
		//		return Json(new { value = responseModel });
		//	}
		//	catch (Exception ex)
		//	{
		//	}
		//	responseModel.ResponseText = "Error occured while processing";
		//	responseModel.ResponseStatus = false;
		//	return Json(new { value = responseModel });
		//}


		#region Select List

		[NonAction]
		private SelectList GetCurrencyList()
		{
			return new SelectList(_ICommonRepository.GetAllCurrency(), "CurrCode", "CurrName");
		}

		[NonAction]
		private SelectList GetBranchList()
		{
			return new SelectList(_ICommonRepository.GetAllBranch(), "BPLId", "BPLName");
		}

		[NonAction]
		private SelectList GetItemGroupList()
		{
			return new SelectList(_ICommonRepository.GetAllItemGroup(), "ID", "Name");
		}

		[NonAction]
		private SelectList GetUOMGroupList()
		{
			return new SelectList(_ICommonRepository.GetAllUOMGroup(), "ID", "Name");
		}

		[NonAction]
		private SelectList GetAllUOMMaster()
		{
			return new SelectList(_ICommonRepository.GetAllUOMMaster(), "ID", "Name");
		}

		[NonAction]
		private SelectList GetAllTypeOfSubstrate()
		{
			return new SelectList(_ICommonRepository.GetAllTypeOfSubstrate(), "ID", "Name");
		}

		[NonAction]
		private SelectList GetAllVarnish()
		{
			return new SelectList(_ICommonRepository.GetAllVarnish(), "ID", "Name");
		}


		[NonAction]
		private SelectList GetWarehouseList()
		{
			return new SelectList(_ICommonRepository.GetAllWarehouse(), "WhsCode", "WhsName");
		}

		[NonAction]
		private SelectList GetShippingTypeList()
		{
			return new SelectList(_ICommonRepository.GetAllShippingType(), "TrnspCode", "TrnspName");
		}

		[NonAction]
		private SelectList GetHSNList()
		{
			return new SelectList(_ICommonRepository.GetAllHSN(), "Chapter", "ChapterID");
		}

		[NonAction]
		private SelectList GetYNList()
		{
			var selectLists = new SelectList(
					new List<SelectListItem>
					{
						new SelectListItem { Value = "Y", Text = "Yes"},
						new SelectListItem { Value= "N", Text = "No"},
					}, "Value", "Text");

			return selectLists;
		}
		private SelectList GetActiveYNList()
		{
			var selectLists = new SelectList(
					new List<SelectListItem>
					{
						new SelectListItem { Value = "Yes", Text = "Yes"},
						new SelectListItem { Value= "No", Text = "No"},
					}, "Value", "Text");

			return selectLists;
		}

		[NonAction]
		private SelectList GetEmployeeList()
		{
			return new SelectList(_ICommonRepository.GetAllEmployee(), "empID", "Name");
		}

		[NonAction]
		private SelectList GetSalesEmployeeList(string userId)
		{
			return new SelectList(_ICommonRepository.GetAllTeamSalesEmployee(userId), "SlpCode", "SlpName");
		}

		#endregion
	}
}
