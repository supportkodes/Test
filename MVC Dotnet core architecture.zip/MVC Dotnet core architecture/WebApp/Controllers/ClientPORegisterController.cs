﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;
using WebDAL.Helper;
using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Repository;

namespace WebApp.Controllers
{
    public class ClientPORegisterController : Controller
    {
        public readonly IClientPORegisterRepository _IClientPORegisterRepository = null;

        public readonly ICommonRepository _ICommonRepository = null;

        private IHostingEnvironment _IHostingEnvironment;

        private readonly ILogger<ClientPORegisterController> _ILogger;

        public ClientPORegisterController(IClientPORegisterRepository iClientPORegisterRepository, ICommonRepository iCommonRepository, IHostingEnvironment iHostingEnvironment, ILogger<ClientPORegisterController> iLogger)
        {
            _IClientPORegisterRepository = iClientPORegisterRepository;
            _ICommonRepository = iCommonRepository;
            _IHostingEnvironment = iHostingEnvironment;
            _ILogger = iLogger;
        }

        [Authorize]
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult GetAll()
        {
            List<ClientPORegisterModel> data = _IClientPORegisterRepository.GetAll();
            for (int i = 0; i < data.Count; i++)
            {
                //data[i].EditLink = Url.Action("Edit", "ClientPORegister", new { docEntry = data[i].DocEntry });
                data[i].EditLink = Url.Action("Edit", "ClientPORegister", new { docEntry = data[i].DocEntry, type = "O" });
            }
            return Json(new { aaData = data });
            //return Json(new { aaData = data });
        }


        [HttpGet]
        public IActionResult GetAllClose()
        {

            List<ClientPORegisterModel> data = _IClientPORegisterRepository.GetAllClose();
            for (int i = 0; i < data.Count; i++)
            {
                data[i].EditLink = Url.Action("Edit", "ClientPORegister", new { docEntry = data[i].DocEntry, type = "C" });
            }
            return Json(new { aaData = data });
        }

        [Authorize]
        [HttpGet]
        public IActionResult Add(string? baseEntry)
        {
            var userId = HttpContext.User.Identity.Name;
            string ownerId = _ICommonRepository.GetEmpId(userId);
            ClientPORegisterModel model = new ClientPORegisterModel();

            if (!string.IsNullOrEmpty(baseEntry))
            {
                // model = IClientPORegisterRepository.GetClientPOSQData(baseEntry);
                model = _IClientPORegisterRepository.GetSQToClientPOData(baseEntry);
            }
            else
            {
                #region ClientPORegister Rows
                List<ClientPORegisterRowsModel> ClientPORegisterModellList = new List<ClientPORegisterRowsModel>();
                ClientPORegisterRowsModel clientPORegisterRowsModel = new ClientPORegisterRowsModel();
                clientPORegisterRowsModel.Index = 1;
                ClientPORegisterModellList.Add(clientPORegisterRowsModel);
                model.WEB_PO_REGISTER1Collection = ClientPORegisterModellList;
                #endregion
            }
            model.U_DocDate = DateTime.Now.ToString("dd-MM-yyyy");
            model.U_PORefDt = DateTime.Now.ToString("dd-MM-yyyy");

            #region Attachment Rows
            List<ClientPORegister_Attachment> ClientPORegister_AttachmentList = new List<ClientPORegister_Attachment>();
            ClientPORegister_Attachment clientPORegister_Attachment = new ClientPORegister_Attachment();
            clientPORegister_Attachment.LineId = 1;
            ClientPORegister_AttachmentList.Add(clientPORegister_Attachment);
            model.WEB_PO_REGISTER3Collection = ClientPORegister_AttachmentList;
            #endregion

            ViewBag.CurrencyList = GetCurrencyList();
            return View(model);
        }
        [HttpPost]
        [DisableRequestSizeLimit]
        public IActionResult Add(ClientPORegisterModel model)
        {
            string responseText = string.Empty;
            string userId = base.HttpContext.User.Identity.Name;
            ResponseModel responseModel = new ResponseModel();
            model.UserId = userId;
            //string Line = _IClientPORegisterRepository.GetProdutionOrderData();
            responseModel = Validate(model);
            if (responseModel.ResponseStatus)
            {
                responseModel = _IClientPORegisterRepository.Add(model);
                if (responseModel.ResponseStatus)
                {
                    TempData["Success"] = "1";
                    TempData["Message"] = responseModel.ResponseText;
                    return RedirectToAction("Index", "ClientPORegister");
                }
            }
            ViewBag.CurrencyList = GetCurrencyList();
            ViewData["Error"] = "1";
            ViewData["Message"] = responseModel.ResponseText;
            return View(model);
        }

        private ResponseModel Validate(ClientPORegisterModel model)
        {
            ResponseModel responseModel = new ResponseModel();
            responseModel.ResponseStatus = true;


            for (int i = 0; i < model.WEB_PO_REGISTER1Collection.Count; i++)
            {
                if (!string.IsNullOrEmpty(model.WEB_PO_REGISTER1Collection[i].U_ItemCode)
                    && model.WEB_PO_REGISTER1Collection[i].U_BomType == "P")
                {
                    if (string.IsNullOrEmpty(model.WEB_PO_REGISTER1Collection[i].U_Rate))
                    {
                        responseModel.ResponseStatus = false;
                        responseModel.ResponseText = "Please Enter Manual Rate for row " + Convert.ToString(i + 1) + " ItemCode: " + model.WEB_PO_REGISTER1Collection[i].U_ItemCode;
                        return responseModel;
                    }
                }
            }

            return responseModel;
        }

        [Authorize]
        [HttpGet]
        public IActionResult Edit(string docEntry)
        {
            ClientPORegisterModel data = _IClientPORegisterRepository.Get(docEntry);
            ViewBag.CurrencyList = GetCurrencyList();

            return View(data);
        }

        [DisableRequestSizeLimit]
        [HttpPost]
        public IActionResult Edit(ClientPORegisterModel model)
        {
            string userId = HttpContext.User.Identity.Name;
            ResponseModel responseModel = new ResponseModel();
            try
            {
                responseModel = Validate(model);
                if (responseModel.ResponseStatus == true)
                {
                    responseModel = _IClientPORegisterRepository.Update(model);
                }
            }
            catch (Exception ex)
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = ex.Message;
            }
            if (responseModel.ResponseStatus == true)
            {
                TempData["Success"] = "1";
                TempData["Message"] = responseModel.ResponseText;
                return RedirectToAction("Index", "ClientPORegister");
            }
            ViewData["Error"] = "1";
            ViewData["Message"] = responseModel.ResponseText;
            List<ClientPORegisterQtyPerPOModel> list = new List<ClientPORegisterQtyPerPOModel>();
            ClientPORegisterQtyPerPOModel qtyPerPOModel = new ClientPORegisterQtyPerPOModel();
            qtyPerPOModel.Index = 1;
            list.Add(qtyPerPOModel);
            model.WEB_PO_REGISTER2Collection = list;
            ViewBag.CurrencyList = GetCurrencyList();

            return View(model);
        }

        [HttpPost]
        public ActionResult ClientPORegisterAddRow(int index)
        {
            index = index - 1;
            var newRow = new ClientPORegisterRowsModel() { Index = index + 1 };
            ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("WEB_PO_REGISTER1Collection[{0}]", index);
            return PartialView("~/Views/Shared/EditorTemplates/ClientPORegisterRowsModel.cshtml", newRow);
        }
        [HttpPost]
        public ActionResult ClientPOAttachmentAddRow(int index)
        {
            index = index - 1;
            var newRow = new ClientPORegister_Attachment() { LineId = index + 1 };
            ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("WEB_PO_REGISTER3Collection[{0}]", index);
            return PartialView("~/Views/Shared/EditorTemplates/ClientPORegister_Attachment.cshtml", newRow);
        }
        [HttpPost]
        public ActionResult ClientPORegisterQtyPerPOAddRow(int index)
        {
            index = index - 1;
            var newRow = new ClientPORegisterQtyPerPOModel() { Index = index + 1 };
            ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("WEB_PO_REGISTER2Collection[{0}]", index);
            return PartialView("~/Views/Shared/EditorTemplates/ClientPORegisterQtyPerPOModel.cshtml", newRow);
        }

        [HttpPost]
        public JsonResult UpdateRateSendMail(List<ClientPORegisterRowsModel> model, List<ClientPORegister_Attachment> Attachmentmodel, string cardcode, string cardname, int docnum, string docEntry, string currency)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                if (model.Count > 0)
                {
                    model.ForEach(i => i.Currency = currency);

                    Helpers helpers = new Helpers();
                    SendMail _sendMail = new SendMail();
                    string message = "";
                    DataTable dt = new DataTable();
                    dt = helpers.ToDataTable(model);

                    var lineIdList = model.Where(a => a.U_IsGang == "Y" && !string.IsNullOrEmpty(a.U_Rate)).ToList();
                    var alllineIdList = model.Where(a => !string.IsNullOrEmpty(a.U_Rate)).ToList();
                    string lineIds = string.Join(",", lineIdList.Select(x => x.LineId));
                    string alllineIds = string.Join(",", alllineIdList.Select(x => x.LineId));

                    DataTable gangUpdataTable = _IClientPORegisterRepository.GetGangUpData(docEntry, lineIds);
                    string tableBody_Gangup = helpers.ConvertToHtml(gangUpdataTable);

                    #region Mail Body Columns
                    try
                    {
                        dt.Columns.Remove("U_IsSelect");
                        dt.Columns.Remove("IsSelect");
                        dt.Columns.Remove("IsDeleted");
                        dt.Columns.Remove("U_SrNo");
                        dt.Columns.Remove("Index");
                        dt.Columns.Remove("LineId");

                        dt.Columns.Remove("BOMRatio");
                        dt.Columns.Remove("BaseBOMLine");
                        dt.Columns.Remove("IsGang");
                        dt.Columns.Remove("U_ArtAttach");
                        dt.Columns.Remove("U_BomType");
                        dt.Columns.Remove("U_BaseEn");
                        dt.Columns.Remove("U_BaseLine");
                        dt.Columns.Remove("U_TargEn");
                        dt.Columns.Remove("U_TargLine");
                        dt.Columns.Remove("U_AppArt");
                        dt.Columns.Remove("U_RefId");
                        try
                        {
                            dt.Columns.Remove("U_SOEn");
                        }
                        catch { }
                        try
                        {
                            dt.Columns.Remove("U_MailSent");
                        }
                        catch { }
                        try
                        {
                            dt.Columns.Remove("U_ManualRate");
                        }
                        catch { }
                    }
                    catch { }
                    try
                    {
                        dt.Columns["U_ItemCode"].ColumnName = "Item Code";
                        dt.Columns["U_ItemName"].ColumnName = "Item Name";
                        dt.Columns["U_Qty"].ColumnName = "Quantity";
                        dt.Columns["U_KLDNo"].ColumnName = "KLD No";
                        dt.Columns["U_Rate"].ColumnName = "Manual Rate";
                        dt.Columns["U_RateSys"].ColumnName = "System Rate";
                        dt.Columns["U_FromDate"].ColumnName = "From Date";
                        dt.Columns["U_ToDate"].ColumnName = "To Date";
                        dt.Columns["U_IsGang"].ColumnName = "Gangup Job";
                        //dt.Columns["U_BomType"].ColumnName = "Bom Type";
                        dt.Columns["U_NoOfUPS"].ColumnName = "No Of UPS";
                        //dt.Columns["U_AppArt"].ColumnName = "Approved ArtWork";
                        //dt.Columns["U_RefId"].ColumnName = "Referance Id";
                        //dt.Columns["U_ArtAttach"].ColumnName = "ArtWork Attach";
                    }
                    catch { }
                    #endregion

                    #region Mail Body Columns GangUp
                    //try
                    //{
                    //    dt.Columns.Remove("U_ItemCode");
                    //    dt.Columns.Remove("U_ItemName");
                    //    dt.Columns.Remove("U_KLDNo");
                    //    dt.Columns.Remove("U_NoOfUPS");
                    //}
                    //catch { }
                    //try
                    //{
                    //    dt.Columns["U_ItemCode"].ColumnName = "Item Code";
                    //    dt.Columns["U_ItemName"].ColumnName = "Item Name";
                    //    dt.Columns["U_Qty"].ColumnName = "Quantity";
                    //    dt.Columns["U_KLDNo"].ColumnName = "KLD No";
                    //    dt.Columns["U_Rate"].ColumnName = "Manual Rate";
                    //    dt.Columns["U_RateSys"].ColumnName = "System Rate";
                    //    dt.Columns["U_FromDate"].ColumnName = "From Date";
                    //    dt.Columns["U_ToDate"].ColumnName = "To Date";
                    //    dt.Columns["U_IsGang"].ColumnName = "Gangup Job";
                    //    //dt.Columns["U_BomType"].ColumnName = "Bom Type";
                    //    dt.Columns["U_NoOfUPS"].ColumnName = "No Of UPS";
                    //    dt.Columns["U_AppArt"].ColumnName = "Approved ArtWork";
                    //    dt.Columns["U_RefId"].ColumnName = "Referance Id";
                    //    //dt.Columns["U_ArtAttach"].ColumnName = "ArtWork Attach";
                    //}
                    //catch { }
                    #endregion

                    string subject = "Web Portal - Authorize Client PO Rate Update - " + cardname;
                    string tableBody = helpers.ConvertToHtml(dt);
                    StringBuilder sbBody = new StringBuilder();
                    sbBody.Append("<p> Dear Sir/Madam <p/>");
                    sbBody.Append("<p> Please see below document Client PO Rate details<p/>");
                    sbBody.Append("Document No : " + docnum + "Client Code " + cardcode + " &" + "Client Name " + cardname + " ");
                    sbBody.Append(tableBody);
                    if (lineIdList.Count > 0)
                    {
                        sbBody.Append("<p>Gang-Up Details<p/>");
                        sbBody.Append(tableBody_Gangup);
                    }
                    sbBody.Append("<p> Regards <br/>");
                    sbBody.Append("Web Admin<p/>");

                    string fromEmail = HttpContext.User.Identity.Name;
                    string creator = _IClientPORegisterRepository.GetCreator(docEntry);
                    string toEmail = _ICommonRepository.GetUserEmailAddress(creator);
                    string slpcode = _ICommonRepository.GetBPSalesEmployee(cardcode);
                    string salesEmployeeEmailAddress = _ICommonRepository.GetSalesEmployeeEmailAddress(cardcode);

                    string commonToEmail = _ICommonRepository.GetAppDataValue(AppData.ClientPOEmailAddress);
                    //toEmail = "support@kodeslab.com";
                    toEmail = toEmail + "," + commonToEmail;
                    ClientPORegisterModel clientPORegisterModel = new ClientPORegisterModel();
                    ClientPORegister_Attachment ClientPORegister_Attachment = new ClientPORegister_Attachment();
                    List<string> attachmentList = Attachmentmodel.ToList().Select(a => a.U_Attach).ToList();

                    bool result = _sendMail.sendMail(fromEmail, toEmail, salesEmployeeEmailAddress, "", subject, sbBody.ToString(), attachmentList, out message);
                    if (result == true)
                    {
                        _IClientPORegisterRepository.UpdateMailSent(docEntry, alllineIds);
                    }
                    string responseMessage = "Send Mail Successfully";
                    return Json(responseMessage);
                }
                else
                {
                    string responseMessage = "No Rows selected";
                    return Json(responseMessage);
                }
            }
            catch (Exception ex)
            {
                _ILogger.LogError(ex.Message);
            }
            responseModel.ResponseText = "Error occured while processing ClientPORegister ";
            return Json(new { value = responseModel });
        }

        [HttpGet]
        public JsonResult GetClientPORegisterData(string cardcode)
        {
            List<CopyDocumentModel> list = _IClientPORegisterRepository.GetClientPORegisterData(cardcode);
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetClientPOSelectedData(string docEntry)
        {
            List<ClientPORegisterRowsModel> list = _IClientPORegisterRepository.GetClientPOSelectedData(docEntry);
            return Json(new { aaData = list });
        }

        [HttpPost]
        public JsonResult AddUpdateQtyPerPO(List<ClientPORegisterQtyPerPOModel> model)
        {
            ResponseModel responseModel = new ResponseModel();
            var data = _IClientPORegisterRepository.AddUpdateQtyPerPO(model);
            return Json(data);
        }

        [HttpGet]
        public JsonResult GetQtyPerPOList(string docEntry, string lineNo)
        {
            ResponseModel responseModel = new ResponseModel();
            var data = _IClientPORegisterRepository.GetQtyPerPOList(docEntry, lineNo);
            return Json(data);
        }

        [HttpPost]
        public string UploadItemData(IFormFile postedFile)
        {
            if (postedFile != null)
            {
                string path = Path.Combine(_IHostingEnvironment.WebRootPath, "Uploads");
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                string fileName = Path.GetFileName(postedFile.FileName);
                string filePath = Path.Combine(path, fileName);
                using (FileStream stream = new FileStream(filePath, FileMode.Create))
                {
                    postedFile.CopyTo(stream);
                }
                DataTable dt = new DataTable();
                using (XLWorkbook workBook = new XLWorkbook(filePath))
                {
                    IXLWorksheet workSheet = workBook.Worksheet(1);
                    bool firstRow = true;
                    foreach (IXLRow row in workSheet.Rows())
                    {
                        if (firstRow)
                        {
                            foreach (IXLCell cell in row.Cells())
                            {

                                dt.Columns.Add(cell.Value.ToString());
                            }
                            firstRow = false;
                        }
                        else
                        {
                            dt.Rows.Add();
                            int i = 0;
                            foreach (IXLCell cell in row.Cells())
                            {
                                try
                                {

                                    dt.Rows[dt.Rows.Count - 1][i] = cell.Value.ToString();
                                }
                                catch { }
                                i++;
                            }
                        }
                    }
                }
                ViewBag.Data = dt;
                dt = dt.Rows
                .Cast<DataRow>()
                .Where(row => !row.ItemArray.All(field => field is DBNull ||
                                                 string.IsNullOrWhiteSpace(field as string)))
                .CopyToDataTable();
                System.IO.File.Delete(filePath);
                dt.Columns.Add("KLDNo", typeof(String));
                dt.Columns.Add("AppArt", typeof(String));
                dt.Columns.Add("BomType", typeof(String));
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string itemcode = dt.Rows[i]["ItemCode"].ToString();
                    string kldNo = _ICommonRepository.GetKLDNo(itemcode);
                    dt.Rows[i]["KLDNo"] = kldNo;

                    string bomType = _ICommonRepository.GetItemBOMType(itemcode);
                    string approvedDate = _ICommonRepository.GetArtworkApprovedDate(itemcode);
                    if (!string.IsNullOrEmpty(approvedDate) || bomType == "P" || bomType == "S")
                    {
                        dt.Rows[i]["AppArt"] = "Y";
                    }
                    else
                    {
                        dt.Rows[i]["AppArt"] = "N";
                    }
                    dt.Rows[i]["BomType"] = bomType;
                }
                var jsonData = JsonConvert.SerializeObject(dt);
                return jsonData;
            }
            else
            {
                return null;
            }
        }

        [HttpGet]
        public JsonResult GetClientPOItemDetails(string itemcode)
        {
            var model = _IClientPORegisterRepository.GetClientPOItemDetails(itemcode);
            return Json(new { aaData = model });
        }

        public ResponseModel UploadAttachment(IFormFile postedFile)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                if (postedFile != null)
                {
                    string path = ConfigManager.GetUploadPath() + "ClientPO\\" + DateTime.Now.ToString("dd_MM_yyyy");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }
                    string seed = DateTime.Now.ToString("dd_MM_yyyy_hh_mm_tt");   //+ Convert.ToString((int)DateTime.Now.Ticks);
                    string fileName = Path.GetFileName(postedFile.FileName);
                    fileName = System.IO.Path.GetFileNameWithoutExtension(fileName);
                    System.IO.FileInfo fi = new System.IO.FileInfo(postedFile.FileName);
                    string fileExtension = fi.Extension;
                    fileName = fileName + "_" + seed + fileExtension; //+ "_" + fileName;
                    string filePath = Path.Combine(path, fileName);
                    using (FileStream stream = new FileStream(filePath, FileMode.Create))
                    {
                        postedFile.CopyTo(stream);
                    }
                    responseModel.ResponseStatus = true;
                    responseModel.ResponseText = filePath;
                    return responseModel;
                }
            }
            catch (Exception ex)
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = ex.Message;
            }
            return responseModel;
        }

        [NonAction]
        private SelectList GetCurrencyList()
        {
            return new SelectList(_ICommonRepository.GetAllCurrency(), "CurrCode", "CurrName");
        }
    }
}
