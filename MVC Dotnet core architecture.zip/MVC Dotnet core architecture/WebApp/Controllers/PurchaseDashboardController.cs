﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;

namespace WebApp.Controllers
{
    public class PurchaseDashboardController : Controller
    {
        public readonly IPurchaseDashboardRepository _IDashboardRepository = null;
        public readonly ICommonRepository _ICommonRepository = null;

        public PurchaseDashboardController(IPurchaseDashboardRepository iDashboardRepository, ICommonRepository iCommonRepository)
        {
            //Dependency Injection
            _IDashboardRepository = iDashboardRepository;
            _ICommonRepository = iCommonRepository;
        }

		[Authorize]
		[SessionExpire]
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
         
        [HttpGet]
        public JsonResult GetPendingForApprovalPurchaseOrder()
        {
            var userId = HttpContext.User.Identity.Name;
            List<PendingForApprovalModel> data = _IDashboardRepository.GetPendingForApprovalPurchaseOrder(userId);
            for (int i = 0; i < data.Count; i++)
            {
                data[i].EditLink = Url.Action("Edit", "PurchaseOrder", new { docEntry = data[i].DocEntry,type="draft" });
            }
            return Json(new { aaData = data });
        }


		[HttpGet]
		public JsonResult GetDraftPurchaseOrderItems(string docEntry)
		{
			List<PendingForApprovalItemModel> data = _IDashboardRepository.GetDraftPurchaseOrderItems(docEntry);
			return Json(new { aaData = data });
		}

	}
}
