﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using WebDAL.Helper;
using Microsoft.AspNetCore.Authorization;
using System.Text;

namespace WebApp.Controllers
{
    public class SalesQuotationController : Controller
    {
        public readonly ISalesQuotationRepository _ISalesQuotationRepository = null;
        public readonly ICommonRepository _ICommonRepository = null;
        private IHostingEnvironment _IHostingEnvironment;
        public SalesQuotationController(ISalesQuotationRepository iSalesQuotationRepository, ICommonRepository iCommonRepository
            , IHostingEnvironment iHostingEnvironment)
        {
            _ISalesQuotationRepository = iSalesQuotationRepository;
            _ICommonRepository = iCommonRepository;
            _IHostingEnvironment = iHostingEnvironment;
        }

        [Authorize]
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public IActionResult GetAll(string type)
        {
            var userId = HttpContext.User.Identity.Name;
            List<DocumentModel> data = _ISalesQuotationRepository.GetAll(userId, type);
            for (int i = 0; i < data.Count; i++)
            {
                data[i].EditLink = Url.Action("Edit", "SalesQuotation", new { docEntry = data[i].DocEntry, type = type.ToUpper() });
            }
            return Json(new { aaData = data });
        }
        [HttpGet]
        public IActionResult Add(string? baseEntry, string lineNo)
        {
            var userId = HttpContext.User.Identity.Name;
            string ownerId = _ICommonRepository.GetEmpId(userId);
            DocumentModel model = new DocumentModel();
            model.SalesPersonCode = "-1";
            //model.DocDate = DateTime.Now.ToShortDateString();
            //model.DocDueDate = DateTime.Now.ToShortDateString();
            //model.TaxDate = DateTime.Now.ToShortDateString();

            model.DocDate = DateTime.Now.ToString("dd-MM-yyyy");
            model.DocDueDate = DateTime.Now.ToString("dd-MM-yyyy");
            model.TaxDate = DateTime.Now.ToString("dd-MM-yyyy");

            model.NetAmount = 0;
            model.DiscountPercent = 0;
            model.RoundingDiffAmount = 0;
            model.DocumentTotal = 0;
            model.DocRate = "1";
            model.DocCurrency = "INR";
            model.DocumentsOwner = ownerId;

            DocumentRowsModel salesOrderRowsModel = new DocumentRowsModel();

            if (!string.IsNullOrEmpty(baseEntry))
            {
                model = _ICommonRepository.GetClientPOSOData(baseEntry, lineNo);
                model.DiscountPercent = 0;
                model.DocDate = DateTime.Now.ToString("dd-MM-yyyy");
                model.DocDueDate = DateTime.Now.ToString("dd-MM-yyyy");
                model.DocumentsOwner = ownerId;
            }
            else
            {
                #region Item Rows
                List<DocumentRowsModel> salesOrderRowsModelList = new List<DocumentRowsModel>();
                for (int i = 1; i <= 1; i++)
                {
                    salesOrderRowsModel.Index = i;
                    salesOrderRowsModel.ItemCode = "";
                    //salesOrderRowsModel.ShipDate = DateTime.Now;
                    salesOrderRowsModelList.Add(salesOrderRowsModel);
                }
                model.DocumentLines = salesOrderRowsModelList;
                #endregion
            }

            #region Attachment Rows
            List<DocumentModel_Attachment> documentModel_AttachmentList = new List<DocumentModel_Attachment>();
            DocumentModel_Attachment documentModel_Attachment = new DocumentModel_Attachment();
            documentModel_Attachment.Index = 1;
            documentModel_AttachmentList.Add(documentModel_Attachment);
            model.Attachments2_Lines = documentModel_AttachmentList;
            #endregion

            #region Expense Rows
            List<DocumentModel_Expenses> documentModel_ExpensesList = new List<DocumentModel_Expenses>();
            List<ExpenseModel> expenseModelsList = _ICommonRepository.GetAllExpenses();
            for (int i = 0; i < expenseModelsList.Count; i++)
            {
                DocumentModel_Expenses documentModel_Expenses = new DocumentModel_Expenses();
                documentModel_Expenses.Index = i + 1;
                documentModel_Expenses.ExpenseCode = expenseModelsList[i].ExpnsCode;
                documentModel_Expenses.ExpenseName = expenseModelsList[i].ExpnsName;
                documentModel_ExpensesList.Add(documentModel_Expenses);
            }

            model.DocumentAdditionalExpenses = documentModel_ExpensesList;
            #endregion

            ViewBag.CurrencyList = GetCurrencyList();
            ViewBag.BranchList = GetBranchList();
            ViewBag.ShippingTypeList = GetShippingTypeList();
            ViewBag.EmployeeList = GetEmployeeList();
            ViewBag.HSNList = GetHSNList();
            ViewBag.SalesEmployeeList = GetSalesEmployeeList(userId);
            ViewBag.CategoryList = GetCategoryList();
            ViewBag.WarehouseList = GetWarehouseList();

            return View(model);
        }
        [HttpPost]
        public IActionResult Add(DocumentModel model)
        {
            string responseText = string.Empty;
            var userId = HttpContext.User.Identity.Name;
            model.UserId = userId;
            if (Validate(model, out responseText) == true)
            {
                ResponseModel responseModel = _ISalesQuotationRepository.Add(model);
                if (responseModel.ResponseStatus == true)
                {
                    string seriesremark = _ICommonRepository.GetSeriesRemark(model.Series);
                    string slpcode = _ICommonRepository.GetSlpCodeFromEmailAddress(model.UserId);
                    if (slpcode == model.SalesPersonCode || seriesremark.ToUpper().Contains("PROOFING"))
                    {

                    }
                    else
                    {
                        model.DocEntry = responseModel.ResponseEntry;
                        SendMail(model);
                    }
                    TempData["Success"] = "1";
                    TempData["Message"] = responseModel.ResponseText;
                    return RedirectToAction("Index", "SalesQuotation");
                }
                else
                {
                    responseText = responseModel.ResponseText;
                }
            }
            ViewBag.CategoryList = GetCategoryList();
            ViewBag.CurrencyList = GetCurrencyList();
            ViewBag.BranchList = GetBranchList();
            ViewBag.ShippingTypeList = GetShippingTypeList();
            ViewBag.EmployeeList = GetEmployeeList();
            ViewBag.SalesEmployeeList = GetSalesEmployeeList(userId);
            ViewBag.WarehouseList = GetWarehouseList();
            ViewData["Error"] = "1";
            ViewData["Message"] = responseText;
            return View(model);

        }
        [Authorize]
        [HttpGet]
        public IActionResult Edit(string docEntry, string type)
        {
            var userId = HttpContext.User.Identity.Name;
            DocumentModel data = _ISalesQuotationRepository.Get(docEntry, userId, type);
            data.Type = type.ToUpper();
            ViewBag.CurrencyList = GetCurrencyList();
            ViewBag.BranchList = GetBranchList();
            ViewBag.ShippingTypeList = GetShippingTypeList();
            ViewBag.EmployeeList = GetEmployeeList();
            ViewBag.HSNList = GetHSNList();
            ViewBag.SalesEmployeeList = GetSalesEmployeeList(userId);
            ViewBag.YNList = GetYNList();
            ViewBag.CategoryList = GetCategoryList();
            ViewBag.WarehouseList = GetWarehouseList();
            return View(data);
        }
        [Authorize]
        [HttpPost]
        [DisableRequestSizeLimit]
        public IActionResult Edit(DocumentModel model)
        {
            var userId = HttpContext.User.Identity.Name;
            try
            {
                ResponseModel responseModel = _ISalesQuotationRepository.Update(model);
                if (responseModel.ResponseStatus == true)
                {
                    TempData["Success"] = "1";
                    TempData["Message"] = responseModel.ResponseText;
                    return RedirectToAction("Index", "SalesQuotation");
                }
                else
                {
                    ViewData["Error"] = "1";
                    ViewData["Message"] = responseModel.ResponseText + ".";

                    ViewBag.CurrencyList = GetCurrencyList();
                    ViewBag.BranchList = GetBranchList();
                    ViewBag.ShippingTypeList = GetShippingTypeList();
                    ViewBag.EmployeeList = GetEmployeeList();
                    ViewBag.HSNList = GetHSNList();
                    ViewBag.SalesEmployeeList = GetSalesEmployeeList(userId);
                    ViewBag.YNList = GetYNList();
                    ViewBag.CategoryList = GetCategoryList();
                    ViewBag.WarehouseList = GetWarehouseList();
                    return View(model);
                }
            }
            catch (Exception ex)
            {
                ViewData["Error"] = "1";
                ViewData["Message"] = ex.Message + ".";
                return View(model);
            }
        }

        [HttpPost]
        public ActionResult AttachmentAddRow(int index)
        {
            index = index - 1;
            var newRow = new DocumentModel_Attachment() { Index = index + 1 };
            ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("Attachments2_Lines[{0}]", index);
            return PartialView("~/Views/Shared/EditorTemplates/DocumentModel_Attachment.cshtml", newRow);
        }
        private bool Validate(DocumentModel model, out string responseMessage)
        {
            responseMessage = string.Empty;
            if (string.IsNullOrEmpty(model.CardCode))
            {
                responseMessage = "Please select business partner";
                return false;
            }
            else if (string.IsNullOrEmpty(model.WarehouseCode))
            {
                responseMessage = "Please select warehouse";
                return false;
            }
            return true;
        }
        [HttpPost]
        public string UploadItemData(IFormFile postedFile)
        {
            if (postedFile != null)
            {
                string path = Path.Combine(_IHostingEnvironment.WebRootPath, "Uploads");
                //string path = Path.Combine("D:\\Project\\LFC\\Web Portal\\Vissco Web Portal\\WebApp\\wwwroot\\", "Uploads");
                if (!Directory.Exists(path))
                {
                    Directory.CreateDirectory(path);
                }
                string fileName = Path.GetFileName(postedFile.FileName);
                string filePath = Path.Combine(path, fileName);
                using (FileStream stream = new FileStream(filePath, FileMode.Create))
                {
                    postedFile.CopyTo(stream);
                }
                DataTable dt = new DataTable();
                using (XLWorkbook workBook = new XLWorkbook(filePath))
                {
                    IXLWorksheet workSheet = workBook.Worksheet(1);
                    bool firstRow = true;
                    foreach (IXLRow row in workSheet.Rows())
                    {
                        if (firstRow)
                        {
                            foreach (IXLCell cell in row.Cells())
                            {
                                dt.Columns.Add(cell.Value.ToString());
                            }
                            firstRow = false;
                        }
                        else
                        {
                            dt.Rows.Add();
                            int i = 0;
                            foreach (IXLCell cell in row.Cells())
                            {
                                dt.Rows[dt.Rows.Count - 1][i] = cell.Value.ToString();
                                i++;
                            }
                        }
                    }
                }
                ViewBag.Data = dt;
                System.IO.File.Delete(filePath);
                //return Json(new { aaData = dt });
                //int index = 5;
                //var newRow = new SalesOrderRowsModel() { Index = index + 1 };
                //ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("salesOrderRowsModels[{0}]", index);
                //return PartialView("~/Views/Shared/EditorTemplates/SalesOrderRowsModel.cshtml", newRow);
                var jsonData = JsonConvert.SerializeObject(dt);
                return jsonData;
            }
            else
            {
                return null;
            }
            //return JsonConvert.SerializeObject(new { result = jsonData });
        }
        [HttpPost]
        public JsonResult UpdateStatus(string docEntry, string status)
        {
            var userId = HttpContext.User.Identity.Name;
            userId = _ICommonRepository.GetUserId(userId);
            ResponseModel responseModel = _ISalesQuotationRepository.UpdateStatus(docEntry, status, userId);
            return Json(new { value = responseModel });
        }
        public ResponseModel UploadAttachment(IFormFile postedFile)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                if (postedFile != null)
                {
                    string path = Path.Combine(_IHostingEnvironment.WebRootPath, "Uploads\\" + DateTime.Now.ToString("dd_MM_yyyy"));
                    //string path = Path.Combine("D:\\Project\\LFC\\Web Portal\\Vissco Web Portal\\WebApp\\wwwroot\\", "Uploads");
                    if (!Directory.Exists(path))
                    {
                        Directory.CreateDirectory(path);
                    }
                    string seed = DateTime.Now.ToString("dd_MM_yyyy_hh_mm_tt");   //+ Convert.ToString((int)DateTime.Now.Ticks);
                    string fileName = Path.GetFileName(postedFile.FileName);
                    fileName = System.IO.Path.GetFileNameWithoutExtension(fileName);
                    System.IO.FileInfo fi = new System.IO.FileInfo(postedFile.FileName);
                    string fileExtension = fi.Extension;
                    fileName = fileName + "_" + seed + fileExtension; //+ "_" + fileName;
                    string filePath = Path.Combine(path, fileName);
                    using (FileStream stream = new FileStream(filePath, FileMode.Create))
                    {
                        postedFile.CopyTo(stream);
                    }
                    responseModel.ResponseStatus = true;
                    responseModel.ResponseText = filePath;
                    return responseModel;
                }
            }
            catch (Exception ex)
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = ex.Message;
            }
            return responseModel;
        }
        [HttpPost]
        public ActionResult SalesQuotationAddRow(int index)
        {
            index = index - 1;
            var newRow = new DocumentRowsModel() { Index = index + 1 };
            ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("DocumentLines[{0}]", index);
            //ViewBag.HSNList = GetHSNList();
            ViewBag.CategoryList = GetCategoryList();
            ViewBag.WarehouseList = GetWarehouseList();
            return PartialView("~/Views/Shared/EditorTemplates/DocumentRowsModel.cshtml", newRow);
        }
        [HttpPost]
        public JsonResult Close(string docEntry)
        {
            ResponseModel responseModel = new ResponseModel();
            responseModel = _ISalesQuotationRepository.Close(docEntry);
            return Json(new { value = responseModel });
        }
        [HttpPost]
        public JsonResult Cancel(string docEntry)
        {
            ResponseModel responseModel = new ResponseModel();
            responseModel = _ISalesQuotationRepository.Cancel(docEntry);
            return Json(new { value = responseModel });
        }
        [HttpGet]
        public JsonResult GetSQClientPOData(string cardcode)
        {
            List<DocumentModel> list = _ISalesQuotationRepository.GetSQClientPOData(cardcode);
            return Json(new { aaData = list });
        }
        [HttpGet]
        public JsonResult GetSQSelectedData(string docEntry)
        {
            List<CopyLineModel> list = _ISalesQuotationRepository.GetSQSelectedData(docEntry);
            return Json(new { aaData = list });
        }

        [HttpGet]
        public JsonResult GetSQItemsNotAddedInClientPO(string docEntry)
        {
            List<CopyLineModel> list = _ISalesQuotationRepository.GetSQItemsNotAddedInClientPO(docEntry);
            return Json(list);
        }

        #region Select List
        [NonAction]
        private SelectList GetCurrencyList()
        {
            return new SelectList(_ICommonRepository.GetAllCurrency(), "CurrCode", "CurrName");
        }
        [NonAction]
        private SelectList GetBranchList()
        {
            return new SelectList(_ICommonRepository.GetAllBranch(), "BPLId", "BPLName");
        }
        [NonAction]
        private SelectList GetWarehouseList()
        {
            return new SelectList(_ICommonRepository.GetAllWarehouse(), "WhsCode", "WhsName");
        }
        [NonAction]
        private SelectList GetShippingTypeList()
        {
            return new SelectList(_ICommonRepository.GetAllShippingType(), "TrnspCode", "TrnspName");
        }
        [NonAction]
        private SelectList GetHSNList()
        {
            return new SelectList(_ICommonRepository.GetAllHSN(), "Chapter", "ChapterID");
        }
        [NonAction]
        private SelectList GetCategoryList()
        {
            return new SelectList(_ICommonRepository.GetUDFValuesList("RDR1", "Category"), "ID", "Name");
        }
        [NonAction]
        private SelectList GetYNList()
        {
            var selectLists = new SelectList(
                    new List<SelectListItem>
                    {
                        new SelectListItem { Value = "Y", Text = "Yes"},
                        new SelectListItem { Value= "N", Text = "No"},
                    }, "Value", "Text");

            return selectLists;
        }
        [NonAction]
        private SelectList GetEmployeeList()
        {
            return new SelectList(_ICommonRepository.GetAllEmployee(), "empID", "Name");
        }
        [NonAction]
        private SelectList GetSalesEmployeeList(string userId)
        {
            return new SelectList(_ICommonRepository.GetAllTeamSalesEmployee(userId), "SlpCode", "SlpName");
        }
        #endregion

        private ResponseModel SendMail(DocumentModel documentModel)
        {
            ResponseModel responseModel = new ResponseModel();
            Helpers helpers = new Helpers();
            SendMail _sendMail = new SendMail();
            string message = "";
            string subject = "Web Portal - Authorize Sales Quotation of Customer " + documentModel.CardName;
            DataTable dt = new DataTable();

            dt = helpers.ToDataTable(documentModel.DocumentLines);
            try
            {
                dt.Columns.Remove("Index");
                dt.Columns.Remove("LineId");
                dt.Columns.Remove("InStockQuantity");
                dt.Columns.Remove("DeliveredQuantity");
                dt.Columns.Remove("OpenQuantity");
                dt.Columns.Remove("IsDeleted");
                dt.Columns.Remove("HSNEntry");
                dt.Columns.Remove("WarehouseCode");
                dt.Columns.Remove("TaxCode");
                dt.Columns.Remove("UnitPrice");
                dt.Columns.Remove("Total");
                dt.Columns.Remove("TaxRate");
                dt.Columns.Remove("SupplierCatNum");
                dt.Columns.Remove("ShipDate");
            }
            catch { }
            string tableBody = helpers.ConvertToHtml(dt);
            string url = ConfigManager.GetWebSiteURL() + "SalesQuotation/Edit?docEntry=" + documentModel.DocEntry + "&type=draft";
            string draftNo = _ICommonRepository.GetDraftNo(documentModel.DocEntry);
            StringBuilder sbBody = new StringBuilder();
            //sbBody.Replace("{OTP}", otp);
            sbBody.Append("<p> Dear Sir/Madam <p/>");
            sbBody.Append("<p> Draft No:" + draftNo + "<p/>");
            sbBody.Append("<p> Billing Address:" + documentModel.Address + "<p/>");
            sbBody.Append("<p> Delivery Address:" + documentModel.Address2 + "<p/>");
            sbBody.Append("<p> Please see below document product details<p/>");
            sbBody.Append(tableBody);
            sbBody.Append("<p> Plese approve or reject document using below link <br/>");
            sbBody.Append(url + " <p/>");
            sbBody.Append("<p> Regards <br/>");
            sbBody.Append("   Web Admin<p/>");
            string ccEmail = documentModel.UserId;
            string toEmail = _ICommonRepository.GetSalesEmployeeEmailAddress(documentModel.SalesPersonCode);
            string bccEmail = ConfigManager.GetEmail_BCCEmailAddress();
            //bccEmail = "pravinaug17@gmail.com";
            List<string> attachmentList = documentModel.Attachments2_Lines.ToList().Select(a => a.trgtPath).ToList();
            string from = ConfigManager.GetSMTP_UserName();
            bool result = _sendMail.sendMail(from, toEmail, ccEmail, bccEmail, subject, sbBody.ToString(), attachmentList, out message);
            responseModel.ResponseStatus = result;
            responseModel.ResponseText = message;
            return responseModel;
        }
        [HttpGet]
        public JsonResult Print(string docEntry)
        {
            var data = _ISalesQuotationRepository.PDF(docEntry);
            return Json(new { aaData = data });
        }
    }
}
