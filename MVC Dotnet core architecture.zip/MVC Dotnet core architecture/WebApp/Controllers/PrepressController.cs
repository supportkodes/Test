﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using WebDAL.Helper;
using Microsoft.AspNetCore.Authorization;
using DocumentFormat.OpenXml.Spreadsheet;
using static WebDAL.Models.PrepressModel;
using DocumentFormat.OpenXml.Drawing.Charts;
using CrystalDecisions.ReportAppServer.Prompting;
using DocumentFormat.OpenXml.Vml.Office;

namespace WebApp.Controllers
{
    public class PrepressController : Controller
    {
        public readonly IPrepressRepository _IPrepressRepository = null;
        public readonly ICommonRepository _ICommonRepository = null;
        private IHostingEnvironment _IHostingEnvironment;
        public PrepressController(IPrepressRepository iIPrepressRepository, ICommonRepository iCommonRepository
            , IHostingEnvironment iHostingEnvironment)
        {
            _IPrepressRepository = iIPrepressRepository;
            _ICommonRepository = iCommonRepository;
            _IHostingEnvironment = iHostingEnvironment;
        }

        [Authorize]
        [HttpGet]
        public IActionResult Open(string? itemcode)
        {
            PrepressModel model = new PrepressModel();
            model.ItemCode = itemcode;
            return View(model);
        }

        [Authorize]
        [HttpGet]
        public IActionResult Closed(string? itemcode)
        {
            PrepressModel model = new PrepressModel();
            model.ItemCode = itemcode;
            return View(model);
        }

        //[Authorize]
        //[HttpGet]
        //public JsonResult GetAllOpenData(string name)
        //{
        //    List<PrepressRowsModel> data = _IPrepressRepository.GetAll(name, "O");
        //    return Json(new { aaData = data });
        //}

        [Authorize]
        [HttpGet]
        public JsonResult GetAllCloseData(string itemcode)
        {
            List<PrepressRowsModel> data = _IPrepressRepository.GetAll("name", "C", itemcode);
            return Json(new { aaData = data });
        }

        [Authorize]
        [HttpGet]
        public JsonResult GetAllOpenData_WIP(string itemcode)
        {
            List<PrepressRowsModel> data = _IPrepressRepository.GetAllOpenData_WIP(itemcode);
            return Json(new { aaData = data });
        }

        [Authorize]
        [HttpGet]
        public JsonResult GetAllOpenData_QC(string itemcode)
        {
            List<PrepressRowsModel> data = _IPrepressRepository.GetAllOpenData_QC(itemcode);
            return Json(new { aaData = data });
        }

        [Authorize]
        [HttpGet]
        public JsonResult GetAllOpenData_FO(string itemcode)
        {
            List<PrepressRowsModel> data = _IPrepressRepository.GetAllOpenData_FO(itemcode);
            return Json(new { aaData = data });
        }


        [NonAction]
        private SelectList GetReferenceSampleList()
        {
            var selectLists = new SelectList(
                    new List<SelectListItem>
                    {
                        new SelectListItem { Value = "APS", Text = "As Per Sample"},
                        new SelectListItem { Value= "NA", Text = "N/A"},
                    }, "Value", "Text");

            return selectLists;
        }

        [NonAction]
        private SelectList GetUserList()
        {
            return new SelectList(_ICommonRepository.GetAllPrepressEmployee(), "empID", "Name");
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateQCApproval(string itemcode)
        {
            ResponseModel responseModel = _IPrepressRepository.UpdateQCApproval(itemcode);
            return Json(new { value = responseModel });
        }
        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateFinalApproval(string itemcode)
        {
            ResponseModel responseModel = _IPrepressRepository.UpdateFinalApproval(itemcode);
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateArtworkApproval(string itemcode)
        {
            ResponseModel responseModel = _IPrepressRepository.UpdateArtworkApproval(itemcode);
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateRevisedApproval(string itemcode)
        {
            ResponseModel responseModel = _IPrepressRepository.UpdateRevisedApproval(itemcode);
            if (responseModel.ResponseStatus == true)
            {
                _IPrepressRepository.ReworkLog(itemcode);
            }
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateStartWork(string itemcode)
        {
            ResponseModel responseModel = _IPrepressRepository.UpdateStartWork(itemcode, "U_StartDate", "U_WIP_UpdateDate");
            return Json(new { value = responseModel });
        }


        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateEndWork(string itemcode)
        {
            ResponseModel responseModel = _IPrepressRepository.UpdateEndWork(itemcode, "U_EndDate", "U_WIP_UpdateDate");
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateQCStartWork(string itemcode)
        {
            ResponseModel responseModel = _IPrepressRepository.UpdateStartWork(itemcode, "U_StartDtQC", "U_QC_UpdateDate");
            return Json(new { value = responseModel });
        }


        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateQCEndWork(string itemcode)
        {
            ResponseModel responseModel = _IPrepressRepository.UpdateEndWork(itemcode, "U_EndDtQC", "U_QC_UpdateDate");
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateFOStartWork(string itemcode)
        {
            ResponseModel responseModel = _IPrepressRepository.UpdateStartWork(itemcode, "U_StartDtFO", "U_FO_UpdateDate");
            return Json(new { value = responseModel });
        }


        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateFOEndWork(string itemcode)
        {
            ResponseModel responseModel = _IPrepressRepository.UpdateEndWork(itemcode, "U_EndDtFO", "U_FO_UpdateDate");
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateArtworkReleaseDate(string itemcode, string date)
        {
            ResponseModel responseModel = _IPrepressRepository.UpdateArtworkReleaseDate(itemcode, date, "U_WIP_UpdateDate");
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateArtworkReleaseApproveDate(string itemcode, string date)
        {
            ResponseModel responseModel = _IPrepressRepository.UpdateArtworkReleaseApproveDate(itemcode, date, "U_WIP_UpdateDate");
            return Json(new { value = responseModel });
        }


        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateRemark(string itemcode, string Remark)
        {
            ResponseModel responseModel = _IPrepressRepository.UpdateRemark(itemcode, "U_Remarks", Remark, "U_WIP_UpdateDate");
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateQCRemark(string itemcode, string Remark)
        {
            ResponseModel responseModel = _IPrepressRepository.UpdateRemark(itemcode, "U_RemarkQC", Remark, "U_QC_UpdateDate");
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateFORemark(string itemcode, string Remark)
        {
            ResponseModel responseModel = _IPrepressRepository.UpdateRemark(itemcode, "U_RemarkFO", Remark, "U_FO_UpdateDate");
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateRefSample(string tableId, string itemcode, string refSampl)
        {
            string fieldName = "";
            if (tableId.Contains("WIP"))
            {
                fieldName = "";
            }
            else if (tableId.Contains("QC"))
            {
                fieldName = "";
            }
            else if (tableId.Contains("Final"))
            {
                fieldName = "";
            }
            ResponseModel responseModel = _IPrepressRepository.UpdateRefSample(itemcode, refSampl, "U_WIP_UpdateDate");
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateJobAssignTo(string itemcode, string value)
        {
            ResponseModel responseModel = _IPrepressRepository.UpdatePrepressColumnData(itemcode, "U_JobAssTo", value, "U_WIP_UpdateDate");
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateQCJobAssignTo(string itemcode, string value)
        {
            ResponseModel responseModel = _IPrepressRepository.UpdatePrepressColumnData(itemcode, "U_JobAsTQC", value, "U_QC_UpdateDate");
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateFOJobAssignTo(string itemcode, string value)
        {
            ResponseModel responseModel = _IPrepressRepository.UpdatePrepressColumnData(itemcode, "U_JobAsTFO", value, "U_FO_UpdateDate");
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateSampleSubmitDate(string itemcode, string date, string refsample)
        {
            ResponseModel responseModel = _IPrepressRepository.UpdateSampleSubmitDate(itemcode, date, refsample);
            return Json(new { value = responseModel });
        }

        public JsonResult ReworkLog(string itemcode)
        {
            ResponseModel responseModel = _IPrepressRepository.ReworkLog(itemcode);
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateKLDPunch(string itemcode, string KLDNo, string PunchNo)
        {
            ResponseModel responseModel = _IPrepressRepository.UpdateKLD(itemcode, KLDNo);
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdatePunch(string itemcode, string PunchNo)
        {
            ResponseModel responseModel = _IPrepressRepository.UpdatePunch(itemcode, PunchNo);
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateInkType(string itemcode, string InkType)
        {
            ResponseModel responseModel = _IPrepressRepository.UpdateInkType(itemcode, InkType);
            return Json(new { value = responseModel });
        }

    }
}
