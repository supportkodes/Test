﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using WebDAL.Helper;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Logging;
using System.Net.Http;
using System.Net;
using System.Reflection;
using DocumentFormat.OpenXml.EMMA;

namespace WebApp.Controllers
{
    public class KLDMasterController : Controller
    {
        public readonly IKLDMasterRepository _IKLDMasterRepository = null;
        public readonly ICommonRepository _ICommonRepository = null;
        private IHostingEnvironment _IHostingEnvironment;
        private readonly ILogger<KLDMasterController> _ILogger;

        public KLDMasterController(IKLDMasterRepository iIKLDMasterRepository,
            ICommonRepository iCommonRepository, IHostingEnvironment iHostingEnvironment
            , ILogger<KLDMasterController> iLogger
            )
        {
            _IKLDMasterRepository = iIKLDMasterRepository;
            _ICommonRepository = iCommonRepository;
            _IHostingEnvironment = iHostingEnvironment;
            _ILogger = iLogger;
        }

        [Authorize]
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult GetAll(string status)
        {
            var userId = HttpContext.User.Identity.Name;
            List<KLDMasterModel> data = _IKLDMasterRepository.GetAll(status);
            for (int i = 0; i < data.Count; i++)
            {
                data[i].EditLink = Url.Action("Edit", "KLDMaster", new { code = data[i].Code });// , itemcode = data[i].U_ItemCode 
            }
            return Json(new { aaData = data });
        }

        [Authorize]
        [HttpGet]
        public IActionResult Add()
        {

            var userId = HttpContext.User.Identity.Name;
            string ownerId = _ICommonRepository.GetEmpId(userId);
            KLDMasterModel kLDMasterModel = new KLDMasterModel();
            kLDMasterModel.U_KLDDt = DateTime.Now.ToString("dd-MM-yyyy");
            List<KLDMasterRowsModel> rowsList = new List<KLDMasterRowsModel>();
            KLDMasterRowsModel rowsModel = new KLDMasterRowsModel();
            rowsModel.Index = 1;
            rowsList.Add(rowsModel);
            kLDMasterModel.Rows = rowsList;
            ViewBag.CartonTypeList = GetDropDownList("CARTONTYPE");
            ViewBag.NumberingList = GetNumberingList();

            List<KLDPartRowsModel> partRowsList = new List<KLDPartRowsModel>();
            var partCodes = _ICommonRepository.GetDropDownList("PART");
            for (int i = 0; i < partCodes.Count; i++)
            {
                KLDPartRowsModel partRowsModel = new KLDPartRowsModel();
                partRowsModel.Index = i + 1;
                partRowsModel.PartNo = partCodes[i].ID;
                partRowsModel.PartName = partCodes[i].Name;
                partRowsList.Add(partRowsModel);
            }
            kLDMasterModel.PartRows = partRowsList;
            return View(kLDMasterModel);
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public IActionResult Add(KLDMasterModel model)
        {
            string responseText = string.Empty;
            var userId = HttpContext.User.Identity.Name;
            string createdBy = _ICommonRepository.GetUserId(userId);
            model.U_CrBy = createdBy;
            ResponseModel responseModel = new ResponseModel();
            responseModel = Validate(model);
            if (responseModel.ResponseStatus == true)
            {
                responseModel = _IKLDMasterRepository.Add(model);
                if (responseModel.ResponseStatus == true)
                {
                    TempData["Success"] = "1";
                    TempData["Message"] = responseModel.ResponseText;
                    return RedirectToAction("Add", "KLDMaster");
                }
            }
            ViewBag.CartonTypeList = GetDropDownList("CARTONTYPE");
            ViewBag.NumberingList = GetNumberingList();
            //ViewBag.PartCodeList = GetDropDownList("PART");
            ViewData["Error"] = "1";
            ViewData["Message"] = responseModel.ResponseText;
            return View(model);
        }
        [HttpGet]
        public IActionResult Edit(string code)// , string itemcode
        {
            KLDMasterRowsModel rowsModel = new KLDMasterRowsModel();
            //string itemcode =  rowsModel.U_ItemCode;
            string userId = HttpContext.User.Identity.Name;
            userId = _ICommonRepository.GetUserId(userId);
            KLDMasterModel data = _IKLDMasterRepository.Get(code);// , itemcode
            ViewBag.CartonTypeList = GetDropDownList("CARTONTYPE");
            ViewBag.PartCodeList = GetDropDownList("PART");
            return View(data);
        }

        [DisableRequestSizeLimit]
        [HttpPost]
        public IActionResult Edit(KLDMasterModel model)
        {
            string userId = HttpContext.User.Identity.Name;
            ResponseModel responseModel = new ResponseModel();
            responseModel = Validate(model);
            if (responseModel.ResponseStatus == true)
            {
                responseModel = _IKLDMasterRepository.Update(model);
                if (responseModel.ResponseStatus == true)
                {
                    TempData["Success"] = "1";
                    TempData["Message"] = responseModel.ResponseText;
                    return RedirectToAction("Add", "KLDMaster", new { code = model.Code });
                }
            }
            ViewBag.CartonTypeList = GetDropDownList("CARTONTYPE");
            ViewBag.PartCodeList = GetDropDownList("PART");
            ViewData["Error"] = "1";
            ViewData["Message"] = responseModel.ResponseText + ".";
            return RedirectToAction("Add", "KLDMaster");
        }

        [DisableRequestSizeLimit]
        [HttpGet]
        public void AddBulkImport()
        {
            string path = "D:\\Pravin\\Code\\kld.json";
            var jsonText = System.IO.File.ReadAllText(path);
            var list = JsonConvert.DeserializeObject<List<KLDMasterModel>>(jsonText);
            for (int i = 0; i < list.Count; i++)
            {
                KLDMasterModel model = list[i];
                _IKLDMasterRepository.Add(model);
            }
        }

        [HttpPost]
        public ActionResult AddRow(int index)
        {
            index = index - 1;
            var newRow = new KLDMasterRowsModel() { Index = index + 1 };
            ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("Rows[{0}]", index);
            return PartialView("~/Views/Shared/EditorTemplates/KLDMasterRowsModel.cshtml", newRow);
        }

        private ResponseModel Validate(KLDMasterModel model)
        {
            ResponseModel responseModel = new ResponseModel();
            responseModel.ResponseStatus = true;
            try
            {
                if (string.IsNullOrEmpty(model.U_KLDNo))
                {
                    responseModel.ResponseText = "Please check KLD No";
                    responseModel.ResponseStatus = false;
                    return responseModel;
                }
                //else if (string.IsNullOrEmpty(model.U_CardCode))
                //{
                //    responseModel.ResponseText = "Please Select Client Name";
                //    responseModel.ResponseStatus = false;
                //    return responseModel;
                //}
                else if (string.IsNullOrEmpty(model.U_Location))
                {
                    responseModel.ResponseText = "Please Select Location";
                    responseModel.ResponseStatus = false;
                    return responseModel;
                }
                else if (string.IsNullOrEmpty(model.U_CartTyp))
                {
                    responseModel.ResponseText = "Please Select Card Type";
                    responseModel.ResponseStatus = false;
                    return responseModel;
                }
                else if (string.IsNullOrEmpty(model.U_Lmm))
                {
                    responseModel.ResponseText = "Please Enter Length";
                    responseModel.ResponseStatus = false;
                    return responseModel;
                }
                else if (string.IsNullOrEmpty(model.U_Wmm))
                {
                    responseModel.ResponseText = "Please Enter Width";
                    responseModel.ResponseStatus = false;
                    return responseModel;
                }
                else if (string.IsNullOrEmpty(model.U_Hmm))
                {
                    responseModel.ResponseText = "Please Enter Height";
                    responseModel.ResponseStatus = false;
                    return responseModel;
                }
                else if (string.IsNullOrEmpty(model.U_Desc))
                {
                    responseModel.ResponseText = "Please Enter Description";
                    responseModel.ResponseStatus = false;
                    return responseModel;
                }
            }
            catch (Exception ex)
            {
            }
            return responseModel;
        }

        [NonAction]
        private SelectList GetDropDownList(string code)
        {
            return new SelectList(_ICommonRepository.GetDropDownList(code), "ID", "Name");
        }


        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateStatus(string code, string status)
        {
            _IKLDMasterRepository.UpdateStatus(code, status);
            return Json("Status updated successfully");
        }

        [NonAction]
        private SelectList GetNumberingList()
        {
            List<SelectListItem> listItems = new List<SelectListItem>();
            for (int i = 0; i <= 20; i++)
            {
                SelectListItem item = new SelectListItem();
                item.Value = i.ToString().PadLeft(2, '0');
                item.Text = i.ToString().PadLeft(2, '0');
                listItems.Add(item);
            }

            var selectLists = new SelectList(listItems, "Value", "Text");
            return selectLists;
        }
    }
}
