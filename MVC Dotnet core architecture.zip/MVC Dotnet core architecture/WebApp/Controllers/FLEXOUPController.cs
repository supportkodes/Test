﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using WebDAL.Helper;
using Microsoft.AspNetCore.Authorization;
using DocumentFormat.OpenXml.Spreadsheet;

namespace WebApp.Controllers
{
	public class FLEXOUPController : Controller
	{
		public readonly IFLEXOUPRepository _IFLEXOUPRepository = null;
		public readonly ICommonRepository _ICommonRepository = null;
		private IHostingEnvironment _IHostingEnvironment;
		public FLEXOUPController(IFLEXOUPRepository iIFLEXOUPRepository, ICommonRepository iCommonRepository
			, IHostingEnvironment iHostingEnvironment)
		{
			_IFLEXOUPRepository = iIFLEXOUPRepository;
			_ICommonRepository = iCommonRepository;
			_IHostingEnvironment = iHostingEnvironment;
		}

		[Authorize]
		[HttpGet]
		public IActionResult Index()
		{
			return View();
		}

		[HttpGet]
		public IActionResult GetAll()
		{
			List<FLEXOUPIndexModel> data = _IFLEXOUPRepository.GetAll();
			for (int i = 0; i < data.Count; i++)
			{
				data[i].EditLink = Url.Action("Edit", "FLEXOUP", new { docEntry = data[i].DocEntry });
			}
			return Json(new { aaData = data });
		}

		[HttpGet]
		public IActionResult Add()
		{
			var userId = HttpContext.User.Identity.Name;
			string ownerId = _ICommonRepository.GetEmpId(userId);
			FLEXOUPModel model = new FLEXOUPModel();
			 
			#region Rows
			
			List<FLEXOUPModelRow> rowsModelList = new List<FLEXOUPModelRow>();
			FLEXOUPModelRow rowModel = new FLEXOUPModelRow();
			rowModel.Index = 1;
			rowsModelList.Add(rowModel);
			model.APAFUP1Collection = rowsModelList;

			#endregion

			//ViewBag.SalesEmployeeList = GetSalesEmployeeList(userId);
			return View(model);
		}

		[HttpPost]
		public IActionResult Add(FLEXOUPModel model)
		{
			string responseText = string.Empty;
			var userId = HttpContext.User.Identity.Name;
			//model.UserId = userId;
			if (Validate(model, out responseText) == true)
			{
				ResponseModel responseModel = _IFLEXOUPRepository.Add(model);
				if (responseModel.ResponseStatus == true)
				{
					TempData["Success"] = "1";
					TempData["Message"] = responseModel.ResponseText;
					return RedirectToAction("Index", "FLEXOUP");
				}
				else
				{
					responseText = responseModel.ResponseText;
				}
			}

			ViewData["Error"] = "1";
			ViewData["Message"] = responseText;
			return View(model);
		}
	
		[HttpGet]
		public IActionResult Edit(string docEntry)
		{
			FLEXOUPModel data = _IFLEXOUPRepository.Get(docEntry);
			//data.Code = itemcode;
			
			return View(data);
		}


		[DisableRequestSizeLimit]
		[HttpPost]
		public IActionResult Edit(FLEXOUPModel model)
		{
			var userId = HttpContext.User.Identity.Name;
			ResponseModel responseModel = _IFLEXOUPRepository.Update(model);
			ResponseModel responseModel1 = new ResponseModel();
			//try
			//{
			//	responseModel1 = _IFLEXOUPRepository.Update(model);
			//}
			//catch (Exception ex)
			//{
			//	responseModel.ResponseStatus = false;
			//	responseModel.ResponseText = ex.Message;
			//}
			if (responseModel.ResponseStatus == true)
			{
				TempData["Success"] = "1";
				TempData["Message"] = responseModel.ResponseText;
				return RedirectToAction("Index", "FLEXOUP");
			}
			else
			{
				ViewData["Error"] = "1";
				ViewData["Message"] = responseModel.ResponseText + ".";
				
				return View(model);
			}
		}


		[HttpPost]
		public ActionResult FLEXOUPAddRow(int index)
		{
			index = index - 1;
			var newRow = new FLEXOUPModelRow() { Index = index + 1 };
			ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("APAFUP1Collection[{0}]", index);
			//ViewBag.HSNList = GetHSNList();
			return PartialView("~/Views/Shared/EditorTemplates/FLEXOUPModelRow.cshtml", newRow);
		}
		private bool Validate(FLEXOUPModel model, out string responseMessage)
		{
			responseMessage = string.Empty;
			//if (string.IsNullOrEmpty(model.TreeCode))
			//{
			//	responseMessage = "Please select header itemcode";
			//	return false;
			//}
            return true;
		}

		#region Select List

		[NonAction]
		private SelectList GetSalesEmployeeList(string userId)
		{
			return new SelectList(_ICommonRepository.GetAllTeamSalesEmployee(userId), "SlpCode", "SlpName");
		}
		#endregion
	}
}
