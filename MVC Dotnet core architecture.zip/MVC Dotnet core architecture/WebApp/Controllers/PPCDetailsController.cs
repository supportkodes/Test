﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using WebDAL.Helper;
using Microsoft.AspNetCore.Authorization;
using DocumentFormat.OpenXml.Spreadsheet;
using static WebDAL.Models.PrepressModel;
using CrystalDecisions.ReportAppServer.Prompting;
using static WebDAL.Models.PPCDetailsModel;

namespace WebApp.Controllers
{
    public class PPCDetailsController : Controller
    {
        public readonly IPPCDetailsRepository _IPPCDetailsRepository = null;
        public readonly ICommonRepository _ICommonRepository = null;
        private IHostingEnvironment _IHostingEnvironment;
        public PPCDetailsController(IPPCDetailsRepository iIPPCDetailsRepository, ICommonRepository iCommonRepository
            , IHostingEnvironment iHostingEnvironment)
        {
            _IPPCDetailsRepository = iIPPCDetailsRepository;
            _ICommonRepository = iCommonRepository;
            _IHostingEnvironment = iHostingEnvironment;
        }


        [Authorize]
        [HttpGet]
        public IActionResult Index(string sono)
        {
            PPCDetailsModel model = new PPCDetailsModel();
            model.SONo = sono;
            model.Branch = "1";
            ViewBag.BranchList = GetBranchList();
            //ViewBag.LocationList = GetLocationList();

            return View(model);
        }

        [HttpGet]
        public IActionResult GetAll(string sono,string branch,string itemcode)
        {
            DataTable dataTable = new DataTable();
            List<PPCDetailsRowModel> data = _IPPCDetailsRepository.GetAllPPCDetails(sono, branch, itemcode,out dataTable);
            return Json(new { aaData = data });
        }

        [Authorize]
        [HttpGet]
        public IActionResult MachinePlanning(string sono)
        {
            PPCDetailsModel model = new PPCDetailsModel();
            model.SONo = sono;
            model.Branch = "1";
            ViewBag.BranchList = GetBranchList();
            return View(model);
        }


        [HttpGet]
        public IActionResult GetMachinePlanning(string sono, string branch, string itemcode)
        {
            DataTable dataTable = new DataTable();
            List<PPCDetailsRowModel> data = _IPPCDetailsRepository.GetMachinePlanning(sono, branch, itemcode, out dataTable);
            return Json(new { aaData = data });
        }


        [NonAction]
        private SelectList GetUserList()
        {
            return new SelectList(_ICommonRepository.GetAllPrepressEmployee(), "empID", "Name");
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateDispatchDate1(string itemcode, string date)
        {
            ResponseModel responseModel = _IPPCDetailsRepository.UpdateDispatchDate1(itemcode, date);
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateDispatchDate2(string itemcode, string date)
        {
            ResponseModel responseModel = _IPPCDetailsRepository.UpdateDispatchDate2(itemcode, date);
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateDispatchDate3(string itemcode, string date)
        {
            ResponseModel responseModel = _IPPCDetailsRepository.UpdateDispatchDate3(itemcode, date);
            return Json(new { value = responseModel });
        }

        [HttpGet]
        public JsonResult GetBOMInkDetails(string itemcode, string group)
        {
            List<PPCDetailsInkDetailsModel> data = _IPPCDetailsRepository.GetBOMInkDetails(itemcode, group);
            return Json(new { aaData = data });
        }

        [HttpPost]
        //[DisableRequestSizeLimit]
        public JsonResult UpdateInkDetails(List<PPCDetailsInkDetailsModel> lists)
        {
            ResponseModel responseModel = _IPPCDetailsRepository.UpdateInkDetails(lists);
            return Json(new { value = responseModel });
        }

        [HttpPost]
        public JsonResult UpdateItemInInkDetails(string father, string itemcode)
        {
            ResponseModel responseModel = _IPPCDetailsRepository.UpdateItemInInkDetails(father, itemcode);
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateINKDate(string itemcode)
        {
            ResponseModel responseModel = _IPPCDetailsRepository.UpdateDate(itemcode, "U_LinkDate");
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateINKConfirmationDate(string itemcode, string date)
        {
            ResponseModel responseModel = _IPPCDetailsRepository.UpdateConfirmationDate(itemcode, "U_LinkDate", date);
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateVanishConfirmationDate(string itemcode, string date)
        {
            ResponseModel responseModel = _IPPCDetailsRepository.UpdateConfirmationDate(itemcode, "U_VarnishDate", date);
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateBoxConfirmationDate(string itemcode, string date)
        {
            ResponseModel responseModel = _IPPCDetailsRepository.UpdateConfirmationDate(itemcode, "U_CBoxDate", date);
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdatePaperConfirmationDate(string itemcode, string date)
        {
            ResponseModel responseModel = _IPPCDetailsRepository.UpdateConfirmationDate(itemcode, "U_PaperDate", date);
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateFilmConfirmationDate(string itemcode, string date)
        {
            ResponseModel responseModel = _IPPCDetailsRepository.UpdateConfirmationDate(itemcode, "U_LFilmDate", date);
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateVanishDate(string itemcode)
        {
            ResponseModel responseModel = _IPPCDetailsRepository.UpdateDate(itemcode, "U_VarnishDate");
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateBoxDate(string itemcode)
        {
            ResponseModel responseModel = _IPPCDetailsRepository.UpdateDate(itemcode, "U_CBoxDate");
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdatePaperDate(string itemcode)
        {
            ResponseModel responseModel = _IPPCDetailsRepository.UpdateDate(itemcode, "U_PaperDate");
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateFilmDate(string itemcode)
        {
            ResponseModel responseModel = _IPPCDetailsRepository.UpdateDate(itemcode, "U_LFilmDate");
            return Json(new { value = responseModel });
        }

        [HttpPost]
        public JsonResult UpdateItemStatusInInkDetails(string father, string itemcode, string status)
        {
            ResponseModel responseModel = new ResponseModel();
            if (!string.IsNullOrEmpty(itemcode))
            {
                responseModel = _IPPCDetailsRepository.UpdateItemStatusInInkDetails(father, itemcode, status);
            }
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateINKConfirmation(string itemcode)
        {
            ResponseModel responseModel = _IPPCDetailsRepository.UpdateConfirmation(itemcode, "U_IsLink");
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateVanishConfirmation(string itemcode)
        {
            ResponseModel responseModel = _IPPCDetailsRepository.UpdateConfirmation(itemcode, "U_IsVarnish");
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdatePaperConfirmation(string itemcode)
        {
            ResponseModel responseModel = _IPPCDetailsRepository.UpdateConfirmation(itemcode, "U_IsPaper");
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateBoxConfirmation(string itemcode)
        {
            ResponseModel responseModel = _IPPCDetailsRepository.UpdateConfirmation(itemcode, "U_IsCBox");
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateFilmConfirmation(string itemcode)
        {
            ResponseModel responseModel = _IPPCDetailsRepository.UpdateConfirmation(itemcode, "U_IsLFilm");
            return Json(new { value = responseModel });
        }

        [NonAction]
        private SelectList GetBranchList()
        {
            return new SelectList(_ICommonRepository.GetAllBranch(), "BPLId", "BPLName");
        }

        [NonAction]
        private SelectList GetLocationList()
        {
            return new SelectList(_ICommonRepository.GetAllWarehouseList(), "BPLId", "BPLName");
        }

        public ActionResult ExportToExcel(string sono, string branch,string itemcode)
        {
            DataTable dataTable = new DataTable();
            _IPPCDetailsRepository.GetAllPPCDetails(sono, branch, itemcode, out dataTable);
            // Name of File
            string fileName = "PPC.xlsx";
            using (XLWorkbook wb = new XLWorkbook())
            {
                dataTable.TableName = "PPC";
                // Add DataTable in worksheet
                wb.Worksheets.Add(dataTable);
                using (MemoryStream stream = new MemoryStream())
                {
                    wb.SaveAs(stream);
                    // Return xlsx Excel File
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
                }
            }
        }
    }
}
