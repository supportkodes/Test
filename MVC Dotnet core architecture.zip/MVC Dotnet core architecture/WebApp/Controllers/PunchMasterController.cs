﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using WebDAL.Helper;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Logging;
using System.Net.Http;
using System.Net;
using CrystalDecisions.CrystalReports.Engine;
using static WebDAL.Models.PurchaseOrderModel;
using static WebDAL.Models.PunchMasterModel;

namespace WebApp.Controllers
{
    public class PunchMasterController : Controller
    {
        public readonly IPunchMasterRepository _IPunchMasterRepository = null;
        public readonly ICommonRepository _ICommonRepository = null;
        private IHostingEnvironment _IHostingEnvironment;
        private readonly ILogger<PunchMasterController> _ILogger;

        public PunchMasterController(IPunchMasterRepository iIPunchMasterRepository,
            ICommonRepository iCommonRepository, IHostingEnvironment iHostingEnvironment
            , ILogger<PunchMasterController> iLogger
            )
        {
            _IPunchMasterRepository = iIPunchMasterRepository;
            _ICommonRepository = iCommonRepository;
            _IHostingEnvironment = iHostingEnvironment;
            _ILogger = iLogger;
        }

        [HttpGet]
        public IActionResult GetAll(string type)
        {
            var userId = HttpContext.User.Identity.Name;
            List<PunchMasterModel> data = _IPunchMasterRepository.GetAll();
            for (int i = 0; i < data.Count; i++)
            {
                data[i].EditLink = Url.Action("Edit", "PunchMaster", new { code = data[i].Code });
            }
            return Json(new { aaData = data });
        }

        [Authorize]
        [HttpGet]
        public IActionResult Add()
        {
            var userId = HttpContext.User.Identity.Name;
            PunchMasterModel model = new PunchMasterModel();
            model.U_PunchDt = DateTime.Now.ToString("dd-MM-yyyy");
            //model.U_PunRecDt = DateTime.Now.ToString("dd-MM-yyyy");
            //model.U_PunSenDt = DateTime.Now.ToString("dd-MM-yyyy");

            List<PunchMasterRowsModel> rowsList = new List<PunchMasterRowsModel>();
            PunchMasterRowsModel rowsModel = new PunchMasterRowsModel();
            rowsModel.Index = 1;
            rowsList.Add(rowsModel);

            model.Rows = rowsList;
            ViewBag.CartonTypeList = GetDropDownList("CARTONTYPE");
            return View(model);
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public IActionResult Add(PunchMasterModel model)
        {
            string responseText = string.Empty;
            var userId = HttpContext.User.Identity.Name;
            string createdBy = _ICommonRepository.GetUserId(userId);
            model.U_CrBy = createdBy;
            ResponseModel responseModel = new ResponseModel();
            if (Validate(model, out responseText) == true)
            {
                responseModel = _IPunchMasterRepository.Add(model);
                if (responseModel.ResponseStatus == true)
                {
                    TempData["Success"] = "1";
                    TempData["Message"] = responseModel.ResponseText;
                    return RedirectToAction("Add", "PunchMaster");
                }
                else
                {
                    responseText = responseModel.ResponseText;
                }
            }
            ViewBag.CartonTypeList = GetDropDownList("CARTONTYPE");
            ViewData["Error"] = "1";
            ViewData["Message"] = responseText;
            return View(model);
        }
        [HttpGet]
        public IActionResult Edit(string code)
        {
            PunchMasterModel data = new PunchMasterModel();
            data = _IPunchMasterRepository.Get(code);
            ViewBag.CartonTypeList = GetDropDownList("CARTONTYPE");
            return View(data);
        }

        [DisableRequestSizeLimit]
        [HttpPost]
        public IActionResult Edit(PunchMasterModel model)
        {
            string userId = HttpContext.User.Identity.Name;
            string responseText = "";
            if (Validate(model, out responseText) == true)
            {
                ResponseModel responseModel = _IPunchMasterRepository.Update(model);
                if (responseModel.ResponseStatus == true)
                {
                    TempData["Success"] = "1";
                    TempData["Message"] = responseModel.ResponseText;
                    return RedirectToAction("Add", "PunchMaster");
                }
                else
                {
                    responseText = responseModel.ResponseText;
                }
            }
            ViewBag.CartonTypeList = GetDropDownList("CARTONTYPE");
            ViewData["Error"] = "1";
            ViewData["Message"] = responseText;
            return View(model);
        }

        [HttpPost]
        public ActionResult AddRow(int index)
        {
            index = index - 1;
            var newRow = new PunchMasterRowsModel() { Index = index + 1 };
            ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("Rows[{0}]", index);
            return PartialView("~/Views/Shared/EditorTemplates/PunchMasterRowsModel.cshtml", newRow);
        }

        private bool Validate(PunchMasterModel model, out string responseMessage)
        {
            responseMessage = string.Empty;
            try
            {

                double dblTotalRowsNoOfOps = 0;
                double dblHeaderNoOfOps = string.IsNullOrEmpty(model.U_NoOfUps) ? 0 : double.Parse(model.U_NoOfUps);
                model.Rows = model.Rows.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
                for (int i = 0; i < model.Rows.Count; i++)
                {
                    dblTotalRowsNoOfOps = dblTotalRowsNoOfOps + Convert.ToDouble(model.Rows[i].U_NoofUPS);
                }
                if (dblHeaderNoOfOps != dblTotalRowsNoOfOps)
                {
                    responseMessage = "Total No Of Ups is not matching with row total no of ups";
                    return false;
                }
                else if (string.IsNullOrEmpty(model.U_Location))
                {
                    responseMessage = "Please Select Location";
                    return false;
                }
                else if (string.IsNullOrEmpty(model.U_SuppCode))
                {
                    responseMessage = "Please Select Vendor Name";
                    return false;
                }
                else if (string.IsNullOrEmpty(model.U_PunchTyp))
                {
                    responseMessage = "Please Select Punch Type";
                    return false;
                }
                else if (string.IsNullOrEmpty(model.U_CartTyp))
                {
                    responseMessage = "Please Select Carton Type";
                    return false;
                }
                else if (string.IsNullOrEmpty(model.U_NoOfUps))
                {
                    responseMessage = "Please Enter No Of UPS";
                    return false;
                }
                //else if (string.IsNullOrEmpty(model.U_PunRecDt))
                //{
                //    responseMessage = "Please Select Punch Received Date";
                //    return false;
                //}
                else if (string.IsNullOrEmpty(model.U_SizeX))
                {
                    responseMessage = "Please Enter Size X";
                    return false;
                }
                else if (string.IsNullOrEmpty(model.U_SizeY))
                {
                    responseMessage = "Please Enter Size Y";
                    return false;
                }
                //else if (string.IsNullOrEmpty(model.U_Remark))
                //{
                //    responseMessage = "Please Enter Remark";
                //    return false;
                //}
                //else if (string.IsNullOrEmpty(model.U_PunSenDt))
                //{
                //    responseMessage = "Please Select Punch Send Date";
                //    return false;
                //}
                //else if (string.IsNullOrEmpty(model.U_KLDNo))
                //{
                //    responseMessage = "Please Select KLD No";
                //    return false;
                //}

            }
            catch (Exception ex)
            {
            }
            return true;
        }


        [NonAction]
        private SelectList GetDropDownList(string code)
        {
            return new SelectList(_ICommonRepository.GetDropDownList(code), "ID", "Name");
        }


        [DisableRequestSizeLimit]
        [HttpGet]
        public void AddBulkImport()
        {
            string path = "D:\\Pravin\\Code\\punch.json";
            var jsonText = System.IO.File.ReadAllText(path);
            var list = JsonConvert.DeserializeObject<List<PunchMasterModel>>(jsonText);
            for (int i = 0; i < list.Count; i++)
            {
                PunchMasterModel model = list[i];
                List<PunchMasterRowsModel> rowsList = new List<PunchMasterRowsModel>();
                PunchMasterRowsModel rowsModel = new PunchMasterRowsModel();
                rowsModel.U_KLDNo = model.U_KLDNo;
                rowsModel.U_NoofUPS = model.U_NoOfUps;
                rowsList.Add(rowsModel);
                model.Rows = rowsList;
                _IPunchMasterRepository.AddBulkImport(model);
            }
        }
    }
}
