﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using CrystalDecisions.CrystalReports.Engine;
using DocumentFormat.OpenXml.EMMA;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml.Vml;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebDAL.Helper;
using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Repository;

namespace WebApp.Controllers
{
    public class ECRController : Controller
    {
        public readonly IECRRepository _IECRRepository = null;
        public readonly ICommonRepository _ICommonRepository = null;
        private IHostingEnvironment _IHostingEnvironment;

        public string dept { get; private set; }

        public ECRController(IECRRepository iECRRepository, ICommonRepository iCommonRepository
            , IHostingEnvironment iHostingEnvironment)
        {
            _IECRRepository = iECRRepository;
            _ICommonRepository = iCommonRepository;
            _IHostingEnvironment = iHostingEnvironment;
        }

        [Authorize]
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult GetAll(string status)
        {
            var userId = HttpContext.User.Identity.Name;
            string department = GetDepartmentId();

            List<ECRMasterModel> data = _IECRRepository.GetAll(userId, department, status);
            for (int i = 0; i < data.Count; i++)
            {
                data[i].EditLink = Url.Action("Edit", "ECR", new { code = data[i].Code });
            }
            return Json(new { aaData = data });
        }

        [HttpGet]
        public IActionResult Add()
        {
            var userId = HttpContext.User.Identity.Name;
            string ownerId = _ICommonRepository.GetEmpId(userId);
            ECRMasterModel model = new ECRMasterModel();
            model.U_Date = DateTime.Now.ToString("dd-MM-yyyy");
            model.Code = "1";
            #region ECR Rows
            List<ECRRowModel> ECRRowModellList = new List<ECRRowModel>();
            ECRRowModel eCRRowModel = new ECRRowModel();
            eCRRowModel.Index = 1;
            string code = _IECRRepository.GetECRAutoNo();
            model.Code = code;
            ECRRowModellList.Add(eCRRowModel);
            model.ECR1Collection = ECRRowModellList;
            #endregion

            #region Attachment Rows
            List<ECRModel_Attachment> ecrModel_AttachmentList = new List<ECRModel_Attachment>();
            ECRModel_Attachment ecrModel_Attachment = new ECRModel_Attachment();
            ecrModel_Attachment.LineId = 1;
            ecrModel_AttachmentList.Add(ecrModel_Attachment);
            model.ECR2Collection = ecrModel_AttachmentList;
            #endregion

            ViewBag.SalesEmployeeList = GetSalesEmployeeList(userId);
			ViewBag.ReasonList = GetDropDownList(DropDown.ECRREASON.ToString());

			return View(model);
        }

        [HttpPost]
        public IActionResult Add(ECRMasterModel model)
        {
            string responseText = string.Empty;
            var userId = HttpContext.User.Identity.Name;
            model.UserId = userId;
            string empId = GetEmpId();
            model.EmpId = empId;

            if (Validate(model, out responseText) == true)
            {
                ResponseModel responseModel = _IECRRepository.Add(model);
                if (responseModel.ResponseStatus == true)
                {
                    SendMail(model);
                    TempData["Success"] = "1";
                    TempData["Message"] = responseModel.ResponseText;
                    return RedirectToAction("Index", "ECR");
                }
                else
                {
                    responseText = responseModel.ResponseText;
                }
            }
            ViewBag.SalesEmployeeList = GetSalesEmployeeList(userId);
			ViewBag.ReasonList = GetDropDownList(DropDown.ECRREASON.ToString());

			ViewData["Error"] = "1";
            ViewData["Message"] = responseText;
            return View(model);
        }

        [HttpGet]
        public IActionResult Edit(string code)
        {
            var userId = HttpContext.User.Identity.Name;
            string department = GetDepartmentId();

            ECRMasterModel data = _IECRRepository.Get(code, userId, department);
            ViewBag.SalesEmployeeList = GetSalesEmployeeList(userId);
			ViewBag.ReasonList = GetDropDownList(DropDown.ECRREASON.ToString());

			return View(data);
        }

        //[Authorize]
        //[HttpPost]
        //public IActionResult Edit(ECRMasterModel model)
        //{
        //	var userId = HttpContext.User.Identity.Name;
        //	string empId = GetEmpId();
        //	model.EmpId = empId;
        //	model.Department = GetDepartmentId();

        //	ResponseModel responseModel = _IECRRepository.Update(model);
        //	if (responseModel.ResponseStatus == true)
        //	{
        //		SendMail(model);
        //		TempData["Success"] = "1";
        //		TempData["Message"] = responseModel.ResponseText;
        //		return RedirectToAction("Index", "ECR");
        //	}
        //	else
        //	{
        //		TempData["Success"] = "1";
        //		TempData["Message"] = responseModel.ResponseText;
        //		ViewBag.SalesEmployeeList = GetSalesEmployeeList(userId);
        //		return View(model);
        //	}
        //}

        [Authorize]
        [HttpPost]
        public IActionResult Edit(ECRMasterModel model)
        {
            string responseText = string.Empty;
            var userId = HttpContext.User.Identity.Name;
            string empId = GetEmpId();
            model.EmpId = empId;
            model.Department = GetDepartmentId();
            if (Validate(model, out responseText) == true)
            {
                ResponseModel responseModel = _IECRRepository.Update(model);
                if (responseModel.ResponseStatus == true)
                {
                    SendMail(model);
                    TempData["Success"] = "1";
                    TempData["Message"] = responseModel.ResponseText;
                    return RedirectToAction("Index", "ECR");
                }
                else
                {
                    responseText = responseModel.ResponseText;
                }
            }
			ViewBag.ReasonList = GetDropDownList(DropDown.ECRREASON.ToString());
			ViewBag.SalesEmployeeList = GetSalesEmployeeList(userId);
            ViewData["Error"] = "1";
            ViewData["Message"] = responseText;
            return View(model);
        }

        [HttpPost]
        public ActionResult ECRAddRow(int index)
        {
            index = index - 1;
            var newRow = new ECRRowModel() { Index = index + 1 };
            ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("ECR1Collection[{0}]", index);
            ViewBag.HSNList = GetHSNList();
			ViewBag.ReasonList = GetDropDownList(DropDown.ECRREASON.ToString());
			return PartialView("~/Views/Shared/EditorTemplates/ECRRowModel.cshtml", newRow);
        }

        [HttpPost]
        public ActionResult ECRAttachmentAddRow(int index)
        {
            index = index - 1;
            var newRow = new ECRModel_Attachment() { LineId = index + 1 };
            ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("ECR2Collection[{0}]", index);
            return PartialView("~/Views/Shared/EditorTemplates/ECRModel_Attachment.cshtml", newRow);
        }
        private bool Validate(ECRMasterModel model, out string responseMessage)
        {
            responseMessage = string.Empty;
            try
            {
                if (string.IsNullOrEmpty(model.U_CardCode))
                {
                    responseMessage = "Please select business partner";
                    return false;
                }
                else if (string.IsNullOrEmpty(model.U_DebNRec))
                {
                    responseMessage = "Please select Debit Note Recevied";
                    return false;
                }
                else if (string.IsNullOrEmpty(model.U_CreNIss))
                {
                    responseMessage = "Please select Credit Note To be Issue";
                    return false;
                }
                else if (string.IsNullOrEmpty(model.U_AssignTo))
                {
                    responseMessage = "Please select AssignTo";
                    return false;
                }
                model.ECR1Collection = model.ECR1Collection.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
                for (int i = 0; i < model.ECR1Collection.Count; i++)
                {
                    try
                    {
                        if (string.IsNullOrEmpty(model.ECR1Collection[i].U_Rem))
                        {
                            responseMessage = "Please update remark";
                            return false;
                        }
                    }
                    catch (Exception ex)
                    {

                    }
                }

            }
            catch (Exception ex)
            {
            }
            return true;
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult UpdateRemark(string basecode, string baseline, string remarks, string assignTo)
        {
            string empId = GetEmpId();
            //string department = GetDepartmentId();
            ResponseModel responseModel = _IECRRepository.UpdateRemark(basecode, baseline, remarks, empId, assignTo);
            return Json(new { value = responseModel });
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult CloseECR(string code, string assignTo)
        {
            var userId = HttpContext.User.Identity.Name;
            ResponseModel responseModel = new ResponseModel();
            if ((assignTo == "10") || (userId == "vaibhavi.kulkarni@ajantaprintarts.com" || userId == "sandeep@ajantaprintarts.com"))
            {
                responseModel = _IECRRepository.CloseECR(code);
            }
            else
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "You are not authorise to Close ECR";
            }
            return Json(responseModel);
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public JsonResult CancelECR(string code)
        {
            string empId = GetEmpId();
            ResponseModel responseModel = _IECRRepository.CancelECR(code);
            return Json(new { value = responseModel });

        }

        public string GetEmpId()
        {
            var identity = (System.Security.Claims.ClaimsIdentity)HttpContext.User.Identity;
            return identity.Claims.FirstOrDefault(c => c.Type == "EmpId").Value;
        }

        private string GetDepartment()
        {
            var identity = (System.Security.Claims.ClaimsIdentity)HttpContext.User.Identity;
            return identity.Claims.FirstOrDefault(c => c.Type == "Department").Value;
        }

        private string GetDepartmentId()
        {
            var identity = (System.Security.Claims.ClaimsIdentity)HttpContext.User.Identity;
            return identity.Claims.FirstOrDefault(c => c.Type == "DepartmentId").Value;
        }

        [HttpGet]
        public IActionResult GetAllRemarkDetails(string basecode, string baseline)
        {
            string empId = GetEmpId();
            //string empId = GetDepartmentId();
            List<ECRModel_RemarkDetails> data = _IECRRepository.GetAllRemarkDetails(basecode, baseline, empId);
            return Json(new { aaData = data });
        }
        private ResponseModel SendMail(ECRMasterModel documentModel)
        {
            ResponseModel responseModel = new ResponseModel();
            Helpers helpers = new Helpers();
            SendMail _sendMail = new SendMail();
            string code = documentModel.Code;
            DataTable dataTable = _IECRRepository.GetMailDraft(code);
            string assignto = documentModel.U_AssignTo;
            string ecrno = documentModel.Code;
            string invno = documentModel.ECR1Collection.Select(a => a.U_InvNo).FirstOrDefault();
            string message = "";
            string subject = "ECR No :" + ecrno + " & Invoice No :  " + invno + " Of " + "Customer " + documentModel.U_CardName;

            string tableBody = helpers.ConvertToHtml(dataTable);

            StringBuilder sbBody = new StringBuilder();
            sbBody.Append("<p> Dear Sir/Madam <p/>");
            sbBody.Append("<p> Please see below document ECR details<p/>");
            sbBody.Append(tableBody);
            sbBody.Append("<p> Regards <br/>");
            sbBody.Append("Web Admin<p/>");
            string toEmail = "";
            string salesempcode = documentModel.U_SlpCode;
            if (assignto == "1")
            {
                string usermailid = HttpContext.User.Identity.Name;
                string SalesEmpMail = _ICommonRepository.GetEmailDepartmentWise(salesempcode);
                toEmail = usermailid + "," + SalesEmpMail;
            }
            else
            {
                List<string> toEmailList = _ICommonRepository.GetECREmailDepartmentWise(assignto);
                toEmail = String.Join(",", toEmailList).Replace(",,", "");
            }
            //string ccEmail = ConfigManager.GetECREmailAddress();
            string ccEmail = _ICommonRepository.GetAppDataValue(AppData.ECREmailAddress);
            string bccEmail = "";
            string fromEmail = HttpContext.User.Identity.Name;
            bool result = _sendMail.sendMail(fromEmail, toEmail, ccEmail, bccEmail, subject, sbBody.ToString(), null, out message);
            responseModel.ResponseStatus = result;
            responseModel.ResponseText = message;
            return responseModel;
        }
        [HttpGet]
        public JsonResult Print(string docEntry)
        {
            var data = _ICommonRepository.PDF(docEntry, PrintForm.ECRLayout);
            return Json(new { aaData = data });
        }
        [HttpGet]
        public JsonResult ECRCreditMemoPrint(string docEntry)
        {
            var data = _ICommonRepository.PDF(docEntry, PrintForm.ECRCreditNoteLayout);
            return Json(new { aaData = data });
        }
        #region Select List

        [NonAction]
        private SelectList GetCurrencyList()
        {
            return new SelectList(_ICommonRepository.GetAllCurrency(), "CurrCode", "CurrName");
        }

        [NonAction]
        private SelectList GetBranchList()
        {
            return new SelectList(_ICommonRepository.GetAllBranch(), "BPLId", "BPLName");
        }

        [NonAction]
        private SelectList GetWarehouseList()
        {
            return new SelectList(_ICommonRepository.GetAllWarehouse(), "WhsCode", "WhsName");
        }

        [NonAction]
        private SelectList GetShippingTypeList()
        {
            return new SelectList(_ICommonRepository.GetAllShippingType(), "TrnspCode", "TrnspName");
        }

        [NonAction]
        private SelectList GetHSNList()
        {
            return new SelectList(_ICommonRepository.GetAllHSN(), "Chapter", "ChapterID");
        }

        [NonAction]
        private SelectList GetYNList()
        {
            var selectLists = new SelectList(
                    new List<SelectListItem>
                    {
                        new SelectListItem { Value = "Y", Text = "Yes"},
                        new SelectListItem { Value= "N", Text = "No"},
                    }, "Value", "Text");

            return selectLists;
        }

        [NonAction]
        private SelectList GetEmployeeList()
        {
            return new SelectList(_ICommonRepository.GetAllEmployee(), "empID", "Name");
        }

        [NonAction]
        private SelectList GetSalesEmployeeList(string userId)
        {
            return new SelectList(_ICommonRepository.GetAllTeamSalesEmployee(userId), "SlpCode", "SlpName");
        }

		[NonAction]
		private SelectList GetDropDownList(string code)
		{
			return new SelectList(_ICommonRepository.GetDropDownList(code), "ID", "Name");
		}

		#endregion

	}
}
