﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using WebDAL.Helper;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Logging;
using System.Net.Http;
using System.Net;
using CrystalDecisions.CrystalReports.Engine;
using static WebDAL.Models.PurchaseOrderModel;
using DocumentFormat.OpenXml.EMMA;

namespace WebApp.Controllers
{
	public class PurchaseOrderController : Controller
	{
		public readonly IPurchaseOrderRepository _IPurchaseOrderRepository = null;
		public readonly ICommonRepository _ICommonRepository = null;
		private IHostingEnvironment _IHostingEnvironment;
		private readonly ILogger<PurchaseOrderController> _ILogger;

		public PurchaseOrderController(IPurchaseOrderRepository iPurchaseOrderRepository,
			ICommonRepository iCommonRepository, IHostingEnvironment iHostingEnvironment
			, ILogger<PurchaseOrderController> iLogger
			)
		{
			_IPurchaseOrderRepository = iPurchaseOrderRepository;
			_ICommonRepository = iCommonRepository;
			_IHostingEnvironment = iHostingEnvironment;
			_ILogger = iLogger;
		}

		[Authorize]
		[HttpGet]
		public IActionResult Index()
		{
			return View();
		}

		[HttpGet]
		public IActionResult GetAllDraft()
		{
			var userId = HttpContext.User.Identity.Name;
			string type = "draft";
			List<PurchaseOrderModel> data = _IPurchaseOrderRepository.GetAllDraft(userId);
			for (int i = 0; i < data.Count; i++)
			{
				data[i].EditLink = Url.Action("Edit", "PurchaseOrder", new { docEntry = data[i].DocEntry, type = type.ToUpper() });
			}
			return Json(new { aaData = data });
		}

		[HttpGet]
		public IActionResult GetAllDocument()
		{
			var userId = HttpContext.User.Identity.Name;
			string type = "document";
			List<PurchaseOrderModel> data = _IPurchaseOrderRepository.GetAllDocument(userId);
			for (int i = 0; i < data.Count; i++)
			{
				data[i].EditLink = Url.Action("Edit", "PurchaseOrder", new { docEntry = data[i].DocEntry, type = type.ToUpper() });
			}
			return Json(new { aaData = data });
		}

		[Authorize]
		[HttpGet]
		public IActionResult Add()
		{
			var userId = HttpContext.User.Identity.Name;
			string ownerId = _ICommonRepository.GetEmpId(userId);
			PurchaseOrderModel purchaseOrderModel = new PurchaseOrderModel();
			purchaseOrderModel.SalesPersonCode = "-1";
			purchaseOrderModel.DocDate = DateTime.Now.ToString("dd-MM-yyyy");
			purchaseOrderModel.DocDueDate = DateTime.Now.ToString("dd-MM-yyyy");
			purchaseOrderModel.TaxDate = DateTime.Now.ToString("dd-MM-yyyy");
			purchaseOrderModel.U_InvDate = DateTime.Now.ToString("dd-MM-yyyy");
			purchaseOrderModel.U_GatePassDate = DateTime.Now.ToString("dd-MM-yyyy");
			purchaseOrderModel.NetAmount = 0;
			purchaseOrderModel.DiscountPercent = 0;
			purchaseOrderModel.RoundingDiffAmount = 0;
			purchaseOrderModel.DocumentTotal = 0;
			purchaseOrderModel.DocRate = "1";
			purchaseOrderModel.DocCurrency = "INR";
			purchaseOrderModel.DocStatus = "Open";
			purchaseOrderModel.DocumentsOwner = ownerId;

			#region Purchase Rows
			List<PurchaseOrderRowsModel> PurchaseOrderRowsModelList = new List<PurchaseOrderRowsModel>();
			for (int i = 1; i <= 1; i++)
			{
				PurchaseOrderRowsModel purchaseOrderRowsModel = new PurchaseOrderRowsModel();
				purchaseOrderRowsModel.Index = i;
				purchaseOrderRowsModel.ItemCode = "";
				purchaseOrderRowsModel.Weight1 = "0";
				PurchaseOrderRowsModelList.Add(purchaseOrderRowsModel);
			}
			purchaseOrderModel.DocumentLines = PurchaseOrderRowsModelList;
			#endregion

			#region Expense Rows
			List<POModel_Expenses> POModel_ExpensesList = new List<POModel_Expenses>();
			List<ExpenseModel> expenseModelsList = _ICommonRepository.GetAllExpenses();
			for (int i = 0; i < expenseModelsList.Count; i++)
			{
				POModel_Expenses poModel_Expenses = new POModel_Expenses();
				poModel_Expenses.Index = i + 1;
				poModel_Expenses.ExpenseCode = expenseModelsList[i].ExpnsCode;
				poModel_Expenses.ExpenseName = expenseModelsList[i].ExpnsName;
				POModel_ExpensesList.Add(poModel_Expenses);
			}

			purchaseOrderModel.DocumentAdditionalExpenses = POModel_ExpensesList;
			#endregion

			#region Attachment Rows
			List<POModel_Attachment> documentModel_AttachmentList = new List<POModel_Attachment>();
			POModel_Attachment documentModel_Attachment = new POModel_Attachment();
			documentModel_Attachment.Index = 1;
			documentModel_AttachmentList.Add(documentModel_Attachment);
			purchaseOrderModel.Attachments2_Lines = documentModel_AttachmentList;
			#endregion

			ViewBag.PaymentTermsList = GetPaymentTermsList();
			ViewBag.PlaceOfSupplyList = GetPlaceOfSupplyList();
			ViewBag.LocationList = GetLocationList();
			ViewBag.WarehouseList = GetWarehouseList();
			ViewBag.CategoryList = GetCategoryList();
			ViewBag.BillToLocationList = GetBillToLocationList();
			ViewBag.ApprovalList = GetApprovalListList();
			ViewBag.ShipToLocationList = GetShipToLocationList();

			ViewBag.CurrencyList = GetCurrencyList();
			ViewBag.BranchList = GetBranchList();
			ViewBag.ShippingTypeList = GetShippingTypeList();
			ViewBag.EmployeeList = GetEmployeeList();
			ViewBag.HSNList = GetHSNList();
			ViewBag.SalesEmployeeList = GetSalesEmployeeList();
			ViewBag.GeneralList = GetDistributionList(DistributionDimension.General);
			ViewBag.MachineList = GetDistributionList(DistributionDimension.Machine);
			ViewBag.ClientWiseList = GetDistributionList(DistributionDimension.ClientWise);

			return View(purchaseOrderModel);
		}

		[HttpPost]
		[DisableRequestSizeLimit]
		public IActionResult Add(PurchaseOrderModel model)
		{
			string responseText = string.Empty;
			var userId = HttpContext.User.Identity.Name;
			ResponseModel responseModel = new ResponseModel();
			model.UserId = userId;
			if (Validate(model, out responseText) == true)
			{
				string originator = _ICommonRepository.GetUserId(userId);
				model.OriginatorId = originator;
				model.U_CRBY = originator;
				model.DocStatus = "O";
				responseModel = _IPurchaseOrderRepository.Add(model);
				if (responseModel.ResponseStatus == true)
				{

					TempData["Success"] = "1";
					TempData["Message"] = responseModel.ResponseText;
					return RedirectToAction("Index", "PurchaseOrder");
				}
				else
				{
					responseText = responseModel.ResponseText;
				}
			}
			ViewBag.PlaceOfSupplyList = GetPlaceOfSupplyList();
			ViewBag.WarehouseList = GetWarehouseList();
			ViewBag.PaymentTermsList = GetPaymentTermsList();
			ViewBag.LocationList = GetLocationList();
			ViewBag.CategoryList = GetCategoryList();
			ViewBag.BillToLocationList = GetBillToLocationList();
			ViewBag.ApprovalList = GetApprovalListList();
			ViewBag.ShipToLocationList = GetShipToLocationList();

			ViewBag.CurrencyList = GetCurrencyList();
			ViewBag.BranchList = GetBranchList();
			ViewBag.ShippingTypeList = GetShippingTypeList();
			ViewBag.EmployeeList = GetEmployeeList();
			ViewBag.SalesEmployeeList = GetSalesEmployeeList();
			ViewBag.GeneralList = GetDistributionList(DistributionDimension.General);
			ViewBag.MachineList = GetDistributionList(DistributionDimension.Machine);
			ViewBag.ClientWiseList = GetDistributionList(DistributionDimension.ClientWise);

			ViewData["Error"] = "1";
			ViewData["Message"] = responseText;
			return View(model);
		}

		[Authorize]
		[HttpGet]
		public IActionResult Edit(string docEntry, string type)
		{
			var userId = HttpContext.User.Identity.Name;
			userId = _ICommonRepository.GetUserId(userId);

			PurchaseOrderModel data = _IPurchaseOrderRepository.Get(docEntry, userId, type);
			data.Type = type.ToUpper();

			ViewBag.PaymentTermsList = GetPaymentTermsList();
			ViewBag.PlaceOfSupplyList = GetPlaceOfSupplyList();
			ViewBag.LocationList = GetLocationList();
			ViewBag.WarehouseList = GetWarehouseList();
			ViewBag.CategoryList = GetCategoryList();
			ViewBag.BillToLocationList = GetBillToLocationList();
			ViewBag.ApprovalList = GetApprovalListList();
			ViewBag.ShipToLocationList = GetShipToLocationList();

			ViewBag.CurrencyList = GetCurrencyList();
			ViewBag.BranchList = GetBranchList();
			ViewBag.ShippingTypeList = GetShippingTypeList();
			ViewBag.EmployeeList = GetEmployeeList();
			ViewBag.HSNList = GetHSNList();
			ViewBag.SalesEmployeeList = GetSalesEmployeeList();
			ViewBag.GeneralList = GetDistributionList(DistributionDimension.General);
			ViewBag.MachineList = GetDistributionList(DistributionDimension.Machine);
			ViewBag.ClientWiseList = GetDistributionList(DistributionDimension.ClientWise);

			return View(data);
		}

		[DisableRequestSizeLimit]
		[HttpPost]
		public IActionResult Edit(PurchaseOrderModel model)
		{
			var updateButtonAttribute = Request.Form["Update"];
			string buttonValue = string.Empty;
			if (updateButtonAttribute.Count > 0)
			{
				buttonValue = updateButtonAttribute[0];
			}
			else
			{
				buttonValue = "UpdateExcludeItems";
			}
			model.ButtonValue = buttonValue;
			var userId = HttpContext.User.Identity.Name;
			userId = _ICommonRepository.GetUserId(userId);
			model.UserId = userId;
			ResponseModel responseModel = new ResponseModel();
			try
			{
				string responseText = "";
				if (Validate(model, out responseText) == true)
				{
					responseModel = _IPurchaseOrderRepository.Update(model);
				}
				else
				{
					responseModel.ResponseStatus = false;
					responseModel.ResponseText = responseText;
				}
				//if (Validate(model, out responseText) == true)
				//{
				//	responseModel = _IPurchaseOrderRepository.Update(model);
				//}
				//else
				//{
				//	responseModel.ResponseStatus = false;
				//	responseModel.ResponseText = responseText;
				//}
			}
			catch (Exception ex)
			{
				responseModel.ResponseStatus = false;
				responseModel.ResponseText = ex.Message;
			}
			if (responseModel.ResponseStatus == true)
			{
				TempData["Success"] = "1";
				TempData["Message"] = responseModel.ResponseText;
				return RedirectToAction("Index", "PurchaseOrder");
			}
			else
			{
				ViewData["Error"] = "1";
				ViewData["Message"] = responseModel.ResponseText;

				ViewBag.PaymentTermsList = GetPaymentTermsList();
				ViewBag.PlaceOfSupplyList = GetPlaceOfSupplyList();
				ViewBag.LocationList = GetLocationList();
				ViewBag.WarehouseList = GetWarehouseList();
				ViewBag.CategoryList = GetCategoryList();
				ViewBag.BillToLocationList = GetBillToLocationList();
				ViewBag.ApprovalList = GetApprovalListList();
				ViewBag.ShipToLocationList = GetShipToLocationList();

				ViewBag.CurrencyList = GetCurrencyList();
				ViewBag.BranchList = GetBranchList();
				ViewBag.ShippingTypeList = GetShippingTypeList();
				ViewBag.EmployeeList = GetEmployeeList();
				ViewBag.HSNList = GetHSNList();
				ViewBag.SalesEmployeeList = GetSalesEmployeeList();
				ViewBag.GeneralList = GetDistributionList(DistributionDimension.General);
				ViewBag.MachineList = GetDistributionList(DistributionDimension.Machine);
				ViewBag.ClientWiseList = GetDistributionList(DistributionDimension.ClientWise);

				return View(model);
			}
		}

		[HttpPost]
		public ActionResult PurchaseOrderAddRow(int index)
		{
			index = index - 1;
			var newRow = new PurchaseOrderRowsModel() { Index = index + 1 };
			ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("DocumentLines[{0}]", index);

			ViewBag.CategoryList = GetCategoryList();
			ViewBag.WarehouseList = GetWarehouseList();
			ViewBag.LocationList = GetLocationList();
			ViewBag.GeneralList = GetDistributionList(DistributionDimension.General);
			ViewBag.MachineList = GetDistributionList(DistributionDimension.Machine);
			ViewBag.ClientWiseList = GetDistributionList(DistributionDimension.ClientWise);

			return PartialView("~/Views/Shared/EditorTemplates/PurchaseOrderRowsModel.cshtml", newRow);
		}
		[HttpPost]
		public ActionResult AttachmentAddRow(int index)
		{
			index = index - 1;
			var newRow = new POModel_Attachment() { Index = index + 1 };
			ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("Attachments2_Lines[{0}]", index);
			return PartialView("~/Views/Shared/EditorTemplates/POModel_Attachment.cshtml", newRow);
		}

		[Authorize]
		[HttpGet]
		public JsonResult IsApprovalApplicable(string docEntry)
		{
			var userId = HttpContext.User.Identity.Name;
			userId = _ICommonRepository.GetUserId(userId);
			//string originator = _ICommonRepository.GetUserId(userId);
			PurchaseOrderModel model = _IPurchaseOrderRepository.Get(docEntry, userId, "Draft");
			model.OriginatorId = userId;
			_IPurchaseOrderRepository.IsApprovalApplicable(model);
			return Json(new { value = "" });
		}

		private bool Validate(PurchaseOrderModel model, out string responseMessage)
		{
			responseMessage = string.Empty;
			try
			{
				if (string.IsNullOrEmpty(model.CardCode))
				{
					responseMessage = "Please select business partner";
					return false;
				}
				//commented NG
				//else if (model.PaymentGroupCode == 9)
				//{
				//	responseMessage = "Please select payment terms";
				//	return false;
				//}
				if (model.PaymentGroupCode == 9 || model.PaymentGroupCode == 0)
				{
					responseMessage = "Please select payment terms";
					return false;
				}

				string isIGST = _ICommonRepository.GetAddressIGST(model.CardCode, model.ShipToCode);
				bool isLocal = false;
				if (isIGST.ToLower() == "no")
				{
					isLocal = true;
				}
				model.DocumentLines = model.DocumentLines.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
				string docType = model.DocType;
				string whscode = "";

				for (int i = 0; i < model.DocumentLines.Count; i++)
				{
					if (docType == "S")
					{
						if (string.IsNullOrEmpty(model.DocumentLines[i].LocationCode))
						{
							responseMessage = "Location is mandatory";
							return false;
						}
						if (string.IsNullOrEmpty(model.DocumentLines[i].SACEntry))
						{
							responseMessage = "SAC Code is mandatory";
							return false;
						}
					}
					else if (docType == "I")
					{
						string itemcode = model.DocumentLines[i].ItemCode;
						string value = _ICommonRepository.GetAllPOItemGroup(itemcode);

						if (value == "109" || value == "103" || value == "100" || value == "101" || value == "147" || value == "106"
							|| value == "121" || value == "107" || value == "126" || value == "105" || value == "104"
							|| value == "108" || value == "122" || value == "163")
						{
							if (string.IsNullOrEmpty(model.DocumentLines[i].U_JCText))
							{
								responseMessage = "Job Details is mandatory";
								return false;
							}
							if (string.IsNullOrEmpty(model.DocumentLines[i].U_NoOfUps))
							{
								responseMessage = "No Of UPS is mandatory";
								return false;
							}
							if (string.IsNullOrEmpty(model.SalesPersonCode) || model.SalesPersonCode == "-1")
							{
								responseMessage = "Sales Employee is mandatory";
								return false;
							}
						}
					}
					string taxcode = model.DocumentLines[i].TaxCode;
					if (isLocal == true)
					{
						if (taxcode.Contains("IGST"))
						{
							responseMessage = "Please select CGST/SGST Tax";
							return false;
						}
					}
					else
					{
						if (taxcode.Contains("CGST"))
						{
							responseMessage = "Please select IGST Tax";
							return false;
						}
					}

					whscode = model.DocumentLines[i].WarehouseCode;

				}
				if (docType == "I")
				{
					string shipFrom = model.U_LOC;
					string physicalLocation = _ICommonRepository.GetWarehousePhysicalLocation(whscode);
					if (shipFrom != physicalLocation)
					{
						responseMessage = "Ship From location not matching with wahreouse physical location";
						return false;
					}
				}

				//else if (string.IsNullOrEmpty(model.WarehouseCode))
				//{
				//	responseMessage = "Please select warehouse";
				//	return false;
				//}
				//else if (model.DutyStatus == "Y")
				//{
				//	bool isIGST0 = model.DocumentLines.Any(a => a.TaxCode == "IGST0");
				//	if (isIGST0 == true)
				//	{
				//		responseMessage = "You have selected export, You should be select Without Payment of Duty. Sandeep Jha!!";
				//		return false;
				//	}
				//}
				//else if (model.DutyStatus == "N")
				//{
				//	bool isIGST0 = model.DocumentLines.Any(a => a.TaxCode == "IGST0");
				//	if (isIGST0 == false)
				//	{
				//		responseMessage = "You have selected export, You should be select Without Payment of Duty. Sandeep Jha!!";
				//		return false;
				//	}
				//}
			}
			catch (Exception ex)
			{

			}
			return true;
		}

		[HttpPost]
		public JsonResult UpdatePurchaseOrderStatus(string docEntry, string status)
		{
			ResponseModel responseModel = new ResponseModel();
			try
			{
				var userId = HttpContext.User.Identity.Name;
				userId = _ICommonRepository.GetUserId(userId);
				responseModel = _IPurchaseOrderRepository.UpdateStatus(docEntry, status, userId);
				return Json(new { value = responseModel });
			}
			catch (Exception ex)
			{
				_ILogger.LogError(ex, ex.Message);
			}
			responseModel.ResponseText = "Error occured while processing UpdatePurchaseOrderStatus ";
			responseModel.ResponseStatus = false;
			return Json(new { value = responseModel });
		}


		#region Select List

		[NonAction]
		private SelectList GetPaymentTermsList()
		{
			return new SelectList(_ICommonRepository.GetAllPaymentTermsList(), "GroupNum", "PymntGroup");
		}

		[NonAction]
		private SelectList GetPlaceOfSupplyList()
		{
			return new SelectList(_ICommonRepository.GetPlaceOfSupply(), "ID", "Name");
		}

		[NonAction]
		private SelectList GetLocationList()
		{
			return new SelectList(_ICommonRepository.GetLocationList(), "ID", "Name");
		}
		[NonAction]
		private SelectList GetBillToLocationList()
		{
			return new SelectList(_ICommonRepository.GetUDFValuesList("ORDR", "BillLoc"), "ID", "Name");
		}
		[NonAction]
		private SelectList GetApprovalListList()
		{
			return new SelectList(_ICommonRepository.GetUDFValuesList("OPOR", "Approval"), "ID", "Name");
		}
		[NonAction]
		private SelectList GetShipToLocationList()
		{
			return new SelectList(_ICommonRepository.GetUDFValuesList("ORDR", "LOC"), "ID", "Name");
		}

		[NonAction]
		private SelectList GetWarehouseList()
		{
			return new SelectList(_ICommonRepository.GetAllWarehouse(), "WhsCode", "WhsName");
		}

		[NonAction]
		private SelectList GetCurrencyList()
		{
			return new SelectList(_ICommonRepository.GetAllCurrency(), "CurrCode", "CurrName");
		}

		[NonAction]
		private SelectList GetBranchList()
		{
			return new SelectList(_ICommonRepository.GetAllBranch(), "BPLId", "BPLName");
		}


		[NonAction]
		private SelectList GetShippingTypeList()
		{
			return new SelectList(_ICommonRepository.GetAllShippingType(), "TrnspCode", "TrnspName");
		}

		[NonAction]
		private SelectList GetHSNList()
		{
			return new SelectList(_ICommonRepository.GetAllHSN(), "Chapter", "ChapterID");
		}

		[NonAction]
		private SelectList GetCategoryList()
		{
			return new SelectList(_ICommonRepository.GetUDFValuesList("RDR1", "Category"), "ID", "Name");
		}

		[NonAction]
		private SelectList GetYNList()
		{
			var selectLists = new SelectList(
					new List<SelectListItem>
					{
						new SelectListItem { Value = "Y", Text = "Yes"},
						new SelectListItem { Value= "N", Text = "No"},
					}, "Value", "Text");

			return selectLists;
		}

		[NonAction]
		private SelectList GetEmployeeList()
		{
			return new SelectList(_ICommonRepository.GetAllEmployee(), "empID", "Name");
		}

		[NonAction]
		private SelectList GetSalesEmployeeList(string userId)
		{
			return new SelectList(_ICommonRepository.GetAllTeamSalesEmployee(userId), "SlpCode", "SlpName");
		}

		[NonAction]
		private SelectList GetSalesEmployeeList()
		{
			return new SelectList(_ICommonRepository.GetAllSalesEmployee(), "SlpCode", "SlpName");
		}

		[NonAction]
		private SelectList GetDistributionList(DistributionDimension distributionDimension)
		{
			int dimCode = (int)distributionDimension;
			return new SelectList(_ICommonRepository.GetDistributionList(dimCode), "ID", "Name");
		}


		#endregion

		[HttpGet]
		public JsonResult Print(string docEntry)
		{
			var data = _ICommonRepository.PDF(docEntry, PrintForm.PurchaseOrderLayout);
			return Json(new { aaData = data });
		}

		public JsonResult Close(string docEntry)
		{
			ResponseModel responseModel = new ResponseModel();
			responseModel = _IPurchaseOrderRepository.Close(docEntry);
			return Json(new { value = responseModel });
		}

		[HttpPost]
		public JsonResult Cancel(string docEntry)
		{
			ResponseModel responseModel = new ResponseModel();
			responseModel = _IPurchaseOrderRepository.Cancel(docEntry);
			return Json(new { value = responseModel });
		}

		[HttpPost]
		public JsonResult UpdateLineStatus(string docEntry)
		{
			ResponseModel responseModel = new ResponseModel();
			int linenum = 0;
			string[] docEntry_Split = docEntry.Split('_');
			docEntry = docEntry_Split[0];
			linenum = int.Parse(docEntry_Split[1]);
			int documentRowsCount = _IPurchaseOrderRepository.GetOpenDocumentRowCount(docEntry);
			if (documentRowsCount == 1)
			{
				responseModel = _IPurchaseOrderRepository.Close(docEntry);
			}
			else
			{
				responseModel = _IPurchaseOrderRepository.UpdateLineStatus(docEntry, linenum);
			}
			return Json(new { value = responseModel });
		}

	}
}
