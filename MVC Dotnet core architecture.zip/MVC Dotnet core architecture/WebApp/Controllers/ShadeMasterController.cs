﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using System.Data;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Hosting;
using Newtonsoft.Json;
using WebDAL.Helper;
using System.Text;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Logging;
using System.Net.Http;
using System.Net;
using CrystalDecisions.CrystalReports.Engine;
using static WebDAL.Models.PurchaseOrderModel;
using RestSharp;

namespace WebApp.Controllers
{
    public class ShadeMasterController : Controller
    {
        public readonly IShadeMasterRepository _IShadeMasterRepository = null;
        public readonly ICommonRepository _ICommonRepository = null;
        private IHostingEnvironment _IHostingEnvironment;
        private readonly ILogger<ShadeMasterController> _ILogger;

        public ShadeMasterController(IShadeMasterRepository iIShadeMasterRepository,
            ICommonRepository iCommonRepository, IHostingEnvironment iHostingEnvironment
            , ILogger<ShadeMasterController> iLogger
            )
        {
            _IShadeMasterRepository = iIShadeMasterRepository;
            _ICommonRepository = iCommonRepository;
            _IHostingEnvironment = iHostingEnvironment;
            _ILogger = iLogger;
        }

        [HttpGet]
        public IActionResult GetAll(string type)
        {
            var userId = HttpContext.User.Identity.Name;
            List<ShadeMasterModel> data = _IShadeMasterRepository.GetAll();
            for (int i = 0; i < data.Count; i++)
            {
                data[i].EditLink = Url.Action("Edit", "ShadeMaster", new { code = data[i].Code });
            }
            return Json(new { aaData = data });
        }

        [Authorize]
        [HttpGet]
        public IActionResult Add()
        {
            var userId = HttpContext.User.Identity.Name;
            ShadeMasterModel model = new ShadeMasterModel();
            model.U_SCDate = DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss");

            List<ShadeMasterRowsModel> rowsList = new List<ShadeMasterRowsModel>();
            ShadeMasterRowsModel rowsModel = new ShadeMasterRowsModel();
            rowsModel.Index = 1;
            rowsList.Add(rowsModel);

            model.Rows = rowsList;
            return View(model);
        }

        [HttpPost]
        [DisableRequestSizeLimit]
        public IActionResult Add(ShadeMasterModel model)
        {
            string responseText = string.Empty;
            ResponseModel responseModel = new ResponseModel();
            responseModel = Validate(model);
            if (responseModel.ResponseStatus == true)
            {
                responseModel = _IShadeMasterRepository.Add(model);
                if (responseModel.ResponseStatus == true)
                {
                    TempData["Success"] = "1";
                    TempData["Message"] = responseModel.ResponseText;
                    return RedirectToAction("Add", "ShadeMaster");
                }
            }
            ViewData["Error"] = "1";
            ViewData["Message"] = responseModel.ResponseText;
            return View(model);
        }
        [HttpGet]
        public IActionResult Edit(string code)
        {
            ShadeMasterModel data = new ShadeMasterModel();
            data = _IShadeMasterRepository.Get(code);
            return View(data);
        }


        [HttpPost]
        public IActionResult Edit(ShadeMasterModel model)
        {
            var userId = HttpContext.User.Identity.Name;
            if (string.IsNullOrEmpty(model.U_SCDate))
            {
                model.U_SCDate = DateTime.Now.Date.ToString("yyyMMdd");
            }
            ResponseModel responseModel = _IShadeMasterRepository.Update(model);
            if (responseModel.ResponseStatus == true)
            {
                TempData["Success"] = "1";
                TempData["Message"] = responseModel.ResponseText;
                return RedirectToAction("Add", "ShadeMaster");
            }
            else
            {
                TempData["Success"] = "1";
                TempData["Message"] = responseModel.ResponseText;
                return View(model);
            }
        }
        [DisableRequestSizeLimit]
        [HttpGet]
        public void AddBulkImport()
        {
            string path = "D:\\Pravin\\Code\\shade.json";
            var jsonText = System.IO.File.ReadAllText(path);
            var list = JsonConvert.DeserializeObject<List<ShadeMasterModel>>(jsonText);
            _IShadeMasterRepository.AddBulkImport(list);
        }


        [HttpPost]
        public ActionResult AddRow(int index)
        {
            index = index - 1;
            var newRow = new ShadeMasterRowsModel() { Index = index + 1 };
            ViewData.TemplateInfo.HtmlFieldPrefix = string.Format("Rows[{0}]", index);
            return PartialView("~/Views/Shared/EditorTemplates/ShadeMasterRowsModel.cshtml", newRow);
        }


        private ResponseModel Validate(ShadeMasterModel model)
        {
            ResponseModel responseModel = new ResponseModel();
            responseModel.ResponseStatus = true;
            try
            {
                if (string.IsNullOrEmpty(model.U_CCode))
                {
                    responseModel.ResponseText = "Please select Customer Code";
                    responseModel.ResponseStatus = false;
                    return responseModel;
                }
                else if (string.IsNullOrEmpty(model.U_CName))
                {
                    responseModel.ResponseText = "Please select Customer Name";
                    responseModel.ResponseStatus = false;
                    return responseModel;
                }
                else if (string.IsNullOrEmpty(model.U_SCNo))
                {
                    responseModel.ResponseText = "Please check Shade card no";
                    responseModel.ResponseStatus = false;
                    return responseModel;
                }
                else if (string.IsNullOrEmpty(model.U_SCDate))
                {
                    responseModel.ResponseText = "Please check Shade card date";
                    responseModel.ResponseStatus = false;
                    return responseModel;
                }
                //else if (string.IsNullOrEmpty(model.Code))
                //{
                //    responseMessage = "Please check Code";
                //    return false;
                //}
                model.Rows = model.Rows.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();

                for (int i = 0; i < model.Rows.Count; i++)
                {
                    string itemcode = model.Rows[i].ItemCode;
                    string itemname = model.Rows[i].ItemName;
                    if (string.IsNullOrEmpty(itemcode))
                    {
                        responseModel.ResponseText = "Please select Item Code";
                        responseModel.ResponseStatus = false;
                        return responseModel;
                    }
                    else if (string.IsNullOrEmpty(itemname))
                    {
                        responseModel.ResponseText = "Please select Item Name";
                        responseModel.ResponseStatus = false;
                        return responseModel;
                    }
                }

            }
            catch (Exception ex)
            {

            }
            return responseModel;
        }

    }
}
