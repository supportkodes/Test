using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using WebDAL.IRepository;
using WebDAL.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Newtonsoft.Json.Serialization;
using Microsoft.AspNetCore.Authentication.Cookies;
using DocumentFormat.OpenXml.Wordprocessing;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.Extensions.Options;

namespace WebDAL
{
	public class Startup
	{
		public Startup(IConfiguration configuration)
		{
			Configuration = configuration;
		}

		public IConfiguration Configuration { get; }

		// This method gets called by the runtime. Use this method to add services to the container.
		public void ConfigureServices(IServiceCollection services)
		{
			services.AddControllersWithViews();
			services.AddControllersWithViews().AddRazorRuntimeCompilation();
			services.AddHttpContextAccessor();
			services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
			services.AddSingleton<IAccountRepository, AccountRepository>();
			services.AddSingleton<IDashboardRepository, DashboardRepository>();
			services.AddSingleton<IPurchaseDashboardRepository, PurchaseDashboardRepository>();
			services.AddSingleton<IReportsRepository, ReportsRepository>();
			services.AddSingleton<ISalesOrderRepository, SalesOrderRepository>();
			services.AddSingleton<ISalesQuotationRepository, SalesQuotationRepository>();
			services.AddSingleton<IItemMasterRepository, ItemMasterRepository>();
			services.AddSingleton<IBOMRepository, BOMRepository>();
			services.AddSingleton<ICommonRepository, CommonRepository>();
			services.AddSingleton<IFLEXOUPRepository, FLEXOUPRepository>();
			services.AddSingleton<IECRRepository, ECRRepository>();
			services.AddSingleton<IPurchaseOrderRepository, PurchaseOrderRepository>();
			services.AddSingleton<IInventoryTransferRepository, InventoryTransferRepository>();
			services.AddSingleton<IJobSequenceRepository, JobSequenceRepository>();
			services.AddSingleton<IShopFloorEntryRepository, ShopFloorEntryRepository>();
			services.AddSingleton<IIssueForProductionRepository, IssueForProductionRepository>();
			services.AddSingleton<IGangupRepository, GangupRepository>();
			services.AddSingleton<IDeliveryRepository, DeliveryRepository>();
			services.AddSingleton<IClientPORegisterRepository, ClientPORegisterRepository>();
			services.AddSingleton<IKLDMasterRepository, KLDMasterRepository>();
			services.AddSingleton<IShadeMasterRepository, ShadeMasterRepository>();
			services.AddSingleton<IPrepressRepository, PrepressRepository>();
            services.AddSingleton<IPunchMasterRepository, PunchMasterRepository>();
            services.AddSingleton<ICRURepository, CRURepository>();
            services.AddSingleton<IPPCDetailsRepository, PPCDetailsRepository>();
            services.AddSingleton<IItemWeightCalculatorRepository, ItemWeightCalculatorRepository>();

            services.Configure<CookiePolicyOptions>(options =>
			{
				// This lambda determines whether user consent for non-essential cookies is needed for a given request.
				//options.CheckConsentNeeded = context => true;
				options.CheckConsentNeeded = context => false;
				options.MinimumSameSitePolicy = SameSiteMode.None;
			});

			//services.Configure<FormOptions>(options => { options.ValueCountLimit = 5000; });

			//services.Configure<FormOptions>(x =>
			//{
			//	x.BufferBody = false;
			//	x.KeyLengthLimit = 2048; // 2 KiB
			//	x.ValueLengthLimit = 4194304; // 32 MiB
			//	x.ValueCountLimit = 8192;
			//	x.MultipartHeadersCountLimit = 32; // 16
			//	x.MultipartHeadersLengthLimit = 32768; // 16384
			//	x.MultipartBoundaryLengthLimit = 256; // 128
			//	x.MultipartBodyLengthLimit = 134217728; // 128 MiB
			//});

			services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
				.AddCookie(options =>
				{
					options.Cookie.Name = "RememberMecookie"; // cookie name
					options.LoginPath = "/Account/Login"; // view where the cookie will be issued for the first time
					options.ExpireTimeSpan = TimeSpan.FromDays(1); // time for the cookei to last in the browser
					options.SlidingExpiration = true; // the cookie would be re-issued on any request half way through the ExpireTimeSpan
				});

			services.AddDistributedMemoryCache();
			services.AddSession(options =>
			{
				// Set session timeout value
				options.IdleTimeout = TimeSpan.FromSeconds(240);
				options.Cookie.HttpOnly = true;
			});
			services.AddControllers()
			  .AddJsonOptions(opts => opts.JsonSerializerOptions.PropertyNamingPolicy = null);

			services.Configure<FormOptions>(options =>
			{
				options.ValueCountLimit = int.MaxValue;
			});
		}

		// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
		public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
		{
			if (env.IsDevelopment())
			{
				app.UseDeveloperExceptionPage();
			}
			else
			{
				app.UseExceptionHandler("/Home/Error");
			}

			//app.Use(async (context, next) =>
			//{
			//	context.Features.Get<IHttpMaxRequestBodySizeFeature>().MaxRequestBodySize = null; // unlimited I guess
			//	await next.Invoke();
			//});

			app.UseSession();
			app.UseStaticFiles();
			app.UseRouting();
			app.UseAuthentication();
			app.UseAuthorization();

			app.UseEndpoints(endpoints =>
			{
				endpoints.MapControllerRoute(
					name: "default",
					pattern: "{controller=Account}/{action=Login}/{id?}");
			});
		}
	}
}
