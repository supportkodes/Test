﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace WebApp
{
    public class SessionData
    {
        //public static string GetUserCode()
        //{
        //    var data = Context.Session.GetString("UserCode");
        //    return Encoding.UTF8.GetString(data);
        //}
        public IHttpContextAccessor _httpContextAccessor = null;
        public SessionData(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }
        //public void SetLoginData(string userCode)
        //{
        //    _httpContextAccessor.HttpContext.Session["UserCode"].Value = userCode;
        //}
    }
}