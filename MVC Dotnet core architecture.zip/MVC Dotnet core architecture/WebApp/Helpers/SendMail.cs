﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using WebDAL.Helper;

namespace WebApp
{
	public class SendMail
	{
		public bool sendMail(string from, string to, string cc, string bcc, string sub, string body, List<string> attachmentList, out string errorMessage)
		{
			errorMessage = string.Empty;
			System.Net.Mail.MailMessage Email = new System.Net.Mail.MailMessage();
			if (to != "")
			{
				Email.To.Add(to);
			}
			if (cc != "")
			{
				Email.CC.Add(cc);
			}
			if (bcc != "")
			{
				Email.Bcc.Add(bcc);
			}
			try
			{
				//ServicePointManager.ServerCertificateValidationCallback = RemoteServerCertificateValidationCallback;
				//System.Net.ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;

				Email.Subject = sub;
				Email.IsBodyHtml = true;
				Email.Body = body;

				SmtpClient smtpClient = new SmtpClient();
				Email.From = new System.Net.Mail.MailAddress(from);
				smtpClient.Host = ConfigManager.GetSMTP_Host();
				smtpClient.Port = ConfigManager.GetSMTP_Port();
				smtpClient.UseDefaultCredentials = true;

				smtpClient.Credentials = new System.Net.NetworkCredential(ConfigManager.GetSMTP_UserName(), ConfigManager.GetSMTP_Password());
				if (ConfigManager.GetSMTP_EnableSsl().ToLower() == "y")
				{
					smtpClient.EnableSsl = true;
				}
				if (attachmentList != null)
				{
					//System.Net.Mime.ContentType contentType = new System.Net.Mime.ContentType();
					//contentType.MediaType = System.Net.Mime.MediaTypeNames.Application.Octet;
					for (int i = 0; i < attachmentList.Count; i++)
					{
						try
						{
                            Email.Attachments.Add(new Attachment(attachmentList[i].ToString()));

                            //contentType.Name = Path.GetFileName(attachmentList[i].ToString());
                            //Email.Attachments.Add(new Attachment(attachmentList[i].ToString(), contentType));
                        }
                        catch { }
					}
				}
				try
				{
					smtpClient.Send(Email);
				}
				catch (SmtpFailedRecipientsException ex)
				{
					errorMessage = ex.Message;
					return false;
				}
			}
			catch (System.Net.Mail.SmtpException se)
			{
				errorMessage = se.Message + " " + se.InnerException;
				return false;
			}
			return true;
		}

		public static bool RemoteServerCertificateValidationCallback(Object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
		{
			if (sslPolicyErrors == SslPolicyErrors.None)
				return true;

			// if got an cert auth error
			if (sslPolicyErrors != SslPolicyErrors.RemoteCertificateNameMismatch) return false;
			const string sertFileName = "smpthost.cer";

			// check if cert file exists
			if (File.Exists(sertFileName))
			{
				var actualCertificate = X509Certificate.CreateFromCertFile(sertFileName);
				return certificate.Equals(actualCertificate);
			}

			// export and check if cert not exists
			using (var file = File.Create(sertFileName))
			{
				var cert = certificate.Export(X509ContentType.Cert);
				file.Write(cert, 0, cert.Length);
			}
			var createdCertificate = X509Certificate.CreateFromCertFile(sertFileName);
			return certificate.Equals(createdCertificate);
		}
	}
}
