﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
//using Microsoft.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sap.Data.Hana;
using WebDAL.Helper;
using WebDAL.Helpers;
using WebDAL.IRepository;
using WebDAL.Models;

namespace WebDAL.Repository
{
	public class FLEXOUPRepository : clsDataAccess, IFLEXOUPRepository
	{
		string query = "";
		CommonRepository commonRepository = new CommonRepository();
		StringBuilder stringBuilder = new StringBuilder();
		string headerTable = CommonTables.FLEXOUPHeaderTable;
		string rowTable = CommonTables.FLEXOUPRowTable;
		public List<FLEXOUPIndexModel> GetAll()
		{
			List<FLEXOUPIndexModel> _list = new List<FLEXOUPIndexModel>();
			try
			{
				//string headerTable = CommonTables.FLEXOUPHeaderTable;
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"DocEntry\",T0.\"DocNum\",T0.\"U_CardCode\",T0.\"U_CardName\",T0.\"U_SlpEmpNm\",T0.\"LogInst\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + headerTable + "\" T0 ");
				stringBuilder.Append(" INNER JOIN (SELECT A.\"DocEntry\",MAX(A.\"LogInst\") AS \"LogInst\" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + headerTable + "\" A GROUP BY A.\"DocEntry\" ) T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" AND  T0.\"LogInst\" = T1.\"LogInst\"  ");
				stringBuilder.Append(" ORDER BY T0.\"DocEntry\" DESC ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<FLEXOUPIndexModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}

		public FLEXOUPModel Get(string docEntry)
		{
			FLEXOUPModel model = new FLEXOUPModel();
			try
			{
				//string headerTable = CommonTables.FLEXOUPHeaderTable;
				//string rowTable = CommonTables.FLEXOUPRowTable;
				//string freightTable = CommonTables.SalesOrderFreightTable;
				int logInstance = 0;
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
				parameters[0].Value = docEntry;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT MAX(T0.\"LogInst\") ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + headerTable + "\" T0 ");
				stringBuilder.Append(" WHERE T0.\"DocEntry\" = :DocEntry ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						logInstance = int.Parse(datatable.Rows[0][0].ToString());
					}
				}

				parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
				parameters[0].Value = docEntry;
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"DocEntry\" ,T0.\"DocNum\",T0.\"U_CardCode\",T0.\"U_CardName\" ");
				stringBuilder.Append(" ,T0.\"U_SlsEmp\" ,T0.\"U_SlpEmpNm\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + headerTable + "\" T0 ");
				stringBuilder.Append(" WHERE T0.\"DocEntry\" = :DocEntry AND T0.\"LogInst\" = " + logInstance + " ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						model = ConvertDatatableToList.ConvertToEntity<FLEXOUPModel>(datatable);
					}
				}

				#region Row
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT ROW_NUMBER() OVER (Order by T0.\"VisOrder\") AS \"Index\",T0.\"LineId\",T0.\"U_ShpCd\" , \"U_ShpAddr\",T0.\"U_ItmCd\"  ");
				stringBuilder.Append(" ,T0.\"U_ItmNm\" , T0.\"U_RollDrctn\",T0.\"U_Pckng\",T0.\"U_IsActive\", T0.\"U_UpdateDate\" ,T0.\"U_UpdateTime\"");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + rowTable + "\" T0 ");
				stringBuilder.Append(" WHERE T0.\"DocEntry\" = :DocEntry AND T0.\"LogInst\" = " + logInstance + " ");
				//stringBuilder.Append(" ORDER BY T0.\"VisOrder\" ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					List<FLEXOUPModelRow> modelRows = ConvertDatatableToList.ConvertToList<FLEXOUPModelRow>(datatable);
					model.APAFUP1Collection = modelRows;
				}
				#endregion
			}
			catch
			{

			}
			return model;
		}

		public ResponseModel Add(FLEXOUPModel model)
		{
			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				FLEXOUPModel _objServiceLayer = new FLEXOUPModel();

				#region Header

				_objServiceLayer.U_CardCode = model.U_CardCode;
				_objServiceLayer.U_CardName = model.U_CardName;
				_objServiceLayer.U_SlsEmp = model.U_SlsEmp;
				_objServiceLayer.U_SlpEmpNm = model.U_SlpEmpNm;

				#endregion

				int modelRow = 0;
				List<FLEXOUPModelRow> modelLines_ServiceLayer = new List<FLEXOUPModelRow>();
				model.APAFUP1Collection = model.APAFUP1Collection.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
				for (int i = 0; i < model.APAFUP1Collection.Count; i++)
				{
					if (!string.IsNullOrEmpty(model.APAFUP1Collection[i].U_ItmCd))
					{
						modelLines_ServiceLayer.Add(new FLEXOUPModelRow { });
						modelLines_ServiceLayer[modelRow].U_ShpCd = model.APAFUP1Collection[i].U_ShpCd;
						modelLines_ServiceLayer[modelRow].U_ShpAddr = model.APAFUP1Collection[i].U_ShpAddr;
						modelLines_ServiceLayer[modelRow].U_ItmCd = model.APAFUP1Collection[i].U_ItmCd;
						modelLines_ServiceLayer[modelRow].U_ItmNm = model.APAFUP1Collection[i].U_ItmNm;
						modelLines_ServiceLayer[modelRow].U_Pckng = model.APAFUP1Collection[i].U_Pckng;
						modelLines_ServiceLayer[modelRow].U_RollDrctn = model.APAFUP1Collection[i].U_RollDrctn;
						modelLines_ServiceLayer[modelRow].U_IsActive = model.APAFUP1Collection[i].U_IsActive;
						modelLines_ServiceLayer[modelRow].U_UpdateDate = DateTime.Now.Date.ToString("yyyMMdd");
						modelLines_ServiceLayer[modelRow].U_UpdateTime = DateTime.Now.ToString("HH:mm:ss");
						modelRow++;

                    }
				}
				_objServiceLayer.APAFUP1Collection = modelLines_ServiceLayer;

				string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
				{
					NullValueHandling = NullValueHandling.Ignore,
				});


				var temp = JsonConvert.DeserializeObject<JObject>(main);

				string serviceLayerObject = "APAFUP";
				rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject;
				rc.patchJSON = main;
				rc.B1SESSION = res;
				string message = "";
				bool result = rc.postRequest(out message);
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string docEntry = jobject["DocEntry"].ToString();
					model.Code = docEntry;
					responseModel.ResponseEntry = docEntry;
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during process: " + jsonMessage;
				}
				rc.LogOut();
			}
			else
			{
				responseModel.ResponseText = "Service layer login failed";
			}
			return responseModel;
		}

		public ResponseModel Update(FLEXOUPModel model)
		{
			try
			{
				string headerTable = CommonTables.FLEXOUPHeaderTable;
				string rowTable = CommonTables.FLEXOUPRowTable;

				ResponseModel responseModel = new ResponseModel();
				ServiceLayer rc = new ServiceLayer();
				string res = rc.Login();
				if (res != "" && res.Contains("error") == false)
				{
					FLEXOUPModel _objServiceLayer = new FLEXOUPModel();

					#region Header

					_objServiceLayer.Code = model.Code;
					_objServiceLayer.DocEntry = model.DocEntry;
					_objServiceLayer.DocNum = model.DocNum;
					_objServiceLayer.U_CardCode = model.U_CardCode;
					_objServiceLayer.U_CardName = model.U_CardName;
					_objServiceLayer.U_SlsEmp = model.U_SlsEmp;
					_objServiceLayer.U_SlpEmpNm = model.U_SlpEmpNm;

					//string treeType = model.TreeType;
					//if (treeType == "S")
					//{
					//	treeType = "iSalesTree";
					//}
					#endregion

					int modelRow = 0;
					List<FLEXOUPModelRow> modelLines_ServiceLayer = new List<FLEXOUPModelRow>();
					model.APAFUP1Collection = model.APAFUP1Collection.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
					for (int i = 0; i < model.APAFUP1Collection.Count; i++)
					{
						if (!string.IsNullOrEmpty(model.APAFUP1Collection[i].U_ItmCd))
						{
							modelLines_ServiceLayer.Add(new FLEXOUPModelRow { });
							modelLines_ServiceLayer[modelRow].LineId = model.APAFUP1Collection[i].LineId;
							modelLines_ServiceLayer[modelRow].U_ShpCd = model.APAFUP1Collection[i].U_ShpCd;
							modelLines_ServiceLayer[modelRow].U_ShpAddr = model.APAFUP1Collection[i].U_ShpAddr;
							modelLines_ServiceLayer[modelRow].U_ItmCd = model.APAFUP1Collection[i].U_ItmCd;
							modelLines_ServiceLayer[modelRow].U_ItmNm = model.APAFUP1Collection[i].U_ItmNm;
							modelLines_ServiceLayer[modelRow].U_Pckng = model.APAFUP1Collection[i].U_Pckng;
							modelLines_ServiceLayer[modelRow].U_RollDrctn = model.APAFUP1Collection[i].U_RollDrctn;
							modelLines_ServiceLayer[modelRow].U_IsActive = model.APAFUP1Collection[i].U_IsActive;
							try
							{
								if (model.APAFUP1Collection[i].IsChanged != null && model.APAFUP1Collection[i].IsChanged == "Y")
								{
									modelLines_ServiceLayer[modelRow].U_UpdateDate = DateTime.Now.Date.ToString("yyyMMdd");
									modelLines_ServiceLayer[modelRow].U_UpdateTime = DateTime.Now.ToString("HH:mm:ss");
								}
								else
								{
									modelLines_ServiceLayer[modelRow].U_UpdateTime = model.APAFUP1Collection[i].U_UpdateTime;
									DateTime dtUpdateDate = Convert.ToDateTime(model.APAFUP1Collection[i].U_UpdateDate);
									modelLines_ServiceLayer[modelRow].U_UpdateDate = dtUpdateDate.ToString("yyyyMMdd");
								}
							}
							catch { }
							modelRow++;
						}
					}
					_objServiceLayer.APAFUP1Collection = modelLines_ServiceLayer;

					string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
					{
						NullValueHandling = NullValueHandling.Ignore,
					});

					string serviceLayerObject = "APAFUP";
					rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject + "(" + model.DocEntry + ")";
					rc.patchJSON = main;
					rc.B1SESSION = res;
					rc.httpMethod = httpVerb.PATCH;
					string message = "";
					bool result = rc.patchRequest(out message);
					responseModel.ResponseStatus = result;
					if (result == true)
					{
						responseModel.ResponseText = "Operation completed successfully";
					}
					else
					{
						//JObject json = JObject.Parse(message);
						var jobject = JsonConvert.DeserializeObject<JObject>(message);
						string jsonMessage = jobject["error"].ToString();
						jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
						jsonMessage = jobject["message"].ToString();
						jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
						jsonMessage = jobject["value"].ToString();
						responseModel.ResponseText = "Error occured during process: " + jsonMessage;
					}
					rc.LogOut();
				}
				return responseModel;
			}
			catch (Exception ex)
			{
				throw new Exception(ex.ToString());
			}
		}

	}
}