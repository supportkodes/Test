﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
//using Microsoft.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using Microsoft.SqlServer.Server;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sap.Data.Hana;
using WebDAL.Helper;
using WebDAL.Helpers;
using WebDAL.IRepository;
using WebDAL.Models;
using static WebDAL.Models.PrepressModel;

namespace WebDAL.Repository
{
    public class PrepressRepository : clsDataAccess, IPrepressRepository
    {
        CommonRepository commonRepository = new CommonRepository();
        StringBuilder stringBuilder = new StringBuilder();
        string headerTable = CommonTables.FLEXOUPHeaderTable;
        string rowTable = CommonTables.FLEXOUPRowTable;

        public List<PrepressRowsModel> GetAll(string name, string type, string itemcode)
        {
            List<PrepressRowsModel> _list = new List<PrepressRowsModel>();

            try
            {
                HanaParameter[] parameters = new HanaParameter[2];
                parameters[0] = new HanaParameter("Type", SqlDbType.VarChar);
                parameters[0].Value = type;

                parameters[1] = new HanaParameter("ItemCode", SqlDbType.VarChar);
                parameters[1].Value = string.IsNullOrEmpty(itemcode) ? string.Empty : itemcode.Trim();

                string query = "";

                if (type == "O")
                {
                    if (name == "WIP")
                    {
                        query = ConfigManager.GetSAPDatabase() + ".\"Web_Prepress_Data\"";
                    }
                    else if (name == "QC")
                    {
                        query = ConfigManager.GetSAPDatabase() + ".\"Web_Prepress_Data_QC\"";
                    }
                    else if (name == "FO")
                    {
                        query = ConfigManager.GetSAPDatabase() + ".\"Web_Prepress_Data_FO\"";
                    }
                }
                else
                {
                    query = ConfigManager.GetSAPDatabase() + ".\"Web_Prepress_Data\"";
                }

                using (DataTable datatable = FillDataTable(query, CommandType.StoredProcedure, out string message, parameters))
                {
                    _list = ConvertDatatableToList.ConvertToList<PrepressRowsModel>(datatable);
                    _list.Where(a => a.Remarks == null).ToList().ForEach(c => c.Remarks = string.Empty);
                    _list.Where(a => a.U_ArtRelDt == null).ToList().ForEach(c => c.U_ArtRelDt = string.Empty);
                    _list.Where(a => a.ArtworkRecdApprovedDate == null).ToList().ForEach(c => c.ArtworkRecdApprovedDate = string.Empty);
                    _list.Where(a => a.U_SmplSubDt == null).ToList().ForEach(c => c.U_SmplSubDt = string.Empty);
                }
            }
            catch
            {
            }
            return _list;
        }

        public List<PrepressRowsModel> GetAllOpenData_WIP(string itemcode)
        {
            List<PrepressRowsModel> _list = new List<PrepressRowsModel>();
            try
            {
                HanaParameter[] parameters = new HanaParameter[2];
                parameters[0] = new HanaParameter("Type", SqlDbType.VarChar);
                parameters[0].Value = "O";

                parameters[1] = new HanaParameter("ItemCode", SqlDbType.VarChar);
                parameters[1].Value = itemcode == null ? string.Empty : itemcode.Trim().Replace("\t", "");
                string query = ConfigManager.GetSAPDatabase() + ".\"Web_Prepress_Data\"";
                using (DataTable datatable = FillDataTable(query, CommandType.StoredProcedure, out string message, parameters))
                {
                    _list = ConvertDatatableToList.ConvertToList<PrepressRowsModel>(datatable);
                    //_list = _list.Where(a => a.ItemCode == "13500111050760541F2401062").ToList();
                    _list.Where(a => a.Remarks == null).ToList().ForEach(c => c.Remarks = string.Empty);
                    _list.Where(a => a.U_ArtRelDt == null).ToList().ForEach(c => c.U_ArtRelDt = string.Empty);
                    _list.Where(a => a.ArtworkRecdApprovedDate == null).ToList().ForEach(c => c.ArtworkRecdApprovedDate = string.Empty);
                    _list.Where(a => a.U_SmplSubDt == null).ToList().ForEach(c => c.U_SmplSubDt = string.Empty);
                    _list.Where(a => a.U_JobAssTo == null).ToList().ForEach(c => c.U_JobAssTo = string.Empty);

                    #region Calculate Ageing

                    //string format = "-";
                    //var _listAgeing = _list.Where(a => a.U_StartDate != null && a.U_EndDate != null).ToList();
                    //for (int i = 0; i < _listAgeing.Count; i++)
                    //{
                    //    string startDate = _listAgeing[i].U_StartDate;
                    //    string endDate = _listAgeing[i].U_EndDate;
                    //    try
                    //    {
                    //        if (startDate.Contains("-"))
                    //        {
                    //            format = "dd-MM-yyyy hh:mm:ss";
                    //        }
                    //        else
                    //        {
                    //            format = "dd/MM/yyyy hh:mm:ss";
                    //        }
                    //        DateTime dtStartDate = DateTime.ParseExact(startDate, format, CultureInfo.InvariantCulture);
                    //        DateTime dtEndDate = DateTime.ParseExact(endDate, format, CultureInfo.InvariantCulture);

                    //        TimeSpan timeSpan = dtEndDate.Subtract(dtStartDate);

                    //        _listAgeing[i].Ageing = timeSpan.Hours.ToString().PadLeft(2, '0') + ":" + timeSpan.Minutes.ToString().PadLeft(2, '0') + ":" + timeSpan.Seconds.ToString().PadLeft(2, '0');
                    //    }
                    //    catch { }
                    //}

                    #endregion
                }
            }
            catch
            {
            }
            return _list;
        }

        public List<PrepressRowsModel> GetAllOpenData_QC(string itemcode)
        {
            List<PrepressRowsModel> _list = new List<PrepressRowsModel>();
            try
            {
                HanaParameter[] parameters = new HanaParameter[2];
                parameters[0] = new HanaParameter("Type", SqlDbType.VarChar);
                parameters[0].Value = "O";

                parameters[1] = new HanaParameter("ItemCode", SqlDbType.VarChar);
                parameters[1].Value = itemcode == null ? string.Empty : itemcode.Trim().Replace("\t", "");

                string query = ConfigManager.GetSAPDatabase() + ".\"Web_Prepress_Data_QC\"";
                using (DataTable datatable = FillDataTable(query, CommandType.StoredProcedure, out string message, parameters))
                {
                    _list = ConvertDatatableToList.ConvertToList<PrepressRowsModel>(datatable);
                    //_list = _list.Where(a => a.ItemCode == "135325811022120151F2400294").ToList();
                    _list.Where(a => a.Remarks == null).ToList().ForEach(c => c.Remarks = string.Empty);
                    _list.Where(a => a.U_ArtRelDt == null).ToList().ForEach(c => c.U_ArtRelDt = string.Empty);
                    _list.Where(a => a.ArtworkRecdApprovedDate == null).ToList().ForEach(c => c.ArtworkRecdApprovedDate = string.Empty);
                    _list.Where(a => a.U_SmplSubDt == null).ToList().ForEach(c => c.U_SmplSubDt = string.Empty);
                    _list.Where(a => a.U_JobAssTo == null).ToList().ForEach(c => c.U_JobAssTo = string.Empty);

                    //#region Calculate Ageing

                    //string format = "-";
                    //var _listAgeing = _list.Where(a => a.U_StartDtQC != null && a.U_EndDtQC != null).ToList();
                    //for (int i = 0; i < _listAgeing.Count; i++)
                    //{
                    //    string startDate = _listAgeing[i].U_StartDtQC;
                    //    string endDate = _listAgeing[i].U_EndDtQC;
                    //    try
                    //    {
                    //        if (startDate.Contains("-"))
                    //        {
                    //            format = "dd-MM-yyyy hh:mm:ss";
                    //        }
                    //        else
                    //        {
                    //            format = "dd/MM/yyyy hh:mm:ss";
                    //        }
                    //        DateTime dtStartDate = DateTime.ParseExact(startDate, format, CultureInfo.InvariantCulture);
                    //        DateTime dtEndDate = DateTime.ParseExact(endDate, format, CultureInfo.InvariantCulture);

                    //        TimeSpan timeSpan = dtEndDate.Subtract(dtStartDate);
                    //        _listAgeing[i].Ageing = timeSpan.Hours.ToString().PadLeft(2, '0') + ":" + timeSpan.Minutes.ToString().PadLeft(2, '0') + ":" + timeSpan.Seconds.ToString().PadLeft(2, '0');
                    //        //_listAgeing[i].Ageing = timeSpan.Hours.ToString() + ":" + timeSpan.Minutes.ToString() + ":" + timeSpan.Seconds.ToString();
                    //    }
                    //    catch { }
                    //}

                    //#endregion
                }
            }
            catch
            {
            }
            return _list;
        }

        public List<PrepressRowsModel> GetAllOpenData_FO(string itemcode)
        {
            List<PrepressRowsModel> _list = new List<PrepressRowsModel>();
            try
            {
                HanaParameter[] parameters = new HanaParameter[2];
                parameters[0] = new HanaParameter("Type", SqlDbType.VarChar);
                parameters[0].Value = "O";

                parameters[1] = new HanaParameter("ItemCode", SqlDbType.VarChar);
                parameters[1].Value = itemcode == null ? string.Empty : itemcode.Trim().Replace("\t", "");

                string query = ConfigManager.GetSAPDatabase() + ".\"Web_Prepress_Data_FO\"";
                using (DataTable datatable = FillDataTable(query, CommandType.StoredProcedure, out string message, parameters))
                {
                    _list = ConvertDatatableToList.ConvertToList<PrepressRowsModel>(datatable);
                    //_list = _list.Where(a => a.ItemCode == "135325811022120151F2400294").ToList();
                    _list.Where(a => a.Remarks == null).ToList().ForEach(c => c.Remarks = string.Empty);
                    _list.Where(a => a.U_ArtRelDt == null).ToList().ForEach(c => c.U_ArtRelDt = string.Empty);
                    _list.Where(a => a.ArtworkRecdApprovedDate == null).ToList().ForEach(c => c.ArtworkRecdApprovedDate = string.Empty);
                    _list.Where(a => a.U_SmplSubDt == null).ToList().ForEach(c => c.U_SmplSubDt = string.Empty);
                    _list.Where(a => a.U_JobAssTo == null).ToList().ForEach(c => c.U_JobAssTo = string.Empty);

                    //#region Calculate Ageing

                    //string format = "-";
                    //var _listAgeing = _list.Where(a => a.U_StartDtFO != null && a.U_EndDtFO != null).ToList();
                    //for (int i = 0; i < _listAgeing.Count; i++)
                    //{
                    //    string startDate = _listAgeing[i].U_StartDtFO;
                    //    string endDate = _listAgeing[i].U_EndDtFO;
                    //    try
                    //    {
                    //        if (startDate.Contains("-"))
                    //        {
                    //            format = "dd-MM-yyyy hh:mm:ss";
                    //        }
                    //        else
                    //        {
                    //            format = "dd/MM/yyyy hh:mm:ss";
                    //        }
                    //        DateTime dtStartDate = DateTime.ParseExact(startDate, format, CultureInfo.InvariantCulture);
                    //        DateTime dtEndDate = DateTime.ParseExact(endDate, format, CultureInfo.InvariantCulture);

                    //        TimeSpan timeSpan = dtEndDate.Subtract(dtStartDate);
                    //        _listAgeing[i].Ageing = timeSpan.Hours.ToString().PadLeft(2, '0') + ":" + timeSpan.Minutes.ToString().PadLeft(2, '0') + ":" + timeSpan.Seconds.ToString().PadLeft(2, '0');
                    //    }
                    //    catch { }
                    //}

                    //#endregion
                }
            }
            catch
            {
            }
            return _list;
        }

        public ResponseModel UpdateQCApproval(string itemcode)
        {
            string message = "";
            ResponseModel responseModel = new ResponseModel();

            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\" SET ");
            stringBuilder.Append(" \"U_IsQCApp\" = 'Y'  ");
            stringBuilder.Append(" WHERE \"U_ItemCode\" = '" + itemcode + "' ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (message == string.Empty)
            {
                responseModel.ResponseStatus = true;
                responseModel.ResponseText = "Updated successfully";
            }
            else
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            return responseModel;
        }
        public ResponseModel UpdateFinalApproval(string itemcode)
        {
            string message = "";
            ResponseModel responseModel = new ResponseModel();

            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\" SET ");
            stringBuilder.Append(" \"U_IsFinApp\" = 'Y'  ");
            //stringBuilder.Append(" \"U_DataUpDt\"= '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "'  ");
            stringBuilder.Append(" WHERE \"U_ItemCode\" = '" + itemcode + "' ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (message == string.Empty)
            {
                responseModel.ResponseStatus = true;
                responseModel.ResponseText = "Updated successfully";
            }
            else
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            return responseModel;
        }
        public ResponseModel UpdateArtworkApproval(string itemcode)
        {
            string message = "";
            ResponseModel responseModel = new ResponseModel();

            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\" SET ");
            stringBuilder.Append(" \"U_ArtAppDt\"= '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "' , \"U_IsArtApp\" = 'Y' , ");
            stringBuilder.Append(" \"U_RevAppDt\" = NULL ");
            //stringBuilder.Append(" \"U_DataUpDt\"= '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "'  ");
            stringBuilder.Append(" WHERE \"U_ItemCode\" = '" + itemcode + "' ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (message == string.Empty)
            {
                responseModel.ResponseStatus = true;
                responseModel.ResponseText = "Updated successfully";
            }
            else
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            return responseModel;
        }
        public ResponseModel UpdateRevisedApproval(string itemcode)
        {
            string message = "";
            ResponseModel responseModel = new ResponseModel();

            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\" SET ");
            stringBuilder.Append(" \"U_RevAppDt\"= '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "' , \"U_IsRevApp\" = 'Y'  ");
            stringBuilder.Append(" , \"U_IsArtApp\" = 'N'  ");
            //stringBuilder.Append(" ,\"U_StartDate\"= '' , \"U_IsStart\" = 'N'  ");
            //stringBuilder.Append(" ,\"U_EndDate\"= '' , \"U_IsEnd\" = 'N'  ");
            //stringBuilder.Append(" ,\"U_UpdateDate\"= '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "'  ");
            //stringBuilder.Append(" \"U_DataUpDt\"= '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "'  ");
            stringBuilder.Append(" WHERE \"U_ItemCode\" = '" + itemcode + "' ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (message == string.Empty)
            {
                responseModel.ResponseStatus = true;
                responseModel.ResponseText = "Updated successfully";
            }
            else
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            return responseModel;
        }
        public string GetPrepressCode(string itemcode)
        {
            string code = "";
            string message = "";
            ResponseModel responseModel = new ResponseModel();
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" SELECT \"Code\"  FROM   " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\" WHERE \"U_ItemCode\" = '" + itemcode + "' ");
            DataTable dt = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (dt.Rows.Count == 0)
            {
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" Select cast(max((TO_NUMBER(T0.\"Code\")))+1 as nvarchar(50)) AS \"Code\"   from " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\" T0 ");
                DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
                if (datatable.Rows.Count > 0)
                {
                    code = datatable.Rows[0][0].ToString();
                    if (code == string.Empty)
                    {
                        code = "1";
                    }
                }
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" INSERT INTO  " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\"(\"Code\",\"Name\",\"U_ItemCode\" ");
                stringBuilder.Append("  ) ");
                stringBuilder.Append(" VALUES('" + code + "','" + code + "','" + itemcode + "' ");
                stringBuilder.Append("  ) ");
                FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
                if (message == string.Empty)
                {
                    responseModel.ResponseText = "Operation completed successfully";
                    responseModel.ResponseStatus = true;
                }
                else
                {
                    responseModel.ResponseText = "Error occured during process: " + message;
                }
            }
            else
            {
                code = dt.Rows[0][0].ToString();
            }
            return code;
        }

        public DataTable GetPrepressData(string code)
        {
            string message = "";
            ResponseModel responseModel = new ResponseModel();
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" SELECT * ");
            stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\" ");
            stringBuilder.Append(" WHERE \"Code\" = '" + code + "' ");
            DataTable dt = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            return dt;
        }
        public ResponseModel UpdateStartWork(string itemcode, string ColumnName, string ColumnName2)
        {
            string message = "";
            ResponseModel responseModel = new ResponseModel();
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" SELECT \"U_ItemCode\"  FROM   " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\" WHERE \"U_ItemCode\" = '" + itemcode + "' ");
            DataTable dt = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (dt.Rows.Count == 0)
            {
                string code = "";
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" Select cast(max((TO_NUMBER(T0.\"Code\")))+1 as nvarchar(50)) AS \"Code\"   from " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\" T0 ");
                DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
                if (datatable.Rows.Count > 0)
                {
                    code = datatable.Rows[0][0].ToString();
                    if (code == string.Empty)
                    {
                        code = "1";
                    }
                }
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" INSERT INTO  " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\"(\"Code\",\"Name\",\"U_ItemCode\" ");
                stringBuilder.Append(" ,\"U_StartDate\" ,\"U_IsStart\"");
                stringBuilder.Append("  ) ");
                stringBuilder.Append(" VALUES('" + code + "','" + code + "','" + itemcode + "' ");
                stringBuilder.Append(" ,'" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "' , 'Y' ");
                stringBuilder.Append("  ) ");
                FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
                if (message == string.Empty)
                {
                    responseModel.ResponseText = "Operation completed successfully";
                    responseModel.ResponseStatus = true;
                }
                else
                {
                    responseModel.ResponseText = "Error occured during process: " + message;
                }
            }
            else
            {

            }
            {
                //string date = DateTime.Now.ToString("dd-MM-yyyy");
                //DateTime startdate = DateTime.ParseExact(date, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\" SET ");
                stringBuilder.Append(" \"" + ColumnName + "\"= '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "' , \"U_IsStart\" = 'Y' , ");
                stringBuilder.Append(" \"" + ColumnName2 + "\"= '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "' ");
                //stringBuilder.Append(" \"U_DataUpDt\"= '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "'  ");
                stringBuilder.Append(" WHERE \"U_ItemCode\" = '" + itemcode + "' ");
                FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
                if (message == string.Empty)
                {
                    responseModel.ResponseStatus = true;
                    responseModel.ResponseText = "Updated successfully";
                }
                else
                {
                    responseModel.ResponseStatus = false;
                    responseModel.ResponseText = "Error occured during process: " + message;
                }
            }
            return responseModel;
        }
        public ResponseModel UpdateEndWork(string itemcode, string columnName, string columnName2)
        {
            string message = "";
            ResponseModel responseModel = new ResponseModel();
            //string date = DateTime.Now.ToString("dd-MM-yyyy");

            stringBuilder = new StringBuilder();
            stringBuilder.Append(" SELECT TO_NVARCHAR(\"U_StartDate\", 'DD/MM/YYYY HH24:MI:SS') \"U_StartDate\", ");
            stringBuilder.Append(" TO_NVARCHAR(\"U_StartDtQC\", 'DD/MM/YYYY HH24:MI:SS') \"U_StartDtQC\",");
            stringBuilder.Append(" TO_NVARCHAR(\"U_StartDtFO\", 'DD/MM/YYYY HH24:MI:SS') \"U_StartDtFO\" ");
            stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\" ");
            stringBuilder.Append(" WHERE \"U_ItemCode\" = '" + itemcode + "' ");
            DataTable dtPrePress = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            string startDate = dtPrePress.Rows[0]["U_StartDate"].ToString();
            string format = "";

            string ageColumn = "U_WIPAge";
            if (columnName.Contains("QC"))
            {
                ageColumn = "U_QCAge";
                startDate = dtPrePress.Rows[0]["U_StartDtQC"].ToString();
            }
            else if (columnName.Contains("FO"))
            {
                ageColumn = "U_FOAge";
                startDate = dtPrePress.Rows[0]["U_StartDtFO"].ToString();
            }
            if (startDate.Contains("-"))
            {
                format = "dd-MM-yyyy HH:mm:ss";
            }
            else
            {
                format = "dd/MM/yyyy HH:mm:ss";
            }
            DateTime dtStartDate = DateTime.ParseExact(startDate, format, CultureInfo.InvariantCulture);
            string endDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            DateTime dtEndDate = DateTime.ParseExact(endDate, "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
            TimeSpan timeSpan = dtEndDate.Subtract(dtStartDate);

            string age = timeSpan.Hours.ToString().PadLeft(2, '0') + ":" + timeSpan.Minutes.ToString().PadLeft(2, '0') + ":" + timeSpan.Seconds.ToString().PadLeft(2, '0');

            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\" SET ");
            stringBuilder.Append(" \"" + columnName + "\"= '" + endDate + "' , \"U_IsEnd\" = 'Y'  ");
            stringBuilder.Append(" ,\"" + columnName2 + "\"= '" + endDate + "'    ");
            stringBuilder.Append(" ,\"" + ageColumn + "\"= '" + age + "'  ");
            stringBuilder.Append(" WHERE \"U_ItemCode\" = '" + itemcode + "' ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (message == string.Empty)
            {

                responseModel.ResponseStatus = true;
                responseModel.ResponseText = "Updated successfully";
            }
            else
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            return responseModel;
        }
        public ResponseModel UpdateArtworkReleaseDate(string itemcode, string date, string columnName2)
        {
            string message = "";
            ResponseModel responseModel = new ResponseModel();
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\" SET ");
            stringBuilder.Append(" \"U_ArtRecdDt\"= '" + DateTime.ParseExact(date, "dd-MM-yyyy", CultureInfo.InvariantCulture).ToString("yyyyMMdd") + "', ");
            stringBuilder.Append(" \"" + columnName2 + "\"= '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "'  ");
            stringBuilder.Append(" WHERE \"U_ItemCode\" = '" + itemcode + "' ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (message == string.Empty)
            {
                responseModel.ResponseStatus = true;
                responseModel.ResponseText = "Updated successfully";
            }
            else
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            return responseModel;
        }

        public ResponseModel UpdateArtworkReleaseApproveDate(string itemcode, string date, string columnName2)
        {
            string message = "";
            ResponseModel responseModel = new ResponseModel();
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\" SET ");
            stringBuilder.Append(" \"U_ArtRelDt\"= '" + DateTime.ParseExact(date, "dd-MM-yyyy", CultureInfo.InvariantCulture).ToString("yyyyMMdd") + "', ");
            stringBuilder.Append(" \"" + columnName2 + "\"= '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "'  ");
            stringBuilder.Append(" WHERE \"U_ItemCode\" = '" + itemcode + "' ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (message == string.Empty)
            {
                responseModel.ResponseStatus = true;
                responseModel.ResponseText = "Updated successfully";

                stringBuilder = new StringBuilder();
                stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PO_REGISTER1\" SET ");
                stringBuilder.Append(" \"U_AppArt\"= 'Y' ");
                stringBuilder.Append(" WHERE \"U_ItemCode\" = '" + itemcode + "' ");
                FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            }
            else
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            return responseModel;
        }

        public ResponseModel UpdateRemark(string itemcode, string columnName, string Remark, string CoulumnName2)
        {
            string message = "";
            ResponseModel responseModel = new ResponseModel();
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\" SET ");
            stringBuilder.Append(" \"" + columnName + "\"= '" + Remark + "', ");
            stringBuilder.Append(" \"" + CoulumnName2 + "\"= '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "'  ");
            stringBuilder.Append(" WHERE \"U_ItemCode\" = '" + itemcode + "' ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (message == string.Empty)
            {
                responseModel.ResponseStatus = true;
                responseModel.ResponseText = "Updated successfully";
            }
            else
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            return responseModel;
        }
        public ResponseModel UpdateRefSample(string itemcode, string refSampl, string CoulumnName2)
        {
            string message = "";
            ResponseModel responseModel = new ResponseModel();
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\" SET ");
            stringBuilder.Append(" \"U_RefSaml\"= '" + refSampl + "', ");
            stringBuilder.Append(" \"" + CoulumnName2 + "\"= '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "'  ");
            stringBuilder.Append(" WHERE \"U_ItemCode\" = '" + itemcode + "' ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (message == string.Empty)
            {
                responseModel.ResponseStatus = true;
                responseModel.ResponseText = "Updated successfully";
            }
            else
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            return responseModel;
        }
        public ResponseModel UpdateSampleSubmitDate(string itemcode, string date, string refsample)
        {
            string message = "";
            string prepresscode = GetPrepressCode(itemcode);
            ResponseModel responseModel = new ResponseModel();
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\" SET ");
            stringBuilder.Append(" \"U_SmplSubDt\"= '" + DateTime.ParseExact(date, "dd-MM-yyyy", CultureInfo.InvariantCulture).ToString("yyyyMMdd") + "' ");
            stringBuilder.Append(" WHERE \"Code\" = '" + prepresscode + "' ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (message == string.Empty)
            {
                responseModel.ResponseStatus = true;
                responseModel.ResponseText = "Updated successfully";
            }
            else
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            return responseModel;
        }
        public ResponseModel UpdatePrepressColumnData(string itemcode, string columName, string value, string columnName2)
        {
            string message = "";
            string prepresscode = GetPrepressCode(itemcode);

            ResponseModel responseModel = new ResponseModel();
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\" SET ");
            stringBuilder.Append(" \"" + columName + "\"= '" + value + "' ,");
            stringBuilder.Append(" \"" + columnName2 + "\"= '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "'  ");
            stringBuilder.Append(" WHERE \"Code\" = '" + prepresscode + "' ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (message == string.Empty)
            {
                responseModel.ResponseStatus = true;
                responseModel.ResponseText = "Updated successfully";
            }
            else
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            return responseModel;
        }

        public ResponseModel ReworkLog(string itemcode)
        {
            string message = "";

            string prepresscode = GetPrepressCode(itemcode);
            DataTable prepressDataTable = GetPrepressData(prepresscode);

            ResponseModel responseModel = new ResponseModel();
            #region Insert in Log

            string code = "";
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" Select cast(max((TO_NUMBER(T0.\"Code\")))+1 as nvarchar(50)) AS \"Code\"   from " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESSLOG\" T0 ");
            DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (datatable.Rows.Count > 0)
            {
                code = datatable.Rows[0][0].ToString();
                if (code == string.Empty)
                {
                    code = "1";
                }
            }

            stringBuilder = new StringBuilder();
            stringBuilder.Append(" INSERT INTO  " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESSLOG\"(\"Code\",\"Name\",\"U_ItemCode\" ");
            stringBuilder.Append(" ,\"U_ArtAppDt\" ,\"U_RevAppDt\",\"U_Remarks\",\"U_DataUpDt\",\"U_RefSDt\",\"U_SmplSubDt\" ");
            stringBuilder.Append(" ,\"U_ArtRelDt\" ,\"U_StartDate\",\"U_EndDate\",\"U_ArtRecdDt\",\"U_RefSaml\",\"U_StartDtQC\" ");
            stringBuilder.Append(" ,\"U_EndDtQC\" ,\"U_RemarkQC\",\"U_JobAsTQC\",\"U_StartDtFO\",\"U_EndDtFO\",\"U_RemarkFO\" ");
            stringBuilder.Append(" ,\"U_JobAsTFO\" ,\"U_WIP_UpdateDate\",\"U_QC_UpdateDate\",\"U_FO_UpdateDate\" ");
            stringBuilder.Append(" ,\"U_WIPAge\" ,\"U_QCAge\",\"U_FOAge\" ");
            stringBuilder.Append("  ) ");
            stringBuilder.Append(" SELECT '" + code + "','" + code + "','" + itemcode + "' ");
            stringBuilder.Append(" ,\"U_ArtAppDt\" ,\"U_RevAppDt\",\"U_Remarks\",\"U_DataUpDt\",\"U_RefSDt\",\"U_SmplSubDt\" ");
            stringBuilder.Append(" ,\"U_ArtRelDt\" ,\"U_StartDate\",\"U_EndDate\",\"U_ArtRecdDt\",\"U_RefSaml\",\"U_StartDtQC\" ");
            stringBuilder.Append(" ,\"U_EndDtQC\" ,\"U_RemarkQC\",\"U_JobAsTQC\",\"U_StartDtFO\",\"U_EndDtFO\",\"U_RemarkFO\" ");
            stringBuilder.Append(" ,\"U_JobAsTFO\" ,\"U_WIP_UpdateDate\",\"U_QC_UpdateDate\",\"U_FO_UpdateDate\" ");
            stringBuilder.Append(" ,\"U_WIPAge\" ,\"U_QCAge\",\"U_FOAge\" ");
            stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\"  ");
            stringBuilder.Append(" WHERE \"Code\" ='" + prepresscode + "'  ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            #endregion

            #region Clear Prepress Data
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\" SET ");
            stringBuilder.Append(" \"U_IsArtApp\" = NULL, ");
            stringBuilder.Append(" \"U_RevAppDt\" = NULL, ");
            stringBuilder.Append(" \"U_IsRevApp\" = NULL, ");
            stringBuilder.Append(" \"U_Remarks\" = NULL, ");
            stringBuilder.Append(" \"U_IsStart\" = NULL, ");
            stringBuilder.Append(" \"U_IsEnd\" = NULL, ");
            stringBuilder.Append(" \"U_DataUpDt\" = NULL, ");
            stringBuilder.Append(" \"U_RefSDt\" = NULL, ");
            stringBuilder.Append(" \"U_SmplSubDt\" = NULL, ");
            stringBuilder.Append(" \"U_ArtRelDt\" = NULL, ");
            stringBuilder.Append(" \"U_StartDate\" = NULL, ");
            stringBuilder.Append(" \"U_EndDate\" = NULL, ");
            stringBuilder.Append(" \"U_ArtRecdDt\" = NULL, ");
            stringBuilder.Append(" \"U_RefSaml\" = NULL, ");
            stringBuilder.Append(" \"U_IsQCApp\" = NULL, ");
            stringBuilder.Append(" \"U_IsFinApp\" = NULL, ");
            stringBuilder.Append(" \"U_JobAssTo\" = NULL, ");
            stringBuilder.Append(" \"U_StartDtQC\" = NULL, ");
            stringBuilder.Append(" \"U_EndDtQC\" = NULL, ");
            stringBuilder.Append(" \"U_JobAsTQC\" = NULL, ");
            stringBuilder.Append(" \"U_RemarkQC\" = NULL, ");
            stringBuilder.Append(" \"U_StartDtFO\" = NULL, ");
            stringBuilder.Append(" \"U_EndDtFO\" = NULL, ");
            stringBuilder.Append(" \"U_RemarkFO\" = NULL, ");
            stringBuilder.Append(" \"U_JobAsTFO\" = NULL, ");
            stringBuilder.Append(" \"U_WIP_UpdateDate\" = NULL, ");
            stringBuilder.Append(" \"U_QC_UpdateDate\" = NULL, ");
            stringBuilder.Append(" \"U_FO_UpdateDate\" = NULL, ");
            stringBuilder.Append(" \"U_WIPAge\" = NULL, ");
            stringBuilder.Append(" \"U_QCAge\" = NULL, ");
            stringBuilder.Append(" \"U_FOAge\" = NULL ");
            stringBuilder.Append(" WHERE \"Code\" = '" + prepresscode + "' ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (message == string.Empty)
            {
                responseModel.ResponseStatus = true;
                responseModel.ResponseText = "Updated successfully";
            }
            else
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            #endregion

            return responseModel;
        }

        public ResponseModel UpdateKLD(string itemcode, string KLDNo)
        {
            string message = "";
            string prepresscode = GetPrepressCode(itemcode);
            ResponseModel responseModel = new ResponseModel();
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\" SET ");
            stringBuilder.Append(" \"U_KLDNo\" = '"+KLDNo+ "'");
            stringBuilder.Append(" WHERE \"U_ItemCode\" = '" + itemcode + "' ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (message == string.Empty)
            {
                responseModel.ResponseStatus = true;
                responseModel.ResponseText = "Updated successfully";
            }
            else
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            return responseModel;
        }

        public ResponseModel UpdatePunch(string itemcode, string PunchNo)
        {
            string message = "";
            string prepresscode = GetPrepressCode(itemcode);
            ResponseModel responseModel = new ResponseModel();
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\" SET ");
            stringBuilder.Append(" \"U_PunchNo\" = '" + PunchNo + "'  ");
            stringBuilder.Append(" WHERE \"U_ItemCode\" = '" + itemcode + "' ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (message == string.Empty)
            {
                responseModel.ResponseStatus = true;
                responseModel.ResponseText = "Updated successfully";
            }
            else
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            return responseModel;
        }

        public ResponseModel UpdateInkType(string itemcode, string InkType)
        {
            string message = "";
            string prepresscode = GetPrepressCode(itemcode);
            ResponseModel responseModel = new ResponseModel();
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"OITM\" SET ");
            stringBuilder.Append(" \"U_InkType\" = '" + InkType + "'  ");
            stringBuilder.Append(" WHERE \"ItemCode\" = '" + itemcode + "' ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (message == string.Empty)
            {
                responseModel.ResponseStatus = true;
                responseModel.ResponseText = "Updated successfully";
            }
            else
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            return responseModel;
        }

    }
}