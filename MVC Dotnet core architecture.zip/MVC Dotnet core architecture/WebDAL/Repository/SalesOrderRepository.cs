﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using Microsoft.Win32.SafeHandles;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sap.Data.Hana;
using WebDAL.Helper;
using WebDAL.Helpers;
using WebDAL.IRepository;
using WebDAL.Models;

namespace WebDAL.Repository
{
	public class SalesOrderRepository : clsDataAccess, ISalesOrderRepository
	{
		CommonRepository commonRepository = new CommonRepository();
		StringBuilder stringBuilder = new StringBuilder();
		public List<DocumentIndexModel> GetAll(string userId, string type)
		{
			List<DocumentIndexModel> _list = new List<DocumentIndexModel>();
			try
			{
				string isSuperUser = commonRepository.IsUserSuperUser(userId);
				string slpName = commonRepository.GetSlpNameFromEmailAddress(userId);
				string headerTable = CommonTables.SalesOrderHeaderTable;
				string rowTable = CommonTables.SalesOrderRowTable;
				if (type.ToUpper() == "DRAFT")
				{
					headerTable = CommonTables.DraftHeaderTable;
					rowTable = CommonTables.DraftRowTable;
				}

				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("@UserId", System.Data.SqlDbType.VarChar);
				parameters[0].Value = userId;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT '" + type + "' AS \"Type\" , T0.\"DocEntry\", T0.\"DocNum\",TO_NVARCHAR(T0.\"DocDate\", 'DD/MM/YYYY')  AS \"DocDate\" ,\"CardName\" ");
				stringBuilder.Append(" ,CASE WHEN \"DocStatus\" = 'O' THEN 'Open' ");
				stringBuilder.Append("  WHEN \"DocStatus\" = 'C' AND \"CANCELED\" = 'Y' THEN 'Cancelled' ELSE 'Closed' END AS \"DocStatus\"");
				stringBuilder.Append(" ,\"Comments\"  ");
				stringBuilder.Append(" ,\"NumAtCard\"  ");
				//stringBuilder.Append(" ,(SELECT MAX(\"DocNum\") \""+CommonTables.ClientPORegisterHeaderTable+"\" WHERE \"DocEntry\" (SELECT MAX(A.\"U_Exp1\") FROM  " + ConfigManager.GetSAPDatabase() + "." + rowTable + " A WHERE A.\"DocEntry\" = T0.\"DocEntry\" ) AS \"ClientPONo\" ");
				stringBuilder.Append(" ,(SELECT MAX(A.\"DocNum\")  FROM " + ConfigManager.GetSAPDatabase() + ".\"" + CommonTables.ClientPORegisterHeaderTable + "\" A INNER JOIN  " + ConfigManager.GetSAPDatabase() + "." + rowTable + " B ON CAST(A.\"DocEntry\" AS VARCHAR(100)) = CAST(B.\"U_Exp1\" AS VARCHAR(100)) WHERE B.\"DocEntry\" = T0.\"DocEntry\") AS \"ClientPONo\" ");
				stringBuilder.Append(" ,T0.\"SlpCode\" AS \"SalesPersonCode\"  ");
				stringBuilder.Append(" ,T1.\"SlpName\"  ");
				stringBuilder.Append(" ,DAYS_BETWEEN(T0.\"DocDate\",CURRENT_DATE)  AS \"SOAge\"  ");
				if (type.ToUpper() == "DRAFT")
				{
					stringBuilder.Append(" ,CASE WHEN T0.\"U_IsApp\" = 'Y' THEN 'Approved' WHEN T0.\"U_IsApp\" = 'N' THEN 'Rejected' ELSE 'Pending' END \"ApprovalStatus\"  ");
				}
				else
				{
					stringBuilder.Append(" ,'Approved' \"ApprovalStatus\"  ");
				}
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + headerTable + " T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OSLP T1 ON T0.\"SlpCode\"=T1.\"SlpCode\" ");
				if (type.ToUpper() == "DRAFT")
				{
					stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OWDD T2 ON T0.\"DocEntry\"=T2.\"DraftEntry\" ");
				}
				stringBuilder.Append(" WHERE T0.\"DocStatus\" = 'O' AND T0.\"ObjType\" ='" + Convert.ToString((int)ObjectType.Orders) + "' ");
				if (type.ToUpper() == "DRAFT")
				{
					stringBuilder.Append(" AND T0.\"DocDate\" >= '2022-12-01' ");
					stringBuilder.Append(" AND T2.\"DraftEntry\"  IS NULL ");
					stringBuilder.Append(" AND (T0.\"U_IsApp\"='Y' OR T0.\"U_IsApp\" IS NULL) ");
				}
				else
				{
					stringBuilder.Append(" AND (T0.\"U_IsApp\"='Y' OR T0.\"U_IsApp\" IS NULL) ");
				}
				if (isSuperUser == "Y")
				{
					stringBuilder.Append(" ORDER BY Case When T1.\"SlpName\" Like '" + slpName + "%' then 0 elSe 1 end,T0.\"DocDate\"  Desc ");
				}
				else
				{
					stringBuilder.Append(" ORDER BY T0.\"DocEntry\" DESC ");
				}
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<DocumentIndexModel>(datatable);
					if (isSuperUser != "Y")
					{
						List<SalesEmployeeModel> teamSalesEmployee = commonRepository.GetAllTeamSalesEmployee(userId);
						_list = _list.Where(x => teamSalesEmployee.Any(y => y.SlpCode == x.SalesPersonCode)).ToList();
					}
					else
					{
						//_list = _list.OrderBy(name => name.Count(c => c == 'b' || c == 'B')).ToList();
					}
				}
			}
			catch
			{

			}
			return _list;
		}
		public DocumentModel Get(string docEntry, string userId, string type)
		{
			DocumentModel model = new DocumentModel();
			try
			{
				string slpcode = commonRepository.GetSlpCodeFromEmailAddress(userId);
				string headerTable = CommonTables.SalesOrderHeaderTable;
				string rowTable = CommonTables.SalesOrderRowTable;
				string freightTable = CommonTables.SalesOrderFreightTable;
				string taxExtensionTable = CommonTables.SalesOrderAddressTable;
				if (type.ToUpper() == "DRAFT")
				{
					headerTable = CommonTables.DraftHeaderTable;
					rowTable = CommonTables.DraftRowTable;
					freightTable = CommonTables.DraftFreightTable;
					taxExtensionTable = CommonTables.DraftAddressTable;
				}

				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
				parameters[0].Value = docEntry;
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT '" + type.ToUpper() + "' AS \"Type\", T0.\"DocEntry\",T0.\"DocNum\",T0.\"DocCur\" AS \"DocCurrency\",T0.\"DocRate\",T0.\"Series\",T0.\"SlpCode\" AS \"SalesPersonCode\",T2.\"SeriesName\" ");
				stringBuilder.Append(" ,T0.\"CardCode\",T0.\"CardName\",T0.\"NumAtCard\",TO_VARCHAR(T0.\"DocDate\", 'DD-MM-YYYY') \"DocDate\",TO_VARCHAR(T0.\"TaxDate\", 'DD-MM-YYYY') AS \"TaxDate\" ");
				if (type.ToUpper() == "DRAFT")
				{
					stringBuilder.Append(" ,'Draft' AS \"DocStatus\"");
				}
				else
				{
					stringBuilder.Append(" ,CASE WHEN \"DocStatus\" = 'O' THEN 'Open' ");
					stringBuilder.Append("  WHEN \"DocStatus\" = 'C' AND \"CANCELED\" = 'Y' THEN 'Cancelled' ELSE 'Closed' END AS \"DocStatus\"");
				}
				stringBuilder.Append(" ,T0.\"BPLId\" AS \"BPL_IDAssignedToInvoice\",TO_VARCHAR(T0.\"DocDueDate\", 'DD-MM-YYYY') \"DocDueDate\" ");
				stringBuilder.Append(" ,T0.\"ShipToCode\",T0.\"PayToCode\",T0.\"TrnspCode\" AS \"TransportationCode\" ");
				stringBuilder.Append(" ,T0.\"OwnerCode\" AS \"DocumentsOwner\",T0.\"Comments\" ");
				stringBuilder.Append(" ,T0.\"DiscPrcnt\" AS \"DiscountPercent\" ");
				stringBuilder.Append(" ,T0.\"RoundDif\" AS \"RoundingDiffAmount\"  ");

				stringBuilder.Append(" ,CASE WHEN T0.\"DocRate\" = 1 THEN T0.\"VatSum\" ELSE T0.\"VatSumFC\"	END AS \"TaxAmount\" ");
				stringBuilder.Append(" ,CASE WHEN T0.\"DocRate\" = 1 THEN T0.\"DocTotal\" ELSE T0.\"DocTotalFC\" END AS \"DocumentTotal\" ");
				stringBuilder.Append(" ,CASE WHEN T0.\"DocRate\" = 1 THEN T0.\"TotalExpns\" ELSE T0.\"TotalExpFC\" END AS \"TotalExpns\" ");
				stringBuilder.Append(" ,T0.\"TotalExpns\"  ");
				stringBuilder.Append(" ,T3.\"State\" AS \"BillTo_State\"  ");
				stringBuilder.Append(" ,T4.\"State\" AS \"ShipTo_State\"  ");
				stringBuilder.Append(" ,T0.\"Address\"  ");
				stringBuilder.Append(" ,T0.\"Address2\"  ");
				stringBuilder.Append(" ,T0.\"AtcEntry\"  ");
				stringBuilder.Append(" ,T0.\"DutyStatus\"  ");

				stringBuilder.Append(" ,T0.\"U_MdTrns\",T0.\"U_PortDischarge\",T0.\"U_PortLoad\",T0.\"U_INCOTERMS\"  ");

				stringBuilder.Append(" ,T5.\"U_BPTL\" AS \"BPTolerancePercent\" ");
				stringBuilder.Append(" ,T5.\"U_BPLTL\" AS \"BPLowerTolerancePercent\" ");
				stringBuilder.Append(" ,T0.\"U_IsApp\" ");
				stringBuilder.Append(" ,T6.\"ImpORExp\" ,T6.\"ExportType\" ");
				stringBuilder.Append(" ,T0.\"U_CRBY\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + headerTable + " T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OSLP T1 ON T0.\"SlpCode\" = T1.\"SlpCode\"  ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".NNM1 T2 ON T0.\"Series\" = T2.\"Series\"  ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".CRD1 T3 ON T0.\"CardCode\" = T3.\"CardCode\" AND T0.\"PayToCode\" = T3.\"Address\" AND T3.\"AdresType\"='B'  ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".CRD1 T4 ON T0.\"CardCode\" = T4.\"CardCode\" AND T0.\"ShipToCode\" = T4.\"Address\" AND T4.\"AdresType\"='S'  ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCRD T5 ON T0.\"CardCode\" = T5.\"CardCode\"  ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + "." + taxExtensionTable + " T6 ON T0.\"DocEntry\" = T6.\"DocEntry\"  ");
				stringBuilder.Append(" WHERE T0.\"DocEntry\" = :DocEntry ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						model = ConvertDatatableToList.ConvertToEntity<DocumentModel>(datatable);
						if (type.ToUpper() == "DRAFT")
						{
							string isApp = model.U_IsApp;
							string empPosition = commonRepository.GetEmployeePosition(userId);
							if (model.SalesPersonCode == slpcode || empPosition == "HEAD")
							{
								if (string.IsNullOrEmpty(isApp))
								{
									model.ShowApproval = "Y";
								}
							}
							model.IsEditable = "Y";
						}
						if (model.SalesPersonCode == slpcode)
						{
							model.IsEditable = "Y";
						}
						model.boolImpORExp = model.ImpORExp == "Y" ? true : false;
					}
				}

				#region Row
				double docRate = double.Parse(model.DocRate);
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"VisOrder\" + 1 AS \"Index\",T0.\"LineNum\", T0.\"ItemCode\",T0.\"Dscription\" AS \"ItemName\" ");
				stringBuilder.Append(" ,T0.\"Quantity\",T0.\"TreeType\" ,T1.\"U_KLDNo\"");
				stringBuilder.Append(" ,T0.\"SubCatNum\" \"SupplierCatNum\",T0.\"U_Category\",T0.\"FreeTxt\" AS \"FreeText\" ");
				stringBuilder.Append(" ,T0.\"U_CTOL\",T0.\"U_CTLOL\",T0.\"unitMsr\" \"MeasureUnit\",T0.\"WhsCode\" AS \"WarehouseCode\" ");
				stringBuilder.Append(" ,T0.\"TaxCode\",T2.\"Rate\" AS \"TaxRate\",T1.\"ChapterID\" AS \"HSNEntry\",T3.\"ChapterID\" AS \"HSNName\" ");
				stringBuilder.Append(" ,T0.\"U_UnwDrctn\",T0.\"U_Packng\" ");
				if (docRate == 1)
				{
					stringBuilder.Append(" ,T0.\"PriceBefDi\" AS \"UnitPrice\",T0.\"LineTotal\" AS \"Total\" ");
				}
				else
				{
					stringBuilder.Append(" ,T0.\"Price\" AS \"UnitPrice\",T0.\"TotalFrgn\" AS \"Total\" ");
				}
				stringBuilder.Append(" ,TO_VARCHAR(T0.\"ShipDate\", 'DD-MM-YYYY') \"ShipDate\" ");
				stringBuilder.Append(" ,T0.\"BaseEntry\",T0.\"BaseLine\",T0.\"BaseType\",T0.\"LineStatus\" ");
				stringBuilder.Append(" ,T0.\"U_Exp1\",T0.\"U_Exp2\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + rowTable + " T0 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OITM T1 ON T0.\"ItemCode\" = T1.\"ItemCode\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OSTC T2 ON T0.\"TaxCode\" = T2.\"Code\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T3 ON T1.\"ChapterID\" = T3.\"AbsEntry\" ");

				stringBuilder.Append(" WHERE T0.\"DocEntry\" = :DocEntry ");
				stringBuilder.Append(" ORDER BY T0.\"VisOrder\" ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					List<DocumentRowsModel> modelRows = ConvertDatatableToList.ConvertToList<DocumentRowsModel>(datatable);
					model.DocumentLines = modelRows;
					if (datatable.Rows.Count > 0)
					{
						model.WarehouseCode = model.DocumentLines.Select(a => a.WarehouseCode).FirstOrDefault();
						model.NetAmount = model.DocumentLines.Select(a => a.Total).Sum();
					}
					else
					{
						modelRows.Add(new DocumentRowsModel { });
						model.DocumentLines = modelRows;
					}
					bool isAnySalesBOM = modelRows.Where(a => a.TreeType == "S").Any();
					if (isAnySalesBOM == true)
					{
						int baseBomLineId = 0;
						List<BOMModel> listBOModel = new List<BOMModel>();

						for (int i = 0; i < modelRows.Count; i++)
						{
							int lineId = modelRows[i].Index.Value;
							string itemcode = modelRows[i].ItemCode;

							string treeType = modelRows[i].TreeType;
							if (treeType == "S")
							{
								baseBomLineId = lineId;
								listBOModel = new List<BOMModel>();
								listBOModel = commonRepository.GetBOMComponents(itemcode);
							}
							else if (treeType == "I")
							{
								modelRows[i].BaseBOMLine = baseBomLineId.ToString();
								try
								{
									var bomData = listBOModel.Where(a => a.ItemCode == itemcode).FirstOrDefault();
									modelRows[i].BOMRatio = bomData.BOMRatio.ToString();
								}
								catch { }
							}
						}
					}
				}
				#endregion

				#region Attachment 
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT  T1.\"trgtPath\",T1.\"FileName\", T1.\"FileExt\", T1.\"Line\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + headerTable + " T0 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".ATC1 T1 ON T0.\"AtcEntry\" = T1.\"AbsEntry\" ");
				stringBuilder.Append(" WHERE T0.\"DocEntry\" = :DocEntry ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						List<DocumentModel_Attachment> modelRows = ConvertDatatableToList.ConvertToList<DocumentModel_Attachment>(datatable);
						model.Attachments2_Lines = modelRows;
						for (int i = 0; i < model.Attachments2_Lines.Count; i++)
						{
							model.Attachments2_Lines[i].Index = (i + 1);
							model.Attachments2_Lines[i].trgtPath += "\\" + model.Attachments2_Lines[i].FileName + "." + model.Attachments2_Lines[i].FileExt;
						}
					}
				}
				#endregion

				#region Freight

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT  T1.\"ExpnsCode\" AS \"ExpenseCode\",T1.\"ExpnsName\" AS \"ExpenseName\" ");
				stringBuilder.Append(" ,T0.\"TaxCode\", T0.\"VatPrcnt\" AS \"TaxPercent\" ");
				if (docRate == 1)
				{
					stringBuilder.Append(" , T0.\"LineTotal\",T0.\"VatSum\" AS \"TaxSum\", T0.\"GrsAmount\" AS \"LineGross\" ");
				}
				else
				{
					stringBuilder.Append(" ,T0.\"TotalFrgn\" AS \"LineTotal\",T0.\"VatSumFrgn\" AS \"TaxSum\", T0.\"GrsFC\" AS \"LineGross\" ");
				}
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + freightTable + " T0 ");
				stringBuilder.Append(" RIGHT JOIN " + ConfigManager.GetSAPDatabase() + ".OEXD T1 ON T0.\"ExpnsCode\" = T1.\"ExpnsCode\" AND T0.\"DocEntry\" = :DocEntry ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					List<DocumentModel_Expenses> modelRows = ConvertDatatableToList.ConvertToList<DocumentModel_Expenses>(datatable);
					if (modelRows.Count == 0)
					{
						DocumentModel_Expenses documentModel_Expenses = new DocumentModel_Expenses();
						modelRows.Add(documentModel_Expenses);
					}
					model.DocumentAdditionalExpenses = modelRows;
					double? freightAmount = model.TotalExpns;
					if (freightAmount == 0)
					{
						string itemTaxCode = model.DocumentLines.Select(a => a.TaxCode).FirstOrDefault();
						for (int i = 0; i < model.DocumentAdditionalExpenses.Count; i++)
						{
							model.DocumentAdditionalExpenses[i].TaxCode = itemTaxCode;
						}
					}
				}
				#endregion
			}
			catch
			{

			}
			return model;
		}
		public ResponseModel Add(DocumentModel model)
		{
			string headerTable = CommonTables.SalesOrderHeaderTable;
			string rowTable = CommonTables.SalesOrderRowTable;
			string addressExtensionTable = CommonTables.SalesOrderAddressTable;

			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				string slpcode = commonRepository.GetSlpCodeFromEmailAddress(model.UserId);
				string slpname = commonRepository.GetSlpNameFromSlpCode(model.SalesPersonCode);
				DocumentModel _objServiceLayer = new DocumentModel();

				#region Header
				_objServiceLayer.CardCode = model.CardCode;
				_objServiceLayer.CardName = model.CardName;
				_objServiceLayer.Series = model.Series;
				_objServiceLayer.DocCurrency = model.DocCurrency;
				_objServiceLayer.DocRate = model.DocRate;
				_objServiceLayer.U_CRBY = model.U_CRBY;

				_objServiceLayer.DocObjectCode = Convert.ToString((int)ObjectType.Orders);
				_objServiceLayer.NumAtCard = model.NumAtCard;

				if (model.DocDate == null)
				{
					model.DocDate = DateTime.Now.ToString("dd-MM-yyyy");
				}
				if (model.DocDueDate == null)
				{
					model.DocDueDate = DateTime.Now.ToString("dd-MM-yyyy");
				}
				if (model.TaxDate == null)
				{
					model.TaxDate = DateTime.Now.ToString("dd-MM-yyyy");
				}

				DateTime dtDocDate = DateTime.ParseExact(model.DocDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
				DateTime dtDocDueDate = DateTime.ParseExact(model.DocDueDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
				DateTime dtTaxDate = DateTime.ParseExact(model.TaxDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);

				//DateTime dtDocDate = Convert.ToDateTime(model.DocDate);
				//DateTime dtDocDueDate = Convert.ToDateTime(model.DocDueDate);
				//DateTime dtTaxDate = Convert.ToDateTime(model.TaxDate);

				_objServiceLayer.DocDate = dtDocDate.ToString("yyyyMMdd");
				_objServiceLayer.DocDueDate = dtDocDueDate.ToString("yyyyMMdd");
				_objServiceLayer.TaxDate = dtTaxDate.ToString("yyyyMMdd");
				_objServiceLayer.BPL_IDAssignedToInvoice = model.BPL_IDAssignedToInvoice;
				_objServiceLayer.PayToCode = model.PayToCode;
				_objServiceLayer.ShipToCode = model.ShipToCode;
				//_objServiceLayer.Address = model.Address;
				//_objServiceLayer.Address2 = model.Address2;
				_objServiceLayer.SalesPersonCode = model.SalesPersonCode;
				_objServiceLayer.Comments = model.Comments;
				_objServiceLayer.DiscountPercent = model.DiscountPercent;
				_objServiceLayer.RoundingDiffAmount = model.RoundingDiffAmount;
				_objServiceLayer.TransportationCode = model.TransportationCode;
				_objServiceLayer.DocumentsOwner = model.DocumentsOwner;
				_objServiceLayer.Comments = model.Comments;
				#endregion

				#region Tax

				//_objServiceLayer.DutyStatus = model.DutyStatus;

				#endregion

				#region UDF
				_objServiceLayer.U_MdTrns = model.U_MdTrns;
				_objServiceLayer.U_PortDischarge = model.U_PortDischarge;
				_objServiceLayer.U_PortLoad = model.U_PortLoad;
				_objServiceLayer.U_INCOTERMS = model.U_INCOTERMS;

				#endregion

				#region Item Rows

				int modelRow = 0;
				List<DocumentRowsModel> modelLines_ServiceLayer = new List<DocumentRowsModel>();
				model.DocumentLines = model.DocumentLines.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
				for (int i = 0; i < model.DocumentLines.Count; i++)
				{
					string treeType = model.DocumentLines[i].TreeType;
					if (treeType == "I")
					{
						continue;
					}
					if (!string.IsNullOrEmpty(model.DocumentLines[i].ItemCode))
					{

						modelLines_ServiceLayer.Add(new DocumentRowsModel { });

						modelLines_ServiceLayer[modelRow].ItemCode = model.DocumentLines[i].ItemCode;
						modelLines_ServiceLayer[modelRow].Quantity = model.DocumentLines[i].Quantity;
						modelLines_ServiceLayer[modelRow].UnitPrice = model.DocumentLines[i].UnitPrice;
						modelLines_ServiceLayer[modelRow].TaxCode = model.DocumentLines[i].TaxCode;
						modelLines_ServiceLayer[modelRow].HSNEntry = model.DocumentLines[i].HSNEntry;
						modelLines_ServiceLayer[modelRow].U_Category = string.IsNullOrEmpty(model.DocumentLines[i].U_Category) ? "1004" : model.DocumentLines[i].U_Category;
						//modelLines_ServiceLayer[modelRow].U_Category =  model.DocumentLines[i].U_Category;
						modelLines_ServiceLayer[modelRow].FreeText = model.DocumentLines[i].FreeText;
						modelLines_ServiceLayer[modelRow].WarehouseCode = model.WarehouseCode;
						modelLines_ServiceLayer[modelRow].U_UnwDrctn = model.DocumentLines[i].U_UnwDrctn;
						modelLines_ServiceLayer[modelRow].U_Packng = model.DocumentLines[i].U_Packng;
						try
						{
							modelLines_ServiceLayer[modelRow].U_CTOL = model.DocumentLines[i].U_CTOL;
						}
						catch { }
						try
						{
							modelLines_ServiceLayer[modelRow].U_CTLOL = model.DocumentLines[i].U_CTLOL;
						}
						catch { }
						try
						{
							DateTime dtShipDate = DateTime.ParseExact(model.DocumentLines[i].ShipDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
							modelLines_ServiceLayer[modelRow].ShipDate = dtShipDate.ToString("yyyyMMdd");
							// modelLines_ServiceLayer[modelRow].ShipDate = dtShipDate.ToString("yyyy-MM-dd");
						}
						catch { }
						try
						{
							if (model.DocumentLines[i].BaseEntry.HasValue)
							{
								modelLines_ServiceLayer[modelRow].BaseEntry = model.DocumentLines[i].BaseEntry;
								modelLines_ServiceLayer[modelRow].BaseLine = model.DocumentLines[i].BaseLine;
								modelLines_ServiceLayer[modelRow].BaseType = 23;
							}
						}
						catch { }
						try
						{
							modelLines_ServiceLayer[modelRow].U_Exp1 = model.DocumentLines[i].U_Exp1;
						}
						catch { }
						try
						{
							modelLines_ServiceLayer[modelRow].U_Exp2 = model.DocumentLines[i].U_Exp2;
						}
						catch { }
						modelRow++;
					}
				}
				#endregion

				#region Freight
				List<DocumentModel_Expenses> model_Expenses_ServiceLayerList = new List<DocumentModel_Expenses>();
				try
				{
					int expenseRow = 0;
					//model.DocumentAdditionalExpenses = model.DocumentAdditionalExpenses.Where(a => a.LineGross > 0).ToList();
					for (int i = 0; i < model.DocumentAdditionalExpenses.Count; i++)
					{
						if (model.DocumentAdditionalExpenses[i].LineGross > 0)
						{
							model_Expenses_ServiceLayerList.Add(new DocumentModel_Expenses { });
							model_Expenses_ServiceLayerList[expenseRow].ExpenseCode = model.DocumentAdditionalExpenses[i].ExpenseCode;
							model_Expenses_ServiceLayerList[expenseRow].TaxCode = model.DocumentAdditionalExpenses[i].TaxCode;
							model_Expenses_ServiceLayerList[expenseRow].LineTotal = model.DocumentAdditionalExpenses[i].LineTotal;
							expenseRow++;

						}

					}
				}
				catch { }
				#endregion

				#region Address Extension
				//AddressModel shipToAddressModel = commonRepository.GetBPAddressDetails(_objServiceLayer.CardCode, "S", _objServiceLayer.ShipToCode);
				//DocumentModel_AddressExtension documentModel_AddressExtension = new DocumentModel_AddressExtension();
				//documentModel_AddressExtension.ShipToStreet = shipToAddressModel.Street;
				//documentModel_AddressExtension.ShipToStreetNo = shipToAddressModel.StreetNo;
				//documentModel_AddressExtension.ShipToAddress2 = shipToAddressModel.Address2;
				//documentModel_AddressExtension.ShipToAddress3 = shipToAddressModel.Address3;
				//documentModel_AddressExtension.ShipToBlock = shipToAddressModel.Block;
				//documentModel_AddressExtension.ShipToCity = shipToAddressModel.City;
				//documentModel_AddressExtension.ShipToZipCode = shipToAddressModel.ZipCode;
				//documentModel_AddressExtension.ShipToCountry = shipToAddressModel.Country;
				//documentModel_AddressExtension.ShipToState = shipToAddressModel.State;

				//AddressModel billToAddressModel = commonRepository.GetBPAddressDetails(_objServiceLayer.CardCode, "B", _objServiceLayer.PayToCode);

				//documentModel_AddressExtension.BillToStreet = billToAddressModel.Street;
				//documentModel_AddressExtension.BillToStreetNo = billToAddressModel.StreetNo;
				//documentModel_AddressExtension.BillToAddress2 = billToAddressModel.Address2;
				//documentModel_AddressExtension.BillToAddress3 = billToAddressModel.Address3;
				//documentModel_AddressExtension.BillToBlock = billToAddressModel.Block;
				//documentModel_AddressExtension.BillToCity = billToAddressModel.City;
				//documentModel_AddressExtension.BillToZipCode = billToAddressModel.ZipCode;
				//documentModel_AddressExtension.BillToState = billToAddressModel.State;
				//documentModel_AddressExtension.BillToCountry = billToAddressModel.Country;
				#endregion

				#region Tax Extension
				DocumentModel_TaxExtension documentModel_TaxExtension = new DocumentModel_TaxExtension();
				if (model.boolImpORExp == true)
				{
					documentModel_TaxExtension.ImportOrExport = "tYES";
					documentModel_TaxExtension.ImportOrExportType = GetImportExportType(model.ExportType);
				}
				else
				{
					documentModel_TaxExtension.ImportOrExport = "tNO";
				}
				//try
				//{
				//	documentModel_TaxExtension.CityB = billToAddressModel.City;
				//	documentModel_TaxExtension.CityS = shipToAddressModel.City;

				//	documentModel_TaxExtension.CountryB = billToAddressModel.Country;
				//	documentModel_TaxExtension.CountryS = shipToAddressModel.Country;

				//	documentModel_TaxExtension.State = shipToAddressModel.State;
				//	documentModel_TaxExtension.StateB = billToAddressModel.State;
				//	documentModel_TaxExtension.StateS = shipToAddressModel.State;

				//	documentModel_TaxExtension.StreetB = billToAddressModel.Street;
				//	documentModel_TaxExtension.StreetS = shipToAddressModel.Street;

				//	documentModel_TaxExtension.ZipCodeB = billToAddressModel.ZipCode;
				//	documentModel_TaxExtension.ZipCodeS = shipToAddressModel.ZipCode;

				//}
				//catch { }
				#endregion


				_objServiceLayer.DocumentLines = modelLines_ServiceLayer;
				_objServiceLayer.DocumentAdditionalExpenses = model_Expenses_ServiceLayerList;
				//_objServiceLayer.AddressExtension = documentModel_AddressExtension;
				_objServiceLayer.TaxExtension = documentModel_TaxExtension;
				string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
				{
					NullValueHandling = NullValueHandling.Ignore,
				});
				string isDraft = "Y";
				string serviceLayerObject = "";
				string seriesremark = commonRepository.GetSeriesRemark(model.Series);
				// || seriesremark.ToUpper().Contains("PROOFING")

				if (seriesremark.ToUpper().Contains("INTERNAL") || model.CardName.ToUpper().Contains("AJANTA PRINT ARTS"))
				//comment by nilam
				//if (slpcode == model.SalesPersonCode || slpname == "SELF" || seriesremark.ToUpper().Contains("INTERNAL"))
				{
					isDraft = "N";
					//serviceLayerObject = ServiceLayerEntity.Orders.ToString();
				}
				serviceLayerObject = ServiceLayerEntity.Drafts.ToString();
				headerTable = CommonTables.DraftHeaderTable;
				rowTable = CommonTables.DraftRowTable;
				addressExtensionTable = CommonTables.DraftAddressTable;
				rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject;
				rc.patchJSON = main;
				rc.B1SESSION = res;
				string message = "";
				bool result = rc.postRequest(out message);
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string docEntry = jobject["DocEntry"].ToString();
					model.DocEntry = docEntry;
					responseModel.ResponseEntry = docEntry;
					string userId = commonRepository.GetUserId(model.UserId);
					//try
					//{
					//	UpdateAddressExtension(addressExtensionTable, docEntry, _objServiceLayer);
					//}
					//catch { }
					//bool anyAttachment = model.Attachments2_Lines.Any(a => a.IsChanged == "Y");
					try
					{
						bool anyNewAttachment = model.Attachments2_Lines.Any(a => a.trgtPath.Contains("wwwroot"));
						if (anyNewAttachment == true)
						{
							Utility utility = new Utility();
							utility.SaveAttachment(res, model.DocEntry, model.AtcEntry, userId, model.Attachments2_Lines, serviceLayerObject);
							//SaveAttachment(res, model, serviceLayerObject);
						}
					}
					catch { }

					commonRepository.UpdateUserSign("Add", headerTable, "DocEntry", docEntry, userId);
					UpdateDutyStatus(headerTable, model.DocEntry, model);
					UpdateItemChildItems(rowTable, model.DocEntry, model.DocumentLines);
					//if (serviceLayerObject == ServiceLayerEntity.Drafts.ToString())
					//{
					//}
					commonRepository.UpdateDocumentItemChildLocation(rowTable, model.DocEntry, model);
					commonRepository.UpdateDocumentItemChildTaxCode(rowTable, model.DocEntry);
					if (isDraft == "N")
					{
						UpdateStatus(model.DocEntry, "Y", userId, res);

						stringBuilder = new StringBuilder();
						stringBuilder.Append(" UPDATE T0 ");
						stringBuilder.Append(" SET T0.\"U_SOEn\" = CASE WHEN IFNULL(T0.\"U_SOEn\",'') ='' THEN Cast(T1.\"DocEntry\" as varchar(100)) || '_'|| Cast(T1.\"LineNum\" as varchar(100))   ");
						stringBuilder.Append(" ELSE T0.\"U_SOEn\" || ','|| Cast(T1.\"DocEntry\" as varchar(100)) || '_'|| Cast(T1.\"LineNum\" as varchar(100))  END ");
						stringBuilder.Append(" ,T0.\"U_SOQty\" = IFNULL(T0.\"U_SOQty\",0) + T1.\"Quantity\" ");
						stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + CommonTables.ClientPORegisterRowTable + "\" T0 ");
						stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"" + CommonTables.SalesOrderRowTable + "\" T1 ON T0.\"DocEntry\" = T1.\"U_Exp1\" AND T0.\"LineId\" = T1.\"U_Exp2\" ");
						stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"" + CommonTables.ItemTable + "\" T2 ON T1.\"ItemCode\" = T2.\"ItemCode\" ");
						stringBuilder.Append(" WHERE T1.\"DocEntry\" = " + docEntry + " AND T2.\"TreeType\" NOT IN ('I') ");
						FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
					}
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during creating " + serviceLayerObject.ToString() + " : " + jsonMessage;
				}
				rc.LogOut();
			}
			else
			{
				responseModel.ResponseText = "Service layer login failed";
			}
			return responseModel;
		}
		public ResponseModel Update(DocumentModel model)
		{
			string headerTable = CommonTables.SalesOrderHeaderTable;
			string rowTable = CommonTables.SalesOrderRowTable;

			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				#region Header

				DocumentModel _objServiceLayer = new DocumentModel();
				//DateTime dtDocDate = Convert.ToDateTime(model.DocDate);

				_objServiceLayer.NumAtCard = model.NumAtCard;
				_objServiceLayer.DocCurrency = model.DocCurrency;
				_objServiceLayer.DocRate = model.DocRate;
				_objServiceLayer.U_CRBY = model.U_CRBY;

				DateTime dtDocDate = DateTime.ParseExact(model.DocDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
				DateTime dtDocDueDate = DateTime.ParseExact(model.DocDueDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
				DateTime dtTaxDate = DateTime.ParseExact(model.TaxDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);

				_objServiceLayer.DocDate = dtDocDate.ToString("yyyyMMdd");
				_objServiceLayer.DocDueDate = dtDocDueDate.ToString("yyyyMMdd");
				_objServiceLayer.TaxDate = dtTaxDate.ToString("yyyyMMdd");

				if (model.Type.ToUpper() == "DRAFT")
				{
					_objServiceLayer.DocDate = DateTime.Now.Date.ToString("yyyyMMdd");
				}
				else
				{
					_objServiceLayer.DocDate = dtDocDate.ToString("yyyyMMdd");
				}

				_objServiceLayer.PayToCode = model.PayToCode;
				_objServiceLayer.ShipToCode = model.ShipToCode;
				//_objServiceLayer.Address = model.Address;
				//_objServiceLayer.Address2 = model.Address2;
				_objServiceLayer.SalesPersonCode = model.SalesPersonCode;
				_objServiceLayer.Comments = model.Comments;
				_objServiceLayer.DiscountPercent = model.DiscountPercent;
				_objServiceLayer.RoundingDiffAmount = model.RoundingDiffAmount;
				_objServiceLayer.TransportationCode = model.TransportationCode;
				_objServiceLayer.DocumentsOwner = model.DocumentsOwner;
				_objServiceLayer.Comments = model.Comments;
				_objServiceLayer.Series = model.Series;
				#endregion

				//#region Tax

				//_objServiceLayer.DutyStatus = model.DutyStatus;

				//#endregion


				#region UDF
				_objServiceLayer.U_MdTrns = model.U_MdTrns;
				_objServiceLayer.U_PortDischarge = model.U_PortDischarge;
				_objServiceLayer.U_PortLoad = model.U_PortLoad;
				_objServiceLayer.U_INCOTERMS = model.U_INCOTERMS;

				#endregion

				#region Item Rows

				int modelRow = 0;
				List<DocumentRowsModel> modelLines_ServiceLayer = new List<DocumentRowsModel>();
				model.DocumentLines = model.DocumentLines.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
				for (int i = 0; i < model.DocumentLines.Count; i++)
				{
					string itemcode = model.DocumentLines[i].ItemCode;
					string treeType = model.DocumentLines[i].TreeType;
					//string lineStatus = model.DocumentLines[i].LineStatus;
					int? lineId = model.DocumentLines[i].LineNum;
					//string baseBOMLine = model.DocumentLines[i].BaseBOMLine;
					//if (treeType == "I")
					//{
					//	continue;
					//}
					//if (model.DocumentLines[i].LineStatus != null && model.DocumentLines[i].LineStatus == "C")
					//{
					//    continue;
					//}
					if (!string.IsNullOrEmpty(itemcode))
					{
						modelLines_ServiceLayer.Add(new DocumentRowsModel { });
						modelLines_ServiceLayer[modelRow].LineNum = lineId;
						modelLines_ServiceLayer[modelRow].ItemCode = model.DocumentLines[i].ItemCode;
						string lineStatus = string.IsNullOrEmpty(model.DocumentLines[i].LineStatus) ? "O" : model.DocumentLines[i].LineStatus;
						modelLines_ServiceLayer[modelRow].LineStatus = lineStatus == "O" ? "bost_Open" : "bost_Close";
						modelLines_ServiceLayer[modelRow].Quantity = model.DocumentLines[i].Quantity;
						modelLines_ServiceLayer[modelRow].UnitPrice = model.DocumentLines[i].UnitPrice == null ? 0 : model.DocumentLines[i].UnitPrice;
						modelLines_ServiceLayer[modelRow].TaxCode = model.DocumentLines[i].TaxCode;
						modelLines_ServiceLayer[modelRow].HSNEntry = model.DocumentLines[i].HSNEntry;
						modelLines_ServiceLayer[modelRow].U_Category = model.DocumentLines[i].U_Category;
						modelLines_ServiceLayer[modelRow].FreeText = model.DocumentLines[i].FreeText;
						modelLines_ServiceLayer[modelRow].WarehouseCode = model.WarehouseCode;
						modelLines_ServiceLayer[modelRow].Total = model.DocumentLines[i].Total;
						modelLines_ServiceLayer[modelRow].U_UnwDrctn = model.DocumentLines[i].U_UnwDrctn;
						modelLines_ServiceLayer[modelRow].U_Packng = model.DocumentLines[i].U_Packng;
						if (treeType == "S")
						{
							treeType = "iSalesTree";
						}
						else if (treeType == "I")
						{
							treeType = "iIngredient";
						}
						else if (treeType == "P")
						{
							treeType = "iProductionTree";
						}
						else if (treeType == "N")
						{
							treeType = "iNotATree";
						}
						if (treeType != string.Empty)
						{
							modelLines_ServiceLayer[modelRow].TreeType = treeType;
						}
						try
						{
							modelLines_ServiceLayer[modelRow].U_CTOL = model.DocumentLines[i].U_CTOL;
						}
						catch { }
						try
						{
							modelLines_ServiceLayer[modelRow].U_CTLOL = model.DocumentLines[i].U_CTLOL;
						}
						catch { }
						try
						{
							DateTime dtShipDate = DateTime.ParseExact(model.DocumentLines[i].ShipDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
							modelLines_ServiceLayer[modelRow].ShipDate = dtShipDate.ToString("yyyyMMdd");
						}
						catch { }
						try
						{
							modelLines_ServiceLayer[modelRow].U_Exp1 = model.DocumentLines[i].U_Exp1;
						}
						catch { }
						try
						{
							modelLines_ServiceLayer[modelRow].U_Exp2 = model.DocumentLines[i].U_Exp2;
						}
						catch { }
						modelRow++;
					}
				}

				#endregion

				#region Freight
				List<DocumentModel_Expenses> model_Expenses_ServiceLayerList = new List<DocumentModel_Expenses>();
				if (model.DocumentAdditionalExpenses != null)
				{
					int expenseRow = 0;
					//model.DocumentAdditionalExpenses = model.DocumentAdditionalExpenses.Where(a => a.LineGross > 0).ToList();
					for (int i = 0; i < model.DocumentAdditionalExpenses.Count; i++)
					{
						if (model.DocumentAdditionalExpenses[i].LineGross > 0)
						{
							model_Expenses_ServiceLayerList.Add(new DocumentModel_Expenses { });
							model_Expenses_ServiceLayerList[expenseRow].ExpenseCode = model.DocumentAdditionalExpenses[i].ExpenseCode;
							model_Expenses_ServiceLayerList[expenseRow].TaxCode = model.DocumentAdditionalExpenses[i].TaxCode;
							model_Expenses_ServiceLayerList[expenseRow].LineTotal = model.DocumentAdditionalExpenses[i].LineTotal;
							expenseRow++;

						}
					}
				}
				_objServiceLayer.DocumentAdditionalExpenses = model_Expenses_ServiceLayerList;
				#endregion

				#region Tax Extension
				DocumentModel_TaxExtension documentModel_TaxExtension = new DocumentModel_TaxExtension();
				if (model.boolImpORExp == true)
				{
					documentModel_TaxExtension.ImportOrExport = "tYES";
					documentModel_TaxExtension.ImportOrExportType = GetImportExportType(model.ExportType);
				}
				else
				{
					documentModel_TaxExtension.ImportOrExport = "tNO";
				}
				_objServiceLayer.TaxExtension = documentModel_TaxExtension;
				#endregion

				#region Address Extension

				//AddressModel shipToAddressModel = commonRepository.GetBPAddressDetails(model.CardCode, "S", model.ShipToCode);
				//DocumentModel_AddressExtension documentModel_AddressExtension = new DocumentModel_AddressExtension();
				//documentModel_AddressExtension.ShipToStreet = shipToAddressModel.Street;
				//documentModel_AddressExtension.ShipToStreetNo = shipToAddressModel.StreetNo;
				//documentModel_AddressExtension.ShipToAddress2 = shipToAddressModel.Address2;
				//documentModel_AddressExtension.ShipToAddress3 = shipToAddressModel.Address3;
				//documentModel_AddressExtension.ShipToStreetNo = shipToAddressModel.StreetNo;
				//documentModel_AddressExtension.ShipToBlock = shipToAddressModel.Block;
				//documentModel_AddressExtension.ShipToCity = shipToAddressModel.City;
				//documentModel_AddressExtension.ShipToZipCode = shipToAddressModel.ZipCode;
				//documentModel_AddressExtension.ShipToCountry = shipToAddressModel.Country;
				//documentModel_AddressExtension.ShipToState = shipToAddressModel.State;
				//documentModel_AddressExtension.ShipToCountry = shipToAddressModel.Country;

				//AddressModel billToAddressModel = commonRepository.GetBPAddressDetails(model.CardCode, "B", model.PayToCode);

				//documentModel_AddressExtension.BillToStreet = billToAddressModel.Street;
				//documentModel_AddressExtension.BillToStreetNo = billToAddressModel.StreetNo;
				//documentModel_AddressExtension.BillToAddress2 = billToAddressModel.Address2;
				//documentModel_AddressExtension.BillToAddress3 = billToAddressModel.Address3;
				//documentModel_AddressExtension.BillToStreetNo = billToAddressModel.StreetNo;
				//documentModel_AddressExtension.BillToBlock = billToAddressModel.Block;
				//documentModel_AddressExtension.BillToCity = billToAddressModel.City;
				//documentModel_AddressExtension.BillToZipCode = billToAddressModel.ZipCode;
				//documentModel_AddressExtension.BillToCountry = billToAddressModel.Country;
				//documentModel_AddressExtension.BillToState = billToAddressModel.State;
				//documentModel_AddressExtension.BillToCountry = billToAddressModel.Country;
				//_objServiceLayer.AddressExtension = documentModel_AddressExtension;

				#endregion


				if (model.ButtonValue.ToLower() == "update")
				{
					_objServiceLayer.DocumentLines = modelLines_ServiceLayer;
				}

				string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
				{
					NullValueHandling = NullValueHandling.Ignore,
				});
				string serviceLayerObject = "";
				if (model.Type.ToUpper() == "DRAFT")
				{
					serviceLayerObject = ServiceLayerEntity.Drafts.ToString();
					headerTable = CommonTables.DraftHeaderTable;
					rowTable = CommonTables.DraftRowTable;
				}
				else
				{
					serviceLayerObject = ServiceLayerEntity.Orders.ToString();
				}
				rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject + "(" + model.DocEntry + ")";
				rc.patchJSON = main;
				rc.B1SESSION = res;
				rc.httpMethod = httpVerb.PATCH;
				string message = "";
				bool result = rc.patchRequest(out message);
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
					ResponseModel attachmentResponseModel = new ResponseModel();
					bool anyNewAttachment = model.Attachments2_Lines.Any(a => a.trgtPath.Contains("wwwroot"));
					string userId = commonRepository.GetUserId(model.UserId);

					if (anyNewAttachment == true)
					{
						Utility utility = new Utility();
						attachmentResponseModel = utility.SaveAttachment(res, model.DocEntry, model.AtcEntry, userId, model.Attachments2_Lines, serviceLayerObject);
					}
					commonRepository.UpdateUserSign("Update", headerTable, "DocEntry", model.DocEntry, userId);
					UpdateDutyStatus(headerTable, model.DocEntry, model);
					UpdateItemChildItems(rowTable, model.DocEntry, model.DocumentLines);
					if (serviceLayerObject == ServiceLayerEntity.Drafts.ToString())
					{
						commonRepository.UpdateDocumentItemChildLocation(rowTable, model.DocEntry, model);
						commonRepository.UpdateDocumentItemChildTaxCode(rowTable, model.DocEntry);
					}
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during process: " + jsonMessage;
				}
				rc.LogOut();
			}
			return responseModel;
		}
		public ResponseModel UpdateStatus(string docEntry, string status, string userId, string res)
		{
			ResponseModel responseModel = new ResponseModel();
			string message = "";
			string query = "";
			try
			{
				List<string> list = new List<string>();
				list = docEntry.Split(',').ToList();
				for (int i = 0; i < list.Count; i++)
				{
					docEntry = list[i].ToString();
					if (status == "Y")
					{
						UpdateDate(docEntry);


						#region If already created then continue
						query = "SELECT \"DocEntry\" FROM  " + ConfigManager.GetSAPDatabase() + ".ORDR WHERE \"draftKey\" = " + docEntry + " ";
						using (DataTable dt = FillDataTable(query, CommandType.Text, out message))
						{
							if (dt.Rows.Count > 0)
							{
								continue;
							}
						}
						#endregion


						#region Update Attachment Entry in Temp field
						query = "SELECT \"AtcEntry\" FROM " + ConfigManager.GetSAPDatabase() + ".ODRF WHERE \"DocEntry\" = " + docEntry + " ";
						string atcEntry = GetRecordValue(query, CommandType.Text, out message);
						if (!string.IsNullOrEmpty(atcEntry))
						{
							query = "UPDATE " + ConfigManager.GetSAPDatabase() + ".ODRF SET \"JrnlMemo\"= " + atcEntry + ", \"AtcEntry\"= NULL WHERE \"DocEntry\" = " + docEntry + " ";
							FillDataTable(query, CommandType.Text, out message);
						}
						#endregion

						responseModel = DraftsService_SaveDraftToDocument(docEntry, res);
						if (responseModel.ResponseStatus == false)
						{
							try
							{
								CommonRepository common = new CommonRepository();
								ErrorLogModel model = new ErrorLogModel();
								model.U_Form = "SO";
								model.U_User = userId;
								model.U_Desc = responseModel.ResponseText;
								common.InsertInLog(model);
							}
							catch { }
							if (!string.IsNullOrEmpty(atcEntry))
							{
								query = "UPDATE " + ConfigManager.GetSAPDatabase() + ".ODRF SET \"JrnlMemo\"= NULL, \"AtcEntry\"= " + atcEntry + " WHERE \"DocEntry\" = " + docEntry + " ";
								FillDataTable(query, CommandType.Text, out message);
							}
							return responseModel;
						}
						else
						{
							if (!string.IsNullOrEmpty(atcEntry))
							{
								query = "UPDATE " + ConfigManager.GetSAPDatabase() + ".ORDR SET \"AtcEntry\"= " + atcEntry + " WHERE \"JrnlMemo\" = '" + atcEntry + "' ";
								FillDataTable(query, CommandType.Text, out message);
							}

							query = "UPDATE " + ConfigManager.GetSAPDatabase() + ".ORDR SET \"U_AppBy\"= '" + userId + "' WHERE \"draftKey\" = " + docEntry + " ";
							FillDataTable(query, CommandType.Text, out message);


							stringBuilder = new StringBuilder();
							stringBuilder.Append(" UPDATE T0 ");
							stringBuilder.Append(" SET T0.\"U_SOEn\" = CASE WHEN IFNULL(T0.\"U_SOEn\",'') ='' THEN Cast(T1.\"DocEntry\" as varchar(100)) || '_'|| Cast(T1.\"LineNum\" as varchar(100))   ");
							stringBuilder.Append(" ELSE T0.\"U_SOEn\" || ','|| Cast(T1.\"DocEntry\" as varchar(100)) || '_'|| Cast(T1.\"LineNum\" as varchar(100))  END ");
							stringBuilder.Append(" ,T0.\"U_SOQty\" = IFNULL(T0.\"U_SOQty\",0) + T1.\"Quantity\" ");
							stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + CommonTables.ClientPORegisterRowTable + "\" T0 ");
							stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"" + CommonTables.SalesOrderRowTable + "\" T1 ON T0.\"DocEntry\" = T1.\"U_Exp1\" AND T0.\"LineId\" = T1.\"U_Exp2\" ");
							stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"" + CommonTables.SalesOrderHeaderTable + "\" T2 ON T1.\"DocEntry\" = T2.\"DocEntry\" ");
							stringBuilder.Append(" WHERE T2.\"draftKey\" = " + docEntry + " ");
							FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
						}
					}

					HanaParameter[] parameters = new HanaParameter[2];
					int iParameter = 0;
					parameters[iParameter] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
					parameters[iParameter].Value = docEntry;
					iParameter++;

					parameters[iParameter] = new HanaParameter("Status", System.Data.SqlDbType.VarChar);
					parameters[iParameter].Value = status;
					iParameter++;

					query = "UPDATE " + ConfigManager.GetSAPDatabase() + ".ODRF SET \"U_IsApp\"= :Status WHERE \"DocEntry\" = :DocEntry ";

					FillDataTable(query, CommandType.Text, out message, parameters);
					if (message == string.Empty)
					{
						responseModel.ResponseStatus = true;
						responseModel.ResponseText = "Operation completed successfully";
					}
					else
					{
						responseModel.ResponseText = "Error occured while processing record " + message;
						responseModel.ResponseStatus = false;
					}
				}
			}
			catch (Exception ex)
			{
				responseModel.ResponseText = "Error occured while processing record " + ex.Message;
				responseModel.ResponseStatus = false;
			}
			return responseModel;
		}
		public ResponseModel UpdateIPAApproval(string docEntry)
		{
			ResponseModel responseModel = new ResponseModel();
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];
				int iParameter = 0;
				parameters[iParameter] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
				parameters[iParameter].Value = docEntry;
				iParameter++;

				string query = "UPDATE " + ConfigManager.GetSAPDatabase() + ".ODRF SET \"U_IPAAppr\"= 'Y' WHERE \"DocEntry\" = :DocEntry ";

				FillDataTable(query, CommandType.Text, out string message, parameters);
				if (message == string.Empty)
				{
					responseModel.ResponseStatus = true;
					responseModel.ResponseText = "Operation completed successfully";
				}
				else
				{
					responseModel.ResponseText = "Error occured while processing record " + message;
					responseModel.ResponseStatus = false;
				}
			}
			catch (Exception ex)
			{
				responseModel.ResponseText = "Error occured while processing record " + ex.Message;
				responseModel.ResponseStatus = false;
			}

			return responseModel;
		}
		public ResponseModel DraftsService_SaveDraftToDocument(string docEntry, string res)
		{
			ResponseModel responseModel = new ResponseModel();

			ServiceLayer rc = new ServiceLayer();
			if (res == string.Empty)
			{
				res = rc.Login();
			}
			DocumentModel_SaveDraftToDocument _objServiceLayer = new DocumentModel_SaveDraftToDocument();
			DraftDocument draftDocument = new DraftDocument();

			draftDocument.DocEntry = docEntry;
			_objServiceLayer.Document = draftDocument;
			string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
			{
				NullValueHandling = NullValueHandling.Ignore,
			});
			rc.endPoint = ConfigManager.GetServiceLayerURL() + "DraftsService_SaveDraftToDocument";
			rc.patchJSON = main;
			rc.B1SESSION = res;
			rc.httpMethod = httpVerb.POST;
			string message = "";
			bool result = rc.postRequest(out message);
			responseModel.ResponseStatus = result;
			if (result == true)
			{
				var jobject = JsonConvert.DeserializeObject<JObject>(message);
				//string sodocEntry = jobject["DocEntry"].ToString();
				responseModel.ResponseText = "Operation completed successfully";
				//responseModel.ResponseEntry = sodocEntry;
			}
			else
			{
				var jobject = JsonConvert.DeserializeObject<JObject>(message);
				string jsonMessage = jobject["error"].ToString();
				jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
				jsonMessage = jobject["message"].ToString();
				jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
				jsonMessage = jobject["value"].ToString();
				responseModel.ResponseText = "Sales Order DocEntry:" + docEntry.ToString() + " Error occured during process: " + jsonMessage;
			}
			return responseModel;
		}
		public void UpdateDate(string docEntry)
		{

			HanaParameter[] parameters = new HanaParameter[2];
			int iParameter = 0;
			parameters[iParameter] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
			parameters[iParameter].Value = docEntry;
			iParameter++;

			parameters[iParameter] = new HanaParameter("DocDate", System.Data.SqlDbType.VarChar);
			parameters[iParameter].Value = DateTime.Now.Date;
			iParameter++;

			string query = "UPDATE " + ConfigManager.GetSAPDatabase() + ".ODRF SET \"DocDate\"= :DocDate WHERE \"DocEntry\" = :DocEntry ";
			FillDataTable(query, CommandType.Text, out string message, parameters);
		}
		public void UpdateItemChildItems(string rowTable, string docEntry, List<DocumentRowsModel> rows)
		{
			rows = rows.Where(a => a.TreeType == "I").ToList();
			for (int i = 0; i < rows.Count; i++)
			{
				// Pravin 18 Dec 23
				HanaParameter[] parameters = new HanaParameter[5];
				int iParameter = 0;
				parameters[iParameter] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
				parameters[iParameter].Value = docEntry;
				iParameter++;

				parameters[iParameter] = new HanaParameter("ItemCode", System.Data.SqlDbType.VarChar);
				parameters[iParameter].Value = rows[i].ItemCode;
				iParameter++;

				parameters[iParameter] = new HanaParameter("U_Category", System.Data.SqlDbType.VarChar);
				parameters[iParameter].Value = rows[i].U_Category == null ? string.Empty : rows[i].U_Category;
				iParameter++;

				parameters[iParameter] = new HanaParameter("U_UnwDrctn", System.Data.SqlDbType.VarChar);
				parameters[iParameter].Value = rows[i].U_UnwDrctn == null ? string.Empty : rows[i].U_UnwDrctn;
				iParameter++;

				parameters[iParameter] = new HanaParameter("U_Packng", System.Data.SqlDbType.VarChar);
				parameters[iParameter].Value = rows[i].U_Packng == (object)DBNull.Value ? string.Empty : rows[i].U_Packng;
				iParameter++;

				string query = "UPDATE " + ConfigManager.GetSAPDatabase() + "." + rowTable + " SET \"U_Category\"= :U_Category,\"U_UnwDrctn\"= :U_UnwDrctn,\"U_Packng\"= :U_Packng WHERE \"DocEntry\" = :DocEntry AND \"ItemCode\" =:ItemCode  ";
				FillDataTable(query, CommandType.Text, out string message, parameters);
			}
		}
		public ResponseModel Close(string docEntry)
		{
			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				DocumentModel_SaveDraftToDocument _objServiceLayer = new DocumentModel_SaveDraftToDocument();
				DraftDocument draftDocument = new DraftDocument();
				draftDocument.DocEntry = docEntry;
				_objServiceLayer.Document = draftDocument;
				string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
				{
					NullValueHandling = NullValueHandling.Ignore,
				});
				rc.endPoint = ConfigManager.GetServiceLayerURL() + ServiceLayerEntity.Orders.ToString() + "(" + docEntry + ")/Close";
				rc.patchJSON = main;
				rc.B1SESSION = res;
				rc.httpMethod = httpVerb.POST;
				string message = "";
				bool result = rc.postRequest(out message);
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during process: " + jsonMessage;
				}
				rc.LogOut();
			}
			return responseModel;
		}
		public ResponseModel Cancel(string docEntry)
		{
			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				DocumentModel_SaveDraftToDocument _objServiceLayer = new DocumentModel_SaveDraftToDocument();
				DraftDocument draftDocument = new DraftDocument();
				draftDocument.DocEntry = docEntry;
				_objServiceLayer.Document = draftDocument;
				string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
				{
					NullValueHandling = NullValueHandling.Ignore,
				});
				rc.endPoint = ConfigManager.GetServiceLayerURL() + ServiceLayerEntity.Orders.ToString() + "(" + docEntry + ")/Cancel";
				rc.patchJSON = main;
				rc.B1SESSION = res;
				rc.httpMethod = httpVerb.POST;
				string message = "";
				bool result = rc.postRequest(out message);
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during process: " + jsonMessage;
				}
				rc.LogOut();
			}
			return responseModel;
		}
		public DocumentModel GetSalesQuotationOpenRows(string sqdocEntry)
		{
			DocumentModel model = new DocumentModel();
			try
			{
				string headerTable = CommonTables.SalesQuotationHeaderTable;
				string rowTable = CommonTables.SalesQuotationRowTable;
				string freightTable = CommonTables.SalesQuotationFreightTable;

				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
				parameters[0].Value = sqdocEntry;

				#region Row

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"VisOrder\" + 1 AS \"Index\",T0.\"LineNum\" AS \"LineId\", T0.\"ItemCode\",T0.\"Dscription\" AS \"ItemName\" ");
				stringBuilder.Append(" ,T0.\"OpenQty\" AS \"Quantity\",T0.\"TreeType\" ");
				stringBuilder.Append(" ,T0.\"SubCatNum\" \"SupplierCatNum\",T0.\"U_Category\",T0.\"FreeTxt\" AS \"FreeText\" ");
				stringBuilder.Append(" ,T0.\"unitMsr\" \"MeasureUnit\",T0.\"WhsCode\" AS \"WarehouseCode\" ");
				stringBuilder.Append(" ,T0.\"TaxCode\",T2.\"Rate\" AS \"TaxRate\",T1.\"ChapterID\" AS \"HSNEntry\",T3.\"ChapterID\" AS \"HSNName\" ");

				stringBuilder.Append(" , CASE WHEN T4.\"DocRate\" = 1 THEN T0.\"PriceBefDi\" ELSE T0.\"Price\"  END AS \"UnitPrice\"  ");
				stringBuilder.Append(" , CASE WHEN T4.\"DocRate\" = 1 THEN T0.\"LineTotal\" ELSE T0.\"TotalFrgn\"  END AS \"Total\" ");


				stringBuilder.Append(" ,TO_VARCHAR(T0.\"ShipDate\", 'DD-MM-YYYY') \"ShipDate\" ");
				stringBuilder.Append(" ,T0.\"DocEntry\" AS \"BaseEntry\",T0.\"LineNum\" AS \"BaseLine\" ");

				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + rowTable + " T0 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OITM T1 ON T0.\"ItemCode\" = T1.\"ItemCode\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OSTC T2 ON T0.\"TaxCode\" = T2.\"Code\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T3 ON T1.\"ChapterID\" = T3.\"AbsEntry\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + "." + headerTable + " T4 ON T0.\"DocEntry\" = T4.\"DocEntry\" ");

				stringBuilder.Append(" WHERE T0.\"DocEntry\" = :DocEntry ");
				stringBuilder.Append(" AND T0.\"OpenQty\" > 0 AND T0.\"LineStatus\" = 'O' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						List<DocumentRowsModel> modelRows = ConvertDatatableToList.ConvertToList<DocumentRowsModel>(datatable);
						model.DocumentLines = modelRows;
						model.WarehouseCode = model.DocumentLines.Select(a => a.WarehouseCode).FirstOrDefault();
						model.NetAmount = model.DocumentLines.Select(a => a.Total).Sum();
					}
				}
				#endregion

				#region Freight

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT  T0.\"ExpnsCode\" AS \"ExpenseCode\",T1.\"ExpnsName\" AS \"ExpenseName\" ");
				stringBuilder.Append(" ,T0.\"TaxCode\", T0.\"LineTotal\", T0.\"VatPrcnt\" AS \"TaxPercent\" ");
				stringBuilder.Append(" ,T0.\"VatSum\" AS \"TaxSum\", T0.\"GrsAmount\" AS \"LineGross\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + freightTable + " T0 ");
				stringBuilder.Append(" RIGHT JOIN " + ConfigManager.GetSAPDatabase() + ".OEXD T1 ON T0.\"ExpnsCode\" = T1.\"ExpnsCode\" AND T0.\"DocEntry\" = :DocEntry ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					List<DocumentModel_Expenses> modelRows = ConvertDatatableToList.ConvertToList<DocumentModel_Expenses>(datatable);
					if (modelRows.Count == 0)
					{
						DocumentModel_Expenses documentModel_Expenses = new DocumentModel_Expenses();
						modelRows.Add(documentModel_Expenses);
					}
					model.DocumentAdditionalExpenses = modelRows;
				}
				#endregion
			}
			catch
			{

			}
			return model;
		}
		private void UpdateDutyStatus(string headerTableName, string docEntry, DocumentModel model)
		{
			HanaParameter[] parameters = new HanaParameter[2];

			parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
			parameters[0].Value = docEntry;

			parameters[1] = new HanaParameter("DutyStatus", System.Data.SqlDbType.VarChar);
			parameters[1].Value = model.DutyStatus;

			//parameters[2] = new HanaParameter("ImpOrExp", System.Data.SqlDbType.VarChar);
			//parameters[2].Value = model.ImpORExp == false ? "N" : "Y";

			//parameters[3] = new HanaParameter("ExportType", System.Data.SqlDbType.VarChar);
			//parameters[3].Value = model.ExportType;

			stringBuilder = new StringBuilder();
			stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + "." + headerTableName + " SET ");
			stringBuilder.Append(" \"DutyStatus\"= :DutyStatus ");
			stringBuilder.Append(" WHERE \"DocEntry\" = :DocEntry ");
			FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters);
		}
		private void UpdateAddressExtension(string headerTableName, string docEntry, DocumentModel model)
		{
			HanaParameter[] parameters = new HanaParameter[1];

			parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
			parameters[0].Value = docEntry;

			stringBuilder = new StringBuilder();
			stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + "." + headerTableName + " SET ");
			stringBuilder.Append(" \"StreetS\"= '" + model.AddressExtension.ShipToStreet + "', ");
			stringBuilder.Append(" \"StreetNoS\"= '" + model.AddressExtension.ShipToStreetNo + "', ");
			stringBuilder.Append(" \"Address2S\"= '" + model.AddressExtension.ShipToAddress2 + "', ");
			stringBuilder.Append(" \"Address3S\"= '" + model.AddressExtension.ShipToAddress3 + "', ");
			stringBuilder.Append(" \"BlockS\"= '" + model.AddressExtension.ShipToBlock + "', ");
			stringBuilder.Append(" \"CityS\"= '" + model.AddressExtension.ShipToCity + "', ");
			stringBuilder.Append(" \"ZipCodeS\"= '" + model.AddressExtension.ShipToZipCode + "', ");
			stringBuilder.Append(" \"CountryS\"= '" + model.AddressExtension.ShipToCountry + "', ");
			stringBuilder.Append(" \"StateS\"= '" + model.AddressExtension.ShipToState + "', ");

			stringBuilder.Append(" \"StreetB\"= '" + model.AddressExtension.BillToStreet + "', ");
			stringBuilder.Append(" \"StreetNoB\"= '" + model.AddressExtension.BillToStreetNo + "', ");
			stringBuilder.Append(" \"Address2B\"= '" + model.AddressExtension.BillToAddress2 + "', ");
			stringBuilder.Append(" \"Address3B\"= '" + model.AddressExtension.BillToAddress3 + "', ");
			stringBuilder.Append(" \"BlockB\"= '" + model.AddressExtension.BillToBlock + "', ");
			stringBuilder.Append(" \"CityB\"= '" + model.AddressExtension.BillToCity + "', ");
			stringBuilder.Append(" \"ZipCodeB\"= '" + model.AddressExtension.BillToZipCode + "', ");
			stringBuilder.Append(" \"CountryB\"= '" + model.AddressExtension.BillToCountry + "', ");
			stringBuilder.Append(" \"StateB\"= '" + model.AddressExtension.BillToState + "' ");
			stringBuilder.Append(" WHERE \"DocEntry\" = :DocEntry ");
			FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters);
		}
		private string GetImportExportType(string value)
		{
			string returnValue = "";
			if (value == "E")
			{
				returnValue = "et_IpmortsOrExports";
			}
			else if (value == "S")
			{
				returnValue = "et_SEZ_Developer";
			}
			else if (value == "U")
			{
				returnValue = "et_SEZ_Unit";
			}
			else if (value == "D")
			{
				returnValue = "et_Deemed_ImportsOrExports";
			}
			return returnValue;
		}
		public DataTable GetSalesOrderReportData(string docEntry)
		{
			HanaParameter[] parameters = new HanaParameter[1];

			parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
			parameters[0].Value = docEntry;

			string query = ConfigManager.GetSAPDatabase() + ".\"Web_Reports_SalesOrder\"";

			return FillDataTable(query, CommandType.StoredProcedure, out string message, parameters);
		}
		public ResponseModel GetPendingAdviceData(string cardcode)
		{
			ResponseModel model = new ResponseModel();
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("@CardCode", System.Data.SqlDbType.VarChar);
				parameters[0].Value = cardcode;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" Select T1.\"U_CCode\", T1.\"U_AcctCode\", T1.\"U_CName\", ");
				stringBuilder.Append(" T1.\"U_TBranch\", DAYS_BETWEEN(T1.\"U_VDate\",Now()) AS \"Days\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@OINCDATA\" T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"@INCDATA1\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
				stringBuilder.Append(" WHERE  ");
				stringBuilder.Append(" DAYS_BETWEEN(T1.\"U_VDate\",Now()) > 15  and T1.\"U_IncEnt\" Is Null   ");
				stringBuilder.Append(" AND T1.\"U_CCode\" = :CardCode  ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						model.ResponseStatus = false;
						model.ResponseText = "Please clear the pending payment advice";
					}
					else
					{
						model.ResponseStatus = true;
					}
				}
			}
			catch
			{

			}
			return model;
		}
		public ResponseModel GetPendingInvoiceData(string cardcode)
		{
			ResponseModel model = new ResponseModel();
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("@CardCode", System.Data.SqlDbType.VarChar);
				parameters[0].Value = cardcode;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" Select T0.\"DocEntry\"");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"OINV\" T0 ");
				stringBuilder.Append(" WHERE T0.\"CANCELED\"='N'  AND IFNULL(T0.\"PaidToDate\",0) <> IFNULL(T0.\"DocTotal\",0) ");
				stringBuilder.Append(" AND DAYS_BETWEEN(T0.\"DocDueDate\",CURRENT_DATE)>30  ");
				stringBuilder.Append(" AND T0.\"CardCode\" = :CardCode  ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						model.ResponseStatus = false;
						model.ResponseText = "You can not add any new SO until previous pending payments are released by client";
					}
					else
					{
						model.ResponseStatus = true;
					}
				}
			}
			catch
			{

			}
			return model;
		}
		public string GetDraftCardCode(string docEntry)
		{
			string cardcode = "";
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];
				int iParameter = 0;
				parameters[iParameter] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
				parameters[iParameter].Value = docEntry;
				iParameter++;

				string query = "SELECT \"CardCode\" FROM " + ConfigManager.GetSAPDatabase() + ".ODRF WHERE \"DocEntry\" = :DocEntry ";

				using (DataTable dt = FillDataTable(query, CommandType.Text, out string message, parameters))
				{
					if (message == string.Empty)
					{
						cardcode = dt.Rows[0][0].ToString();
					}
					else
					{
					}
				}
			}
			catch (Exception ex)
			{
			}
			return cardcode;
		}
		public ValidateModel GetSOItemDetails(string itemcode)
		{
			ValidateModel _list = new ValidateModel();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"QryGroup1\" AS \"QryGrp\",T0.\"U_FLEXO1\"AS \"Flexo\"  ");
				stringBuilder.Append(" ,T0.\"TreeType\" AS \"BOMType\",T1.\"ItmsGrpNam\" AS \"GroupName\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ". OITM T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ". OITB T1 on T1.\"ItmsGrpCod\"= T0.\"ItmsGrpCod\" ");
				stringBuilder.Append(" WHERE T0.\"ItemCode\" = '" + itemcode + "' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToEntity<ValidateModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}

		public ResponseModel UpdateLineStatus(string docEntry, int linenum)
		{
			ResponseModel responseModel = new ResponseModel();
			string res = "";
			ServiceLayer rc = new ServiceLayer();
			res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				DocumentModel_LineStatus_Close _objServiceLayer = new DocumentModel_LineStatus_Close();
				List<DocumentModel_LineStatus_CloseLines> _objServiceLayerLinesList = new List<DocumentModel_LineStatus_CloseLines>();

				DocumentModel_LineStatus_CloseLines _objServiceLayerLines = new DocumentModel_LineStatus_CloseLines();
				_objServiceLayerLines.LineNum = linenum;
				_objServiceLayerLines.LineStatus = "bost_Close";
				_objServiceLayerLinesList.Add(_objServiceLayerLines);
				_objServiceLayer.DocumentLines = _objServiceLayerLinesList;

				string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
				{
					NullValueHandling = NullValueHandling.Ignore,
				});
				rc.endPoint = ConfigManager.GetServiceLayerURL() + ServiceLayerEntity.Orders.ToString() + "(" + docEntry + ")";
				rc.patchJSON = main;
				rc.B1SESSION = res;
				rc.httpMethod = httpVerb.PATCH;
				string message = "";
				bool result = rc.postRequest(out message);
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					//string sodocEntry = jobject["DocEntry"].ToString();
					responseModel.ResponseText = "Operation completed successfully";
					//responseModel.ResponseEntry = sodocEntry;
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Sales Order DocEntry:" + docEntry.ToString() + " Error occured during process: " + jsonMessage;
				}
			}
			return responseModel;
		}
		public int GetOpenDocumentRowCount(string docEntry)
		{
			int count = 0;
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];
				int iParameter = 0;
				parameters[iParameter] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
				parameters[iParameter].Value = docEntry;
				iParameter++;
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT \"DocEntry\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + CommonTables.SalesOrderRowTable + " ");
				stringBuilder.Append(" WHERE \"DocEntry\" = :DocEntry AND \"LineStatus\" ='O' ");
				using (DataTable dt = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					count = dt.Rows.Count;
				}
			}
			catch (Exception ex)
			{
			}
			return count;
		}
	}
}
