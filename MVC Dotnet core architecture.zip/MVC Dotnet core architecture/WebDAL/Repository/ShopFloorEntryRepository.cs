﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sap.Data.Hana;
using WebDAL.Helper;
using WebDAL.Helpers;
using WebDAL.IRepository;
using WebDAL.Models;

namespace WebDAL.Repository
{
	public class ShopFloorEntryRepository : clsDataAccess, IShopFloorEntryRepository
    {
		string query = "";
		CommonRepository commonRepository = new CommonRepository();
		StringBuilder stringBuilder = new StringBuilder();
		public List<ShopFloorEntryModel> GetAll()

		{
			List<ShopFloorEntryModel> _list = new List<ShopFloorEntryModel>();
			try
			{
				string headerTable = CommonTables.ShopFloorEntryHeaderTable;
				string rowTable = CommonTables.ShopFloorEntryRowTable;
				HanaParameter[] parameters = new HanaParameter[1];
			
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT  T0.\"DocEntry\", T0.\"DocNum\",T0.\"U_MCode\", T0.\"U_MName\",TO_NVARCHAR(T0.\"U_DocDt\", 'DD/MM/YYYY')  AS \"U_DocDt\"");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@VCDPM\" T0 ");
                stringBuilder.Append(" ORDER BY Cast(T0.\"DocNum\" as numeric(19,0)) DESC ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<ShopFloorEntryModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}
		public ShopFloorEntryModel Get(string docEntry, string userId)
		{
            ShopFloorEntryModel model = new ShopFloorEntryModel();
			try
			{
                string headerTable = CommonTables.ShopFloorEntryHeaderTable;
                string rowTable = CommonTables.ShopFloorEntryRowTable;

                HanaParameter[] parameters = new HanaParameter[1];
				parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
				parameters[0].Value = docEntry;

                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"U_MCode\", T0.\"U_MName\""); //,T0.\"U_Shift\"
				stringBuilder.Append(" ,T0.\"DocNum\",T0.\"Series\",T1.\"SeriesName\", TO_NVARCHAR(T0.\"U_DocDt\",'DD/MM/YYYY')  AS \"U_DocDt\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@VCDPM\" T0 ");
				stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						model = ConvertDatatableToList.ConvertToEntity<ShopFloorEntryModel>(datatable);
					
					}
				}

				#region Row
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"U_OpType\",T0.\"U_PlanKey\",T0.\"U_StrHour\",T0.\"U_EndHour\" ");
				stringBuilder.Append(" ,T0.\"U_OName\",T0.\"U_OpName\", T0.\"U_OCode\" ,T0.\"U_PlanNo\",T0.\"U_Date\",T0.\"U_IsSplit\",T0.\"U_ICode\" ");
				stringBuilder.Append(" ,T0.\"U_IName\",T0.\"U_AvaQty\",T0.\"U_NoOfCut\",T0.\"U_Qty\",T0.\"U_PQty\",T0.\"U_RjQty\"");
				stringBuilder.Append(" ,T0.\"U_Complete\",T1.\"U_Nwhrs\",T3.\"U_IFP\",T3.\"U_RFP\" ");//
				//stringBuilder.Append(" ,T0.\"U_JobNo\",T1.\"U_JobNm\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@VCDPD\" T0 ");
				stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						List<ShopFloorEntryRowsModel> modelRows = ConvertDatatableToList.ConvertToList<ShopFloorEntryRowsModel>(datatable);
						model.VCDPDCollection = modelRows;
					}
					else
					{
						List<ShopFloorEntryRowsModel> ShopFloorEntryRowsModelList = new List<ShopFloorEntryRowsModel>();
						ShopFloorEntryRowsModel shopFloorEntryRowsModel = new ShopFloorEntryRowsModel();
						shopFloorEntryRowsModel.Index = 1;
						ShopFloorEntryRowsModelList.Add(shopFloorEntryRowsModel);
						model.VCDPDCollection = ShopFloorEntryRowsModelList;

					}
				}
				#endregion
			}
			catch
			{

			}
			return model;
		}
		public ResponseModel Add(ShopFloorEntryModel model)
		{
            string headerTable = CommonTables.ShopFloorEntryHeaderTable;
            string rowTable = CommonTables.ShopFloorEntryRowTable;
			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();

			string slpcode = commonRepository.GetSlpCodeFromEmailAddress(model.UserId);
            ShopFloorEntryModel _objServiceLayer = new ShopFloorEntryModel();

            #region Header
            _objServiceLayer.U_MCode = model.U_MCode;
            _objServiceLayer.U_MName = model.U_MName;
            _objServiceLayer.U_ShftCode = model.U_ShftCode;
            _objServiceLayer.Series = model.Series;
			_objServiceLayer.DocNum = model.DocNum;
			_objServiceLayer.Creator = model.Creator;
			_objServiceLayer.Remark = model.Remark;
			DateTime dtDate = DateTime.ParseExact(model.U_DocDt, "dd-MM-yyyy", CultureInfo.InvariantCulture);
			_objServiceLayer.U_DocDt = dtDate.ToString("yyyyMMdd");
			#endregion

			#region ShopFloor Rows

			int modelRow = 0;
			List<ShopFloorEntryRowsModel> modelLines_ServiceLayer = new List<ShopFloorEntryRowsModel>();
			model.VCDPDCollection = model.VCDPDCollection.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
			for (int i = 0; i < model.VCDPDCollection.Count; i++)
			{
				if (!string.IsNullOrEmpty(model.VCDPDCollection[i].U_OpType))
				{
                    modelLines_ServiceLayer.Add(new ShopFloorEntryRowsModel { });
                    modelLines_ServiceLayer[modelRow].U_OpType = model.VCDPDCollection[i].U_OpType;
					modelLines_ServiceLayer[modelRow].U_PlanKey = model.VCDPDCollection[i].U_PlanKey;
					modelLines_ServiceLayer[modelRow].U_StrHour = model.VCDPDCollection[i].U_StrHour;
					modelLines_ServiceLayer[modelRow].U_EndHour = model.VCDPDCollection[i].U_EndHour;
					modelLines_ServiceLayer[modelRow].U_OpName = model.VCDPDCollection[i].U_OpName;
					modelLines_ServiceLayer[modelRow].U_OCode = model.VCDPDCollection[i].U_OCode;
					modelLines_ServiceLayer[modelRow].U_IsSplit = model.VCDPDCollection[i].U_IsSplit;
					modelLines_ServiceLayer[modelRow].U_ICode = model.VCDPDCollection[i].U_ICode;
					modelLines_ServiceLayer[modelRow].U_IName = model.VCDPDCollection[i].U_IName;
					modelLines_ServiceLayer[modelRow].U_AvaQty = model.VCDPDCollection[i].U_AvaQty;
					modelLines_ServiceLayer[modelRow].U_NoOfCut = model.VCDPDCollection[i].U_NoOfCut;
					modelLines_ServiceLayer[modelRow].U_Qty = model.VCDPDCollection[i].U_Qty;
					modelLines_ServiceLayer[modelRow].U_PQty = model.VCDPDCollection[i].U_PQty;
					modelLines_ServiceLayer[modelRow].U_RjQty = model.VCDPDCollection[i].U_RjQty;
					modelLines_ServiceLayer[modelRow].U_Nwhrs = model.VCDPDCollection[i].U_Nwhrs;
					modelLines_ServiceLayer[modelRow].U_IFP = model.VCDPDCollection[i].U_IFP;
					modelLines_ServiceLayer[modelRow].U_RFP = model.VCDPDCollection[i].U_RFP;
					//modelLines_ServiceLayer[modelRow].U_JobNo = model.VCDPDCollection[i].U_JobNo;
					//modelLines_ServiceLayer[modelRow].U_JobNm = model.VCDPDCollection[i].U_JobNm;
					modelRow++;
				}
			}
			#endregion

			_objServiceLayer.VCDPDCollection = modelLines_ServiceLayer;

			string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
			{
				NullValueHandling = NullValueHandling.Ignore,
			});
			var temp = JsonConvert.DeserializeObject<JObject>(main);

			string serviceLayerObject = "";
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				serviceLayerObject = ServiceLayerEntity.VCDPM.ToString();
				rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject;
				rc.patchJSON = main;
				rc.B1SESSION = res;
				string message = "";
				bool result = rc.postRequest(out message);
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during process: " + jsonMessage;
				}
				rc.LogOut();
			}
			else
			{
				responseModel.ResponseText = "Service layer login failed";
			}
			return responseModel;
		}
		public ResponseModel Update(ShopFloorEntryModel model)
		{
            string headerTable = CommonTables.ShopFloorEntryHeaderTable;
            string rowTable = CommonTables.ShopFloorEntryRowTable;
            string objectType = Convert.ToString((int)ObjectType.StockTransfers);//VCJBSM
			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();

			string slpcode = commonRepository.GetSlpCodeFromEmailAddress(model.UserId);
            ShopFloorEntryModel _objServiceLayer = new ShopFloorEntryModel();

            #region Header
            _objServiceLayer.U_MCode = model.U_MCode;
            _objServiceLayer.U_MName = model.U_MName;
            _objServiceLayer.U_ShftCode = model.U_ShftCode;
            _objServiceLayer.Series = model.Series;
            _objServiceLayer.DocNum = model.DocNum;
            _objServiceLayer.Creator = model.Creator;
            _objServiceLayer.Remark = model.Remark;
            DateTime dtDate = DateTime.ParseExact(model.U_DocDt, "dd-MM-yyyy", CultureInfo.InvariantCulture);
            _objServiceLayer.U_DocDt = dtDate.ToString("yyyyMMdd");
            #endregion

            #region ShopFloor Rows

            int modelRow = 0;
            List<ShopFloorEntryRowsModel> modelLines_ServiceLayer = new List<ShopFloorEntryRowsModel>();
            model.VCDPDCollection = model.VCDPDCollection.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
            for (int i = 0; i < model.VCDPDCollection.Count; i++)
            {
                if (!string.IsNullOrEmpty(model.VCDPDCollection[i].U_OpType))
                {
                    modelLines_ServiceLayer.Add(new ShopFloorEntryRowsModel { });
                    modelLines_ServiceLayer[modelRow].U_OpType = model.VCDPDCollection[i].U_OpType;
                    modelLines_ServiceLayer[modelRow].U_PlanKey = model.VCDPDCollection[i].U_PlanKey;
                    modelLines_ServiceLayer[modelRow].U_StrHour = model.VCDPDCollection[i].U_StrHour;
                    modelLines_ServiceLayer[modelRow].U_EndHour = model.VCDPDCollection[i].U_EndHour;
                    modelLines_ServiceLayer[modelRow].U_OpName = model.VCDPDCollection[i].U_OpName;
                    modelLines_ServiceLayer[modelRow].U_OCode = model.VCDPDCollection[i].U_OCode;
                    modelLines_ServiceLayer[modelRow].U_IsSplit = model.VCDPDCollection[i].U_IsSplit;
                    modelLines_ServiceLayer[modelRow].U_ICode = model.VCDPDCollection[i].U_ICode;
                    modelLines_ServiceLayer[modelRow].U_IName = model.VCDPDCollection[i].U_IName;
                    modelLines_ServiceLayer[modelRow].U_AvaQty = model.VCDPDCollection[i].U_AvaQty;
                    modelLines_ServiceLayer[modelRow].U_NoOfCut = model.VCDPDCollection[i].U_NoOfCut;
                    modelLines_ServiceLayer[modelRow].U_Qty = model.VCDPDCollection[i].U_Qty;
                    modelLines_ServiceLayer[modelRow].U_PQty = model.VCDPDCollection[i].U_PQty;
                    modelLines_ServiceLayer[modelRow].U_RjQty = model.VCDPDCollection[i].U_RjQty;
                    //modelLines_ServiceLayer[modelRow].U_Complete = model.VCDPDCollection[i].U_Complete;
                    modelLines_ServiceLayer[modelRow].U_Nwhrs = model.VCDPDCollection[i].U_Nwhrs;
                    modelLines_ServiceLayer[modelRow].U_IFP = model.VCDPDCollection[i].U_IFP;
                    modelLines_ServiceLayer[modelRow].U_RFP = model.VCDPDCollection[i].U_RFP;
					//modelLines_ServiceLayer[modelRow].U_JobNo = model.VCDPDCollection[i].U_JobNo;
					//modelLines_ServiceLayer[modelRow].U_JobNm = model.VCDPDCollection[i].U_JobNm;
					modelRow++;
                }
            }
            #endregion


            _objServiceLayer.VCDPDCollection = modelLines_ServiceLayer;

            string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
			{
				NullValueHandling = NullValueHandling.Ignore,
			});
			var temp = JsonConvert.DeserializeObject<JObject>(main);

			string serviceLayerObject = "";
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				//serviceLayerObject = ServiceLayerEntity.Drafts.ToString();
                //rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject + "(" + model.DocEntry + ")";
                serviceLayerObject = ServiceLayerEntity.VCDPM.ToString();
                rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject + "(" + model.DocNum + ")";
                rc.patchJSON = main;
				rc.B1SESSION = res;
				string message = "";
				bool result = rc.postRequest(out message);
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string docEntry = jobject["DocEntry"].ToString();
					//model.DocEntry = docEntry;
					//responseModel.ResponseEntry = docEntry;
					//commonRepository.UpdateUserSign("Update", headerTable, "DocEntry", docEntry, model.OriginatorId);
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during process: " + jsonMessage;
				}
				rc.LogOut();
			}
			else
			{
				responseModel.ResponseText = "Service layer login failed";
			}
			return responseModel;
		}
        public List<PlanKeyModel> GetPlanKey(string mcode)
        {
            List<PlanKeyModel> _list = new List<PlanKeyModel>();
			try
			{

                stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T1.\"U_PLANNO\" as \"PlanNo\",T1.\"U_Qty\" AS \"Qty\" "); 
                stringBuilder.Append(" ,(SELECT S0.\"SeriesName\" FROM " + ConfigManager.GetSAPDatabase() + ".NNM1 S0 WHERE S0.\"Series\"=T0.\"Series\")||'\\'||T0.\"DocNum\" AS \"JobSeqNo\" ");
				stringBuilder.Append(" ,T0.\"U_DocDt\" AS \"Date\",T1.\"U_OPCode\" AS \"Operation\" ");
				stringBuilder.Append(" ,(SELECT \"DocNum\" FROM " + ConfigManager.GetSAPDatabase() + ".\"@VCPPM\" A1 WHERE A1.\"DocEntry\"=T1.\"U_PLANNO\" ) AS \"JobNo\"");
				stringBuilder.Append(" ,(SELECT \"U_JOBNAME\" FROM " + ConfigManager.GetSAPDatabase() + ".\"@VCPPM\" A1 WHERE A1.\"DocEntry\"=T1.\"U_PLANNO\" ) AS \"JobName\"");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@VCJBSM\" T0");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"@VCJBSD\" T1 ON T0.\"DocEntry\"=T1.\"DocEntry\"");
				//stringBuilder.Append(" WHERE DAYS_BETWEEN(T0.\"U_DocDt\",$[\"@VCDPM\".\"U_DocDt\".date]) < 3 AND T0.\"U_MCode\"= $[\"@VCDPM\".\"U_MCode\"]");
				//stringBuilder.Append(" WHERE DAYS_BETWEEN (T0.\"U_DocDt\" ," + ConfigManager.GetSAPDatabase() + ".\"@VCDPM\".\"U_DocDt\".date) < 3 AND T0.\"U_MCode\"= '" + mcode + "'");
				stringBuilder.Append(" WHERE (T1.\"U_PLANNO\" IN(SELECT S0.\"DocEntry\" FROM " + ConfigManager.GetSAPDatabase() + ".\"@VCPPD1\" S0");
				stringBuilder.Append(" LEFT OUTER JOIN " + ConfigManager.GetSAPDatabase() + ".\"@VCDPD\" S1 ON S0.\"DocEntry\"=S1.\"U_PlanKey\" ");
				stringBuilder.Append(" LEFT OUTER JOIN " + ConfigManager.GetSAPDatabase() + ".\"@VCDPM\" S2 ON S1.\"DocEntry\"=S2.\"DocEntry\" AND S0.\"U_MCode\"= S2.\"U_MCode\"");
				stringBuilder.Append(" WHERE S1.\"U_LSts\"='Y' AND (S0.\"LineId\" IN (SELECT S10.\"LineId\" -1 FROM " + ConfigManager.GetSAPDatabase() + ".\"@VCPPD1\" S10 WHERE S10.\"U_MCode\"= '" + mcode + "' ");
				stringBuilder.Append(" AND S10.\"DocEntry\"=S0.\"DocEntry\" and (S10.\"LineId\")>1))) OR ");
				stringBuilder.Append(" T1.\"U_PLANNO\" IN(SELECT Distinct S0.\"DocEntry\" FROM " + ConfigManager.GetSAPDatabase() + ".\"@VCPPD1\" S0 ");
				stringBuilder.Append(" LEFT OUTER JOIN " + ConfigManager.GetSAPDatabase() + ".\"@VCDPD\" S1 ON S0.\"DocEntry\"=S1.\"U_PlanKey\"  ");
				stringBuilder.Append(" LEFT OUTER JOIN " + ConfigManager.GetSAPDatabase() + ".\"@VCDPM\" S2 ON S1.\"DocEntry\"=S2.\"DocEntry\" AND S0.\"U_MCode\"=S2.\"U_MCode\" ");
				stringBuilder.Append(" WHERE (S0.\"LineId\" IN (SELECT S10.\"LineId\" FROM " + ConfigManager.GetSAPDatabase() + ".\"@VCPPD1\" S10 WHERE S10.\"U_MCode\" = '" + mcode + "' AND S10.\"DocEntry\"=S0.\"DocEntry\" AND (S10.\"LineId\")=1)))) ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<PlanKeyModel>(datatable);
				}
			}
			catch
			{

			}
            return _list;
        }
    }
}