﻿using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Sap.Data.Hana;
using System.Text;

namespace WebDAL.Repository
{
	public class DashboardRepository : clsDataAccess, IDashboardRepository
	{
		StringBuilder stringBuilder = new StringBuilder();

		public List<PendingForApprovalModel> GetPendingForApprovalSalesOrder(string userId)
		{
			List<PendingForApprovalModel> _list = new List<PendingForApprovalModel>();
			try
			{
				CommonRepository commonRepository = new CommonRepository();
				string slpcode = commonRepository.GetSlpCodeFromEmailAddress(userId);

				HanaParameter[] parameters = new HanaParameter[1];
				parameters[0] = new HanaParameter("UserId", SqlDbType.VarChar);
				parameters[0].Value = slpcode;
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT \"DocEntry\", \"DocNum\",TO_NVARCHAR(\"DocDate\", 'DD/MM/YYYY')  AS \"DocDate\" ,\"CardName\" ");
				stringBuilder.Append(" ,CASE WHEN \"DocStatus\" = 'O' THEN 'Open' ELSE 'Closed' END AS \"DocStatus\"");
				stringBuilder.Append(" ,CASE WHEN \"DocType\" = 'I' THEN 'Item' ELSE 'Service' END AS \"VoucherType\"");
				stringBuilder.Append(" ,\"Comments\"  ");
				stringBuilder.Append(" ,\"NumAtCard\", T0.\"VatSum\" ,T0.\"DocTotal\" ");
				stringBuilder.Append(" ,T0.\"SlpCode\" AS \"SalesPersonCode\"  ");
				stringBuilder.Append(" ,T1.\"SlpName\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".ODRF T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OSLP T1 ON T0.\"SlpCode\"=T1.\"SlpCode\" ");
				stringBuilder.Append(" WHERE T0.\"SlpCode\" = :UserId AND \"ObjType\" = '" + (int)ObjectType.Orders + "' ");
				stringBuilder.Append(" AND T0.\"DocStatus\" = 'O' AND  T0.\"U_IsApp\" IS NULL ");
				stringBuilder.Append(" AND T0.\"DocDate\" >'2024-01-01' ");
				stringBuilder.Append(" ORDER BY \"DocEntry\" DESC ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					_list = ConvertDatatableToList.ConvertToList<PendingForApprovalModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}

		public List<PendingForApprovalModel> GetPendingForApprovalSalesQuotation(string userId)
		{
			List<PendingForApprovalModel> _list = new List<PendingForApprovalModel>();
			try
			{
				CommonRepository commonRepository = new CommonRepository();
				string slpcode = commonRepository.GetSlpCodeFromEmailAddress(userId);

				HanaParameter[] parameters = new HanaParameter[1];
				parameters[0] = new HanaParameter("UserId", SqlDbType.VarChar);
				parameters[0].Value = slpcode;
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT \"DocEntry\", \"DocNum\",TO_NVARCHAR(\"DocDate\", 'DD/MM/YYYY')  AS \"DocDate\" ,\"CardName\" ");
				stringBuilder.Append(" ,CASE WHEN \"DocStatus\" = 'O' THEN 'Open' ELSE 'Closed' END AS \"DocStatus\"");
				stringBuilder.Append(" ,\"Comments\"  ");
				stringBuilder.Append(" ,\"NumAtCard\"  ");
				stringBuilder.Append(" ,T0.\"SlpCode\" AS \"SalesPersonCode\"  ");
				stringBuilder.Append(" ,T1.\"SlpName\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".ODRF T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OSLP T1 ON T0.\"SlpCode\"=T1.\"SlpCode\" ");
				stringBuilder.Append(" WHERE T0.\"SlpCode\" = :UserId AND \"ObjType\" = '" + (int)ObjectType.Quotations + "' ");
				stringBuilder.Append(" AND T0.\"DocStatus\" = 'O' AND  T0.\"U_IsApp\" IS NULL ");
				stringBuilder.Append(" ORDER BY \"DocEntry\" DESC ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					_list = ConvertDatatableToList.ConvertToList<PendingForApprovalModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}

		public List<PendingForApprovalItemModel> GetDraftSalesOrderItems(string docEntry)
		{
			List<PendingForApprovalItemModel> _list = new List<PendingForApprovalItemModel>();
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];
				parameters[0] = new HanaParameter("DocEntry", SqlDbType.VarChar);
				parameters[0].Value = docEntry == null ? string.Empty : docEntry;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"ItemCode\",T0.\"Dscription\",T0.\"Quantity\" ,TO_NVARCHAR(\"ShipDate\", 'DD/MM/YYYY') AS \"ShipDate\"");
				stringBuilder.Append(" ,T0.\"Price\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".DRF1 T0 ");
				stringBuilder.Append(" WHERE T0.\"DocEntry\" = :DocEntry ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					_list = ConvertDatatableToList.ConvertToList<PendingForApprovalItemModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}

		public int GetOpenSOCount()
		{
			int count = 0;
			try
			{
				CommonRepository commonRepository = new CommonRepository();

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT Count(\"DocEntry\") \"Cnt\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".ORDR T0 ");
				stringBuilder.Append(" WHERE T0.\"DocStatus\" = 'O' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						count = int.Parse(datatable.Rows[0][0].ToString());
					}
				}
			}
			catch
			{

			}
			return count;
		}

		public List<PendingForApprovalItemModel> GetDraftSalesQuatationItems(string docEntry)
		{
			List<PendingForApprovalItemModel> _list = new List<PendingForApprovalItemModel>();
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];
				parameters[0] = new HanaParameter("DocEntry", SqlDbType.VarChar);
				parameters[0].Value = docEntry == null ? string.Empty : docEntry;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"ItemCode\",T0.\"Dscription\",T0.\"Quantity\" ,TO_NVARCHAR(\"ShipDate\", 'DD/MM/YYYY') AS \"ShipDate\"");
				stringBuilder.Append(" ,T0.\"Price\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".DRF1 T0 ");
				stringBuilder.Append(" WHERE T0.\"DocEntry\" = :DocEntry ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					_list = ConvertDatatableToList.ConvertToList<PendingForApprovalItemModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}

		public int GetOpenSQCount()
		{
			int count = 0;
			try
			{
				CommonRepository commonRepository = new CommonRepository();

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT Count(\"DocEntry\") \"Cnt\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OQUT T0 ");
				stringBuilder.Append(" WHERE T0.\"DocStatus\" = 'O' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						count = int.Parse(datatable.Rows[0][0].ToString());
					}
				}
			}
			catch
			{

			}
			return count;
		}

	}
}