﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
//using Microsoft.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sap.Data.Hana;
using WebDAL.Helper;
using WebDAL.Helpers;
using WebDAL.IRepository;
using WebDAL.Models;
using static WebDAL.Models.PPCDetailsModel;
using static WebDAL.Models.PrepressModel;

namespace WebDAL.Repository
{
    public class PPCDetailsRepository : clsDataAccess, IPPCDetailsRepository
    {
        CommonRepository commonRepository = new CommonRepository();
        StringBuilder stringBuilder = new StringBuilder();
        string rowTable = CommonTables.PPCDetailsInkTable;

        public List<PPCDetailsRowModel> GetAllPPCDetails(string sono, string branch,string itemcode, out DataTable dataTable)
        {
            dataTable = new DataTable();
            List<PPCDetailsRowModel> _list = new List<PPCDetailsRowModel>();
            try
            {
                HanaParameter[] parameters = new HanaParameter[4];
                parameters[0] = new HanaParameter("Type", SqlDbType.VarChar);
                parameters[0].Value = "C";

                parameters[1] = new HanaParameter("SONo", SqlDbType.VarChar);
                parameters[1].Value = string.IsNullOrEmpty(sono) ? string.Empty : sono;

                parameters[2] = new HanaParameter("Branch", SqlDbType.VarChar);
                parameters[2].Value = string.IsNullOrEmpty(branch) ? string.Empty : branch;

                parameters[3] = new HanaParameter("ItemCode", SqlDbType.VarChar);
                parameters[3].Value = string.IsNullOrEmpty(itemcode) ? string.Empty : itemcode.Replace("\t","");

                string query = ConfigManager.GetSAPDatabase() + ".\"Web_PPCDetails\"";
                using (dataTable = FillDataTable(query, CommandType.StoredProcedure, out string message, parameters))
                {
                    _list = ConvertDatatableToList.ConvertToList<PPCDetailsRowModel>(dataTable);
                }
            }
            catch
            {
            }
            return _list;
        }

        public List<PPCDetailsRowModel> GetMachinePlanning(string sono, string branch, string itemcode, out DataTable dataTable)
        {
            dataTable = new DataTable();
            List<PPCDetailsRowModel> _list = new List<PPCDetailsRowModel>();
            try
            {
                HanaParameter[] parameters = new HanaParameter[4];
                parameters[0] = new HanaParameter("Type", SqlDbType.VarChar);
                parameters[0].Value = "C";

                parameters[1] = new HanaParameter("SONo", SqlDbType.VarChar);
                parameters[1].Value = string.IsNullOrEmpty(sono) ? string.Empty : sono;

                parameters[2] = new HanaParameter("Branch", SqlDbType.VarChar);
                parameters[2].Value = string.IsNullOrEmpty(branch) ? string.Empty : branch;

                parameters[3] = new HanaParameter("ItemCode", SqlDbType.VarChar);
                parameters[3].Value = string.IsNullOrEmpty(itemcode) ? string.Empty : itemcode.Replace("\t", "");

                string query = ConfigManager.GetSAPDatabase() + ".\"Web_PPCDetails_MachinePlanning\"";
                using (dataTable = FillDataTable(query, CommandType.StoredProcedure, out string message, parameters))
                {
                    _list = ConvertDatatableToList.ConvertToList<PPCDetailsRowModel>(dataTable);
                }
            }
            catch
            {
            }
            return _list;
        }

        public ResponseModel UpdateDispatchDate1(string itemcode, string date)
        {
            string message = "";
            ResponseModel responseModel = new ResponseModel();

            stringBuilder = new StringBuilder();
            stringBuilder.Append(" SELECT \"U_ItemCode\"  FROM   " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PPCDETAILS\" WHERE \"U_ItemCode\" = '" + itemcode + "' ");
            DataTable dt = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (dt.Rows.Count == 0)
            {
                string code = "";
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" Select cast(max((TO_NUMBER(T0.\"Code\")))+1 as nvarchar(50)) AS \"Code\"   from " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PPCDETAILS\" T0 ");
                DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
                if (datatable.Rows.Count > 0)
                {
                    code = datatable.Rows[0][0].ToString();
                    if (code == string.Empty)
                    {
                        code = "1";
                    }
                }
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" INSERT INTO  " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PPCDETAILS\"(\"Code\",\"Name\",\"U_ItemCode\" ");
                stringBuilder.Append(" ,\"U_DispatchDt1\"");
                stringBuilder.Append("  ) ");
                stringBuilder.Append(" VALUES('" + code + "','" + code + "','" + itemcode + "' ");
                stringBuilder.Append(" ,'" + DateTime.ParseExact(date, "dd-MM-yyyy", CultureInfo.InvariantCulture).ToString("yyyyMMdd") + "' ");
                //stringBuilder.Append(" ,'" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "' ");
                stringBuilder.Append("  ) ");
                FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
                if (message == string.Empty)
                {
                    responseModel.ResponseText = "Operation completed successfully";
                    responseModel.ResponseStatus = true;
                }
                else
                {
                    responseModel.ResponseText = "Error occured during process: " + message;
                }
            }
            else
            {
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PPCDETAILS\" SET ");
                stringBuilder.Append(" \"U_DispatchDt1\"= '" + DateTime.ParseExact(date, "dd-MM-yyyy", CultureInfo.InvariantCulture).ToString("yyyyMMdd") + "' ");
                stringBuilder.Append(" WHERE \"U_ItemCode\" = '" + itemcode + "' ");
                FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
                if (message == string.Empty)
                {
                    responseModel.ResponseStatus = true;
                    responseModel.ResponseText = "Updated successfully";
                }
                else
                {
                    responseModel.ResponseStatus = false;
                    responseModel.ResponseText = "Error occured during process: " + message;
                }
            }
            return responseModel;
        }

        public ResponseModel UpdateDispatchDate2(string itemcode, string date)
        {
            string message = "";
            ResponseModel responseModel = new ResponseModel();

            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PPCDETAILS\" SET ");
            stringBuilder.Append(" \"U_DispatchDt2\"= '" + DateTime.ParseExact(date, "dd-MM-yyyy", CultureInfo.InvariantCulture).ToString("yyyyMMdd") + "' ");
            stringBuilder.Append(" WHERE \"U_ItemCode\" = '" + itemcode + "' ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (message == string.Empty)
            {
                responseModel.ResponseStatus = true;
                responseModel.ResponseText = "Updated successfully";
            }
            else
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            return responseModel;
        }

        public ResponseModel UpdateDispatchDate3(string itemcode, string date)
        {
            string message = "";
            ResponseModel responseModel = new ResponseModel();

            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PPCDETAILS\" SET ");
            stringBuilder.Append(" \"U_DispatchDt3\"= '" + DateTime.ParseExact(date, "dd-MM-yyyy", CultureInfo.InvariantCulture).ToString("yyyyMMdd") + "' ");
            stringBuilder.Append(" WHERE \"U_ItemCode\" = '" + itemcode + "' ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (message == string.Empty)
            {
                responseModel.ResponseStatus = true;
                responseModel.ResponseText = "Updated successfully";
            }
            else
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            return responseModel;
        }

        public List<PPCDetailsInkDetailsModel> GetBOMInkDetails(string itemcode, string group)
        {
            List<PPCDetailsInkDetailsModel> _list = new List<PPCDetailsInkDetailsModel>();
            try
            {
                _list = GetInkDetails(itemcode, group);
                if (_list.Count == 0)
                {
                    stringBuilder = new StringBuilder();
                    stringBuilder.Append(" SELECT T0.\"Father\", T1.\"ItemCode\" ,T1.\"ItemName\",'" + group + "' AS \"MasterGroup\"  ");
                    stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".ITT1 T0 ");
                    stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OITM T1 ON T0.\"Code\" = T1.\"ItemCode\" ");
                    stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OITB T2 ON T1.\"ItmsGrpCod\" = T2.\"ItmsGrpCod\" ");
                    //stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OITM T3 ON T0.\"Father\" = T3.\"ItemCode\" ");
                    //stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OITB T4 ON T3.\"ItmsGrpCod\" = T4.\"ItmsGrpCod\" ");
                    stringBuilder.Append(" WHERE T0.\"Father\"  = '" + itemcode + "' ");
                    if (group == "I")
                    {
                        stringBuilder.Append(" AND UPPER(T2.\"ItmsGrpNam\") LIKE 'INK%' ");

                        //    stringBuilder.Append(" WHERE T2.\"U_MASTGROUP\"  = '" + group + "' ");
                    }
                    else if (group == "V")
                    {
                        stringBuilder.Append(" AND T2.\"ItmsGrpNam\" = 'Coating' ");
                    }
                    else if (group == "R")
                    {
                        stringBuilder.Append(" AND T2.\"ItmsGrpNam\" IN ('Board - Grey Back','Board - White Back','Board - FBB','Board - Others','Paper - Art Paper'  ");
                        stringBuilder.Append(" ,'Paper - Maplitho Pap','Paper - Others','PVC Sheets','IML (Inmould Label)','PP Sheets' ");
                        stringBuilder.Append(" ,'Gumming Sheets','Sticker Sheets','PlayCard RM - PP','PlayCard RM - Board','Jobwork (lab) Sheet' ");
                        stringBuilder.Append(" ,'Other Pack Mat Sheet','Board - Artcard','IML(Inmould Roll)','Paper - Roll','PET Sheets' ");
                        stringBuilder.Append(" ,'Board - Roll','PET Roll','MET - PET - Board','PRNT- Corrug Sheet','GUMMING SHEET ( ROLL ) FLEXO' ");
                        stringBuilder.Append(" ,'PC PRINTED SHEET','GUMMING SHEET - ROLL','PP/PVC Roll') ");
                    }
                    else if (group == "C")
                    {
                        stringBuilder.Append(" AND T2.\"ItmsGrpNam\" = 'Corrugation Box' ");
                    }
                    else if (group == "L")
                    {
                        stringBuilder.Append(" AND T2.\"ItmsGrpNam\" = 'Lamination Film' ");
                    }
                    using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                    {
                        _list = ConvertDatatableToList.ConvertToList<PPCDetailsInkDetailsModel>(datatable);
                        if (_list.Count > 0)
                        {
                            UpdateInkDetails(_list);
                        }
                    }
                }
            }
            catch
            {

            }
            return _list;
        }

        public List<PPCDetailsInkDetailsModel> GetInkDetails(string itemcode,string group)
        {
            List<PPCDetailsInkDetailsModel> _list = new List<PPCDetailsInkDetailsModel>();
            try
            {
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"U_Father\" AS \"Father\",T0.\"U_ItemCode\" AS \"ItemCode\" ");
                stringBuilder.Append(" ,T1.\"ItemName\" ,T0.\"U_MasterGroup\" AS \"U_MasterGroup\",IFNULL(T0.\"U_InActive\",'N') AS \"InActive\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + rowTable + "\" T0  ");
                stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"" + CommonTables.ItemTable + "\" T1 ON T0.\"U_ItemCode\" = T1.\"ItemCode\"  ");
                stringBuilder.Append(" WHERE T0.\"U_Father\" ='" + itemcode + "' ");
                stringBuilder.Append(" AND T0.\"U_MasterGroup\" ='" + group + "' ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    _list = ConvertDatatableToList.ConvertToList<PPCDetailsInkDetailsModel>(datatable);
                }
            }
            catch
            {

            }
            return _list;
        }


        public ResponseModel UpdateInkDetails(List<PPCDetailsInkDetailsModel> lists)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                stringBuilder = new StringBuilder();
                stringBuilder.Append("DELETE FROM " + ConfigManager.GetSAPDatabase() + ".\"" + rowTable + "\" WHERE \"U_Father\" ='" + lists[0].Father + "' AND \"U_MasterGroup\" ='" + lists[0].MasterGroup + "' ");
                GetRecordValue(stringBuilder.ToString(), CommandType.Text, out string message);
                for (int i = 0; i < lists.Count; i++)
                {
                    stringBuilder = new StringBuilder();
                    stringBuilder.Append("SELECT IFNULL(MAX(Cast(\"Code\" as NUMERIC(19,0))),0) + 1   FROM " + ConfigManager.GetSAPDatabase() + ".\"" + rowTable + "\" ");
                    string code = GetRecordValue(stringBuilder.ToString(), CommandType.Text, out message);

                    HanaParameter[] parameters = new HanaParameter[6];
                    int iParameter = 0;

                    parameters[iParameter] = new HanaParameter("Code", System.Data.SqlDbType.VarChar);
                    parameters[iParameter].Value = code;
                    iParameter++;

                    parameters[iParameter] = new HanaParameter("Name", System.Data.SqlDbType.VarChar);
                    parameters[iParameter].Value = code;
                    iParameter++;

                    parameters[iParameter] = new HanaParameter("U_Father", System.Data.SqlDbType.VarChar);
                    parameters[iParameter].Value = lists[i].Father == null ? (Object)DBNull.Value : lists[i].Father;
                    iParameter++;

                    parameters[iParameter] = new HanaParameter("U_ItemCode", System.Data.SqlDbType.VarChar);
                    parameters[iParameter].Value = lists[i].ItemCode == null ? (Object)DBNull.Value : lists[i].ItemCode;
                    iParameter++;

                    parameters[iParameter] = new HanaParameter("U_MasterGroup", System.Data.SqlDbType.VarChar);
                    parameters[iParameter].Value = lists[i].MasterGroup == null ? (Object)DBNull.Value : lists[i].MasterGroup;
                    iParameter++;

                    parameters[iParameter] = new HanaParameter("U_InActive", System.Data.SqlDbType.VarChar);
                    parameters[iParameter].Value = lists[i].InActive == null ? (Object)DBNull.Value : lists[i].InActive;
                    iParameter++;

                    stringBuilder = new StringBuilder();
                    stringBuilder.Append(" INSERT INTO " + ConfigManager.GetSAPDatabase() + ".\"" + rowTable + "\"");
                    stringBuilder.Append(" (\"Code\",\"Name\",\"U_Father\",\"U_ItemCode\",\"U_MasterGroup\",\"U_InActive\") ");
                    stringBuilder.Append(" VALUES ");
                    stringBuilder.Append(" (:Code,:Name,:U_Father ,:U_ItemCode,:U_MasterGroup,:U_InActive) ");
                    DataTable dt = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message, parameters);
                    if (message == string.Empty)
                    {
                        responseModel.ResponseText = "Record inserted successfully";
                        responseModel.ResponseStatus = true;
                    }
                    else
                    {
                        responseModel.ResponseText = "Error occured while processing record " + message;
                        responseModel.ResponseStatus = false;
                    }
                }
            }
            catch
            {

            }
            return responseModel;
        }

        public ResponseModel UpdateDate(string itemcode, string columnName)
        {
            string message = "";
            ResponseModel responseModel = new ResponseModel();
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PPCDETAILS\" SET ");
            stringBuilder.Append(" \"" + columnName + "\"= '" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "'  ");
            stringBuilder.Append(" WHERE \"U_ItemCode\" = '" + itemcode + "' ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (message == string.Empty)
            {
                responseModel.ResponseStatus = true;
                responseModel.ResponseText = "Updated successfully";
            }
            else
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            return responseModel;
        }

        public ResponseModel UpdateConfirmationDate(string itemcode, string columnName, string INKDate)
        {
            string message = "";
            ResponseModel responseModel = new ResponseModel();
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PPCDETAILS\" SET ");
            stringBuilder.Append(" \"" + columnName + "\"= '" + DateTime.ParseExact(INKDate, "dd-MM-yyyy", CultureInfo.InvariantCulture).ToString("yyyyMMdd") + "' ");
            stringBuilder.Append(" WHERE \"U_ItemCode\" = '" + itemcode + "' ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (message == string.Empty)
            {
                responseModel.ResponseStatus = true;
                responseModel.ResponseText = "Updated successfully";
            }
            else
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            return responseModel;
        }

        public ResponseModel UpdateItemInInkDetails(string father, string itemcode)
        {
            ResponseModel responseModel = new ResponseModel();
            string message = "";
            try
            {
                stringBuilder = new StringBuilder();

                stringBuilder = new StringBuilder();
                stringBuilder.Append("SELECT IFNULL(MAX(Cast(\"Code\" as NUMERIC(19,0))),0) + 1   FROM " + ConfigManager.GetSAPDatabase() + ".\"" + rowTable + "\" ");
                string code = GetRecordValue(stringBuilder.ToString(), CommandType.Text, out message);

                HanaParameter[] parameters = new HanaParameter[5];
                int iParameter = 0;

                parameters[iParameter] = new HanaParameter("Code", System.Data.SqlDbType.VarChar);
                parameters[iParameter].Value = code;
                iParameter++;

                parameters[iParameter] = new HanaParameter("Name", System.Data.SqlDbType.VarChar);
                parameters[iParameter].Value = code;
                iParameter++;

                parameters[iParameter] = new HanaParameter("U_Father", System.Data.SqlDbType.VarChar);
                parameters[iParameter].Value = father;
                iParameter++;

                parameters[iParameter] = new HanaParameter("U_ItemCode", System.Data.SqlDbType.VarChar);
                parameters[iParameter].Value = itemcode;
                iParameter++;

                parameters[iParameter] = new HanaParameter("U_InActive", System.Data.SqlDbType.VarChar);
                parameters[iParameter].Value = (Object)DBNull.Value;
                iParameter++;

                stringBuilder = new StringBuilder();
                stringBuilder.Append(" INSERT INTO " + ConfigManager.GetSAPDatabase() + ".\"" + rowTable + "\"");
                stringBuilder.Append(" (\"Code\",\"Name\",\"U_Father\",\"U_ItemCode\",\"U_InActive\") ");
                stringBuilder.Append(" VALUES ");
                stringBuilder.Append(" (:Code,:Name,:U_Father ,:U_ItemCode,:U_InActive) "); //,:U_ItemCode
                DataTable dt = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message, parameters);
                if (message == string.Empty)
                {
                    responseModel.ResponseText = "Record inserted successfully";
                    responseModel.ResponseStatus = true;
                }
                else
                {
                    responseModel.ResponseText = "Error occured while processing record " + message;
                    responseModel.ResponseStatus = false;
                }
            }
            catch
            {

            }
            return responseModel;
        }

        public ResponseModel UpdateItemStatusInInkDetails(string father, string itemcode, string status)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"" + rowTable + "\" ");
                stringBuilder.Append(" SET \"U_InActive\" = '" + status + "' ");
                stringBuilder.Append(" WHERE \"U_Father\" ='" + father + "' AND \"U_ItemCode\" ='" + itemcode + "' ");
                GetRecordValue(stringBuilder.ToString(), CommandType.Text, out string message);
            }
            catch
            {

            }
            return responseModel;
        }

        public ResponseModel UpdateConfirmation(string itemcode, string columnName)
        {
            string message = "";
            ResponseModel responseModel = new ResponseModel();
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PPCDETAILS\" SET ");
            stringBuilder.Append(" \"" + columnName + "\"= 'Y'  ");
            stringBuilder.Append(" WHERE \"U_ItemCode\" = '" + itemcode + "' ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (message == string.Empty)
            {
                responseModel.ResponseStatus = true;
                responseModel.ResponseText = "Updated successfully";
            }
            else
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            return responseModel;
        }
    }
}