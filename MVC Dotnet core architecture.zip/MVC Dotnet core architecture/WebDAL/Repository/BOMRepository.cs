﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
//using Microsoft.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sap.Data.Hana;
using WebDAL.Helper;
using WebDAL.Helpers;
using WebDAL.IRepository;
using WebDAL.Models;

namespace WebDAL.Repository
{
    public class BOMRepository : clsDataAccess, IBOMRepository
    {
        string query = "";
        CommonRepository commonRepository = new CommonRepository();
        StringBuilder stringBuilder = new StringBuilder();

        public List<BOMMasterModel> GetAll(string bomType,out DataTable dataTable)
        {
            dataTable = new DataTable();    
            List<BOMMasterModel> _list = new List<BOMMasterModel>();
            try
            {
                stringBuilder = new StringBuilder();
                stringBuilder.Append("SELECT T0.\"Code\",T1.\"ItemName\" ");
                stringBuilder.Append(",CASE WHEN T0.\"TreeType\" = 'P' THEN 'Production' ");
                stringBuilder.Append("WHEN T0.\"TreeType\" = 'S' THEN 'Sales' ELSE '' END AS \"TreeType\"");
                stringBuilder.Append("FROM " + ConfigManager.GetSAPDatabase() + ".OITT T0 ");
                stringBuilder.Append("INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OITM T1 ON T0.\"Code\" = T1.\"ItemCode\"");
                stringBuilder.Append("WHERE T0.\"TreeType\" = '" + bomType + "' ");
                //stringBuilder.Append(" ORDER BY T0.\"Code\" DESC ");
                using (dataTable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    _list = ConvertDatatableToList.ConvertToList<BOMMasterModel>(dataTable);
                }
            }
            catch
            {

            }
            return _list;
        }

        public BOMMasterModel Get(string code)
        {
            BOMMasterModel model = new BOMMasterModel();
            try
            {
                string headerTable = CommonTables.BOMHeaderTable;
                string rowTable = CommonTables.BOMRowTable;
                string stagesRowTable = CommonTables.BOMStageRowTable;
                //string freightTable = CommonTables.SalesOrderFreightTable;

                HanaParameter[] parameters = new HanaParameter[1];

                parameters[0] = new HanaParameter("Code", System.Data.SqlDbType.VarChar);
                parameters[0].Value = code;

                #region Header
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"Code\" AS \"TreeCode\",T0.\"Name\" AS \"ItemName\",T0.\"TreeType\",T0.\"TreeType\" as \"TreeType_Disabled\",T0.\"PriceList\",T0.\"Qauntity\" AS \"Quantity\", T0.\"HideComp\"  ");
                stringBuilder.Append(" ,T0.\"U_NoOfUps\" ,T0.\"U_CUTSIZE\" , T0.\"U_PrintSide\" ");
                stringBuilder.Append(" ,T0.\"U_BRemarks\" ,T0.\"U_PerPckQty\" ,T0.\"U_PackQty\"  ");
                stringBuilder.Append(" ,T0.\"U_TthNos\" ,T0.\"U_Rlen\"  ");
                stringBuilder.Append(" ,T0.\"U_Wdir\" ,T0.\"U_ArdUps\" ,T0.\"U_AcrUps\"  ");
                stringBuilder.Append(" , T0.\"U_PprSz\", T0.\"U_CUTSIZX\", T0.\"U_CUTSIZY\", T0.\"U_NoOfCuts\" ");
                stringBuilder.Append(" , T0.\"U_InkType\", T0.\"ToWH\" AS \"Warehouse\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + headerTable + " T0 ");
                stringBuilder.Append(" WHERE T0.\"Code\" = :code ");

                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                {
                    if (datatable.Rows.Count > 0)
                    {
                        model = ConvertDatatableToList.ConvertToEntity<BOMMasterModel>(datatable);

                        if (datatable.Rows[0]["HideComp"].ToString() == "Y")
                        {
                            model.IsHideBOM = true;
                        }
                    }
                }

                #endregion

                #region Stages Row
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"StageId\" AS \"StageID\", T0.\"SeqNum\" AS \"SequenceNumber\", T0.\"Name\" ");
                stringBuilder.Append(" ,T0.\"StgEntry\" AS \"StageEntry\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + stagesRowTable + " T0 ");
                stringBuilder.Append(" WHERE T0.\"Father\" = :code ");
                stringBuilder.Append(" ORDER BY T0.\"SeqNum\" ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                {
                    List<ProductTreeStage> modelRows = ConvertDatatableToList.ConvertToList<ProductTreeStage>(datatable);
                    model.ProductTreeStages = modelRows;
                }
                #endregion

                #region Rows
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"VisOrder\" + 1 AS \"Index\",T0.\"ChildNum\",'4' AS \"ItemType\",T0.\"Code\" AS \"ItemCode\",T0.\"ItemName\"  ");
                stringBuilder.Append(" ,T0.\"Quantity\" , T0.\"Warehouse\",T0.\"IssueMthd\" , T0.\"PriceList\" , T0.\"StageId\" AS \"StageID\" ");
                stringBuilder.Append(" ,T0.\"U_FIXVAR\" , T0.\"U_TRNREQ\",T0.\"U_SPW\" , T0.\"U_LinerFlute\" , T0.\"U_AniloxDetail\",T0.\"U_AniloxSrNo\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + rowTable + " T0 ");
                stringBuilder.Append(" WHERE T0.\"Father\" = :code ");
                stringBuilder.Append(" ORDER BY T0.\"VisOrder\" ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                {
                    if (model.ProductTreeStages.Count == 0)
                    {
                        List<BOMMasterModelRow> modelRows = ConvertDatatableToList.ConvertToList<BOMMasterModelRow>(datatable);
                        model.ProductTreeLines = modelRows;
                    }
                    else
                    {
                        List<BOMMasterModelRow> modelItemRows = ConvertDatatableToList.ConvertToList<BOMMasterModelRow>(datatable);

                        List<BOMMasterModelRow> modelRows = new List<BOMMasterModelRow>();
                        for (int i = 0; i < model.ProductTreeStages.Count; i++)
                        {
                            BOMMasterModelRow entity = new BOMMasterModelRow();

                            #region Adding Stage/Route
                            entity.ItemType = "296";
                            entity.ItemCode = model.ProductTreeStages[i].Name;
                            entity.ItemName = model.ProductTreeStages[i].Name;
                            //entity.StageID = model.ProductTreeStages[i].StageID.ToString();
                            entity.StageID = model.ProductTreeStages[i].StageID;
                            modelRows.Add(entity);
                            #endregion

                            var itemList = modelItemRows.Where(a => a.StageID == entity.StageID).ToList();

                            modelRows.AddRange(itemList);
                        }
                        for (int k = 0; k < modelRows.Count; k++)
                        {
                            modelRows[k].Index = k + 1;
                        }
                        model.ProductTreeLines = modelRows;

                    }
                }
                #endregion
            }
            catch
            {

            }
            return model;
        }

        public ResponseModel Add(BOMMasterModel model)
        {
            ResponseModel responseModel = new ResponseModel();
            ServiceLayer rc = new ServiceLayer();
            string res = rc.Login();
            if (res != "" && res.Contains("error") == false)
            {
                BOMMasterModel _objServiceLayer = new BOMMasterModel();

                #region Header

                _objServiceLayer.TreeCode = model.TreeCode;
                string treeType = model.TreeType;
                if (treeType == "S")
                {
                    treeType = "iSalesTree";
                }
                _objServiceLayer.HideBOMComponentsInPrintout = model.IsHideBOM == true ? "tYES" : "tNO";
                _objServiceLayer.TreeType = treeType;
                _objServiceLayer.Quantity = model.Quantity;
                _objServiceLayer.PriceList = model.PriceList;
                _objServiceLayer.Warehouse = model.Warehouse;

                #endregion

                #region UDF
                _objServiceLayer.U_NoOfUps = model.U_NoOfUps;
                _objServiceLayer.U_CUTSIZE = model.U_CUTSIZE;
                _objServiceLayer.U_PrintSide = model.U_PrintSide;
                _objServiceLayer.U_BRemarks = model.U_BRemarks;
                _objServiceLayer.U_PerPckQty = model.U_PerPckQty;
                _objServiceLayer.U_PackQty = model.U_PackQty;
                _objServiceLayer.U_TthNos = model.U_TthNos;
                _objServiceLayer.U_Rlen = model.U_Rlen;
                _objServiceLayer.U_Wdir = model.U_Wdir;
                _objServiceLayer.U_ArdUps = model.U_ArdUps;
                _objServiceLayer.U_AcrUps = model.U_AcrUps;
                _objServiceLayer.U_PprSz = model.U_PprSz;
                _objServiceLayer.U_CUTSIZX = model.U_CUTSIZX;
                _objServiceLayer.U_CUTSIZY = model.U_CUTSIZY;
                _objServiceLayer.U_NoOfCuts = model.U_NoOfCuts;
                _objServiceLayer.U_InkType = model.U_InkType;

                #endregion

                #region Item Rows

                int modelRow = 0;
                int stageId = 0;
                List<BOMMasterModelRow> modelLines_ServiceLayer = new List<BOMMasterModelRow>();
                List<BOMMasterModelRow> itemList = model.ProductTreeLines;
                itemList = model.ProductTreeLines.Where(a => (string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N")).ToList();
                for (int i = 0; i < itemList.Count; i++)
                {
                    string itemType = itemList[i].ItemType;

                    if (itemType == "296")
                    {
                        // stageId = stageId++;
                        stageId = stageId + 1;
                    }


                    if (!string.IsNullOrEmpty(itemList[i].ItemCode) && itemType == "4")
                    {
                        modelLines_ServiceLayer.Add(new BOMMasterModelRow { });
                        modelLines_ServiceLayer[modelRow].ItemCode = itemList[i].ItemCode;
                        modelLines_ServiceLayer[modelRow].Quantity = itemList[i].Quantity;
                        modelLines_ServiceLayer[modelRow].Warehouse = itemList[i].Warehouse;
                        string issueMethod = itemList[i].IssueMethod;
                        issueMethod = issueMethod == "M" ? "im_Manual" : "im_Backflush";
                        modelLines_ServiceLayer[modelRow].IssueMethod = issueMethod;
                        modelLines_ServiceLayer[modelRow].PriceList = itemList[i].PriceList;
                        try
                        {
                            if (stageId > 0)
                            {
                                modelLines_ServiceLayer[modelRow].StageID = stageId;
                            }
                        }
                        catch { }

                        try
                        {
                            modelLines_ServiceLayer[modelRow].U_FIXVAR = itemList[i].U_FIXVAR;
                            modelLines_ServiceLayer[modelRow].U_TRNREQ = itemList[i].U_TRNREQ;
                            modelLines_ServiceLayer[modelRow].U_SPW = itemList[i].U_SPW;
                            modelLines_ServiceLayer[modelRow].U_LinerFlute = itemList[i].U_LinerFlute;
                            modelLines_ServiceLayer[modelRow].U_AniloxDetail = itemList[i].U_AniloxDetail;
                            modelLines_ServiceLayer[modelRow].U_AniloxSrNo = itemList[i].U_AniloxSrNo;
                        }
                        catch { }

                        modelRow++;
                    }
                }

                #endregion


                #region Route Rows

                modelRow = 0;
                List<ProductTreeStage> modelRoute_ServiceLayer = new List<ProductTreeStage>();
                itemList = model.ProductTreeLines.Where(a => (string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N") && a.ItemType == "296").ToList();
                for (int i = 0; i < itemList.Count; i++)
                {
                    if (!string.IsNullOrEmpty(itemList[i].ItemCode))
                    {
                        modelRoute_ServiceLayer.Add(new ProductTreeStage { });
                        modelRoute_ServiceLayer[modelRow].Father = model.TreeCode;
                        modelRoute_ServiceLayer[modelRow].StageID = modelRow + 1;
                        modelRoute_ServiceLayer[modelRow].SequenceNumber = modelRow + 1;
                        modelRoute_ServiceLayer[modelRow].Name = itemList[i].ItemCode;
                        string routeEntry = commonRepository.GetRouteEntry(itemList[i].ItemCode);
                        modelRoute_ServiceLayer[modelRow].StageEntry = int.Parse(routeEntry);
                        modelRow++;
                    }
                }

                #endregion

                _objServiceLayer.ProductTreeLines = modelLines_ServiceLayer;
                _objServiceLayer.ProductTreeStages = modelRoute_ServiceLayer;

                string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
                {
                    NullValueHandling = NullValueHandling.Ignore,
                });

                var myJson = JObject.Parse(main);
                myJson.Descendants()
                .OfType<JProperty>()
                .Where(attr => attr.Name.StartsWith("IsHideBOM"))
                .ToList()
                .ForEach(attr => attr.Remove());
                main = myJson.ToString();

                var temp = JsonConvert.DeserializeObject<JObject>(main);

                string serviceLayerObject = "ProductTrees";
                rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject;
                rc.patchJSON = main;
                rc.B1SESSION = res;
                string message = "";
                bool result = rc.postRequest(out message);
                responseModel.ResponseStatus = result;
                if (result == true)
                {
                    responseModel.ResponseText = "Operation completed successfully";
                    var jobject = JsonConvert.DeserializeObject<JObject>(message);
                    string docEntry = jobject["TreeCode"].ToString();
                    model.Code = docEntry;
                    responseModel.ResponseEntry = docEntry;
                }
                else
                {
                    var jobject = JsonConvert.DeserializeObject<JObject>(message);
                    string jsonMessage = jobject["error"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["message"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["value"].ToString();
                    responseModel.ResponseText = "Error occured during process: " + jsonMessage;
                }
                rc.LogOut();
            }
            else
            {
                responseModel.ResponseText = "Service layer login failed";
            }
            return responseModel;
        }

        public ResponseModel Update(BOMMasterModel model)
        {
            try
            {
                ResponseModel responseModel = new ResponseModel();
                ServiceLayer rc = new ServiceLayer();
                string res = rc.Login();
                if (res != "" && res.Contains("error") == false)
                {
                    BOMMasterModel _objServiceLayer = new BOMMasterModel();

                    #region Header

                    _objServiceLayer.TreeCode = model.TreeCode;
                    string treeType = model.TreeType;
                    if (treeType == "S")
                    {
                        treeType = "iSalesTree";
                    }
                    _objServiceLayer.HideBOMComponentsInPrintout = model.IsHideBOM == true ? "tYES" : "tNO";
                    _objServiceLayer.TreeType = treeType;
                    _objServiceLayer.Quantity = model.Quantity;
                    _objServiceLayer.PriceList = model.PriceList;
                    _objServiceLayer.Warehouse = model.Warehouse;

                    #endregion

                    #region UDF
                    _objServiceLayer.U_NoOfUps = model.U_NoOfUps;
                    _objServiceLayer.U_CUTSIZE = model.U_CUTSIZE;
                    _objServiceLayer.U_PrintSide = model.U_PrintSide;
                    _objServiceLayer.U_BRemarks = model.U_BRemarks;
                    _objServiceLayer.U_PerPckQty = model.U_PerPckQty;
                    _objServiceLayer.U_PackQty = model.U_PackQty;
                    _objServiceLayer.U_TthNos = model.U_TthNos;
                    _objServiceLayer.U_Rlen = model.U_Rlen;
                    _objServiceLayer.U_Wdir = model.U_Wdir;
                    _objServiceLayer.U_ArdUps = model.U_ArdUps;
                    _objServiceLayer.U_AcrUps = model.U_AcrUps;
                    _objServiceLayer.U_PprSz = model.U_PprSz;
                    _objServiceLayer.U_CUTSIZX = model.U_CUTSIZX;
                    _objServiceLayer.U_CUTSIZY = model.U_CUTSIZY;
                    _objServiceLayer.U_NoOfCuts = model.U_NoOfCuts;
                    _objServiceLayer.U_InkType = model.U_InkType;

                    #endregion

                    #region Item Rows

                    int modelRow = 0;
                    int stageId = 0;
                    List<BOMMasterModelRow> modelLines_ServiceLayer = new List<BOMMasterModelRow>();
                    List<BOMMasterModelRow> itemList = model.ProductTreeLines;
                    itemList = model.ProductTreeLines.Where(a => (string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N")).ToList();
                    for (int i = 0; i < itemList.Count; i++)
                    {
                        string itemType = itemList[i].ItemType;
                        //if (treeType == "P")
                        //{
                        if (itemType == "296")
                        {
                            //stageId = stageId++;
                            stageId = stageId + 1;
                        }
                        //}
                        if (!string.IsNullOrEmpty(itemList[i].ItemCode) && itemType == "4")
                        {
                            modelLines_ServiceLayer.Add(new BOMMasterModelRow { });
                            modelLines_ServiceLayer[modelRow].ItemCode = itemList[i].ItemCode;
                            modelLines_ServiceLayer[modelRow].Quantity = itemList[i].Quantity;
                            modelLines_ServiceLayer[modelRow].Warehouse = itemList[i].Warehouse;
                            string issueMethod = itemList[i].IssueMethod;
                            issueMethod = issueMethod == "M" ? "im_Manual" : "im_Backflush";
                            modelLines_ServiceLayer[modelRow].IssueMethod = issueMethod;
                            modelLines_ServiceLayer[modelRow].PriceList = itemList[i].PriceList;
                            try
                            {
                                if (stageId > 0)
                                {
                                    modelLines_ServiceLayer[modelRow].StageID = stageId;
                                }
                            }
                            catch { }
                            try
                            {
                                modelLines_ServiceLayer[modelRow].ChildNum = itemList[i].ChildNum;
                            }
                            catch { }
                            try
                            {
                                //modelLines_ServiceLayer[modelRow].U_CTOL = model.DocumentLines[i].U_CTOL;
                            }
                            catch (Exception ex)
                            {
                            }


                            try
                            {
                                modelLines_ServiceLayer[modelRow].U_FIXVAR = itemList[i].U_FIXVAR;
                                modelLines_ServiceLayer[modelRow].U_TRNREQ = itemList[i].U_TRNREQ;
                                modelLines_ServiceLayer[modelRow].U_SPW = itemList[i].U_SPW;
                                modelLines_ServiceLayer[modelRow].U_LinerFlute = itemList[i].U_LinerFlute;
                                modelLines_ServiceLayer[modelRow].U_AniloxDetail = itemList[i].U_AniloxDetail;
                                modelLines_ServiceLayer[modelRow].U_AniloxSrNo = itemList[i].U_AniloxSrNo;
                            }
                            catch { }

                            modelRow++;
                        }
                    }

                    #endregion

                    #region Route Rows

                    modelRow = 0;
                    List<ProductTreeStage> modelRoute_ServiceLayer = new List<ProductTreeStage>();
                    itemList = model.ProductTreeLines.Where(a => (string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N") && a.ItemType == "296").ToList();
                    for (int i = 0; i < itemList.Count; i++)
                    {
                        if (!string.IsNullOrEmpty(itemList[i].ItemCode))
                        {
                            modelRoute_ServiceLayer.Add(new ProductTreeStage { });
                            modelRoute_ServiceLayer[modelRow].Father = model.TreeCode;
                            modelRoute_ServiceLayer[modelRow].StageID = modelRow + 1;
                            modelRoute_ServiceLayer[modelRow].SequenceNumber = modelRow + 1;
                            modelRoute_ServiceLayer[modelRow].Name = itemList[i].ItemCode;
                            string routeEntry = commonRepository.GetRouteEntry(itemList[i].ItemCode);
                            modelRoute_ServiceLayer[modelRow].StageEntry = int.Parse(routeEntry);
                            modelRow++;
                        }
                    }

                    #endregion

                    _objServiceLayer.ProductTreeLines = modelLines_ServiceLayer;
                    _objServiceLayer.ProductTreeStages = modelRoute_ServiceLayer;
                    string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
                    {
                        NullValueHandling = NullValueHandling.Ignore,
                    });

                    var myJson = JObject.Parse(main);
                    myJson.Descendants()
                    .OfType<JProperty>()
                    .Where(attr => attr.Name.StartsWith("IsHideBOM"))
                    .ToList()
                    .ForEach(attr => attr.Remove());
                    main = myJson.ToString();

                    string serviceLayerObject = "";
                    serviceLayerObject = ServiceLayerEntity.ProductTrees.ToString();
                    rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject + "('" + model.TreeCode + "')";
                    rc.patchJSON = main;
                    rc.B1SESSION = res;
                    rc.httpMethod = httpVerb.PATCH;
                    string message = "";
                    bool result = rc.patchRequest(out message);
                    responseModel.ResponseStatus = result;
                    if (result == true)
                    {
                        responseModel.ResponseText = "Operation completed successfully";
                    }
                    else
                    {
                        var jobject = JsonConvert.DeserializeObject<JObject>(message);
                        string jsonMessage = jobject["error"].ToString();
                        jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                        jsonMessage = jobject["message"].ToString();
                        jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                        jsonMessage = jobject["value"].ToString();
                        responseModel.ResponseText = "Error occured during process: " + jsonMessage;
                    }
                    rc.LogOut();
                }
                return responseModel;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public void UpdateBOMChildWarehouse(string itemcode, string warehouse)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE T0 ");
            stringBuilder.Append(" SET T0.\"Warehouse\" = '" + warehouse + "' ");
            stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".ITT1 T0 ");
            stringBuilder.Append(" WHERE T0.\"Father\" = '" + itemcode + "' AND T0.\"Warehouse\" IS NOT NULL ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message);
        }
    }
}