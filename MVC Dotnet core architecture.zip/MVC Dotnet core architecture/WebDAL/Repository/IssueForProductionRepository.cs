﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sap.Data.Hana;
using WebDAL.Helper;
using WebDAL.Helpers;
using WebDAL.IRepository;
using WebDAL.Models;

namespace WebDAL.Repository
{
	public class IssueForProductionRepository : clsDataAccess, IIssueForProductionRepository
    {
		string query = "";
		CommonRepository commonRepository = new CommonRepository();
		StringBuilder stringBuilder = new StringBuilder();
		public List<IssueForProductionModel> GetAll(string userId, string type)

		{
			List<IssueForProductionModel> _list = new List<IssueForProductionModel>();
			try
			{
				string isSuperUser = commonRepository.IsUserSuperUser(userId);
				string slpName = commonRepository.GetSlpNameFromEmailAddress(userId);
				string headerTable = CommonTables.IssueForProdutionHeaderTable;
				string rowTable = CommonTables.IssueForProdutionRowTable;
				HanaParameter[] parameters = new HanaParameter[1];
				parameters[0] = new HanaParameter("@UserId", System.Data.SqlDbType.VarChar);
				parameters[0].Value = userId;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"U_MCode\", T0.\"U_MName\",TO_NVARCHAR(T0.\"U_DocDt\", 'DD/MM/YYYY')  AS \"U_DocDt\"  ");
				stringBuilder.Append(" ,T0.\"U_ShftCode\", T0.\"DocNum\",  T0.\"DocNum\" , T0.\"Creator\" , T0.\"Creator\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + headerTable + " T0 ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<IssueForProductionModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}
		public IssueForProductionModel Get(string docEntry, string userId, string type)
		{
            IssueForProductionModel model = new IssueForProductionModel();
			try
			{
                string headerTable = CommonTables.IssueForProdutionHeaderTable;
                string rowTable = CommonTables.IssueForProdutionRowTable;
                HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
				parameters[0].Value = docEntry;

                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"U_MCode\", T0.\"U_MName\",TO_NVARCHAR(T0.\"U_DocDt\", 'DD/MM/YYYY')  AS \"U_DocDt\"  ");
                stringBuilder.Append(" ,T0.\"U_ShftCode\", T0.\"DocNum\",  T0.\"DocNum\" , T0.\"Creator\" , T0.\"Creator\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + headerTable + " T0 ");

                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						model = ConvertDatatableToList.ConvertToEntity<IssueForProductionModel>(datatable);
					
					}
				}

				#region Row
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"U_OpType\",T0.\"U_JobCardNo\",T0.\"U_StrHour\" ,T0.\"U_EndHour\" ");
				stringBuilder.Append(" ,T0.\"U_OpName\", T0.\"U_OCode\" , T0.\"U_IsSplit\", T0.\"U_ICode\", T0.\"U_IName\", T0.\"U_AvaQty\" ");
				stringBuilder.Append(" , T0.\"U_NoOfCut\" , T0.\"U_Qty\", T0.\"U_PQty\", T0.\"U_RjQty\",  T0.\"U_Complete\"");
				stringBuilder.Append(" ,T0.\"U_Nwhrs\",T1.\"U_IFP\" ,T3.\"U_RFP\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + headerTable + " T0 ");


                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						List<IssueForProductionRowsModel> modelRows = ConvertDatatableToList.ConvertToList<IssueForProductionRowsModel>(datatable);
					}
				}
				#endregion
			}
			catch
			{

			}
			return model;
		}
		public ResponseModel Add(IssueForProductionModel model)
		{
            string headerTable = CommonTables.IssueForProdutionHeaderTable;
            string rowTable = CommonTables.IssueForProdutionRowTable;
            ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();

			string slpcode = commonRepository.GetSlpCodeFromEmailAddress(model.UserId);
            IssueForProductionModel _objServiceLayer = new IssueForProductionModel();

            #region Header
   //         _objServiceLayer.U_MCode = model.U_MCode;
   //         _objServiceLayer.U_MName = model.U_MName;
   //         _objServiceLayer.U_ShftCode = model.U_ShftCode;
   //         _objServiceLayer.Series = model.Series;
			//_objServiceLayer.DocNum = model.DocNum;
			//_objServiceLayer.Creator = model.Creator;
			//_objServiceLayer.Remark = model.Remark;
			//DateTime dtDate = DateTime.ParseExact(model.U_DocDt, "dd-MM-yyyy", CultureInfo.InvariantCulture);
			//_objServiceLayer.U_DocDt = dtDate.ToString("yyyyMMdd");
			#endregion

			#region ShopFloor Rows

			int modelRow = 0;
			List<IssueForProductionRowsModel> modelLines_ServiceLayer = new List<IssueForProductionRowsModel>();
			model.DocumentLines = model.DocumentLines.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
			for (int i = 0; i < model.DocumentLines.Count; i++)
			{
				//modelLines_ServiceLayer[modelRow].U_OpType = model.DocumentLines[i].U_OpType;
				//modelLines_ServiceLayer[modelRow].U_JobCardNo = model.DocumentLines[i].U_JobCardNo;
				//modelLines_ServiceLayer[modelRow].U_StrHour = model.DocumentLines[i].U_StrHour;
				//modelLines_ServiceLayer[modelRow].U_EndHour = model.DocumentLines[i].U_EndHour;
				//modelLines_ServiceLayer[modelRow].U_OpName = model.DocumentLines[i].U_OpName;
				//modelLines_ServiceLayer[modelRow].U_OCode = model.DocumentLines[i].U_OCode;
				//modelLines_ServiceLayer[modelRow].U_IsSplit = model.DocumentLines[i].U_IsSplit;
				//modelLines_ServiceLayer[modelRow].U_ICode = model.DocumentLines[i].U_ICode;
				//modelLines_ServiceLayer[modelRow].U_IName = model.DocumentLines[i].U_IName;
				//modelLines_ServiceLayer[modelRow].U_AvaQty = model.DocumentLines[i].U_AvaQty;
				//modelLines_ServiceLayer[modelRow].U_NoOfCut = model.DocumentLines[i].U_NoOfCut;
				//modelLines_ServiceLayer[modelRow].U_Qty = model.DocumentLines[i].U_Qty;
				//modelLines_ServiceLayer[modelRow].U_PQty = model.DocumentLines[i].U_PQty;
				//modelLines_ServiceLayer[modelRow].U_RjQty = model.DocumentLines[i].U_RjQty;
				//modelLines_ServiceLayer[modelRow].U_Complete = model.DocumentLines[i].U_Complete;
				//modelLines_ServiceLayer[modelRow].U_Nwhrs = model.DocumentLines[i].U_Nwhrs;
				//modelLines_ServiceLayer[modelRow].U_IFP = model.DocumentLines[i].U_IFP;
				//modelLines_ServiceLayer[modelRow].U_RFP = model.DocumentLines[i].U_RFP;
				//modelRow++;
			}
			#endregion


			_objServiceLayer.DocumentLines = modelLines_ServiceLayer;


			string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
			{
				NullValueHandling = NullValueHandling.Ignore,
			});
			var temp = JsonConvert.DeserializeObject<JObject>(main);

			string serviceLayerObject = "";
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				serviceLayerObject = ServiceLayerEntity.Drafts.ToString();
				rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject;
				rc.patchJSON = main;
				rc.B1SESSION = res;
				string message = "";
				bool result = rc.postRequest(out message);
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					//string docEntry = jobject["DocEntry"].ToString();
					//model.DocEntry = docEntry;
					//responseModel.ResponseEntry = docEntry;
					//commonRepository.UpdateUserSign("Add", headerTable, "DocEntry", docEntry, model.OriginatorId);
				
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during process: " + jsonMessage;
				}
				rc.LogOut();
			}
			else
			{
				responseModel.ResponseText = "Service layer login failed";
			}
			return responseModel;
		}
		public ResponseModel Update(IssueForProductionModel model)
		{
            string headerTable = CommonTables.IssueForProdutionHeaderTable;
            string rowTable = CommonTables.IssueForProdutionRowTable;
            ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();

			string slpcode = commonRepository.GetSlpCodeFromEmailAddress(model.UserId);
            IssueForProductionModel _objServiceLayer = new IssueForProductionModel();

            //#region Header
            //_objServiceLayer.U_MCode = model.U_MCode;
            //_objServiceLayer.U_MName = model.U_MName;
            //_objServiceLayer.U_ShftCode = model.U_ShftCode;
            //_objServiceLayer.Series = model.Series;
            //_objServiceLayer.DocNum = model.DocNum;
            //_objServiceLayer.Creator = model.Creator;
            //_objServiceLayer.Remark = model.Remark;
            //DateTime dtDate = DateTime.ParseExact(model.U_DocDt, "dd-MM-yyyy", CultureInfo.InvariantCulture);
            //_objServiceLayer.U_DocDt = dtDate.ToString("yyyyMMdd");
            //#endregion

            #region ShopFloor Rows

            int modelRow = 0;
            List<IssueForProductionRowsModel> modelLines_ServiceLayer = new List<IssueForProductionRowsModel>();
            model.DocumentLines = model.DocumentLines.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
            for (int i = 0; i < model.DocumentLines.Count; i++)
            {
                //modelLines_ServiceLayer[modelRow].U_OpType = model.DocumentLines[i].U_OpType;
                //modelLines_ServiceLayer[modelRow].U_JobCardNo = model.DocumentLines[i].U_JobCardNo;
                //modelLines_ServiceLayer[modelRow].U_StrHour = model.DocumentLines[i].U_StrHour;
                //modelLines_ServiceLayer[modelRow].U_EndHour = model.DocumentLines[i].U_EndHour;
                //modelLines_ServiceLayer[modelRow].U_OpName = model.DocumentLines[i].U_OpName;
                //modelLines_ServiceLayer[modelRow].U_OCode = model.DocumentLines[i].U_OCode;
                //modelLines_ServiceLayer[modelRow].U_IsSplit = model.DocumentLines[i].U_IsSplit;
                //modelLines_ServiceLayer[modelRow].U_ICode = model.DocumentLines[i].U_ICode;
                //modelLines_ServiceLayer[modelRow].U_IName = model.DocumentLines[i].U_IName;
                //modelLines_ServiceLayer[modelRow].U_AvaQty = model.DocumentLines[i].U_AvaQty;
                //modelLines_ServiceLayer[modelRow].U_NoOfCut = model.DocumentLines[i].U_NoOfCut;
                //modelLines_ServiceLayer[modelRow].U_Qty = model.DocumentLines[i].U_Qty;
                //modelLines_ServiceLayer[modelRow].U_PQty = model.DocumentLines[i].U_PQty;
                //modelLines_ServiceLayer[modelRow].U_RjQty = model.DocumentLines[i].U_RjQty;
                //modelLines_ServiceLayer[modelRow].U_Complete = model.DocumentLines[i].U_Complete;
                //modelLines_ServiceLayer[modelRow].U_Nwhrs = model.DocumentLines[i].U_Nwhrs;
                //modelLines_ServiceLayer[modelRow].U_IFP = model.DocumentLines[i].U_IFP;
                //modelLines_ServiceLayer[modelRow].U_RFP = model.DocumentLines[i].U_RFP;
                //modelRow++;
            }
            #endregion

            _objServiceLayer.DocumentLines = modelLines_ServiceLayer;

            string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
			{
				NullValueHandling = NullValueHandling.Ignore,
			});
			var temp = JsonConvert.DeserializeObject<JObject>(main);

			string serviceLayerObject = "";
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				serviceLayerObject = ServiceLayerEntity.Drafts.ToString();
				//rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject + "(" + model.DocEntry + ")";
				rc.patchJSON = main;
				rc.B1SESSION = res;
				string message = "";
				bool result = rc.postRequest(out message);
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string docEntry = jobject["DocEntry"].ToString();
					//model.DocEntry = docEntry;
					//responseModel.ResponseEntry = docEntry;
					//commonRepository.UpdateUserSign("Update", headerTable, "DocEntry", docEntry, model.OriginatorId);
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during process: " + jsonMessage;
				}
				rc.LogOut();
			}
			else
			{
				responseModel.ResponseText = "Service layer login failed";
			}
			return responseModel;
		}
	}
}