﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sap.Data.Hana;
using WebDAL.Helper;
using WebDAL.Helpers;
using WebDAL.IRepository;
using WebDAL.Models;
using static System.Net.Mime.MediaTypeNames;

namespace WebDAL.Repository
{
	public class GangupRepository : clsDataAccess, IGangupRepository
	{
		string query = "";
		CommonRepository commonRepository = new CommonRepository();
		StringBuilder stringBuilder = new StringBuilder();
		public List<GangupModel> GetAll()
		{
			List<GangupModel> _list = new List<GangupModel>();
			try
			{
				string headerTable = CommonTables.GangupHeaderTable;
				string rowTable = CommonTables.GangupRowTable;
				HanaParameter[] parameters = new HanaParameter[1];

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT  T0.\"DocEntry\",T0.\"DocNum\",TO_NVARCHAR(T0.\"U_DocDate\", 'DD/MM/YYYY')  AS \"U_DocDate\" ,T0.\"U_CardCode\",T2.\"CardName\" ");
				stringBuilder.Append(" ,T1.\"SlpName\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_GANGUP\" T0 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"OSLP\" T1 ON T0.\"U_SlpCode\" = T1.\"SlpCode\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"OCRD\" T2 ON T0.\"U_CardCode\" = T2.\"CardCode\" ");
				stringBuilder.Append(" ORDER BY T0.\"DocEntry\" DESC ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<GangupModel>(datatable);
				}
			}
			catch
			{
			}
			return _list;
		}
		public GangupModel Get(string docEntry)
		{
			GangupModel model = new GangupModel();
			try
			{
				string headerTable = CommonTables.GangupHeaderTable;
				string rowTable = CommonTables.GangupRowTable;
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
				parameters[0].Value = docEntry;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"DocEntry\", T0.\"DocNum\",TO_NVARCHAR(T0.\"U_DocDate\", 'DD/MM/YYYY')  AS \"U_DocDate\" ,T0.\"U_SlpCode\",T0.\"U_CardCode\",T3.\"CardName\"  ");
				stringBuilder.Append(" ,T0.\"U_ItmGrp\", T0.\"U_TNoOfSheet\",T0.\"U_TNoOfUPS\",T0.\"Series\",T1.\"SlpName\",T2.\"SeriesName\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + headerTable + "\" T0 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"OSLP\" T1 ON T0.\"U_SlpCode\" = T1.\"SlpCode\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"NNM1\" T2 ON T0.\"Series\" = T2.\"Series\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"OCRD\" T3 ON T0.\"U_CardCode\" = T3.\"CardCode\" ");
				stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						model = ConvertDatatableToList.ConvertToEntity<GangupModel>(datatable);
					}
				}

				#region Row
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"LineId\",T0.\"LineId\" as \"Index\",T0.\"U_ItemCode\" ,T0.\"U_ItemName\" ");
				stringBuilder.Append(" ,T0.\"U_SOQty\", T0.\"U_NoOfUPS\" , T0.\"U_JobQty\", T0.\"U_Rate\", T0.\"U_KLDNo\", T0.\"U_AppArt\" ");
				stringBuilder.Append(" ,T0.\"DocEntry\" \"U_BaseEn\", T0.\"LineId\" \"U_BaseLine\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + rowTable + "\" T0 ");
				stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						List<GangupRowsModel> modelRows = ConvertDatatableToList.ConvertToList<GangupRowsModel>(datatable);
						model.WEB_GANGUP1Collection = modelRows;
					}
					else
					{
						List<GangupRowsModel> GangupRowsModellList = new List<GangupRowsModel>();
						GangupRowsModel gangupRowsModel = new GangupRowsModel();
						gangupRowsModel.Index = 1;
						GangupRowsModellList.Add(gangupRowsModel);
						model.WEB_GANGUP1Collection = GangupRowsModellList;

					}
				}
				#endregion
			}
			catch
			{

			}
			return model;
		}
		public ResponseModel Add(GangupModel model)
		{
			string headerTable = CommonTables.GangupHeaderTable;
			string rowTable = CommonTables.GangupRowTable;
			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();

			//string slpcode = commonRepository.GetSlpCodeFromEmailAddress(model.UserId);
			GangupModel _objServiceLayer = new GangupModel();

			#region Header
			_objServiceLayer.Series = model.Series;
			_objServiceLayer.DocNum = model.DocNum;
			_objServiceLayer.U_SlpCode = model.U_SlpCode;
			_objServiceLayer.U_CardCode = model.U_CardCode;
			_objServiceLayer.U_ItmGrp = model.U_ItmGrp;
			_objServiceLayer.U_TNoOfSheet = model.U_TNoOfSheet;
			_objServiceLayer.U_TNoOfUPS = model.U_TNoOfUPS;
			_objServiceLayer.U_TotNInk = model.U_TotNInk;
			DateTime dtDate = DateTime.ParseExact(model.U_DocDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
			_objServiceLayer.U_DocDate = dtDate.ToString("yyyyMMdd");
			#endregion


			#region Gangup Rows

			int modelRow = 0;
			List<GangupRowsModel> modelLines_ServiceLayer = new List<GangupRowsModel>();
			model.WEB_GANGUP1Collection = model.WEB_GANGUP1Collection.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
			for (int i = 0; i < model.WEB_GANGUP1Collection.Count; i++)
			{
				if (!string.IsNullOrEmpty(model.WEB_GANGUP1Collection[i].U_ItemCode))
				{
					modelLines_ServiceLayer.Add(new GangupRowsModel { });
					//modelLines_ServiceLayer[modelRow].U_SoNo = model.WEB_GANGUP1Collection[i].U_SoNo;
					//modelLines_ServiceLayer[modelRow].U_SoDate = model.WEB_GANGUP1Collection[i].U_SoDate;
					//DateTime dtsoDate = DateTime.ParseExact(model.WEB_GANGUP1Collection[i].U_SoDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
					//modelLines_ServiceLayer[modelRow].U_SoDate = dtsoDate.ToString("yyyyMMdd");
					modelLines_ServiceLayer[modelRow].U_ItemCode = model.WEB_GANGUP1Collection[i].U_ItemCode;
					modelLines_ServiceLayer[modelRow].U_ItemName = model.WEB_GANGUP1Collection[i].U_ItemName;
					modelLines_ServiceLayer[modelRow].U_SOQty = model.WEB_GANGUP1Collection[i].U_SOQty;
					modelLines_ServiceLayer[modelRow].U_NoOfUPS = model.WEB_GANGUP1Collection[i].U_NoOfUPS;
					modelLines_ServiceLayer[modelRow].U_JobQty = model.WEB_GANGUP1Collection[i].U_JobQty;
					modelLines_ServiceLayer[modelRow].U_KLDNo = model.WEB_GANGUP1Collection[i].U_KLDNo;
					modelLines_ServiceLayer[modelRow].U_Rate = model.WEB_GANGUP1Collection[i].U_Rate;
					modelLines_ServiceLayer[modelRow].U_AppArt = model.WEB_GANGUP1Collection[i].U_AppArt;
					modelLines_ServiceLayer[modelRow].U_BaseEn = model.WEB_GANGUP1Collection[i].U_BaseEn;
					modelLines_ServiceLayer[modelRow].U_BaseLine = model.WEB_GANGUP1Collection[i].U_BaseLine;
					modelRow++;
				}
			}
			#endregion

			_objServiceLayer.WEB_GANGUP1Collection = modelLines_ServiceLayer;

			string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
			{
				NullValueHandling = NullValueHandling.Ignore,
			});
			var temp = JsonConvert.DeserializeObject<JObject>(main);

			string serviceLayerObject = "";
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				serviceLayerObject = ServiceLayerEntity.WEB_GANGUP.ToString();
				rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject;
				rc.patchJSON = main;
				rc.B1SESSION = res;
				string message = "";
				bool result = rc.postRequest(out message);
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";

					#region Update Target Entry and Line
					string outMessage = "";
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string docEntry = jobject["DocEntry"].ToString();

					stringBuilder = new StringBuilder();
					stringBuilder.Append(" UPDATE T0 ");
					stringBuilder.Append(" SET T0.\"U_TargEn\" = T1.\"DocEntry\",T0.\"U_TargLine\" = T1.\"LineId\"  ");
					stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + CommonTables.ClientPORegisterRowTable + "\" T0 ");
					stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"" + CommonTables.GangupRowTable + "\" T1 ON T0.\"DocEntry\" = T1.\"U_BaseEn\" AND T0.\"LineId\" = T1.\"U_BaseLine\" ");
					stringBuilder.Append(" WHERE T1.\"DocEntry\" = " + docEntry + " ");
					FillDataTable(stringBuilder.ToString(), CommandType.Text, out outMessage);
					
					#endregion
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during process: " + jsonMessage;
				}
				rc.LogOut();
			}
			else
			{
				responseModel.ResponseText = "Service layer login failed";
			}
			return responseModel;
		}
		public ResponseModel Update(GangupModel model)
		{
			string headerTable = CommonTables.GangupHeaderTable;
			string rowTable = CommonTables.GangupRowTable;
			string objectType = Convert.ToString((int)ObjectType.StockTransfers);//VCJBSM
			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();
			GangupModel _objServiceLayer = new GangupModel();

			#region Header
			_objServiceLayer.Series = model.Series;
			_objServiceLayer.DocNum = model.DocNum;
			_objServiceLayer.DocEntry = model.DocEntry;
			_objServiceLayer.U_SlpCode = model.U_SlpCode;
			_objServiceLayer.U_CardCode = model.U_CardCode;
			_objServiceLayer.U_ItmGrp = model.U_ItmGrp;
			_objServiceLayer.U_TNoOfSheet = model.U_TNoOfSheet;
			_objServiceLayer.U_TNoOfUPS = model.U_TNoOfUPS;
			_objServiceLayer.U_TotNInk = model.U_TotNInk;
			DateTime dtDate = new DateTime();
			if (model.U_DocDate.Contains("-"))
			{
				dtDate = DateTime.ParseExact(model.U_DocDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
			}
			else
			{
				dtDate = DateTime.ParseExact(model.U_DocDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
			}
			_objServiceLayer.U_DocDate = dtDate.ToString("yyyyMMdd");
			#endregion

			#region Gangup Rows

			int modelRow = 0;
			List<GangupRowsModel> modelLines_ServiceLayer = new List<GangupRowsModel>();
			model.WEB_GANGUP1Collection = model.WEB_GANGUP1Collection.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
			for (int i = 0; i < model.WEB_GANGUP1Collection.Count; i++)
			{
				if (!string.IsNullOrEmpty(model.WEB_GANGUP1Collection[i].U_ItemCode))
				{
					modelLines_ServiceLayer.Add(new GangupRowsModel { });

					modelLines_ServiceLayer[modelRow].LineId = model.WEB_GANGUP1Collection[i].LineId;
					modelLines_ServiceLayer[modelRow].U_ItemCode = model.WEB_GANGUP1Collection[i].U_ItemCode;
					modelLines_ServiceLayer[modelRow].U_ItemName = model.WEB_GANGUP1Collection[i].U_ItemName;
					modelLines_ServiceLayer[modelRow].U_SOQty = model.WEB_GANGUP1Collection[i].U_SOQty;
					modelLines_ServiceLayer[modelRow].U_NoOfUPS = model.WEB_GANGUP1Collection[i].U_NoOfUPS;
					modelLines_ServiceLayer[modelRow].U_JobQty = model.WEB_GANGUP1Collection[i].U_JobQty;
					modelLines_ServiceLayer[modelRow].U_KLDNo = model.WEB_GANGUP1Collection[i].U_KLDNo;
					modelLines_ServiceLayer[modelRow].U_Rate = model.WEB_GANGUP1Collection[i].U_Rate;
					modelLines_ServiceLayer[modelRow].U_AppArt = model.WEB_GANGUP1Collection[i].U_AppArt;
					modelRow++;
				}
			}
			#endregion

			_objServiceLayer.WEB_GANGUP1Collection = modelLines_ServiceLayer;

			string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
			{
				NullValueHandling = NullValueHandling.Ignore,
			});
			var temp = JsonConvert.DeserializeObject<JObject>(main);

			string serviceLayerObject = "";
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				serviceLayerObject = ServiceLayerEntity.WEB_GANGUP.ToString();
				rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject + "(" + model.DocEntry + ")";
				rc.patchJSON = main;
				rc.B1SESSION = res;
				rc.httpMethod = httpVerb.PATCH;
				string message = "";
				bool result = rc.postRequest(out message);
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during process: " + jsonMessage;
				}
				rc.LogOut();
			}
			else
			{
				responseModel.ResponseText = "Service layer login failed";
			}
			return responseModel;
		}
		public List<CopyDocumentModel> GetGangupData(string cardcode)
		{
			List<CopyDocumentModel> _list = new List<CopyDocumentModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"DocEntry\" ,T0.\"DocNum\" ,TO_NVARCHAR(T0.\"U_DocDate\", 'DD/MM/YYYY') as \"DocDate\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_GANGUP\" T0 ");
				//stringBuilder.Append(" WHERE T0.\"U_ClientCod\"  = '" + cardcode + "' ");
				stringBuilder.Append(" WHERE T0.\"U_CardCode\"  = '" + cardcode + "' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<CopyDocumentModel>(datatable);

				}
			}
			catch
			{

			}
			return _list;
		}
		public List<GangupRowsModel> GetGangupSelectedData(string docEntry)
		{
			List<GangupRowsModel> model = new List<GangupRowsModel>();
			try
			{
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"U_ItemCode\", T0.\"U_ItemName\", T0.\"U_SOQty\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_GANGUP1\" T0 ");
				stringBuilder.Append(" WHERE");
				stringBuilder.Append(" T0.\"DocEntry\" = '" + docEntry + "' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					model = ConvertDatatableToList.ConvertToList<GangupRowsModel>(datatable);
				}
			}
			catch
			{

			}
			return model;
		}
		public List<ItemModel> GetAllChildItemDetails(string itemcode)
		{
			List<ItemModel> _list = new List<ItemModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T1.\"Code\" AS \"ItemCode\",T2.\"ItemName\",T3.\"ItmsGrpNam\",T2.\"U_InkType\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"OITT\" T0 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"ITT1\" T1 ON T0.\"Code\" = T1.\"Father\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"OITM\" T2 ON T1.\"Code\" = T2.\"ItemCode\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"OITB\" T3 ON T2.\"ItmsGrpCod\" = T3.\"ItmsGrpCod\" ");
				stringBuilder.Append(" WHERE T0.\"Code\" = '" + itemcode + "' ");
				stringBuilder.Append(" AND T3.\"ItmsGrpNam\" LIKE 'Ink%'  ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<ItemModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}

		public string GetAllChildItemDetailsColor(string itemcode)
		{
			string color = string.Empty;
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T2.\"U_InkType\"  AS \"ID\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"OITT\" T0 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"ITT1\" T1 ON T0.\"Code\" = T1.\"Father\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"OITM\" T2 ON T1.\"Code\" = T2.\"ItemCode\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"OITB\" T3 ON T2.\"ItmsGrpCod\" = T3.\"ItmsGrpCod\" ");
				stringBuilder.Append(" WHERE T0.\"Code\" = '" + itemcode + "' ");
				stringBuilder.Append(" AND T3.\"ItmsGrpNam\" LIKE 'Ink%'  ");
				//stringBuilder.Append(" AND T2.\"U_InkType\" IS NOT NULL  ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					List<CommonValueModel> _list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
					color = string.Join(",", _list.Where(a => a.ID != null).Select(x => x.ID));
				}
			}
			catch
			{

			}
			return color;
		}

		public string GetTotalNoofInk(string itemcodes)
		{
			int iTotalCount = 0;
			try
			{
				List<string> itemList = itemcodes.Split(',').ToList<string>();
				string itemWithSingleQuotes = "'" + string.Join("','", itemList) + "'";

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT DISTINCT T0.\"Code\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"ITT1\" T0 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"OITM\" T1 ON T0.\"Code\" = T1.\"ItemCode\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"OITB\" T2 ON T1.\"ItmsGrpCod\" = T2.\"ItmsGrpCod\" ");
				stringBuilder.Append(" WHERE T0.\"Father\"  IN (" + itemWithSingleQuotes + ") ");
				stringBuilder.Append(" AND T2.\"ItmsGrpNam\" LIKE 'Ink%'  ");

				stringBuilder.Append(" UNION ALL  ");

				stringBuilder.Append(" SELECT DISTINCT T0.\"ItemCode\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"OITM\" T0 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"OITB\" T2 ON T0.\"ItmsGrpCod\" = T2.\"ItmsGrpCod\" ");
				stringBuilder.Append(" WHERE T0.\"ItemCode\"  IN (" + itemWithSingleQuotes + ") AND T0.\"TreeType\"= 'N' ");
				stringBuilder.Append(" AND T2.\"ItmsGrpNam\" LIKE 'Ink%'  ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					iTotalCount = datatable.Rows.Count;
				}
			}
			catch
			{

			}
			return iTotalCount.ToString();
		}

		public GangupModel GetClientPOGangupData(string docEntry, string lineNo)
		{
			GangupModel model = new GangupModel();
			try
			{
				string headerTable = CommonTables.ClientPORegisterHeaderTable;
				string rowTable = CommonTables.ClientPORegisterRowTable;
				HanaParameter[] parameters = new HanaParameter[2];

				parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
				parameters[0].Value = docEntry;


				parameters[1] = new HanaParameter("LineId", System.Data.SqlDbType.VarChar);
				parameters[1].Value = lineNo;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"U_CardCode\",T0.\"U_CardName\" AS \"CardName\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + headerTable + "\" T0 ");
				stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						model = ConvertDatatableToList.ConvertToEntity<GangupModel>(datatable);
					}
				}

				#region Row
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"LineId\",T0.\"LineId\" As \"Index\",  T0.\"U_ItemCode\" ,T0.\"U_ItemName\", T0.\"U_Qty\" As \"U_SOQty\" ");
				stringBuilder.Append(" ,T0.\"U_RateSys\" AS \"U_Rate\" ,T0.\"U_AppArt\",T0.\"U_KLDNo\" ");
				stringBuilder.Append(" ,T0.\"DocEntry\" \"U_BaseEn\", T0.\"LineId\" \"U_BaseLine\" ");
				//stringBuilder.Append(" ,T0.\"U_Qty\", T0.\"U_Rate\" , T0.\"U_RateSys\" , T0.\"U_AppArt\" ,T0.\"U_ArtAttach\" ");
				//stringBuilder.Append(" , TO_NVARCHAR( T0.\"U_FromDate\", 'DD-MM-YYYY') AS \"U_FromDate\" , TO_NVARCHAR( T0.\"U_ToDate\", 'DD-MM-YYYY') AS \"U_ToDate\"  ");
				//stringBuilder.Append(" ,T0.\"U_GangJob\", T0.\"U_BomType\" , T0.\"U_NoOfUPS\" , T0.\"U_RefId\", T0.\"U_IsGang\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + rowTable + "\" T0 ");
				stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " AND T0.\"U_IsGang\" = 'Y' AND T0.\"LineId\" in (" + lineNo + ") ");//AND T0.\"U_AppArt\" = 'N'
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						List<GangupRowsModel> modelRows = ConvertDatatableToList.ConvertToList<GangupRowsModel>(datatable);
						model.WEB_GANGUP1Collection = modelRows;
					}
					else
					{
						List<GangupRowsModel> ClientPORegisterList = new List<GangupRowsModel>();
						GangupRowsModel clientPORegisterRowsModel = new GangupRowsModel();
						ClientPORegisterList.Add(clientPORegisterRowsModel);
						model.WEB_GANGUP1Collection = ClientPORegisterList;
					}
				}
				#endregion
			}
			catch
			{

			}
			return model;
		}

	}
}