﻿using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Sap.Data.Hana;
using System.Text;

namespace WebDAL.Repository
{
    public class AccountRepository : clsDataAccess, IAccountRepository
    {
        string query = "";
        public ResponseModel ValidateLogin(LoginModel loginModel)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                HanaParameter[] parameters = new HanaParameter[2];
                parameters[0] = new HanaParameter("UserCode", SqlDbType.VarChar);
                parameters[0].Value = loginModel.UserCode == null ? string.Empty : loginModel.UserCode.ToUpper();

                parameters[1] = new HanaParameter("OTP", SqlDbType.VarChar);
                parameters[1].Value = loginModel.OTP;
                //query = "SELECT * FROM "  + ConfigManager.GetSAPDatabase() +  ".OHEM";
                query = ConfigManager.GetSAPDatabase() + ".\"Web_Account_Login\"";
                using (DataTable datatable = FillDataTable(query, CommandType.StoredProcedure, out string message, parameters))
                {
                    if (datatable.Rows.Count > 0)
                    {
                        string value = datatable.Rows[0][0].ToString();
                        if (value == string.Empty)
                        {
                            responseModel.ResponseStatus = false;
                            responseModel.ResponseText = "Invalid Credentials";
                        }
                        else
                        {
                            responseModel.ResponseStatus = true;
                            responseModel.ResponseText = "Login Successful";
                            UpdateOTP(loginModel.UserCode, "");
                        }
                    }
                    else
                    {
                        responseModel.ResponseStatus = false;
                        responseModel.ResponseText = "Invalid Credentials/User does not tagged in employee master";
                    }
                }
            }
            catch (Exception ex)
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = ex.InnerException.Message;
            }
            return responseModel;
        }

        public ResponseModel UpdateOTP(string emailId, string otp)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                HanaParameter[] parameters = new HanaParameter[2];

                parameters[0] = new HanaParameter("UserId", System.Data.SqlDbType.VarChar);
                parameters[0].Value = emailId;

                parameters[1] = new HanaParameter("OTP", System.Data.SqlDbType.VarChar);
                parameters[1].Value = otp;

                query = "UPDATE " + ConfigManager.GetSAPDatabase() + ".OHEM SET \"U_OTP\"=:OTP WHERE \"email\" =:UserId ";

                using (DataTable datatable = FillDataTable(query, CommandType.Text, out string message, parameters))
                {
                    responseModel.ResponseStatus = true;
                    responseModel.ResponseText = "OTP generated Successful";
                    //if (datatable.Rows.Count > 0)
                    //{
                    //    string value = datatable.Rows[0][0].ToString();
                    //    if (value == string.Empty)
                    //    {
                    //        responseModel.ResponseStatus = false;
                    //        responseModel.ResponseText = "Invalid user Id";
                    //    }
                    //    else
                    //    {
                    //        responseModel.ResponseStatus = true;
                    //        responseModel.ResponseText = "OTP generated Successful";
                    //    }
                    //}
                    //else
                    //{
                    //    responseModel.ResponseStatus = false;
                    //    responseModel.ResponseText = message;
                    //}
                }

            }
            catch
            {

            }
            return responseModel;
        }

        public UserModel GetUserDetails(string emailId)
        {
            UserModel userModel = new UserModel();
            userModel.ResponseMessage = "";
            try
            {
                HanaParameter[] parameters = new HanaParameter[1];

                parameters[0] = new HanaParameter("UserId", System.Data.SqlDbType.VarChar);
                parameters[0].Value = emailId.ToUpper();

                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"empID\",T0.\"email\" as \"EmailAddress\",T1.\"Name\" as \"Department\",T0.\"dept\" AS \"DepartmentId\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OHEM T0");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OUDP T1 ON T0.\"dept\" = T1.\"Code\" ");
                //stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OUSR T2 ON T0.\"userId\" = T2.\"USERID\" ");
                stringBuilder.Append(" WHERE UPPER(T0.\"email\") =:UserId");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                {
                    userModel = ConvertDatatableToList.ConvertToEntity<UserModel>(datatable);
                    if (userModel == null)
                    {
                        userModel = new UserModel();
                        userModel.ResponseMessage = "User does not exist: " + message;
                    }
                    else
                    {
                        userModel.ResponseMessage = "1";
                    }
                }
            }
            catch (Exception ex)
            {
                userModel.ResponseMessage = ex.Message;
            }
            return userModel;
        }

        public List<CommonValueModel> GetUserDeptFormList(string emailId)
        {
            List<CommonValueModel> list = new List<CommonValueModel>();
            try
            {
                HanaParameter[] parameters = new HanaParameter[1];

                parameters[0] = new HanaParameter("UserId", System.Data.SqlDbType.VarChar);
                parameters[0].Value = emailId.ToUpper();

                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T1.\"U_Action\" AS \"ID\",T1.\"U_MainMenu\" as \"Name\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OHEM T0 ");
                stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"@WEB_DEPT_FORM1\" T1 ON T0.\"U_DeptRole\" = T1.\"Code\" ");
                stringBuilder.Append(" WHERE UPPER(T0.\"email\") =:UserId AND T1.\"U_Action\" IS NOT NULL");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                {
                    list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
                }
            }
            catch (Exception ex)
            {
            }
            return list;
        }

        public string GetEmailFromMacID(string deviceID)
        {
            string emailID = "";
            try
            {
                HanaParameter[] parameters = new HanaParameter[1];

                parameters[0] = new HanaParameter("DeviceID", System.Data.SqlDbType.VarChar);
                parameters[0].Value = deviceID.ToUpper();

                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"email\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OHEM T0");
                stringBuilder.Append(" WHERE UPPER(T0.\"U_MACID\") =:DeviceID");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                {
                    if (datatable.Rows.Count > 0)
                    {
                        emailID = datatable.Rows[0][0].ToString();

                    }
                }
            }
            catch (Exception ex)
            {
            }
            return emailID;
        }

    }
}
