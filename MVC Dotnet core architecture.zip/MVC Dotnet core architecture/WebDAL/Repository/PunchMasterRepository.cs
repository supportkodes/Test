﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sap.Data.Hana;
using WebDAL.Helper;
using WebDAL.Helpers;
using WebDAL.IRepository;
using WebDAL.Models;
using static WebDAL.Models.PunchMasterModel;

namespace WebDAL.Repository
{
    public class PunchMasterRepository : clsDataAccess, IPunchMasterRepository
    {
        string query = "";
        CommonRepository commonRepository = new CommonRepository();
        StringBuilder stringBuilder = new StringBuilder();
        string headerTable = CommonTables.PUNCHHeaderTable;
        string rowTable = CommonTables.PUNCHRowTable;
        public List<PunchMasterModel> GetAll()
        {
            List<PunchMasterModel> _list = new List<PunchMasterModel>();
            try
            {
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT ROW_NUMBER() OVER(order by cast(T0.\"Code\" As int)) AS \"RowNo\"");
                stringBuilder.Append(" ,T0.\"Code\",T0.\"U_NoOfUps\", T0.\"U_SizeX\", T0.\"U_SizeY\"");//T0.\"U_CardCode\",T1.\"CardName\"
                stringBuilder.Append(" ,T0.\"U_PunchNo\",T11.\"U_ItemCode\" , T2.\"ItemName\", T5.\"Location\" , T0.\"U_Remark\" ");
                stringBuilder.Append(" ,TO_NVARCHAR(T0.\"U_PunchDt\", 'DD/MM/YYYY') AS \"U_PunchDt\" ,T0.\"U_SuppCode\",T3.\"CardName\" AS \"SuppName\"");
                stringBuilder.Append(" ,T0.\"U_PunchTyp\",T0.\"U_Emboss\" ,T0.\"U_Striping\" ,T0.\"U_Foil\", T4.\"U_NAME\"");
                stringBuilder.Append(" ,T13.\"U_KLDNo\" ,TO_NVARCHAR(T13.\"U_KLDDt\", 'DD/MM/YYYY') AS \"U_KLDDt\",T14.\"U_Desc\" AS \"U_CartTyp\"");
                stringBuilder.Append(" ,TO_NVARCHAR(T0.\"U_PunRecDt\", 'DD/MM/YYYY') AS \"U_PunRecDt\",TO_NVARCHAR(T0.\"U_PunSenDt\", 'DD/MM/YYYY') AS \"U_PunSenDt\"");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PUNCH\" T0 ");
                // stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCRD T1 ON T0.\"U_CardCode\"=T1.\"CardCode\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PUNCH1\" T11 ON T11.\"U_BaseCode\"=T0.\"Code\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OITM T2 ON T11.\"U_ItemCode\"=T2.\"ItemCode\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCRD T3 ON T3.\"CardCode\"=T0.\"U_SuppCode\" AND T3.\"CardType\" = 'S'");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OUSR T4 ON T0.\"U_CrBy\"=T4.\"USERID\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OLCT T5 ON T0.\"U_Location\"= CAST(T5.\"Code\" as varchar(100)) ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"@WEB_KLD1\" T12 ON T12.\"U_BaseCode\"=T0.\"Code\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"@WEB_KLD\" T13 ON T13.\"U_KLDNo\"=T11.\"U_KLDNo\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"@DDMASTER1\" T14 ON T0.\"U_CartTyp\"=T14.\"U_Value\" AND T14.\"Code\"='CARTONTYPE' ");

                stringBuilder.Append(" ORDER BY Cast(T0.\"Code\" as numeric(19,0)) DESC ");

                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    _list = ConvertDatatableToList.ConvertToList<PunchMasterModel>(datatable);
                }
            }
            catch
            {
            }
            return _list;
        }
        public PunchMasterModel Get(string code)
        {
            PunchMasterModel model = new PunchMasterModel();
            try
            {
                HanaParameter[] parameters = new HanaParameter[1];

                parameters[0] = new HanaParameter("Code", System.Data.SqlDbType.VarChar);
                parameters[0].Value = code;

                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"Code\", T0.\"U_NoOfUps\", T0.\"U_SizeX\", T0.\"U_SizeY\" ");
                stringBuilder.Append(" ,T0.\"U_PunchNo\",T0.\"U_Location\" , T0.\"U_Remark\" ");//, T0.\"U_CardCode\"
                stringBuilder.Append(" ,T0.\"U_SuppCode\",T3.\"CardName\" AS \"SuppName\"");
                stringBuilder.Append(" ,TO_NVARCHAR(T0.\"U_PunchDt\", 'DD-MM-YYYY') AS \"U_PunchDt\" ");
                stringBuilder.Append(" ,TO_NVARCHAR(T0.\"U_PunRecDt\", 'DD-MM-YYYY') AS \"U_PunRecDt\" ");
                stringBuilder.Append(" ,TO_NVARCHAR(T0.\"U_PunSenDt\", 'DD-MM-YYYY') AS \"U_PunSenDt\" ");
                stringBuilder.Append(" ,T0.\"U_PunchTyp\",T0.\"U_Emboss\" ,T0.\"U_Striping\" ,T0.\"U_Foil\", T4.\"U_NAME\"");
                stringBuilder.Append(" ,T0.\"U_CartTyp\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PUNCH\" T0 ");
                // stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCRD T1 ON T0.\"U_CardCode\"=T1.\"CardCode\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCRD T3 ON T3.\"CardCode\"=T0.\"U_SuppCode\" AND T3.\"CardType\" = 'S'");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OUSR T4 ON T0.\"U_CrBy\"=T4.\"USERID\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PUNCH1\" T5 ON T5.\"U_BaseCode\"=T0.\"Code\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OITM T6 ON T5.\"U_ItemCode\"=T6.\"ItemCode\" ");
                stringBuilder.Append(" WHERE T0.\"Code\" = " + code + " ");//AND T5.\"U_ItemCode\" = '" + itemcode + "'

                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    if (datatable.Rows.Count > 0)
                    {
                        model = ConvertDatatableToList.ConvertToEntity<PunchMasterModel>(datatable);
                        if (datatable.Rows[0]["U_Emboss"].ToString() == "Y")
                        {
                            model.IsEmboss = true;
                        }
                        if (datatable.Rows[0]["U_Striping"].ToString() == "Y")
                        {
                            model.IsStriping = true;
                        }
                        if (datatable.Rows[0]["U_Foil"].ToString() == "Y")
                        {
                            model.IsFoil = true;
                        }
                    }
                }
                #region Row
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT ROW_NUMBER() OVER (ORDER BY T0.\"Code\") AS \"Index\",T0.\"Code\" as \"LineId\",T0.\"U_KLDNo\",T0.\"U_NoofUPS\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PUNCH1\" T0 ");
                //stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OITM T1 ON T0.\"U_ItemCode\"=T1.\"ItemCode\" ");
                stringBuilder.Append(" WHERE T0.\"U_BaseCode\" = :code ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                {
                    List<PunchMasterRowsModel> modelRows = ConvertDatatableToList.ConvertToList<PunchMasterRowsModel>(datatable);
                    model.Rows = modelRows;
                }
                #endregion
            }
            catch
            {

            }
            return model;
        }
        public ResponseModel Add(PunchMasterModel model)
        {
            string message = "";
            ResponseModel responseModel = new ResponseModel();
            try
            {
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT MAX(Cast(\"Code\" AS INT)) + 1 FROM   " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PUNCH\" ");
                DataTable dt = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
                string code = dt.Rows[0][0].ToString();
                if (code == string.Empty)
                {
                    code = "1";
                }
                string Emboss = model.IsEmboss == true ? "Y" : "N";
                string Striping = model.IsStriping == true ? "Y" : "N";
                string Foil = model.IsFoil == true ? "Y" : "N";
                DateTime punchdt = DateTime.ParseExact(model.U_PunchDt, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                //DateTime punrecdt = DateTime.ParseExact(model.U_PunRecDt, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                //DateTime punsendt = DateTime.ParseExact(model.U_PunSenDt, "dd-MM-yyyy", CultureInfo.InvariantCulture);

                stringBuilder = new StringBuilder();
                stringBuilder.Append(" INSERT INTO  " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PUNCH\"(\"Code\",\"Name\" ");
                // stringBuilder.Append(" ,\"U_CardCode\" ");
                stringBuilder.Append(" , \"U_PunchNo\" ");
                stringBuilder.Append(" , \"U_PunchDt\" ");
                //stringBuilder.Append(" , \"U_PunRecDt\" ");
                //stringBuilder.Append(" , \"U_PunSenDt\" ");
                if (!string.IsNullOrEmpty(model.U_Location))
                {
                    stringBuilder.Append(" ,\"U_Location\" ");
                }
                if (!string.IsNullOrEmpty(model.U_NoOfUps))
                {
                    stringBuilder.Append(" ,\"U_NoOfUps\" ");
                }
                if (model.U_Remark != null)
                {
                    stringBuilder.Append(" ,\"U_Remark\" ");
                }
                if (!string.IsNullOrEmpty(model.U_SizeX))
                {
                    stringBuilder.Append(" ,\"U_SizeX\"");
                }
                if (!string.IsNullOrEmpty(model.U_SizeY))
                {
                    stringBuilder.Append(" ,\"U_SizeY\"");
                }
                if (!string.IsNullOrEmpty(model.U_PunRecDt))
                {
                    stringBuilder.Append(" ,\"U_PunRecDt\"");
                }
                if (!string.IsNullOrEmpty(model.U_PunSenDt))
                {
                    stringBuilder.Append(" ,\"U_PunSenDt\"");
                }
                stringBuilder.Append(" ,\"U_CrBy\" ,\"U_SuppCode\"");
                stringBuilder.Append(" ,\"U_PunchTyp\",\"U_Emboss\" , \"U_Striping\" , \"U_Foil\", \"U_CartTyp\" ");
                stringBuilder.Append("  ) ");
                stringBuilder.Append(" VALUES('" + code + "','" + code + "'");
                // stringBuilder.Append(" ,'" + model.U_CardCode + "'   ");
                stringBuilder.Append(" ,'" + model.U_PunchNo + "'  ");
                stringBuilder.Append(" ,'" + punchdt.ToString("yyyMMdd") + "' ");
                //stringBuilder.Append(" ,'" + punrecdt.ToString("yyyMMdd") + "' ");
                //stringBuilder.Append(" ,'" + punsendt.ToString("yyyMMdd") + "' ");
                if (!string.IsNullOrEmpty(model.U_Location))
                {
                    stringBuilder.Append(" ,'" + model.U_Location + "' ");
                }
                if (!string.IsNullOrEmpty(model.U_NoOfUps))
                {
                    stringBuilder.Append(" ,'" + model.U_NoOfUps + "' ");
                }
                if (model.U_Remark != null)
                {
                    stringBuilder.Append(" ,'" + model.U_Remark.Replace("'", "''") + "' ");
                }
                if (!string.IsNullOrEmpty(model.U_SizeX))
                {
                    stringBuilder.Append(" ,'" + model.U_SizeX + "'");
                }
                if (!string.IsNullOrEmpty(model.U_SizeY))
                {
                    stringBuilder.Append(" ,'" + model.U_SizeY + "' ");
                }
                if (!string.IsNullOrEmpty(model.U_PunRecDt))
                {
                    stringBuilder.Append(" ,'" + DateTime.ParseExact(model.U_PunRecDt, "dd-MM-yyyy", CultureInfo.InvariantCulture).ToString("yyyMMdd") + "' ");
                }
                if (!string.IsNullOrEmpty(model.U_PunSenDt))
                {
                    stringBuilder.Append(" ,'" + DateTime.ParseExact(model.U_PunSenDt, "dd-MM-yyyy", CultureInfo.InvariantCulture).ToString("yyyMMdd") + "' ");
                }
                stringBuilder.Append(" ,'" + model.U_CrBy + "','" + model.U_SuppCode + "','" + model.U_PunchTyp + "' , '" + Emboss + "' ");
                stringBuilder.Append(" ,'" + Striping + "','" + Foil + "','" + model.U_CartTyp + "' ");
                stringBuilder.Append("  ) ");
                FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
                if (message == string.Empty)
                {
                    responseModel.ResponseText = "Operation completed successfully";
                    responseModel.ResponseStatus = true;
                    AddRows(code, model.Rows);
                    UpdateNextNumber("WEB_KLD_PUNCH", model.U_PunchNo);
                }
                else
                {
                    responseModel.ResponseText = "Error occured during process: " + message;
                }
            }
            catch (Exception ex)
            {
                responseModel.ResponseText = "Error occured during process: " + ex.Message;
                responseModel.ResponseStatus = false;
            }
            return responseModel;
        }
        public ResponseModel Update(PunchMasterModel model)
        {
            ResponseModel responseModel = new ResponseModel();
            string message = "";
            DateTime punchDate = DateTime.ParseExact(model.U_PunchDt, "dd-MM-yyyy", CultureInfo.InvariantCulture);
            //DateTime punrecDate = DateTime.ParseExact(model.U_PunRecDt, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            //DateTime punsenDate = DateTime.ParseExact(model.U_PunSenDt, "dd/MM/yyyy", CultureInfo.InvariantCulture);

            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PUNCH\" ");
            stringBuilder.Append("  SET \"U_PunchDt\" = '" + punchDate.ToString("yyyyMMdd") + "' ");//\"U_CardCode\" = '" + model.U_CardCode + "'
            if (!string.IsNullOrEmpty(model.U_PunRecDt))
            {
                stringBuilder.Append(" ,\"U_PunRecDt\" = '" + DateTime.ParseExact(model.U_PunRecDt, "dd-MM-yyyy", CultureInfo.InvariantCulture).ToString("yyyyMMdd") + "' ");
            }
            if (!string.IsNullOrEmpty(model.U_PunSenDt))
            {
                stringBuilder.Append(" ,\"U_PunSenDt\" = '" + DateTime.ParseExact(model.U_PunSenDt, "dd-MM-yyyy", CultureInfo.InvariantCulture).ToString("yyyyMMdd") + "' ");
            }
            stringBuilder.Append(" ,\"U_NoOfUps\" = '" + model.U_NoOfUps + "',\"U_PunchNo\" = '" + model.U_PunchNo + "' ");

            if (!string.IsNullOrEmpty(model.U_SizeX))
            {
                stringBuilder.Append(" ,\"U_SizeX\" = '" + model.U_SizeX + "' ");
            }
            else
            { 
                stringBuilder.Append(" ,\"U_SizeX\" = NULL ");
			}

			if (!string.IsNullOrEmpty(model.U_SizeY))
			{
				stringBuilder.Append(" ,\"U_SizeY\" = '" + model.U_SizeY + "' ");
			}
			else
			{
				stringBuilder.Append(" ,\"U_SizeY\" = NULL ");
			}

			stringBuilder.Append(" ,\"U_Location\" = '" + model.U_Location + "',\"U_Remark\" = '" + model.U_Remark + "' ");//, \"U_ItemCode\" = '" + model.U_ItemCode + "'
            stringBuilder.Append(" ,\"U_PunchTyp\" = '" + model.U_PunchTyp + "' ,\"U_SuppCode\" = '" + model.U_SuppCode + "' ");
            stringBuilder.Append(" , \"U_Emboss\" = '" + model.U_Emboss + "',\"U_Striping\" = '" + model.U_Striping + "',\"U_Foil\" = '" + model.U_Foil + "'");
            stringBuilder.Append(" , \"U_CartTyp\" = '" + model.U_CartTyp + "' ");
            stringBuilder.Append(" WHERE \"Code\" = '" + model.Code + "'");

            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (message == string.Empty)
            {
                responseModel.ResponseStatus = true;
                responseModel.ResponseText = "Updated successfully";
                AddRows(model.Code, model.Rows);
            }
            else
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            return responseModel;
        }
        public ResponseModel AddRows(string basecode, List<PunchMasterRowsModel> modelRows)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                stringBuilder = new StringBuilder();
                stringBuilder.Append("DELETE FROM " + ConfigManager.GetSAPDatabase() + ".\"" + rowTable + "\" WHERE \"U_BaseCode\" ='" + basecode + "' ");
                GetRecordValue(stringBuilder.ToString(), CommandType.Text, out string message);
                for (int i = 0; i < modelRows.Count; i++)
                {
                    stringBuilder = new StringBuilder();
                    stringBuilder.Append("SELECT IFNULL(MAX(Cast(\"Code\" as NUMERIC(19,0))),0) + 1   FROM " + ConfigManager.GetSAPDatabase() + ".\"" + rowTable + "\" ");
                    string code = GetRecordValue(stringBuilder.ToString(), CommandType.Text, out message);

                    HanaParameter[] parameters = new HanaParameter[5];
                    int iParameter = 0;

                    parameters[iParameter] = new HanaParameter("Code", System.Data.SqlDbType.VarChar);
                    parameters[iParameter].Value = code;
                    iParameter++;

                    parameters[iParameter] = new HanaParameter("Name", System.Data.SqlDbType.VarChar);
                    parameters[iParameter].Value = code;
                    iParameter++;

                    parameters[iParameter] = new HanaParameter("U_BaseCode", System.Data.SqlDbType.VarChar);
                    parameters[iParameter].Value = basecode;
                    iParameter++;
                    //parameters[iParameter] = new HanaParameter("U_ItemCode", System.Data.SqlDbType.VarChar);
                    //parameters[iParameter].Value = modelRows[i].U_ItemCode == null ? (Object)DBNull.Value : modelRows[i].U_ItemCode;
                    //iParameter++;
                    parameters[iParameter] = new HanaParameter("U_KLDNo", System.Data.SqlDbType.VarChar);
                    parameters[iParameter].Value = modelRows[i].U_KLDNo == null ? (Object)DBNull.Value : modelRows[i].U_KLDNo;
                    iParameter++;

                    parameters[iParameter] = new HanaParameter("U_NoofUPS", System.Data.SqlDbType.VarChar);
                    parameters[iParameter].Value = modelRows[i].U_NoofUPS == null ? (Object)DBNull.Value : modelRows[i].U_NoofUPS;
                    iParameter++;

                    stringBuilder = new StringBuilder();
                    stringBuilder.Append(" INSERT INTO " + ConfigManager.GetSAPDatabase() + ".\"" + rowTable + "\"");
                    stringBuilder.Append(" (\"Code\",\"Name\",\"U_BaseCode\"");
                    stringBuilder.Append("  ,\"U_KLDNo\",\"U_NoofUPS\") ");//,\"U_ItemCode\"
                    stringBuilder.Append(" VALUES ");
                    stringBuilder.Append(" (:Code,:Name,:U_BaseCode ,:U_KLDNo,:U_NoofUPS) "); //,:U_ItemCode
                    DataTable dt = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message, parameters);
                    if (message == string.Empty)
                    {
                        responseModel.ResponseText = "Record inserted successfully";
                        responseModel.ResponseStatus = true;
                    }
                    else
                    {
                        responseModel.ResponseText = "Error occured while processing record " + message;
                        responseModel.ResponseStatus = false;
                    }
                }
            }
            catch (Exception ex)
            {
                responseModel.ResponseText = "Error occured while processing record " + ex.Message;
                responseModel.ResponseStatus = false;

            }
            return responseModel;
        }

        public ResponseModel AddBulkImport(PunchMasterModel model)
        {
            string message = "";
            ResponseModel responseModel = new ResponseModel();
            try
            {
                string code = model.Code; 
                string Emboss ="N";
                string Striping ="N";
                string Foil = "N";
                DateTime punchdt = DateTime.Now.Date;

                stringBuilder = new StringBuilder();
                stringBuilder.Append(" INSERT INTO  " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PUNCH\"(\"Code\",\"Name\" ");
                stringBuilder.Append(" , \"U_PunchNo\" ");
                stringBuilder.Append(" , \"U_PunchDt\" ");
                if (!string.IsNullOrEmpty(model.U_Location))
                {
                    stringBuilder.Append(" ,\"U_Location\" ");
                }
                if (!string.IsNullOrEmpty(model.U_NoOfUps))
                {
                    stringBuilder.Append(" ,\"U_NoOfUps\" ");
                }
                if (model.U_Remark != null)
                {
                    stringBuilder.Append(" ,\"U_Remark\" ");
                }
                if (!string.IsNullOrEmpty(model.U_SizeX))
                {
                    stringBuilder.Append(" ,\"U_SizeX\"");
                }
                if (!string.IsNullOrEmpty(model.U_SizeY))
                {
                    stringBuilder.Append(" ,\"U_SizeY\"");
                }
                if (!string.IsNullOrEmpty(model.U_PunRecDt))
                {
                    stringBuilder.Append(" ,\"U_PunRecDt\"");
                }
                if (!string.IsNullOrEmpty(model.U_PunSenDt))
                {
                    stringBuilder.Append(" ,\"U_PunSenDt\"");
                }
                stringBuilder.Append(" ,\"U_CrBy\" ,\"U_SuppCode\"");
                stringBuilder.Append(" ,\"U_PunchTyp\",\"U_Emboss\" , \"U_Striping\" , \"U_Foil\", \"U_CartTyp\" ");
                stringBuilder.Append("  ) ");
                stringBuilder.Append(" VALUES('" + code + "','" + code + "'");
                // stringBuilder.Append(" ,'" + model.U_CardCode + "'   ");
                stringBuilder.Append(" ,'" + model.U_PunchNo + "'  ");
                stringBuilder.Append(" ,'" + punchdt.ToString("yyyMMdd") + "' ");
                //stringBuilder.Append(" ,'" + punrecdt.ToString("yyyMMdd") + "' ");
                //stringBuilder.Append(" ,'" + punsendt.ToString("yyyMMdd") + "' ");
                if (!string.IsNullOrEmpty(model.U_Location))
                {
                    stringBuilder.Append(" ,'" + model.U_Location + "' ");
                }
                if (!string.IsNullOrEmpty(model.U_NoOfUps))
                {
                    stringBuilder.Append(" ,'" + model.U_NoOfUps + "' ");
                }
                if (model.U_Remark != null)
                {
                    stringBuilder.Append(" ,'" + model.U_Remark.Replace("'", "''") + "' ");
                }
                if (!string.IsNullOrEmpty(model.U_SizeX))
                {
                    stringBuilder.Append(" ,'" + model.U_SizeX + "'");
                }
                if (!string.IsNullOrEmpty(model.U_SizeY))
                {
                    stringBuilder.Append(" ,'" + model.U_SizeY + "' ");
                }
                if (!string.IsNullOrEmpty(model.U_PunRecDt))
                {
                    stringBuilder.Append(" ,'" + DateTime.ParseExact(model.U_PunRecDt, "dd-MM-yyyy", CultureInfo.InvariantCulture).ToString("yyyMMdd") + "' ");
                }
                if (!string.IsNullOrEmpty(model.U_PunSenDt))
                {
                    stringBuilder.Append(" ,'" + DateTime.ParseExact(model.U_PunSenDt, "dd-MM-yyyy", CultureInfo.InvariantCulture).ToString("yyyMMdd") + "' ");
                }
                stringBuilder.Append(" ,'" + model.U_CrBy + "','" + model.U_SuppCode + "','" + model.U_PunchTyp + "' , '" + Emboss + "' ");
                stringBuilder.Append(" ,'" + Striping + "','" + Foil + "','" + model.U_CartTyp + "' ");
                stringBuilder.Append("  ) ");
                FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
                if (message == string.Empty)
                {
                    responseModel.ResponseText = "Operation completed successfully";
                    responseModel.ResponseStatus = true;
                    AddRows(code, model.Rows);
                }
                else
                {
                    responseModel.ResponseText = "Error occured during process: " + message;
                }
            }
            catch (Exception ex)
            {
                responseModel.ResponseText = "Error occured during process: " + ex.Message;
                responseModel.ResponseStatus = false;
            }
            return responseModel;
        }
        private void UpdateNextNumber(string objectType, string code)
        {
            try
            {
                string first3Characters = code.Substring(0, 3);
                string newnumber = code.Substring(3, code.Length - 3);
                newnumber = Convert.ToString(Convert.ToInt32(newnumber) + 1);
                newnumber = first3Characters + newnumber.PadLeft(4, '0');

                stringBuilder = new StringBuilder();
                stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_SERIES1\" SET ");
                stringBuilder.Append(" \"U_NextNo\"= '" + newnumber + "' ");
                stringBuilder.Append(" WHERE \"Code\" = '" + objectType + "' ");
                FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message);
            }
            catch { }
        }
    }
}