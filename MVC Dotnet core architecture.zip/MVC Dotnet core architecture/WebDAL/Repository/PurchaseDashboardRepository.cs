﻿using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Sap.Data.Hana;
using System.Text;
using System.Net.Mail;
using System.Collections;

namespace WebDAL.Repository
{
	public class PurchaseDashboardRepository : clsDataAccess, IPurchaseDashboardRepository
	{
		StringBuilder stringBuilder = new StringBuilder();

		public List<PendingForApprovalModel> GetPendingForApprovalPurchaseOrder(string userId)
		{
			List<PendingForApprovalModel> _list = new List<PendingForApprovalModel>();
			try
			{
				CommonRepository commonRepository = new CommonRepository();
                string dbUserId = commonRepository.GetUserId(userId);
				//string usercode = commonRepository.GetUserId(emailAddress);

				HanaParameter[] parameters = new HanaParameter[1];
				parameters[0] = new HanaParameter("UserId", SqlDbType.VarChar);
				parameters[0].Value = dbUserId;
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"DocEntry\", T0.\"DocNum\",TO_NVARCHAR(\"DocDate\", 'DD/MM/YYYY')  AS \"DocDate\" ,\"CardName\" ");
				stringBuilder.Append(" ,CASE WHEN \"DocStatus\" = 'O' THEN 'Open' ELSE 'Closed' END AS \"DocStatus\"");
				stringBuilder.Append(" ,CASE WHEN \"DocType\" = 'I' THEN 'Item' ELSE 'Service' END AS \"VoucherType\"");
				stringBuilder.Append(" ,\"Comments\",\"NumAtCard\"  ");
				stringBuilder.Append(" ,Cast(T0.\"DocTotal\" as numeric(19,3)) as \"DocTotal\",Cast(T0.\"VatSum\" as numeric(19,3)) as \"TaxAmount\" ");
				stringBuilder.Append(" ,T1.\"U_AppUId\" AS \"AppUserId\",T1.\"U_IsApp\" AS \"IsApp\",T1.\"U_Rank\" as \"Rank\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".ODRF T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"@WEB_DOCAU\" T1 ON T0.\"DocEntry\" = T1.\"U_DraftEn\" ");
				stringBuilder.Append(" WHERE \"ObjType\" = '" + (int)ObjectType.PurchaseOrders + "' ");
				stringBuilder.Append(" AND T0.\"DocStatus\" = 'O' AND  T0.\"U_IsApp\" IS NULL AND T1.\"U_IsApp\" = 'Q' ");
				stringBuilder.Append(" AND T1.\"U_AppUId\" = :UserId ");
				//stringBuilder.Append(" AND T0.\"DocDate\" >= '2024-05-10' ");
				stringBuilder.Append(" ORDER BY \"DocEntry\" DESC ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					_list = ConvertDatatableToList.ConvertToList<PendingForApprovalModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}

		public List<PendingForApprovalItemModel> GetDraftPurchaseOrderItems(string docEntry)
		{
			List<PendingForApprovalItemModel> _list = new List<PendingForApprovalItemModel>();
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];
				parameters[0] = new HanaParameter("DocEntry", SqlDbType.VarChar);
				parameters[0].Value = docEntry == null ? string.Empty : docEntry;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"ItemCode\",T0.\"Dscription\",T0.\"Quantity\",T0.\"U_JCText\",T0.\"Text\",T0.\"U_ClientName\" , T2.\"OnHand\"");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".DRF1 T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OITM T1 ON T0.\"ItemCode\" = T1.\"ItemCode\" ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OITW T2 ON T2.\"ItemCode\" = T0.\"ItemCode\" AND T2.\"WhsCode\" = T0.\"WhsCode\" ");
				stringBuilder.Append(" WHERE T0.\"DocEntry\" = :DocEntry ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					_list = ConvertDatatableToList.ConvertToList<PendingForApprovalItemModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}

	}
}