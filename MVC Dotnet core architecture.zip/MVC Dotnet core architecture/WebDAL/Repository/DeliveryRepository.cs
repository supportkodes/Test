﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
//using Microsoft.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sap.Data.Hana;
using WebDAL.Helper;
using WebDAL.Helpers;
using WebDAL.IRepository;
using WebDAL.Models;

namespace WebDAL.Repository
{
    public class DeliveryRepository : clsDataAccess, IDeliveryRepository
    {
        CommonRepository commonRepository = new CommonRepository();
        StringBuilder stringBuilder = new StringBuilder();
        public List<DeliveryModel> GetAll(string userId)
        {
            List<DeliveryModel> _list = new List<DeliveryModel>();
            try
            {
                string isSuperUser = commonRepository.IsUserSuperUser(userId);
                string slpName = commonRepository.GetSlpNameFromEmailAddress(userId);
                string headerTable = CommonTables.DeliveryHeaderTable;

                HanaParameter[] parameters = new HanaParameter[1];

                parameters[0] = new HanaParameter("@UserId", System.Data.SqlDbType.VarChar);
                parameters[0].Value = userId;

                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"DocEntry\", T0.\"DocNum\",TO_NVARCHAR(T0.\"DocDate\", 'DD/MM/YYYY')  AS \"DocDate\" ,\"CardName\" ");
                stringBuilder.Append(" ,CASE WHEN \"DocStatus\" = 'O' THEN 'Open' ");
                stringBuilder.Append("  WHEN \"DocStatus\" = 'C' AND \"CANCELED\" = 'Y' THEN 'Cancelled' ELSE 'Closed' END AS \"DocStatus\"");
                stringBuilder.Append(" ,\"Comments\"  ");
                stringBuilder.Append(" ,\"NumAtCard\"  ");
                stringBuilder.Append(" ,T0.\"SlpCode\" AS \"SalesPersonCode\"  ");
                stringBuilder.Append(" ,T1.\"SlpName\"  ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + headerTable + " T0 ");
                stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OSLP T1 ON T0.\"SlpCode\"=T1.\"SlpCode\" ");
                stringBuilder.Append(" WHERE T0.\"DocStatus\" = 'O'  ");
                if (isSuperUser == "Y")
                {
                    stringBuilder.Append(" ORDER BY Case When T1.\"SlpName\" Like '" + slpName + "%' then 0 elSe 1 end,T0.\"DocDate\"  Desc ");
                }
                else
                {
                    stringBuilder.Append(" ORDER BY T0.\"DocEntry\" DESC ");
                }

                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    _list = ConvertDatatableToList.ConvertToList<DeliveryModel>(datatable);
                    if (isSuperUser != "Y")
                    {
                        List<SalesEmployeeModel> teamSalesEmployee = commonRepository.GetAllTeamSalesEmployee(userId);
                        _list = _list.Where(x => teamSalesEmployee.Any(y => y.SlpCode == x.SalesPersonCode)).ToList();
                    }
                    else
                    {
                    }
                }
            }
            catch
            {
            }
            return _list;
        }
        public DeliveryModel Get(string docEntry, string userId)
        {
            DeliveryModel model = new DeliveryModel();
            try
            {
                string slpcode = commonRepository.GetSlpCodeFromEmailAddress(userId);
                string headerTable = CommonTables.DeliveryHeaderTable;
                string rowTable = CommonTables.DeliveryRowTable;
                string freightTable = CommonTables.DeliveryFreightTable;
                string taxExtensionTable = CommonTables.DeliveryAddressTable;
                HanaParameter[] parameters = new HanaParameter[1];

                parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
                parameters[0].Value = docEntry;
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"DocEntry\",T0.\"DocNum\",T0.\"DocCur\" AS \"DocCurrency\",T0.\"DocRate\",T0.\"Series\",T2.\"SeriesName\" ");
                stringBuilder.Append(" ,T0.\"CardCode\",T0.\"CardName\",T0.\"NumAtCard\",TO_VARCHAR(T0.\"DocDate\", 'DD-MM-YYYY') \"DocDate\",TO_VARCHAR(T0.\"TaxDate\", 'DD-MM-YYYY') AS \"TaxDate\" ");
                stringBuilder.Append(" ,CASE WHEN \"DocStatus\" = 'O' THEN 'Open' ");
                stringBuilder.Append("  WHEN \"DocStatus\" = 'C' AND \"CANCELED\" = 'Y' THEN 'Cancelled' ELSE 'Closed' END AS \"DocStatus\"");
                stringBuilder.Append(" ,T0.\"BPLId\" AS \"BPL_IDAssignedToInvoice\",TO_VARCHAR(T0.\"DocDueDate\", 'DD-MM-YYYY') \"DocDueDate\" ");
                stringBuilder.Append(" ,T0.\"ShipToCode\",T0.\"PayToCode\",T0.\"TrnspCode\" AS \"TransportationCode\" ");
                stringBuilder.Append(" ,T0.\"OwnerCode\" AS \"DocumentsOwner\",T0.\"Comments\" ");
                stringBuilder.Append(" ,T0.\"DiscPrcnt\" AS \"DiscountPercent\" ");
                stringBuilder.Append(" ,T0.\"RoundDif\" AS \"RoundingDiffAmount\"  ");
                stringBuilder.Append(" ,CASE WHEN T0.\"DocRate\" = 1 THEN T0.\"VatSum\" ELSE T0.\"VatSumFC\"	END AS \"TaxAmount\" ");
                stringBuilder.Append(" ,CASE WHEN T0.\"DocRate\" = 1 THEN T0.\"DocTotal\" ELSE T0.\"DocTotalFC\" END AS \"DocumentTotal\" ");
                stringBuilder.Append(" ,CASE WHEN T0.\"DocRate\" = 1 THEN T0.\"TotalExpns\" ELSE T0.\"TotalExpFC\" END AS \"TotalExpns\" ");
                stringBuilder.Append(" ,T0.\"TotalExpns\"  ");
                stringBuilder.Append(" ,T3.\"State\" AS \"BillTo_State\"  ");
                stringBuilder.Append(" ,T4.\"State\" AS \"ShipTo_State\"  ");
                stringBuilder.Append(" ,T0.\"Address\"  ");
                stringBuilder.Append(" ,T0.\"Address2\"  ");
                stringBuilder.Append(" ,T0.\"AtcEntry\"  ");
                stringBuilder.Append(" ,T0.\"DutyStatus\"  ");
                stringBuilder.Append(" ,T0.\"U_MdTrns\",T0.\"U_PortDischarge\",T0.\"U_PortLoad\",T0.\"U_INCOTERMS\"  ");
                stringBuilder.Append(" ,T5.\"U_BPTL\" AS \"BPTolerancePercent\" ");
                stringBuilder.Append(" ,T5.\"U_BPLTL\" AS \"BPLowerTolerancePercent\" ");
                stringBuilder.Append(" ,T0.\"U_IsApp\" ");
                stringBuilder.Append(" ,T6.\"ImpORExp\" ,T6.\"ExportType\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + headerTable + " T0 ");
                stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OSLP T1 ON T0.\"SlpCode\" = T1.\"SlpCode\"  ");
                stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".NNM1 T2 ON T0.\"Series\" = T2.\"Series\"  ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".CRD1 T3 ON T0.\"CardCode\" = T3.\"CardCode\" AND T0.\"PayToCode\" = T3.\"Address\" AND T3.\"AdresType\"='B'  ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".CRD1 T4 ON T0.\"CardCode\" = T4.\"CardCode\" AND T0.\"ShipToCode\" = T4.\"Address\" AND T4.\"AdresType\"='S'  ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCRD T5 ON T0.\"CardCode\" = T5.\"CardCode\"  ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + "." + taxExtensionTable + " T6 ON T0.\"DocEntry\" = T6.\"DocEntry\"  ");
                stringBuilder.Append(" WHERE T0.\"DocEntry\" = :DocEntry ");

                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                {
                    if (datatable.Rows.Count > 0)
                    {
                        model = ConvertDatatableToList.ConvertToEntity<DeliveryModel>(datatable);
                    }
                }

                #region Row
                double docRate = double.Parse(model.DocRate);
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"VisOrder\" + 1 AS \"Index\",T0.\"LineNum\", T0.\"ItemCode\",T0.\"Dscription\" AS \"ItemName\" ");
                stringBuilder.Append(" ,T0.\"Quantity\",T0.\"TreeType\" ");
                stringBuilder.Append(" ,T0.\"SubCatNum\" \"SupplierCatNum\",T0.\"U_Category\",T0.\"FreeTxt\" AS \"FreeText\" ");
                stringBuilder.Append(" ,T0.\"U_CTOL\",T0.\"U_CTLOL\",T0.\"unitMsr\" \"MeasureUnit\",T0.\"WhsCode\" AS \"WarehouseCode\" ");
                stringBuilder.Append(" ,T0.\"TaxCode\",T2.\"Rate\" AS \"TaxRate\",T1.\"ChapterID\" AS \"HSNEntry\",T3.\"ChapterID\" AS \"HSNName\" ");
                stringBuilder.Append(" ,T0.\"U_UnwDrctn\",T0.\"U_Packng\" ");
                if (docRate == 1)
                {
                    stringBuilder.Append(" ,T0.\"PriceBefDi\" AS \"UnitPrice\",T0.\"LineTotal\" AS \"Total\" ");
                }
                else
                {
                    stringBuilder.Append(" ,T0.\"Price\" AS \"UnitPrice\",T0.\"TotalFrgn\" AS \"Total\" ");
                }
                stringBuilder.Append(" ,TO_VARCHAR(T0.\"ShipDate\", 'DD-MM-YYYY') \"ShipDate\" ");
                stringBuilder.Append(" ,T0.\"BaseEntry\",T0.\"BaseLine\" ,T0.\"BaseType\",T0.\"LineStatus\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + rowTable + " T0 ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OITM T1 ON T0.\"ItemCode\" = T1.\"ItemCode\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OSTC T2 ON T0.\"TaxCode\" = T2.\"Code\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T3 ON T1.\"ChapterID\" = T3.\"AbsEntry\" ");

                stringBuilder.Append(" WHERE T0.\"DocEntry\" = :DocEntry ");
                stringBuilder.Append(" ORDER BY T0.\"VisOrder\" ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                {
                    List<DeliveryRowsModel> modelRows = ConvertDatatableToList.ConvertToList<DeliveryRowsModel>(datatable);
                    model.DocumentLines = modelRows;
                    if (datatable.Rows.Count > 0)
                    {
                        model.WarehouseCode = model.DocumentLines.Select(a => a.WarehouseCode).FirstOrDefault();
                        model.NetAmount = model.DocumentLines.Select(a => a.Total).Sum();
                    }
                    else
                    {
                        modelRows.Add(new DeliveryRowsModel { });
                        model.DocumentLines = modelRows;
                    }
                    bool isAnySalesBOM = modelRows.Where(a => a.TreeType == "S").Any();
                    if (isAnySalesBOM == true)
                    {
                        int baseBomLineId = 0;
                        List<BOMModel> listBOModel = new List<BOMModel>();

                        for (int i = 0; i < modelRows.Count; i++)
                        {
                            int lineId = modelRows[i].Index.Value;
                            string itemcode = modelRows[i].ItemCode;
                            string treeType = modelRows[i].TreeType;
                            if (treeType == "S")
                            {

                                baseBomLineId = lineId;
                                listBOModel = new List<BOMModel>();
                                listBOModel = commonRepository.GetBOMComponents(itemcode);
                            }
                            else if (treeType == "I")
                            {
                                modelRows[i].BaseBOMLine = baseBomLineId.ToString();
                                try
                                {
                                    var bomData = listBOModel.Where(a => a.ItemCode == itemcode).FirstOrDefault();
                                    modelRows[i].BOMRatio = bomData.BOMRatio.ToString();
                                }
                                catch { }
                            }
                        }
                    }
                }
                #endregion

                #region Attachment 
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT  T1.\"trgtPath\",T1.\"FileName\", T1.\"FileExt\", T1.\"Line\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + headerTable + " T0 ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".ATC1 T1 ON T0.\"AtcEntry\" = T1.\"AbsEntry\" ");
                stringBuilder.Append(" WHERE T0.\"DocEntry\" = :DocEntry ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                {
                    if (datatable.Rows.Count > 0)
                    {
                        List<DeliveryModel_Attachment> modelRows = ConvertDatatableToList.ConvertToList<DeliveryModel_Attachment>(datatable);
                        model.Attachments2_Lines = modelRows;
                        for (int i = 0; i < model.Attachments2_Lines.Count; i++)
                        {
                            model.Attachments2_Lines[i].Index = (i + 1);
                            model.Attachments2_Lines[i].trgtPath += "\\" + model.Attachments2_Lines[i].FileName + "." + model.Attachments2_Lines[i].FileExt;
                        }
                    }
                }
                #endregion

                #region Freight

                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT  T1.\"ExpnsCode\" AS \"ExpenseCode\",T1.\"ExpnsName\" AS \"ExpenseName\" ");
                stringBuilder.Append(" ,T0.\"TaxCode\", T0.\"VatPrcnt\" AS \"TaxPercent\" ");
                if (docRate == 1)
                {
                    stringBuilder.Append(" , T0.\"LineTotal\",T0.\"VatSum\" AS \"TaxSum\", T0.\"GrsAmount\" AS \"LineGross\" ");
                }
                else
                {
                    stringBuilder.Append(" ,T0.\"TotalFrgn\" AS \"LineTotal\",T0.\"VatSumFrgn\" AS \"TaxSum\", T0.\"GrsFC\" AS \"LineGross\" ");
                }
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + freightTable + " T0 ");
                stringBuilder.Append(" RIGHT JOIN " + ConfigManager.GetSAPDatabase() + ".OEXD T1 ON T0.\"ExpnsCode\" = T1.\"ExpnsCode\" AND T0.\"DocEntry\" = :DocEntry ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                {
                    List<DeliveryModel_Expenses> modelRows = ConvertDatatableToList.ConvertToList<DeliveryModel_Expenses>(datatable);
                    if (modelRows.Count == 0)
                    {
                        DeliveryModel_Expenses documentModel_Expenses = new DeliveryModel_Expenses();
                        modelRows.Add(documentModel_Expenses);
                    }
                    model.DocumentAdditionalExpenses = modelRows;
                    double? freightAmount = model.TotalExpns;
                    if (freightAmount == 0)
                    {
                        string itemTaxCode = model.DocumentLines.Select(a => a.TaxCode).FirstOrDefault();
                        for (int i = 0; i < model.DocumentAdditionalExpenses.Count; i++)
                        {
                            model.DocumentAdditionalExpenses[i].TaxCode = itemTaxCode;
                        }
                    }
                }
                #endregion
            }
            catch
            {

            }
            return model;
        }
        public ResponseModel Add(DeliveryModel model)
        {
            string headerTable = CommonTables.DeliveryHeaderTable;

            ResponseModel responseModel = new ResponseModel();
            ServiceLayer rc = new ServiceLayer();
            string res = rc.Login();
            if (res != "" && res.Contains("error") == false)
            {
                //string slpcode = commonRepository.GetSlpCodeFromEmailAddress(model.UserId);
                DeliveryModel _objServiceLayer = new DeliveryModel();

                #region Header
                _objServiceLayer.CardCode = model.CardCode;
                _objServiceLayer.CardName = model.CardName;
                _objServiceLayer.Series = model.Series;
                _objServiceLayer.DocCurrency = model.DocCurrency;
                _objServiceLayer.DocRate = model.DocRate;

                _objServiceLayer.DocObjectCode = Convert.ToString((int)ObjectType.Orders);
                _objServiceLayer.NumAtCard = model.NumAtCard;
                DateTime dtDocDate = DateTime.ParseExact(model.DocDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                DateTime dtDocDueDate = DateTime.ParseExact(model.DocDueDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                DateTime dtTaxDate = DateTime.ParseExact(model.TaxDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);

                _objServiceLayer.DocDate = dtDocDate.ToString("yyyyMMdd");
                _objServiceLayer.DocDueDate = dtDocDueDate.ToString("yyyyMMdd");
                _objServiceLayer.TaxDate = dtTaxDate.ToString("yyyyMMdd");
                _objServiceLayer.BPL_IDAssignedToInvoice = model.BPL_IDAssignedToInvoice;
                _objServiceLayer.PayToCode = model.PayToCode;
                _objServiceLayer.ShipToCode = model.ShipToCode;
                //_objServiceLayer.Address = model.Address;
                //_objServiceLayer.Address2 = model.Address2;
                _objServiceLayer.SalesPersonCode = model.SalesPersonCode;
                _objServiceLayer.Comments = model.Comments;
                _objServiceLayer.DiscountPercent = model.DiscountPercent;
                _objServiceLayer.RoundingDiffAmount = model.RoundingDiffAmount;
                _objServiceLayer.TransportationCode = model.TransportationCode;
                _objServiceLayer.DocumentsOwner = model.DocumentsOwner;
                _objServiceLayer.Comments = model.Comments;
                #endregion

                #region Tax

                //_objServiceLayer.DutyStatus = model.DutyStatus;

                #endregion

                #region UDF
                _objServiceLayer.U_LRNo = model.U_LRNo;
                DateTime dtLRDate = DateTime.ParseExact(model.U_LRDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                _objServiceLayer.U_LRDate = dtLRDate.ToString("yyyyMMdd");
                _objServiceLayer.U_TransCode = model.U_TransCode;
                _objServiceLayer.U_TransName = model.U_TransName;
                _objServiceLayer.U_TrfVehi = model.U_TrfVehi;
                DateTime dtRemvDate = DateTime.ParseExact(model.U_RemvDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                _objServiceLayer.U_RemvDate = dtRemvDate.ToString("yyyyMMdd"); ;
                _objServiceLayer.U_RemvTime = model.U_RemvTime;
                #endregion

                #region Item Rows

                int modelRow = 0;
                List<DeliveryRowsModel> modelLines_ServiceLayer = new List<DeliveryRowsModel>();
                model.DocumentLines = model.DocumentLines.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
                for (int i = 0; i < model.DocumentLines.Count; i++)
                {
                    string treeType = model.DocumentLines[i].TreeType;
                    //if (treeType == "I")
                    //{
                    //	continue;
                    //}
                    if (!string.IsNullOrEmpty(model.DocumentLines[i].ItemCode))
                    {
                        modelLines_ServiceLayer.Add(new DeliveryRowsModel { });

                        modelLines_ServiceLayer[modelRow].LineNum = modelRow;
                        modelLines_ServiceLayer[modelRow].ItemCode = model.DocumentLines[i].ItemCode;
                        modelLines_ServiceLayer[modelRow].ItemName = model.DocumentLines[i].ItemName;
                        modelLines_ServiceLayer[modelRow].Quantity = model.DocumentLines[i].Quantity;
                        modelLines_ServiceLayer[modelRow].UnitPrice = model.DocumentLines[i].UnitPrice;
                        modelLines_ServiceLayer[modelRow].TaxCode = model.DocumentLines[i].TaxCode;
                        modelLines_ServiceLayer[modelRow].HSNEntry = model.DocumentLines[i].HSNEntry;
                        modelLines_ServiceLayer[modelRow].U_Category = string.IsNullOrEmpty(model.DocumentLines[i].U_Category) ? "1004" : model.DocumentLines[i].U_Category;
                        //modelLines_ServiceLayer[modelRow].U_Category =  model.DocumentLines[i].U_Category;
                        modelLines_ServiceLayer[modelRow].WarehouseCode = model.WarehouseCode;
                        modelLines_ServiceLayer[modelRow].U_UnwDrctn = model.DocumentLines[i].U_UnwDrctn;
                        modelLines_ServiceLayer[modelRow].U_Packng = model.DocumentLines[i].U_Packng;
                        modelLines_ServiceLayer[modelRow].SupplierCatNum = model.DocumentLines[i].SupplierCatNum;
                        modelLines_ServiceLayer[modelRow].MeasureUnit = model.DocumentLines[i].MeasureUnit;
                        modelLines_ServiceLayer[modelRow].TaxRate = model.DocumentLines[i].TaxRate;
                        modelLines_ServiceLayer[modelRow].Total = model.DocumentLines[i].Total;
                        modelLines_ServiceLayer[modelRow].InStockQuantity = model.DocumentLines[i].InStockQuantity;
                        modelLines_ServiceLayer[modelRow].FreeText = model.DocumentLines[i].FreeText;
                        modelLines_ServiceLayer[modelRow].HSNName = model.DocumentLines[i].HSNName;
                        modelLines_ServiceLayer[modelRow].U_JobCardNo = model.DocumentLines[i].U_JobCardNo;
                        try
                        {
                            modelLines_ServiceLayer[modelRow].U_CTOL = model.DocumentLines[i].U_CTOL;
                        }
                        catch { }
                        try
                        {
                            modelLines_ServiceLayer[modelRow].U_CTLOL = model.DocumentLines[i].U_CTLOL;
                        }
                        catch { }
                        try
                        {
                            DateTime dtShipDate = DateTime.ParseExact(model.DocumentLines[i].ShipDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                            modelLines_ServiceLayer[modelRow].ShipDate = dtShipDate.ToString("yyyyMMdd");
                            // modelLines_ServiceLayer[modelRow].ShipDate = dtShipDate.ToString("yyyy-MM-dd");
                        }
                        catch { }
                        try
                        {
                            if (model.DocumentLines[i].BaseEntry.HasValue)
                            {
                                modelLines_ServiceLayer[modelRow].BaseEntry = model.DocumentLines[i].BaseEntry;
                                modelLines_ServiceLayer[modelRow].BaseLine = model.DocumentLines[i].BaseLine;
                                modelLines_ServiceLayer[modelRow].BaseType = 17;
                            }
                        }
                        catch { }


                        #region Batches

                        int BatchmodelRow = 0;
                        List<DeliveryModel_BatchNumber> modelLinesbatchs_ServiceLayer = new List<DeliveryModel_BatchNumber>();
                        for (int j = 0; j < model.DocumentLines[i].BatchNumbers.Count; j++)
                        {
                            modelLinesbatchs_ServiceLayer.Add(new DeliveryModel_BatchNumber { });
                            modelLinesbatchs_ServiceLayer[BatchmodelRow].BatchNumber = model.DocumentLines[i].BatchNumbers[j].BatchNumber;
                            modelLinesbatchs_ServiceLayer[BatchmodelRow].BaseLineNumber = model.DocumentLines[i].BatchNumbers[j].BaseLineNumber;
                            modelLinesbatchs_ServiceLayer[BatchmodelRow].ItemCode = model.DocumentLines[i].BatchNumbers[j].ItemCode;
                            modelLinesbatchs_ServiceLayer[BatchmodelRow].Quantity = model.DocumentLines[i].BatchNumbers[j].Quantity;
                            BatchmodelRow++;
                        }
                        modelLines_ServiceLayer[i].BatchNumbers = modelLinesbatchs_ServiceLayer;

                        #endregion

                        modelRow++;
                    }
                }

                #endregion

                #region Freight
                List<DeliveryModel_Expenses> model_Expenses_ServiceLayerList = new List<DeliveryModel_Expenses>();
                try
                {
                    int expenseRow = 0;
                    //model.DocumentAdditionalExpenses = model.DocumentAdditionalExpenses.Where(a => a.LineGross > 0).ToList();
                    for (int i = 0; i < model.DocumentAdditionalExpenses.Count; i++)
                    {
                        if (model.DocumentAdditionalExpenses[i].LineGross > 0)
                        {
                            model_Expenses_ServiceLayerList.Add(new DeliveryModel_Expenses { });
                            model_Expenses_ServiceLayerList[expenseRow].ExpenseCode = model.DocumentAdditionalExpenses[i].ExpenseCode;
                            model_Expenses_ServiceLayerList[expenseRow].TaxCode = model.DocumentAdditionalExpenses[i].TaxCode;
                            model_Expenses_ServiceLayerList[expenseRow].LineTotal = model.DocumentAdditionalExpenses[i].LineTotal;
                            expenseRow++;
                        }
                    }
                }
                catch { }
                #endregion

                #region Tax Extension
                //DeliveryModel_TaxExtension documentModel_TaxExtension = new DeliveryModel_TaxExtension();
                //if (model.boolImpORExp == true)
                //{
                //	documentModel_TaxExtension.ImportOrExport = "tYES";
                //	documentModel_TaxExtension.ImportOrExportType = GetImportExportType(model.ExportType);
                //}
                //else
                //{
                //	documentModel_TaxExtension.ImportOrExport = "tNO";
                //}
                //_objServiceLayer.TaxExtension = documentModel_TaxExtension;
                #endregion


                _objServiceLayer.DocumentLines = modelLines_ServiceLayer;
                _objServiceLayer.DocumentAdditionalExpenses = model_Expenses_ServiceLayerList;

                string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
                {
                    NullValueHandling = NullValueHandling.Ignore,
                });

                var temp = JsonConvert.DeserializeObject<JObject>(main);

                string serviceLayerObject = "";
                serviceLayerObject = ServiceLayerEntity.DeliveryNotes.ToString();
                rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject;
                rc.patchJSON = main;
                rc.B1SESSION = res;
                string message = "";
                bool result = rc.postRequest(out message);
                responseModel.ResponseStatus = result;
                if (result == true)
                {
                    responseModel.ResponseText = "Operation completed successfully";
                    var jobject = JsonConvert.DeserializeObject<JObject>(message);
                    string docEntry = jobject["DocEntry"].ToString();
                    model.DocEntry = docEntry;
                    responseModel.ResponseEntry = docEntry;
                    string userId = commonRepository.GetUserId(model.UserId);
                    bool anyAttachment = model.Attachments2_Lines.Any(a => a.IsChanged == "Y");
                    try
                    {
                        bool anyNewAttachment = model.Attachments2_Lines.Any(a => a.trgtPath.Contains("wwwroot"));
                        if (anyNewAttachment == true)
                        {
                            Utility utility = new Utility();
                            //comment by nilam
                            //utility.SaveAttachment(res, model.DocEntry, model.AtcEntry, userId, model.Attachments2_Lines, serviceLayerObject);
                            //SaveAttachment(res, model, serviceLayerObject);
                        }
                    }
                    catch { }

                    commonRepository.UpdateUserSign("Add", headerTable, "DocEntry", docEntry, userId);
                    //UpdateDutyStatus(headerTable, model.DocEntry, model);
                    //UpdateSOCategory(rowTable, model.DocEntry, model.DocumentLines);
                }
                else
                {
                    var jobject = JsonConvert.DeserializeObject<JObject>(message);
                    string jsonMessage = jobject["error"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["message"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["value"].ToString();
                    responseModel.ResponseText = "Error occured during process: " + jsonMessage;
                }
                rc.LogOut();
            }
            else
            {
                responseModel.ResponseText = "Service layer login failed";
            }
            return responseModel;
        }
        public ResponseModel Update(DeliveryModel model)
        {
            string headerTable = CommonTables.DeliveryHeaderTable;
            string rowTable = CommonTables.DeliveryHeaderTable;
            string freightTable = CommonTables.DeliveryFreightTable;
            string SalesOrderAddressTable = CommonTables.DeliveryAddressTable;

            ResponseModel responseModel = new ResponseModel();
            ServiceLayer rc = new ServiceLayer();
            string res = rc.Login();
            if (res != "" && res.Contains("error") == false)
            {
                #region Header

                DeliveryModel _objServiceLayer = new DeliveryModel();
                //DateTime dtDocDate = Convert.ToDateTime(model.DocDate);

                _objServiceLayer.NumAtCard = model.NumAtCard;
                _objServiceLayer.DocCurrency = model.DocCurrency;
                _objServiceLayer.DocRate = model.DocRate;

                DateTime dtDocDate = DateTime.ParseExact(model.DocDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                DateTime dtDocDueDate = DateTime.ParseExact(model.DocDueDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                DateTime dtTaxDate = DateTime.ParseExact(model.TaxDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);

                _objServiceLayer.DocDate = dtDocDate.ToString("yyyyMMdd");
                _objServiceLayer.DocDueDate = dtDocDueDate.ToString("yyyyMMdd");
                _objServiceLayer.TaxDate = dtTaxDate.ToString("yyyyMMdd");

                if (model.Type.ToUpper() == "DRAFT")
                {
                    _objServiceLayer.DocDate = DateTime.Now.Date.ToString("yyyyMMdd");
                }
                else
                {
                    _objServiceLayer.DocDate = dtDocDate.ToString("yyyyMMdd");
                }

                _objServiceLayer.PayToCode = model.PayToCode;
                _objServiceLayer.ShipToCode = model.ShipToCode;
                //_objServiceLayer.Address = model.Address;
                //_objServiceLayer.Address2 = model.Address2;
                _objServiceLayer.SalesPersonCode = model.SalesPersonCode;
                _objServiceLayer.Comments = model.Comments;
                _objServiceLayer.DiscountPercent = model.DiscountPercent;
                _objServiceLayer.RoundingDiffAmount = model.RoundingDiffAmount;
                _objServiceLayer.TransportationCode = model.TransportationCode;
                _objServiceLayer.DocumentsOwner = model.DocumentsOwner;
                _objServiceLayer.Comments = model.Comments;
                _objServiceLayer.Series = model.Series;
                #endregion

                #region UDF
                _objServiceLayer.U_LRNo = model.U_LRNo;
                DateTime dtLRDate = DateTime.ParseExact(model.U_LRDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                _objServiceLayer.U_LRDate = dtLRDate.ToString("yyyyMMdd");
                _objServiceLayer.U_TransCode = model.U_TransCode;
                _objServiceLayer.U_TransName = model.U_TransName;
                _objServiceLayer.U_TrfVehi = model.U_TrfVehi;
                DateTime dtRemvDate = DateTime.ParseExact(model.U_RemvDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                _objServiceLayer.U_RemvDate = dtRemvDate.ToString("yyyyMMdd"); ;
                _objServiceLayer.U_RemvTime = model.U_RemvTime;
                #endregion

                #region Item Rows

                int modelRow = 0;
                List<DeliveryRowsModel> modelLines_ServiceLayer = new List<DeliveryRowsModel>();
                model.DocumentLines = model.DocumentLines.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
                for (int i = 0; i < model.DocumentLines.Count; i++)
                {
                    string treeType = model.DocumentLines[i].TreeType;
                    if (treeType == "I")
                    {
                        continue;
                    }
                    if (!string.IsNullOrEmpty(model.DocumentLines[i].ItemCode))
                    {
                        modelLines_ServiceLayer.Add(new DeliveryRowsModel { });

                        modelLines_ServiceLayer[modelRow].ItemCode = model.DocumentLines[i].ItemCode;
                        modelLines_ServiceLayer[modelRow].ItemName = model.DocumentLines[i].ItemName;
                        modelLines_ServiceLayer[modelRow].Quantity = model.DocumentLines[i].Quantity;
                        modelLines_ServiceLayer[modelRow].UnitPrice = model.DocumentLines[i].UnitPrice;
                        modelLines_ServiceLayer[modelRow].TaxCode = model.DocumentLines[i].TaxCode;
                        modelLines_ServiceLayer[modelRow].HSNEntry = model.DocumentLines[i].HSNEntry;
                        modelLines_ServiceLayer[modelRow].U_Category = string.IsNullOrEmpty(model.DocumentLines[i].U_Category) ? "1004" : model.DocumentLines[i].U_Category;
                        //modelLines_ServiceLayer[modelRow].U_Category =  model.DocumentLines[i].U_Category;
                        modelLines_ServiceLayer[modelRow].WarehouseCode = model.WarehouseCode;
                        modelLines_ServiceLayer[modelRow].U_UnwDrctn = model.DocumentLines[i].U_UnwDrctn;
                        modelLines_ServiceLayer[modelRow].U_Packng = model.DocumentLines[i].U_Packng;
                        modelLines_ServiceLayer[modelRow].SupplierCatNum = model.DocumentLines[i].SupplierCatNum;
                        modelLines_ServiceLayer[modelRow].MeasureUnit = model.DocumentLines[i].MeasureUnit;
                        modelLines_ServiceLayer[modelRow].TaxRate = model.DocumentLines[i].TaxRate;
                        modelLines_ServiceLayer[modelRow].Total = model.DocumentLines[i].Total;
                        modelLines_ServiceLayer[modelRow].InStockQuantity = model.DocumentLines[i].InStockQuantity;
                        modelLines_ServiceLayer[modelRow].FreeText = model.DocumentLines[i].FreeText;
                        modelLines_ServiceLayer[modelRow].HSNName = model.DocumentLines[i].HSNName;
                        modelLines_ServiceLayer[modelRow].U_JobCardNo = model.DocumentLines[i].U_JobCardNo;
                        try
                        {
                            modelLines_ServiceLayer[modelRow].U_CTOL = model.DocumentLines[i].U_CTOL;
                        }
                        catch { }
                        try
                        {
                            modelLines_ServiceLayer[modelRow].U_CTLOL = model.DocumentLines[i].U_CTLOL;
                        }
                        catch { }
                        try
                        {
                            DateTime dtShipDate = DateTime.ParseExact(model.DocumentLines[i].ShipDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                            modelLines_ServiceLayer[modelRow].ShipDate = dtShipDate.ToString("yyyyMMdd");
                            // modelLines_ServiceLayer[modelRow].ShipDate = dtShipDate.ToString("yyyy-MM-dd");
                        }
                        catch { }
                        try
                        {
                            if (model.DocumentLines[i].BaseEntry.HasValue)
                            {
                                modelLines_ServiceLayer[modelRow].BaseEntry = model.DocumentLines[i].BaseEntry;
                                modelLines_ServiceLayer[modelRow].BaseLine = model.DocumentLines[i].BaseLine;
                                modelLines_ServiceLayer[modelRow].BaseType = 23;
                            }
                        }
                        catch { }

                        #region Batches

                        int BatchmodelRow = 0;
                        List<DeliveryModel_BatchNumber> modelLinesbatchs_ServiceLayer = new List<DeliveryModel_BatchNumber>();
                        for (int j = 0; j < model.DocumentLines[i].BatchNumbers.Count; j++)
                        {
                            modelLinesbatchs_ServiceLayer.Add(new DeliveryModel_BatchNumber { });
                            modelLinesbatchs_ServiceLayer[BatchmodelRow].BatchNumber = model.DocumentLines[i].BatchNumbers[j].BatchNumber;
                            modelLinesbatchs_ServiceLayer[BatchmodelRow].BaseLineNumber = model.DocumentLines[i].BatchNumbers[j].BaseLineNumber;
                            modelLinesbatchs_ServiceLayer[BatchmodelRow].ItemCode = model.DocumentLines[i].BatchNumbers[j].ItemCode;
                            modelLinesbatchs_ServiceLayer[BatchmodelRow].Quantity = model.DocumentLines[i].BatchNumbers[j].Quantity;
                            BatchmodelRow++;
                        }
                        _objServiceLayer.DocumentLines[i].BatchNumbers = modelLinesbatchs_ServiceLayer;

                        #endregion
                        modelRow++;
                    }
                }

                #endregion

                #region Freight
                List<DeliveryModel_Expenses> model_Expenses_ServiceLayerList = new List<DeliveryModel_Expenses>();
                if (model.DocumentAdditionalExpenses != null)
                {
                    int expenseRow = 0;
                    //model.DocumentAdditionalExpenses = model.DocumentAdditionalExpenses.Where(a => a.LineGross > 0).ToList();
                    for (int i = 0; i < model.DocumentAdditionalExpenses.Count; i++)
                    {
                        if (model.DocumentAdditionalExpenses[i].LineGross > 0)
                        {
                            model_Expenses_ServiceLayerList.Add(new DeliveryModel_Expenses { });
                            model_Expenses_ServiceLayerList[expenseRow].ExpenseCode = model.DocumentAdditionalExpenses[i].ExpenseCode;
                            model_Expenses_ServiceLayerList[expenseRow].TaxCode = model.DocumentAdditionalExpenses[i].TaxCode;
                            model_Expenses_ServiceLayerList[expenseRow].LineTotal = model.DocumentAdditionalExpenses[i].LineTotal;
                            expenseRow++;
                        }
                    }
                }
                _objServiceLayer.DocumentAdditionalExpenses = model_Expenses_ServiceLayerList;
                #endregion

                #region Tax Extension
                DeliveryModel_TaxExtension documentModel_TaxExtension = new DeliveryModel_TaxExtension();
                if (model.boolImpORExp == true)
                {
                    documentModel_TaxExtension.ImportOrExport = "tYES";
                    documentModel_TaxExtension.ImportOrExportType = GetImportExportType(model.ExportType);
                }
                else
                {
                    documentModel_TaxExtension.ImportOrExport = "tNO";
                }
                _objServiceLayer.TaxExtension = documentModel_TaxExtension;
                #endregion

                if (model.ButtonValue.ToLower() == "update")
                {
                    _objServiceLayer.DocumentLines = modelLines_ServiceLayer;
                }

                #region Batches

                #endregion

                _objServiceLayer.DocumentLines = modelLines_ServiceLayer;
                _objServiceLayer.DocumentAdditionalExpenses = model_Expenses_ServiceLayerList;

                string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
                {
                    NullValueHandling = NullValueHandling.Ignore,
                });
                string serviceLayerObject = "";
                if (model.Type.ToUpper() == "DRAFT")
                {
                    serviceLayerObject = ServiceLayerEntity.Drafts.ToString();
                    headerTable = CommonTables.DraftHeaderTable;
                    rowTable = CommonTables.DraftRowTable;
                }
                else
                {
                    serviceLayerObject = ServiceLayerEntity.Orders.ToString();
                }
                rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject + "(" + model.DocEntry + ")";
                rc.patchJSON = main;
                rc.B1SESSION = res;
                rc.httpMethod = httpVerb.PATCH;
                string message = "";
                bool result = rc.patchRequest(out message);
                responseModel.ResponseStatus = result;
                if (result == true)
                {
                    responseModel.ResponseText = "Operation completed successfully";
                    //bool anyAttachment = model.Attachments2_Lines.Any(a => a.IsChanged == "Y");
                    ResponseModel attachmentResponseModel = new ResponseModel();
                    //comment by Nilam
                    //bool anyNewAttachment = model.Attachments2_Lines.Any(a => a.trgtPath.Contains("wwwroot"));
                    //string userId = commonRepository.GetUserId(model.UserId);

                    //if (anyNewAttachment == true)
                    //               {
                    //                   Utility utility = new Utility();
                    //                   attachmentResponseModel = utility.SaveAttachment(res, model.DocEntry, model.AtcEntry, userId, model.Attachments2_Lines, serviceLayerObject);
                    //               }
                    //  commonRepository.UpdateUserSign("Update", headerTable, "DocEntry", model.DocEntry, userId);
                    // UpdateDutyStatus(headerTable, model.DocEntry, model);
                    try
                    {
                        //if (attachmentResponseModel.ResponseStatus == false)
                        //{
                        //    responseModel.ResponseText = responseModel.ResponseText + ". " + attachmentResponseModel.ResponseText;
                        //}
                    }
                    catch { }
                }
                else
                {
                    var jobject = JsonConvert.DeserializeObject<JObject>(message);
                    string jsonMessage = jobject["error"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["message"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["value"].ToString();
                    responseModel.ResponseText = "Error occured during process: " + jsonMessage;
                }
                rc.LogOut();
            }
            return responseModel;
        }
        public ResponseModel Close(string docEntry)
        {
            ResponseModel responseModel = new ResponseModel();
            ServiceLayer rc = new ServiceLayer();
            string res = rc.Login();
            if (res != "" && res.Contains("error") == false)
            {
                DocumentModel_SaveDraftToDocument _objServiceLayer = new DocumentModel_SaveDraftToDocument();
                DraftDocument draftDocument = new DraftDocument();
                //draftDocument.DocEntry = docEntry;
                //_objServiceLayer.Document = draftDocument;
                string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
                {
                    NullValueHandling = NullValueHandling.Ignore,
                });
                rc.endPoint = ConfigManager.GetServiceLayerURL() + ServiceLayerEntity.Orders.ToString() + "(" + docEntry + ")/Close";
                rc.patchJSON = main;
                rc.B1SESSION = res;
                rc.httpMethod = httpVerb.POST;
                string message = "";
                bool result = rc.postRequest(out message);
                responseModel.ResponseStatus = result;
                if (result == true)
                {
                    responseModel.ResponseText = "Operation completed successfully";
                }
                else
                {
                    var jobject = JsonConvert.DeserializeObject<JObject>(message);
                    string jsonMessage = jobject["error"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["message"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["value"].ToString();
                    responseModel.ResponseText = "Error occured during process: " + jsonMessage;
                }
                rc.LogOut();
            }
            return responseModel;
        }
        public ResponseModel Cancel(string docEntry)
        {
            ResponseModel responseModel = new ResponseModel();
            ServiceLayer rc = new ServiceLayer();
            string res = rc.Login();
            if (res != "" && res.Contains("error") == false)
            {
                DocumentModel_SaveDraftToDocument _objServiceLayer = new DocumentModel_SaveDraftToDocument();
                DraftDocument draftDocument = new DraftDocument();
                // draftDocument.DocEntry = docEntry;
                //_objServiceLayer.Document = draftDocument;
                string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
                {
                    NullValueHandling = NullValueHandling.Ignore,
                });
                rc.endPoint = ConfigManager.GetServiceLayerURL() + ServiceLayerEntity.DeliveryNotes.ToString() + "(" + docEntry + ")/Cancel";
                rc.patchJSON = main;
                rc.B1SESSION = res;
                rc.httpMethod = httpVerb.POST;
                string message = "";
                bool result = rc.postRequest(out message);
                responseModel.ResponseStatus = result;
                if (result == true)
                {
                    responseModel.ResponseText = "Operation completed successfully";
                }
                else
                {
                    var jobject = JsonConvert.DeserializeObject<JObject>(message);
                    string jsonMessage = jobject["error"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["message"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["value"].ToString();
                    responseModel.ResponseText = "Error occured during process: " + jsonMessage;
                }
                rc.LogOut();
            }
            return responseModel;
        }
        private void UpdateDutyStatus(string headerTableName, string docEntry, DeliveryModel model)
        {
            HanaParameter[] parameters = new HanaParameter[2];

            parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
            parameters[0].Value = docEntry;

            parameters[1] = new HanaParameter("DutyStatus", System.Data.SqlDbType.VarChar);
            parameters[1].Value = model.DutyStatus;

            //parameters[2] = new HanaParameter("ImpOrExp", System.Data.SqlDbType.VarChar);
            //parameters[2].Value = model.ImpORExp == false ? "N" : "Y";

            //parameters[3] = new HanaParameter("ExportType", System.Data.SqlDbType.VarChar);
            //parameters[3].Value = model.ExportType;

            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + "." + headerTableName + " SET ");
            stringBuilder.Append(" \"DutyStatus\"= :DutyStatus ");
            stringBuilder.Append(" WHERE \"DocEntry\" = :DocEntry ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters);
        }
        private string GetImportExportType(string value)
        {
            string returnValue = "";
            if (value == "E")
            {
                returnValue = "et_IpmortsOrExports";
            }
            else if (value == "S")
            {
                returnValue = "et_SEZ_Developer";
            }
            else if (value == "U")
            {
                returnValue = "et_SEZ_Unit";
            }
            else if (value == "D")
            {
                returnValue = "et_Deemed_ImportsOrExports";
            }
            return returnValue;
        }
        public DocumentModel GetSalesOrderOpenRows(string sodocEntry)
        {
            DocumentModel model = new DocumentModel();
            try
            {
                string headerTable = CommonTables.SalesOrderHeaderTable;
                string rowTable = CommonTables.SalesOrderRowTable;
                string freightTable = CommonTables.SalesOrderFreightTable;

                HanaParameter[] parameters = new HanaParameter[1];

                parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
                parameters[0].Value = sodocEntry;

                #region Row
                string rowTaxCode = "";
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"VisOrder\" + 1 AS \"Index\",T0.\"LineNum\" AS \"LineId\", T0.\"ItemCode\",T0.\"Dscription\" AS \"ItemName\" ");
                stringBuilder.Append(" ,T0.\"OpenQty\" AS \"Quantity\",T0.\"TreeType\",T1.\"OnHand\" ");
                stringBuilder.Append(" ,T0.\"SubCatNum\" \"SupplierCatNum\",T0.\"U_Category\",T0.\"FreeTxt\" AS \"FreeText\" ");
                stringBuilder.Append(" ,T0.\"unitMsr\" \"MeasureUnit\",T0.\"WhsCode\" AS \"WarehouseCode\" ");
                stringBuilder.Append(" ,T0.\"TaxCode\",T2.\"Rate\" AS \"TaxRate\",T1.\"ChapterID\" AS \"HSNEntry\",T3.\"ChapterID\" AS \"HSNName\" ");
                stringBuilder.Append(" , CASE WHEN T4.\"DocRate\" = 1 THEN T0.\"PriceBefDi\" ELSE T0.\"Price\"  END AS \"UnitPrice\"  ");
                stringBuilder.Append(" , CASE WHEN T4.\"DocRate\" = 1 THEN T0.\"LineTotal\" ELSE T0.\"TotalFrgn\"  END AS \"Total\" ");
                stringBuilder.Append(" ,TO_VARCHAR(T0.\"ShipDate\", 'DD-MM-YYYY') \"ShipDate\" ");
                stringBuilder.Append(" ,T0.\"DocEntry\" AS \"BaseEntry\",T0.\"LineNum\" AS \"BaseLine\" ");
                stringBuilder.Append(" ,CASE WHEN T1.\"ManBtchNum\"='Y' THEN 'B' WHEN T1.\"ManSerNum\"='Y' THEN 'S' ELSE 'N' END \"ManagedBy\"  ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + rowTable + " T0 ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OITM T1 ON T0.\"ItemCode\" = T1.\"ItemCode\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OSTC T2 ON T0.\"TaxCode\" = T2.\"Code\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T3 ON T1.\"ChapterID\" = T3.\"AbsEntry\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + "." + headerTable + " T4 ON T0.\"DocEntry\" = T4.\"DocEntry\" ");
                stringBuilder.Append(" WHERE T0.\"DocEntry\" = :DocEntry ");
                stringBuilder.Append(" AND T0.\"OpenQty\" > 0 AND T0.\"LineStatus\" = 'O' ");
                stringBuilder.Append(" ORDER BY T0.\"VisOrder\" ");

                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                {
                    if (datatable.Rows.Count > 0)
                    {
                        List<DocumentRowsModel> modelRows = ConvertDatatableToList.ConvertToList<DocumentRowsModel>(datatable);
                        model.DocumentLines = modelRows;
                        rowTaxCode = model.DocumentLines.Select(a => a.TaxCode).FirstOrDefault();
                        model.WarehouseCode = model.DocumentLines.Select(a => a.WarehouseCode).FirstOrDefault();
                        model.NetAmount = model.DocumentLines.Select(a => a.Total).Sum();


                        #region sales and bom quantity calc (Nilam)

                        bool isAnySalesBOM = modelRows.Where(a => a.TreeType == "S").Any();
                        if (isAnySalesBOM == true)
                        {
                            int baseBomLineId = 0;
                            List<BOMModel> listBOModel = new List<BOMModel>();

                            for (int i = 0; i < modelRows.Count; i++)
                            {
                                int lineId = modelRows[i].Index.Value;
                                string itemcode = modelRows[i].ItemCode;

                                string treeType = modelRows[i].TreeType;
                                if (treeType == "S")
                                {
                                    baseBomLineId = lineId;
                                    listBOModel = new List<BOMModel>();
                                    listBOModel = commonRepository.GetBOMComponents(itemcode);
                                }
                                else if (treeType == "I")
                                {
                                    modelRows[i].BaseBOMLine = baseBomLineId.ToString();
                                    try
                                    {
                                        var bomData = listBOModel.Where(a => a.ItemCode == itemcode).FirstOrDefault();
                                        modelRows[i].BOMRatio = bomData.BOMRatio.ToString();
                                    }
                                    catch { }
                                }
                            }
                        }
                        #endregion
                    }
                }
				#endregion

				#region Freight
				stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT  T0.\"ExpnsCode\" AS \"ExpenseCode\",T1.\"ExpnsName\" AS \"ExpenseName\" ");
                stringBuilder.Append(" ,T0.\"TaxCode\", T0.\"LineTotal\", T0.\"VatPrcnt\" AS \"TaxPercent\" ");
                stringBuilder.Append(" ,T0.\"VatSum\" AS \"TaxSum\", T0.\"GrsAmount\" AS \"LineGross\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + freightTable + " T0 ");
                stringBuilder.Append(" RIGHT JOIN " + ConfigManager.GetSAPDatabase() + ".OEXD T1 ON T0.\"ExpnsCode\" = T1.\"ExpnsCode\"  ");
                stringBuilder.Append(" WHERE T0.\"DocEntry\" = :DocEntry ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                {
                    List<DocumentModel_Expenses> modelRows = ConvertDatatableToList.ConvertToList<DocumentModel_Expenses>(datatable);
                    if (modelRows.Count == 0)
                    {
                        DocumentModel_Expenses documentModel_Expenses = new DocumentModel_Expenses();
                        modelRows.Add(documentModel_Expenses);
                    }
                    var isAnyTaxCode = modelRows.Where(a => a.TaxCode != null).Any();
                    if (isAnyTaxCode == false)
                    {
                        modelRows.ToList().ForEach(w => w.TaxCode = rowTaxCode);
                    }
                    model.DocumentAdditionalExpenses = modelRows;
                }
				#endregion

				#region Tax Extension
				stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT  T0.\"DutyStatus\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + headerTable + " T0 ");
                stringBuilder.Append(" WHERE T0.\"DocEntry\" = :DocEntry ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                {
					List<DocumentModel_TaxExtension> modelRows = ConvertDatatableToList.ConvertToList<DocumentModel_TaxExtension>(datatable);
					if (model.DutyStatus == "Y")
					{
                        model.ImpORExp = "N";
                    }
                    else
                    {
						model.ImpORExp = "Y";
					}
					//model.TaxExtension = modelRows;
				}
                #endregion
            }
            catch
            {

            }
            return model;
        }
        public List<JobCardModel> GetJobCardNoList(string itemcode, string baseentry)
        {
            List<JobCardModel> list = new List<JobCardModel>();
            try
            {
                HanaParameter[] parameters = new HanaParameter[2];
                parameters[0] = new HanaParameter("ItemCode", SqlDbType.VarChar);
                parameters[0].Value = itemcode == null ? string.Empty : itemcode;

                parameters[1] = new HanaParameter("BaseEntry", SqlDbType.VarChar);
                parameters[1].Value = baseentry == null ? string.Empty : baseentry;

                string query = ConfigManager.GetSAPDatabase() + ".\"Web_FMS_Delivery_JobCardNo\"";

                using (DataTable datatable = FillDataTable(query, CommandType.StoredProcedure, out string message, parameters))
                {
                    list = ConvertDatatableToList.ConvertToList<JobCardModel>(datatable);
                }
            }
            catch
            {

            }
            return list;
        }
    }
}