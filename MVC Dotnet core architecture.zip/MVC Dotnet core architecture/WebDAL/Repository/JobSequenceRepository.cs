﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Reflection;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sap.Data.Hana;
using WebDAL.Helper;
using WebDAL.Helpers;
using WebDAL.IRepository;
using WebDAL.Models;

namespace WebDAL.Repository
{
	public class JobSequenceRepository : clsDataAccess, IJobSequenceRepository
	{
		string query = "";
		CommonRepository commonRepository = new CommonRepository();
		StringBuilder stringBuilder = new StringBuilder();
		public List<JobSequenceModel> GetAll()
		{
			List<JobSequenceModel> _list = new List<JobSequenceModel>();
			try
			{
				string headerTable = CommonTables.JobSequenceHeaderTable;
				string rowTable = CommonTables.JobSequenceRowTable;
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"DocEntry\",T0.\"DocNum\",TO_NVARCHAR(T0.\"U_DocDt\", 'DD/MM/YYYY')  AS \"U_DocDt\", T0.\"U_MCode\", T0.\"U_MName\", T0.\"U_AMCode\", T0.\"U_AMName\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@VCJBSM\" T0 ");
                stringBuilder.Append(" ORDER BY Cast(T0.\"DocNum\" as numeric(19,0)) DESC ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<JobSequenceModel>(datatable);
				}
			}
			catch
			{
			}
			return _list;
		}
		public JobSequenceModel Get(string docEntry, string userId)
		{
			JobSequenceModel model = new JobSequenceModel();
			try
			{
				string headerTable = CommonTables.JobSequenceHeaderTable;
				string rowTable = CommonTables.JobSequenceRowTable;
				HanaParameter[] parameters = new HanaParameter[1];
				parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
				parameters[0].Value = docEntry;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"DocNum\",TO_NVARCHAR(T0.\"U_DocDt\", 'DD-MM-YYYY')  AS \"U_DocDt\", T0.\"U_MCode\", T0.\"U_MName\", T0.\"U_AMCode\", T0.\"U_AMName\" ");
				stringBuilder.Append(" ,T0.\"Series\" ,T1.\"SeriesName\" ,T0.\"Remark\",T0.\"Creator\"");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@VCJBSM\" T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"NNM1\" T1 ON  T0.\"Object\" = T1.\"ObjectCode\"");
				stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						model = ConvertDatatableToList.ConvertToEntity<JobSequenceModel>(datatable);
					}
				}
				#region Row
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"LineId\",T0.\"LineId\" as \"Index\",T0.\"U_PLANDNO\" ,T0.\"U_PLANNO\" ");
				stringBuilder.Append(" ,T0.\"U_PLANQty\", T0.\"U_PROCQty\" , T0.\"U_PENDQty\",T0.\"U_Cancel\" ");
				stringBuilder.Append(" ,T0.\"U_ICode\", T0.\"U_IName\" , T0.\"U_Qty\",T0.\"U_IsSplit\",T0.\"U_Status\" ,T0.\"U_OPCode\", T0.\"U_Cancel\"");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + rowTable + "\" T0 ");
				stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						List<JobSequenceRowsModel> modelRows = ConvertDatatableToList.ConvertToList<JobSequenceRowsModel>(datatable);
						model.VCJBSDCollection = modelRows;
					}
					else
					{
						List<JobSequenceRowsModel> JobSequenceRowsModellList = new List<JobSequenceRowsModel>();
						JobSequenceRowsModel jobSequenceRowsModel = new JobSequenceRowsModel();
						jobSequenceRowsModel.Index = 1;
						JobSequenceRowsModellList.Add(jobSequenceRowsModel);
						model.VCJBSDCollection = JobSequenceRowsModellList;

					}
				}
				#endregion
			}
			catch
			{

			}
			return model;
		}
		public ResponseModel Add(JobSequenceModel model)
		{
			string headerTable = CommonTables.JobSequenceHeaderTable;
			string rowTable = CommonTables.JobSequenceRowTable;
			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();
			string slpcode = commonRepository.GetSlpCodeFromEmailAddress(model.UserId);
			JobSequenceModel _objServiceLayer = new JobSequenceModel();

            #region Header
            _objServiceLayer.U_AMCode = model.U_AMCode;
            _objServiceLayer.U_AMName = model.U_AMName;
            _objServiceLayer.U_MCode = model.U_MCode;
            _objServiceLayer.U_MName = model.U_MName;
            _objServiceLayer.Series = model.Series;
			_objServiceLayer.DocNum = model.DocNum;
			DateTime dtDate = DateTime.ParseExact(model.U_DocDt, "dd-MM-yyyy", CultureInfo.InvariantCulture);
			_objServiceLayer.U_DocDt = dtDate.ToString("yyyyMMdd");
			_objServiceLayer.Creator = model.Creator;
			_objServiceLayer.Remark = model.Remark;
			#endregion

			#region Job Sequence Rows
			int modelRow = 0;
			List<JobSequenceRowsModel> modelLines_ServiceLayer = new List<JobSequenceRowsModel>();
			model.VCJBSDCollection = model.VCJBSDCollection.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
			for (int i = 0; i < model.VCJBSDCollection.Count; i++)
			{
				if (!string.IsNullOrEmpty(model.VCJBSDCollection[i].U_PLANDNO))
				{
                    modelLines_ServiceLayer.Add(new JobSequenceRowsModel { });
					modelLines_ServiceLayer[modelRow].U_PLANDNO = model.VCJBSDCollection[i].U_PLANDNO;
					modelLines_ServiceLayer[modelRow].U_PLANNO = model.VCJBSDCollection[i].U_PLANNO;
					modelLines_ServiceLayer[modelRow].U_OPCode = model.VCJBSDCollection[i].U_OPCode;
					modelLines_ServiceLayer[modelRow].U_PLANQty = model.VCJBSDCollection[i].U_PLANQty;
					modelLines_ServiceLayer[modelRow].U_PROCQty = model.VCJBSDCollection[i].U_PROCQty;
					modelLines_ServiceLayer[modelRow].U_PENDQty = model.VCJBSDCollection[i].U_PENDQty;
					modelLines_ServiceLayer[modelRow].U_ICode = model.VCJBSDCollection[i].U_ICode;
					modelLines_ServiceLayer[modelRow].U_IName = model.VCJBSDCollection[i].U_IName;
					modelLines_ServiceLayer[modelRow].U_Qty = model.VCJBSDCollection[i].U_Qty;
					modelLines_ServiceLayer[modelRow].U_IsSplit = model.VCJBSDCollection[i].U_IsSplit;
					modelLines_ServiceLayer[modelRow].U_Status = model.VCJBSDCollection[i].U_Status;
					modelLines_ServiceLayer[modelRow].U_Cancel = model.VCJBSDCollection[i].U_Cancel;
					modelRow++;
				}
			}
			#endregion

			_objServiceLayer.VCJBSDCollection = modelLines_ServiceLayer;
			string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
			{
				NullValueHandling = NullValueHandling.Ignore,
			});
			var temp = JsonConvert.DeserializeObject<JObject>(main);

			string serviceLayerObject = "";
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				serviceLayerObject = ServiceLayerEntity.VCJBSM.ToString();
				rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject;
				rc.patchJSON = main;
				rc.B1SESSION = res;
				string message = "";
				bool result = rc.postRequest(out message);
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during process: " + jsonMessage;
				}
				rc.LogOut();
			}
			else
			{
				responseModel.ResponseText = "Service layer login failed";
			}
			return responseModel;
		}
		public ResponseModel Update(JobSequenceModel model)
		{
			string headerTable = CommonTables.JobSequenceHeaderTable;
			string rowTable = CommonTables.JobSequenceRowTable;
			string objectType = Convert.ToString((int)ObjectType.StockTransfers);//VCJBSM
			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();
			string slpcode = commonRepository.GetSlpCodeFromEmailAddress(model.UserId);
			JobSequenceModel _objServiceLayer = new JobSequenceModel();

            #region Header
            _objServiceLayer.U_AMCode = model.U_AMCode;
            _objServiceLayer.U_AMName = model.U_AMName;
            _objServiceLayer.U_MCode = model.U_MCode;
            _objServiceLayer.U_MName = model.U_MName;
            _objServiceLayer.Series = model.Series;
            _objServiceLayer.DocNum = model.DocNum;
			DateTime dtDate = DateTime.ParseExact(model.U_DocDt, "dd-MM-yyyy", CultureInfo.InvariantCulture);
			_objServiceLayer.U_DocDt = dtDate.ToString("yyyyMMdd");
			_objServiceLayer.Creator = model.Creator;
			_objServiceLayer.Remark = model.Remark;
			#endregion

			#region Tax
			////_objServiceLayer.DutyStatus = model.DutyStatus;
			#endregion

			#region Job Sequence Rows
			int modelRow = 0;
            List<JobSequenceRowsModel> modelLines_ServiceLayer = new List<JobSequenceRowsModel>();
            model.VCJBSDCollection = model.VCJBSDCollection.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
            for (int i = 0; i < model.VCJBSDCollection.Count; i++)
            {
                if (!string.IsNullOrEmpty(model.VCJBSDCollection[i].U_PLANDNO))
                {
                    modelLines_ServiceLayer.Add(new JobSequenceRowsModel { });
                    modelLines_ServiceLayer[modelRow].U_PLANDNO = model.VCJBSDCollection[i].U_PLANDNO;
                    modelLines_ServiceLayer[modelRow].U_PLANNO = model.VCJBSDCollection[i].U_PLANNO;
                    modelLines_ServiceLayer[modelRow].U_OPCode = model.VCJBSDCollection[i].U_OPCode;
                    modelLines_ServiceLayer[modelRow].U_PLANQty = model.VCJBSDCollection[i].U_PLANQty;
                    modelLines_ServiceLayer[modelRow].U_PROCQty = model.VCJBSDCollection[i].U_PROCQty;
                    modelLines_ServiceLayer[modelRow].U_PENDQty = model.VCJBSDCollection[i].U_PENDQty;
                    modelLines_ServiceLayer[modelRow].U_ICode = model.VCJBSDCollection[i].U_ICode;
                    modelLines_ServiceLayer[modelRow].U_IName = model.VCJBSDCollection[i].U_IName;
                    modelLines_ServiceLayer[modelRow].U_Qty = model.VCJBSDCollection[i].U_Qty;
                    modelLines_ServiceLayer[modelRow].U_IsSplit = model.VCJBSDCollection[i].U_IsSplit;
                    modelLines_ServiceLayer[modelRow].U_Status = model.VCJBSDCollection[i].U_Status;
                    modelLines_ServiceLayer[modelRow].U_Cancel = model.VCJBSDCollection[i].U_Cancel;
                    modelRow++;
                }
            }
            #endregion

            _objServiceLayer.VCJBSDCollection = modelLines_ServiceLayer;
            string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
            {
                NullValueHandling = NullValueHandling.Ignore,
            });
            var temp = JsonConvert.DeserializeObject<JObject>(main);

            string serviceLayerObject = "";
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				//serviceLayerObject = ServiceLayerEntity.Drafts.ToString();
                //rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject + "(" + model.DocEntry + ")";
                serviceLayerObject = ServiceLayerEntity.VCJBSM.ToString();
                rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject + "(" + model.DocNum + ")";
                rc.patchJSON = main;
				rc.B1SESSION = res;
				string message = "";
				bool result = rc.postRequest(out message);
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string docEntry = jobject["DocEntry"].ToString();
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during process: " + jsonMessage;
				}
				rc.LogOut();
			}
			else
			{
				responseModel.ResponseText = "Service layer login failed";
			}
			return responseModel;
		}
        public List<JCModel> GetJCNo(string mcode,string jobNo)
        {
            List<JCModel> _list = new List<JCModel>();
            try
            {
				HanaParameter[] parameters = new HanaParameter[2];
				parameters[0] = new HanaParameter("U_MCode", SqlDbType.VarChar);
				parameters[0].Value = mcode == null ? string.Empty : mcode;

				parameters[1] = new HanaParameter("JobNo", SqlDbType.VarChar);
				parameters[1].Value = jobNo == null ? "0" : jobNo;

				string query = ConfigManager.GetSAPDatabase() + ".\"Web_FMS_JobSequence_JCNo\"";

				using (DataTable datatable = FillDataTable(query, CommandType.StoredProcedure, out string message, parameters))
                {
                    _list = ConvertDatatableToList.ConvertToList<JCModel>(datatable);
                }
            }
            catch
            {

            }
            return _list;
        }
		public List<JCModel> GetOPNo(string planno, string mcode)
        {
			List<JCModel> _list = new List<JCModel>();
			try
            {
				HanaParameter[] parameters = new HanaParameter[2];
				parameters[0] = new HanaParameter("U_PLANNO", SqlDbType.VarChar);
				parameters[0].Value = planno == null ? string.Empty : planno;

				parameters[1] = new HanaParameter("U_MCode", SqlDbType.VarChar);
				parameters[1].Value = mcode == null ? string.Empty : mcode;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"U_ProcNm\" AS \"ProName\" FROM " + ConfigManager.GetSAPDatabase() + ".\"@VCPPD1\" T0 ");
				stringBuilder.Append(" WHERE T0.\"U_MCode\" = '" + mcode + "' AND T0.\"DocEntry\" = '" + planno + "' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<JCModel>(datatable);
				}
            }
            catch
            {

            }
            return _list;
        }
    }
}