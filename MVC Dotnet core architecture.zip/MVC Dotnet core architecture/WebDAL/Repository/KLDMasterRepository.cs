﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sap.Data.Hana;
using WebDAL.Helper;
using WebDAL.Helpers;
using WebDAL.IRepository;
using WebDAL.Models;
using static WebDAL.Models.KLDMasterModel;

namespace WebDAL.Repository
{
    public class KLDMasterRepository : clsDataAccess, IKLDMasterRepository
    {
        string query = "";
        CommonRepository commonRepository = new CommonRepository();
        StringBuilder stringBuilder = new StringBuilder();
        string headerTable = CommonTables.KLDHeaderTable;
        string rowTable = CommonTables.KLDRowTable;
        public List<KLDMasterModel> GetAll(string status)
        {
            List<KLDMasterModel> _list = new List<KLDMasterModel>();
            try
            {
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT ROW_NUMBER() OVER(order by cast(T0.\"Code\" As int)) AS \"RowNo\"");
                stringBuilder.Append(" ,T0.\"Code\",T0.\"U_KLDNo\",T0.\"U_KLDPart\", T0.\"U_NoOfUps\",T0.\"U_CardCode\", T1.\"CardName\"");
                stringBuilder.Append(" ,T11.\"U_ItemCode\" , T2.\"ItemName\", T5.\"Location\" , T0.\"U_Remark\" ,TO_NVARCHAR(T0.\"U_KLDDt\", 'DD/MM/YYYY') AS \"U_KLDDt\"");
                stringBuilder.Append(" ,T0.\"U_Lmm\",T0.\"U_Wmm\" , T0.\"U_Hmm\" ,T14.\"U_Desc\" AS \"U_CartTyp\" ");//,T0.\"U_SuppCode\",T3.\"CardName\" AS \"SuppName\"
                stringBuilder.Append(" ,T0.\"U_Emboss\" ,T0.\"U_Striping\" ,T0.\"U_Foil\", T4.\"U_NAME\"");
                stringBuilder.Append(" ,T13.\"U_PunchNo\" , T13.\"U_PunchTyp\", T0.\"U_Desc\", T0.\"U_Status\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_KLD\" T0 ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCRD T1 ON T0.\"U_CardCode\"=T1.\"CardCode\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"@WEB_KLD1\" T11 ON T11.\"U_BaseCode\"=T0.\"Code\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OITM T2 ON T11.\"U_ItemCode\"=T2.\"ItemCode\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OUSR T4 ON T0.\"U_CrBy\"=T4.\"USERID\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OLCT T5 ON T0.\"U_Location\"= CAST(T5.\"Code\" as varchar(100)) ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PUNCH1\" T15 ON T15.\"U_KLDNo\"=T0.\"U_KLDNo\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PUNCH\" T13 ON T13.\"Code\"=T15.\"U_BaseCode\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"@DDMASTER1\" T14 ON T0.\"U_CartTyp\"=T14.\"U_Value\" AND T14.\"Code\"='CARTONTYPE' ");
                stringBuilder.Append(" where T0.\"U_Status\" = '" + status + "' ");

                stringBuilder.Append(" ORDER BY \"RowNo\" desc ");

                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    _list = ConvertDatatableToList.ConvertToList<KLDMasterModel>(datatable);
                }
            }
            catch
            {
            }
            return _list;
        }
        public KLDMasterModel Get(string code)
        {
            KLDMasterModel model = new KLDMasterModel();
            try
            {
                HanaParameter[] parameters = new HanaParameter[1];

                parameters[0] = new HanaParameter("Code", System.Data.SqlDbType.VarChar);
                parameters[0].Value = code;

                //parameters[1] = new HanaParameter("ItemCode", System.Data.SqlDbType.VarChar);
                //parameters[1].Value = itemcode;

                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"Code\",T0.\"U_KLDNo\", T0.\"U_NoOfUps\",T0.\"U_CardCode\",T1.\"CardName\"");
                stringBuilder.Append(" , T0.\"U_Location\" , T0.\"U_Remark\",TO_NVARCHAR(T0.\"U_KLDDt\", 'DD/MM/YYYY') AS \"U_KLDDt\" ");
                stringBuilder.Append(" ,T0.\"U_Lmm\",T0.\"U_Wmm\" , T0.\"U_Hmm\" ,T0.\"U_CartTyp\"");//,T0.\"U_SuppCode\",T3.\"CardName\" AS \"SuppName\" 
                stringBuilder.Append(" ,T0.\"U_Emboss\" ,T0.\"U_Striping\" ,T0.\"U_Foil\", T4.\"U_NAME\"");
                stringBuilder.Append(" ,T0.\"U_PartCode\" ,T0.\"U_TuckInflap\" ,T0.\"U_NoofPart\", T0.\"U_DustFlap\"");
                stringBuilder.Append(" ,T0.\"U_Status\" ,T0.\"U_RefKLD\" ,T0.\"U_Desc\" ");
                stringBuilder.Append(" ,T5.\"U_ItemCode\" ,T6.\"ItemName\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_KLD\" T0 ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCRD T1 ON T0.\"U_CardCode\"=T1.\"CardCode\" ");
                // stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCRD T3 ON T3.\"CardCode\"=T0.\"U_SuppCode\" AND T3.\"CardType\" = 'S'");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OUSR T4 ON T0.\"U_CrBy\"=T4.\"USERID\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"@WEB_KLD1\" T5 ON T5.\"U_BaseCode\"=T0.\"Code\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OITM T6 ON T5.\"U_ItemCode\"=T6.\"ItemCode\" ");
                stringBuilder.Append(" WHERE T0.\"Code\" = " + code + " ");
                //if (!string.IsNullOrEmpty(itemcode))
                //{
                //    stringBuilder.Append(" AND T5.\"U_ItemCode\" = '" + itemcode + "'  ");
                //}
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                {
                    if (datatable.Rows.Count > 0)
                    {
                        model = ConvertDatatableToList.ConvertToEntity<KLDMasterModel>(datatable);
                        if (datatable.Rows[0]["U_Emboss"].ToString() == "Y")
                        {
                            model.IsEmboss = true;
                        }
                        if (datatable.Rows[0]["U_Striping"].ToString() == "Y")
                        {
                            model.IsStriping = true;
                        }
                        if (datatable.Rows[0]["U_Foil"].ToString() == "Y")
                        {
                            model.IsFoil = true;
                        }
                    }
                }

                #region Row
                //stringBuilder = new StringBuilder();
                //stringBuilder.Append(" SELECT ROW_NUMBER() OVER (ORDER BY T0.\"U_KLDNo\") AS \"Index\" ");
                //stringBuilder.Append(" ,T0.\"U_ItemCode\" AS \"ItemCode\",T0.\"U_NoOfUps\",T1.\"ItemName\" ");
                //stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_KLD\" T0 ");
                //stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OITM T1 ON T0.\"U_ItemCode\"=T1.\"ItemCode\" ");
                //stringBuilder.Append(" WHERE T0.\"U_KLDNo\" = '" + model.U_KLDNo + "' ");
                //using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                //{
                //	List<KLDMasterRowsModel> modelRows = ConvertDatatableToList.ConvertToList<KLDMasterRowsModel>(datatable);
                //	model.Rows = modelRows;
                //}
                #endregion

            }
            catch
            {

            }
            return model;
        }
        public ResponseModel Add(KLDMasterModel model)
        {
            string message = "";
            ResponseModel responseModel = new ResponseModel();
            try
            {

                string Emboss = model.IsEmboss == true ? "Y" : "N";
                string Striping = model.IsStriping == true ? "Y" : "N";
                string Foil = model.IsFoil == true ? "Y" : "N";
                DateTime kldDate = DateTime.ParseExact(model.U_KLDDt, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                var rows = model.PartRows.Where(a => a.Numbering != null).ToList();
                for (int i = 0; i < rows.Count; i++)
                {
                    stringBuilder = new StringBuilder();
                    stringBuilder.Append(" SELECT MAX(Cast(\"Code\" AS INT)) + 1 FROM   " + ConfigManager.GetSAPDatabase() + ".\"@WEB_KLD\" ");
                    DataTable dt = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
                    string code = dt.Rows[0][0].ToString();
                    if (code == string.Empty)
                    {
                        code = "1";
                    }

                    string kldPartNo = model.U_KLDNo + rows[i].PartNo + rows[i].Numbering;
                    stringBuilder = new StringBuilder();
                    stringBuilder.Append(" INSERT INTO  " + ConfigManager.GetSAPDatabase() + ".\"@WEB_KLD\"(\"Code\",\"Name\",\"U_Status\" ");
                    stringBuilder.Append(" ,\"U_KLDNo\" ,\"U_CardCode\" ");
                    stringBuilder.Append(" , \"U_KLDDt\" ");
                    if (!string.IsNullOrEmpty(model.U_Location))
                    {
                        stringBuilder.Append(" ,\"U_Location\" ");
                    }
                    if (!string.IsNullOrEmpty(model.U_NoOfUps))
                    {
                        stringBuilder.Append(" ,\"U_NoOfUps\" ");
                    }
                    if (model.U_Remark != null)
                    {
                        stringBuilder.Append(" ,\"U_Remark\" ");
                    }

                    stringBuilder.Append(" ,\"U_Lmm\",\"U_Wmm\" , \"U_Hmm\" , \"U_CartTyp\",\"U_CrBy\" ");//,\"U_SuppCode\"
                                                                                                          //stringBuilder.Append(" ,\"U_PunchTyp\",\"U_Emboss\" , \"U_Striping\" , \"U_Foil\" ");
                    stringBuilder.Append(" ,\"U_Emboss\" , \"U_Striping\" , \"U_Foil\" ");
                    stringBuilder.Append(" ,\"U_PartCode\" , \"U_TuckInflap\" , \"U_NoofPart\", \"U_DustFlap\" ");
                    stringBuilder.Append(" , \"U_RefKLD\" , \"U_Desc\" ");
                    stringBuilder.Append("  ) ");
                    stringBuilder.Append(" VALUES('" + code + "','" + code + "','A'");
                    stringBuilder.Append(" ,'" + kldPartNo + "','" + model.U_CardCode + "' ");
                    stringBuilder.Append(" ,'" + kldDate.ToString("yyyMMdd") + "' ");
                    if (!string.IsNullOrEmpty(model.U_Location))
                    {
                        stringBuilder.Append(" ,'" + model.U_Location + "' ");
                    }
                    if (!string.IsNullOrEmpty(model.U_NoOfUps))
                    {
                        stringBuilder.Append(" ,'" + model.U_NoOfUps + "' ");
                    }
                    if (model.U_Remark != null)
                    {
                        stringBuilder.Append(" ,'" + model.U_Remark.Replace("'", "''") + "' ");
                    }
                    stringBuilder.Append(" ,'" + model.U_Lmm + "','" + model.U_Wmm + "','" + model.U_Hmm + "' , '" + model.U_CartTyp + "'");
                    //stringBuilder.Append(" ,'" + model.U_CrBy + "','" + model.U_SuppCode + "','" + model.U_PunchTyp + "' , '" + Emboss + "' ");
                    stringBuilder.Append(" ,'" + model.U_CrBy + "', '" + Emboss + "' ");//,'" + model.U_SuppCode + "'
                    stringBuilder.Append(" ,'" + Striping + "','" + Foil + "' ");
                    stringBuilder.Append(" ,'" + model.U_PartCode + "','" + model.U_TuckInflap + "','" + model.U_NoofPart + "','" + model.U_DustFlap + "'");
                    stringBuilder.Append(" ,'" + model.U_RefKLD + "','" + model.U_Desc + "' ");
                    stringBuilder.Append("  ) ");
                    FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
                    if (message == string.Empty)
                    {
                        responseModel.ResponseText = "Operation completed successfully";
                        responseModel.ResponseStatus = true;
                        if (i == 0)
                        {
                            UpdateNextNumber("WEB_KLD");
                        }
                    }
                    else
                    {
                        responseModel.ResponseText = "Error occured during process: " + message;
                    }
                }
            }
            catch (Exception ex)
            {
                responseModel.ResponseText = "Error occured during process: " + ex.Message;
                responseModel.ResponseStatus = false;
            }
            return responseModel;
        }
        public ResponseModel Update(KLDMasterModel model)
        {
            ResponseModel responseModel = new ResponseModel();
            string message = "";

            string Emboss = model.IsEmboss == true ? "Y" : "N";
            string Striping = model.IsStriping == true ? "Y" : "N";
            string Foil = model.IsFoil == true ? "Y" : "N";
            DateTime kldDate = DateTime.ParseExact(model.U_KLDDt, "dd/MM/yyyy", CultureInfo.InvariantCulture);

            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_KLD\" ");
            stringBuilder.Append("  SET \"U_KLDNo\" = '" + model.U_KLDNo + "',\"U_CardCode\" = '" + model.U_CardCode + "' ");
            stringBuilder.Append(" , \"U_KLDDt\" = '" + kldDate.ToString("yyyMMdd") + "' ");
            //stringBuilder.Append(" , \"U_NoOfUps\" = '" + model.U_NoOfUps + "',\"U_SizeX\" = '" + model.U_SizeX + "' ");
            stringBuilder.Append(" , \"U_NoOfUps\" = '" + model.U_NoOfUps + "' ");
            //stringBuilder.Append(" , \"U_SizeY\" = '" + model.U_SizeY + "',\"U_PunchNo\" = '" + model.U_PunchNo + "' ");
            stringBuilder.Append(" ,\"U_Location\" = '" + model.U_Location + "',\"U_Remark\" = '" + model.U_Remark + "' ");
            stringBuilder.Append(" , \"U_Lmm\" = '" + model.U_Lmm + "',\"U_Wmm\" = '" + model.U_Wmm + "',\"U_Hmm\" = '" + model.U_Hmm + "' ");
            //stringBuilder.Append(" , \"U_CartTyp\" = '" + model.U_CartTyp + "',\"U_PunchTyp\" = '" + model.U_PunchTyp + "' ");
            stringBuilder.Append(" , \"U_CartTyp\" = '" + model.U_CartTyp + "' ");
            stringBuilder.Append(" , \"U_Emboss\" = '" + Emboss + "' ,\"U_Striping\" = '" + Striping + "' ,\"U_Foil\" = '" + Foil + "' ");
            stringBuilder.Append(" ,\"U_PartCode\" = '" + model.U_PartCode + "',\"U_TuckInflap\" = '" + model.U_TuckInflap + "' ");
            stringBuilder.Append(" ,\"U_NoofPart\" = '" + model.U_NoofPart + "',\"U_DustFlap\" = '" + model.U_DustFlap + "' ");
            stringBuilder.Append(" ,\"U_Status\" = '" + model.U_Status + "',\"U_RefKLD\" = '" + model.U_RefKLD + "' ");
            stringBuilder.Append(" ,\"U_Desc\" = '" + model.U_Desc + "' ");
            stringBuilder.Append(" WHERE \"Code\" = '" + model.Code + "'");

            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (message == string.Empty)
            {
                responseModel.ResponseText = "Updated successfully";
                //AddRows(model.Code, model.Rows);
            }
            else
            {
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            return responseModel;
        }
        public ResponseModel AddRows(string basecode, List<KLDMasterRowsModel> modelRows)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                stringBuilder = new StringBuilder();
                stringBuilder.Append("DELETE FROM " + ConfigManager.GetSAPDatabase() + ".\"" + rowTable + "\" WHERE \"U_BaseCode\" ='" + basecode + "' ");
                GetRecordValue(stringBuilder.ToString(), CommandType.Text, out string message);
                for (int i = 0; i < modelRows.Count; i++)
                {
                    stringBuilder = new StringBuilder();
                    stringBuilder.Append("SELECT IFNULL(MAX(Cast(\"Code\" as NUMERIC(19,0))),0) + 1   FROM " + ConfigManager.GetSAPDatabase() + ".\"" + rowTable + "\" ");
                    string code = GetRecordValue(stringBuilder.ToString(), CommandType.Text, out message);

                    HanaParameter[] parameters = new HanaParameter[5];
                    int iParameter = 0;

                    parameters[iParameter] = new HanaParameter("Code", System.Data.SqlDbType.VarChar);
                    parameters[iParameter].Value = code;
                    iParameter++;

                    parameters[iParameter] = new HanaParameter("Name", System.Data.SqlDbType.VarChar);
                    parameters[iParameter].Value = code;
                    iParameter++;

                    parameters[iParameter] = new HanaParameter("U_BaseCode", System.Data.SqlDbType.VarChar);
                    parameters[iParameter].Value = basecode;
                    iParameter++;

                    parameters[iParameter] = new HanaParameter("U_ItemCode", System.Data.SqlDbType.VarChar);
                    parameters[iParameter].Value = modelRows[i].U_ItemCode == null ? (Object)DBNull.Value : modelRows[i].U_ItemCode;
                    iParameter++;

                    parameters[iParameter] = new HanaParameter("U_NoofUPS", System.Data.SqlDbType.VarChar);
                    parameters[iParameter].Value = modelRows[i].U_NoofUPS == null ? (Object)DBNull.Value : modelRows[i].U_NoofUPS;
                    iParameter++;

                    stringBuilder = new StringBuilder();
                    stringBuilder.Append(" INSERT INTO " + ConfigManager.GetSAPDatabase() + ".\"" + rowTable + "\"");
                    stringBuilder.Append(" (\"Code\",\"Name\",\"U_BaseCode\" ");
                    stringBuilder.Append("  ,\"U_ItemCode\",\"U_NoofUPS\" )");
                    stringBuilder.Append(" VALUES ");
                    stringBuilder.Append(" (:Code,:Name,:U_BaseCode ,:U_ItemCode,:U_NoofUPS) ");
                    DataTable dt = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message, parameters);
                    if (message == string.Empty)
                    {
                        responseModel.ResponseText = "Record inserted successfully";
                        responseModel.ResponseStatus = true;
                    }
                    else
                    {
                        responseModel.ResponseText = "Error occured while processing record " + message;
                        responseModel.ResponseStatus = false;
                    }
                }
            }
            catch (Exception ex)
            {
                responseModel.ResponseText = "Error occured while processing record " + ex.Message;
                responseModel.ResponseStatus = false;

            }
            return responseModel;
        }
        private void UpdateNextNumber(string objectType)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_SERIES1\" SET ");
            stringBuilder.Append(" \"U_NextNo\"= Cast(\"U_NextNo\" as numeric(19,0)) + 1  ");
            stringBuilder.Append(" WHERE \"Code\" = '" + objectType + "' ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message);
        }

        public void UpdateStatus(string code, string status)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"" + rowTable + "\" SET ");
            stringBuilder.Append(" \"U_Status\"= '" + status + "' ");
            stringBuilder.Append(" WHERE \"Code\" = '" + code + "' ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message);
        }
    }
}