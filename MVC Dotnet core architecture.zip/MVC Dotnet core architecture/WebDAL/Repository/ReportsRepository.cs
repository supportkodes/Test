﻿using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Sap.Data.Hana;
using System.Text;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using WebDAL.Helpers;
using System.Globalization;
using System.Reflection;

namespace WebDAL.Repository
{
	public class ReportsRepository : clsDataAccess, IReportsRepository
	{
		string query = "";
		StringBuilder stringBuilder = new StringBuilder();
		CommonRepository commonRepository = new CommonRepository();

		public List<BackOrderReportModel> GetBackOrderReport(string userId, string fromDate, string toDate, string cardcode, string itemcode)
		{
			List<BackOrderReportModel> _list = new List<BackOrderReportModel>();
			try
			{
				HanaParameter[] parameters = new HanaParameter[4];
				parameters[0] = new HanaParameter("FromDate", SqlDbType.VarChar);
				parameters[0].Value = fromDate == null || fromDate.ToLower() == "nan" ? string.Empty : fromDate;

				parameters[1] = new HanaParameter("ToDate", SqlDbType.VarChar);
				parameters[1].Value = toDate == null || toDate.ToLower() == "nan" ? string.Empty : toDate;

				parameters[2] = new HanaParameter("CardCode", SqlDbType.VarChar);
				parameters[2].Value = cardcode == null ? string.Empty : cardcode;

				parameters[3] = new HanaParameter("ItemCode", SqlDbType.VarChar);
				parameters[3].Value = itemcode == null ? string.Empty : itemcode;

				query = ConfigManager.GetSAPDatabase() + ".\"Web_Reports_BackOrder\"";
				using (DataTable datatable = FillDataTable(query, CommandType.StoredProcedure, out string message, parameters))
				{
					_list = ConvertDatatableToList.ConvertToList<BackOrderReportModel>(datatable);
					string isSuperUser = commonRepository.IsUserSuperUser(userId);
					if (isSuperUser != "Y")
					{
						List<SalesEmployeeModel> teamSalesEmployee = commonRepository.GetAllTeamSalesEmployee(userId);
						_list = _list.Where(x => teamSalesEmployee.Any(y => y.SlpCode == x.SlpCode)).ToList();
					}
				}
			}
			catch
			{
			}
			return _list;
		}

		public List<SuppliedMaterialReportModel> GetSuppliedMaterialReport(string slpcode, string fromDate, string toDate)
		{
			List<SuppliedMaterialReportModel> _list = new List<SuppliedMaterialReportModel>();
			try
			{
				HanaParameter[] parameters = new HanaParameter[3];
				parameters[0] = new HanaParameter("FromDate", SqlDbType.VarChar);
				parameters[0].Value = fromDate == null || fromDate.ToLower() == "nan" ? string.Empty : fromDate;

				parameters[1] = new HanaParameter("ToDate", SqlDbType.VarChar);
				parameters[1].Value = toDate == null || toDate.ToLower() == "nan" ? string.Empty : toDate;

				parameters[2] = new HanaParameter("SlpCode", SqlDbType.VarChar);
				parameters[2].Value = slpcode == null ? string.Empty : slpcode;

				//parameters[3] = new HanaParameter("ItemCode", SqlDbType.VarChar);
				//parameters[3].Value = itemcode == null ? string.Empty : itemcode;

				query = ConfigManager.GetSAPDatabase() + ".\"Web_Reports_SuppliedMaterial\"";
				using (DataTable datatable = FillDataTable(query, CommandType.StoredProcedure, out string message, parameters))
				{
					_list = ConvertDatatableToList.ConvertToList<SuppliedMaterialReportModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}

		public List<FGStockStatusReportRowsModel> GetFGStockStatusReport(string userId, string cardcode)
		{
			List<FGStockStatusReportRowsModel> _list = new List<FGStockStatusReportRowsModel>();
			try
			{
				List<SalesEmployeeModel> teamSalesEmployee = commonRepository.GetAllTeamSalesEmployee(userId);
				//_list = _list.Where(x => teamSalesEmployee.Any(y => y.SlpCode == x.SlpCode)).ToList();
				for (int i = 0; i < teamSalesEmployee.Count; i++)
				{
					string slpcode = teamSalesEmployee[i].SlpCode;
					HanaParameter[] parameters = new HanaParameter[3];
					parameters[0] = new HanaParameter("SlpCode", SqlDbType.VarChar);
					parameters[0].Value = slpcode == null ? string.Empty : slpcode;

					parameters[1] = new HanaParameter("CardCode", SqlDbType.VarChar);
					parameters[1].Value = cardcode == null ? string.Empty : cardcode;

					parameters[2] = new HanaParameter("ItemGroup", SqlDbType.VarChar);
					parameters[2].Value = string.Empty; //itemcode == null ? string.Empty : itemcode;

					query = ConfigManager.GetSAPDatabase() + ".\"Web_FG_Status\"";
					using (DataTable datatable = FillDataTable(query, CommandType.StoredProcedure, out string message, parameters))
					{
						List<FGStockStatusReportRowsModel> _list1 = ConvertDatatableToList.ConvertToList<FGStockStatusReportRowsModel>(datatable);
						_list.AddRange(_list1);
					}
				}

				for (int i = 0; i < _list.Count; i++)
				{
					_list[i].FGStk = double.Parse(_list[i].FGStk).ToString("N0");
					_list[i].OpenOrderQty = double.Parse(_list[i].OpenOrderQty).ToString("N0");
				}
			}
			catch
			{

			}
			return _list;
		}

		public List<DispatchDetailsReportModel> GetDispatchReport(string fromDate, string toDate, string slpcode)
		{
			List<DispatchDetailsReportModel> _list = new List<DispatchDetailsReportModel>();
			try
			{
				HanaParameter[] parameters = new HanaParameter[3];
				parameters[0] = new HanaParameter("FromDate", SqlDbType.VarChar);
				parameters[0].Value = fromDate == null || fromDate.ToLower() == "nan" ? string.Empty : fromDate;

				parameters[1] = new HanaParameter("ToDate", SqlDbType.VarChar);
				parameters[1].Value = toDate == null || toDate.ToLower() == "nan" ? string.Empty : toDate;

				parameters[2] = new HanaParameter("SlpCode", SqlDbType.VarChar);
				parameters[2].Value = slpcode == null ? string.Empty : slpcode;

				
				query = ConfigManager.GetSAPDatabase() + ".\"Web_Reports_DispatchDetails\"";
				using (DataTable datatable = FillDataTable(query, CommandType.StoredProcedure, out string message, parameters))
				{
					_list = ConvertDatatableToList.ConvertToList<DispatchDetailsReportModel>(datatable);
				}
			}
			catch
			{
			}
			return _list;
		}

		public List<FGStockStatusReportDetailRowsModel> GetFGStockStatusItemWiseReport(string itemcode)
		{
			List<FGStockStatusReportDetailRowsModel> _list = new List<FGStockStatusReportDetailRowsModel>();
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];
				parameters[0] = new HanaParameter("ItemCode", SqlDbType.VarChar);
				parameters[0].Value = itemcode == null ? string.Empty : itemcode;

				query = ConfigManager.GetSAPDatabase() + ".\"Web_FG_Status_ItemWise\"";
				using (DataTable datatable = FillDataTable(query, CommandType.StoredProcedure, out string message, parameters))
				{
					_list = ConvertDatatableToList.ConvertToList<FGStockStatusReportDetailRowsModel>(datatable);
					for (int i = 0; i < _list.Count; i++)
					{
						_list[i].SOQty = double.Parse(_list[i].SOQty).ToString("N0");
						_list[i].OpenQty = double.Parse(_list[i].OpenQty).ToString("N0");
						_list[i].DelQty = double.Parse(_list[i].DelQty).ToString("N0");
						_list[i].Diff = double.Parse(_list[i].Diff).ToString("N0");
					}
				}
			}
			catch
			{

			}
			return _list;
		}

		public List<ItemPriceReportModel> GetItemPriceReport(string itemcode)
		{
			List<ItemPriceReportModel> _list = new List<ItemPriceReportModel>();
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("ItemCode", SqlDbType.VarChar);
				parameters[0].Value = itemcode == null ? string.Empty : itemcode;

				query = ConfigManager.GetSAPDatabase() + ".\"Web_Reports_Item_Price\"";
				using (DataTable datatable = FillDataTable(query, CommandType.StoredProcedure, out string message, parameters))
				{
					_list = ConvertDatatableToList.ConvertToList<ItemPriceReportModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}

		public List<PaymentProjectionRowsModel> GetPaymentProjection(string slpcode, string fromDate, string toDate, string year, string weekNo)
		{
			List<PaymentProjectionRowsModel> _list = new List<PaymentProjectionRowsModel>();
			try
			{
				HanaParameter[] parameters = new HanaParameter[5];

				parameters[0] = new HanaParameter("Year", SqlDbType.VarChar);
				parameters[0].Value = year == null ? string.Empty : year;

				parameters[1] = new HanaParameter("WeekNo", SqlDbType.VarChar);
				parameters[1].Value = weekNo == null ? string.Empty : weekNo;

				parameters[2] = new HanaParameter("SlpCode", SqlDbType.VarChar);
				parameters[2].Value = slpcode == null ? string.Empty : slpcode;

				parameters[3] = new HanaParameter("FromDate", SqlDbType.VarChar);
				parameters[3].Value = fromDate == null ? string.Empty : fromDate;

				parameters[4] = new HanaParameter("ToDate", SqlDbType.VarChar);
				parameters[4].Value = toDate == null ? string.Empty : toDate;

				query = ConfigManager.GetSAPDatabase() + ".\"Web_Payment_Projection\"";
				using (DataTable datatable = FillDataTable(query, CommandType.StoredProcedure, out string message, parameters))
				{
					_list = ConvertDatatableToList.ConvertToList<PaymentProjectionRowsModel>(datatable);
					for (int i = 0; i < _list.Count; i++)
					{
						double dblProjection = _list[i].U_ProAmt == null ? 0 : _list[i].U_ProAmt.Value;

						double dblAccountBalance = Math.Round(double.Parse(_list[i].U_AccBal), 2);
						_list[i].U_AccBal = dblAccountBalance.ToString("N0");

						double dblOverDue = Math.Round(double.Parse(_list[i].U_OverDue), 2);
						_list[i].U_OverDue = dblOverDue.ToString("N0");

						double dblAmtReceived = Math.Round(double.Parse(_list[i].U_AmtRecd), 2);
						_list[i].U_AmtRecd = dblAmtReceived.ToString("N0");

						double dblBalance = dblProjection - dblAmtReceived;
						dblBalance = Math.Round(dblBalance, 2);
						_list[i].Balance = dblBalance.ToString("N0");

						double collPerAgainstProjection = 0;
						double collPerAgainstOverDue = 0;
						if (dblProjection > 0)
						{
							collPerAgainstProjection = dblAmtReceived * 100 / dblProjection;
						}
						_list[i].CollProj = Math.Round(collPerAgainstProjection, 2);
						if (dblOverDue > 0)
						{
							collPerAgainstOverDue = dblAmtReceived * 100 / dblOverDue;
						}
						_list[i].CollOD = Math.Round(collPerAgainstOverDue, 2);
					}

				}
			}
			catch
			{

			}
			return _list;
		}

		public ResponseModel ConfirmProjection(string slpcode, string year, string weekNo)
		{
			string message = "";

			ResponseModel responseModel = new ResponseModel();
			stringBuilder = new StringBuilder();
			stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@PAYPROJ\" T0   ");
			stringBuilder.Append(" SET \"U_IsConfirm\"='Y'   ");
			stringBuilder.Append(" WHERE \"Name\" ='" + slpcode + "' AND \"U_Year\" ='" + year + "' AND \"U_WeekNo\" ='" + weekNo + "'      ");
			FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);

			if (message == string.Empty)
			{
				responseModel.ResponseText = "Operation completed successfully";
				responseModel.ResponseStatus = true;
			}
			else
			{
				responseModel.ResponseText = "Error occured during process: " + message;
			}

			return responseModel;
		}

		public ResponseModel AddPaymentProjection(PaymentProjectionModel model)
		{
			string message = "";
			string isConfirm = "N";
			//string slpcode = commonRepository.GetSlpCodeFromEmailAddress(model.UserId);
			string fromDate = model.FromDate;
			string toDate = model.ToDate;

			DateTime dtFromDate = DateTime.ParseExact(fromDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
			fromDate = dtFromDate.ToString("yyyyMMdd");

			DateTime dtToDate = DateTime.ParseExact(toDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
			toDate = dtToDate.ToString("yyyyMMdd");

			ResponseModel responseModel = new ResponseModel();
			stringBuilder = new StringBuilder();
			stringBuilder.Append(" SELECT * FROM  " + ConfigManager.GetSAPDatabase() + ".\"@PAYPROJ\" T0   ");
			stringBuilder.Append(" WHERE \"Name\" ='" + model.SlpCode + "' AND \"U_Year\" ='" + model.U_Year + "' AND \"U_WeekNo\" ='" + model.U_WeekNo + "'      ");
			DataTable dtConfrim = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
			if (dtConfrim.Rows.Count > 0)
			{
				isConfirm = dtConfrim.Rows[0]["U_IsConfirm"].ToString();
				isConfirm = isConfirm == "" ? "N" : isConfirm;
			}
			try
			{
				if (model.PaymentProjectionRows[0].U_IsConfirm == "Y")
				{
					isConfirm = "Y";
				}
			}
			catch { }
			stringBuilder = new StringBuilder();
			stringBuilder.Append(" DELETE FROM  " + ConfigManager.GetSAPDatabase() + ".\"@PAYPROJ\" T0   ");
			stringBuilder.Append(" WHERE \"Name\" ='" + model.SlpCode + "' AND \"U_Year\" ='" + model.U_Year + "' AND \"U_WeekNo\" ='" + model.U_WeekNo + "'      ");
			FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);

			stringBuilder = new StringBuilder();
			stringBuilder.Append(" Select cast(max((TO_NUMBER(T0.\"Code\")))+1 as nvarchar(50))  ");
			stringBuilder.Append(" FROM  " + ConfigManager.GetSAPDatabase() + ".\"@PAYPROJ\" T0      ");
			DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
			string code = datatable.Rows[0][0].ToString();
			code = code == string.Empty ? "1" : code;
			double dblCode = double.Parse(code);

			model.PaymentProjectionRows = model.PaymentProjectionRows.Where(a => !string.IsNullOrEmpty(a.U_CardCode)).ToList();
			//model.PaymentProjectionRows.Count
			for (int i = 0; i < model.PaymentProjectionRows.Count; i++)
			{
				double dblProjectionAmt = model.PaymentProjectionRows[i].U_ProAmt == null ? 0 : model.PaymentProjectionRows[i].U_ProAmt.Value;
				string dblAmtReceived = model.PaymentProjectionRows[i].U_AmtRecd == null ? "0" : model.PaymentProjectionRows[i].U_AmtRecd.Replace(",", "");
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" INSERT INTO " + ConfigManager.GetSAPDatabase() + ".\"@PAYPROJ\"(\"Code\",\"Name\",\"U_CardCode\",\"U_Year\",\"U_WeekNo\",\"U_AccBal\",\"U_OverDue\",\"U_ProAmt\",\"U_IsConfirm\",\"U_FromDate\",\"U_ToDate\") ");
				stringBuilder.Append(" VALUES('" + dblCode.ToString() + "','" + model.SlpCode + "', ");
				stringBuilder.Append(" '" + model.PaymentProjectionRows[i].U_CardCode + "',"); ;
				stringBuilder.Append(" '" + model.U_Year + "', ");
				stringBuilder.Append(" '" + model.U_WeekNo + "', ");
				stringBuilder.Append(" '" + model.PaymentProjectionRows[i].U_AccBal.Replace(",", "") + "', ");
				stringBuilder.Append(" '" + model.PaymentProjectionRows[i].U_OverDue.Replace(",", "") + "', ");
				stringBuilder.Append(" '" + dblProjectionAmt + "', ");
				//stringBuilder.Append(" '" + dblAmtReceived + "', ");
				stringBuilder.Append(" '" + isConfirm + "', ");
				stringBuilder.Append(" '" + fromDate + "', ");
				stringBuilder.Append(" '" + toDate + "' ");
				stringBuilder.Append(" ); ");
				FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
				dblCode = dblCode + 1;
			}
			if (message == string.Empty)
			{
				responseModel.ResponseStatus = true;
				responseModel.ResponseText = "Operation completed successfully";
			}
			else
			{
				responseModel.ResponseStatus = false;
				responseModel.ResponseText = "Error occured during process: " + message;
			}

			return responseModel;
		}

		public ResponseModel ExportSalesQuotation(string docEntry)
		{
			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();
			string res = rc.ReportLogin();
			if (res != "" && res.Contains("error") == false)
			{
				VariantModel _objServiceLayer = new VariantModel();

				List<ReportParameterBody> reportParameterBodyList = new List<ReportParameterBody>();
				ReportParameterBody reportParameterBody = new ReportParameterBody();

				#region DocKey

				reportParameterBody.name = "DocKey@";
				reportParameterBody.type = "xsd:decimal";
				List<string> strings = new List<string>();
				strings.Add(docEntry.Trim());
				List<List<string>> stringList = new List<List<string>>();
				stringList.Add(strings);
				reportParameterBody.value = stringList;
				reportParameterBodyList.Add(reportParameterBody);

				#endregion

				#region ObjectID
				reportParameterBody = new ReportParameterBody();
				reportParameterBody.name = "ObjectID@";
				reportParameterBody.type = "xsd:string";
				strings = new List<string>();
				strings.Add("23");
				stringList = new List<List<string>>();
				stringList.Add(strings);
				reportParameterBody.value = stringList;
				reportParameterBodyList.Add(reportParameterBody);

				#endregion

				#region Schema
				reportParameterBody = new ReportParameterBody();
				reportParameterBody.name = "Schema@";
				reportParameterBody.type = "xsd:string";
				strings = new List<string>();
				strings.Add(ConfigManager.GetSAPDatabase());
				stringList = new List<List<string>>();
				stringList.Add(strings);
				reportParameterBody.value = stringList;
				reportParameterBodyList.Add(reportParameterBody);

				#endregion

				string main = JsonConvert.SerializeObject(reportParameterBodyList, new JsonSerializerSettings()
				{
					NullValueHandling = NullValueHandling.Ignore,
				});


				var temp = JsonConvert.DeserializeObject<JArray>(main);
				//rc.endPoint = ConfigManager.GetReportServiceLayerURL() + "rs/v1/ExportPDFData?DocCode=RCRI0112";
				rc.endPoint = ConfigManager.GetReportServiceLayerURL() + "rs/v1/LoadAuthorizedCRList";
				//rc.patchJSON = main;
				rc.B1SESSION = res;
				rc.httpMethod = httpVerb.GET;
				string message = "";
				//rc.Test();
				//bool result = rc.getRequest(out message);
				//bool result = rc.getRequest(out message);
				bool result = rc.ReportLoginGetRequest(out message);

				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during process: " + jsonMessage;
				}
				rc.LogOut();
			}
			else
			{
				responseModel.ResponseText = "Service layer login failed";
			}
			return responseModel;
		}

		public ResponseModel TestGet(string docEntry)
		{
			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				rc.endPoint = ConfigManager.GetServiceLayerURL() + "Items('13600000019909611800802')";
				//rc.patchJSON = main;
				rc.B1SESSION = res;
				rc.httpMethod = httpVerb.GET;
				string message = "";
				bool result = rc.ReportLoginGetRequest(out message);
				//result = rc.getRequest(out message);
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during process: " + jsonMessage;
				}
				rc.LogOut();
			}
			else
			{
				responseModel.ResponseText = "Service layer login failed";
			}
			return responseModel;
		}

		public List<InventoryTransferReportModel> GetInventoryTransferReport(string toDate)
		{
			List<InventoryTransferReportModel> _list = new List<InventoryTransferReportModel>();
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];
				parameters[0] = new HanaParameter("ToDate", SqlDbType.VarChar);
				parameters[0].Value = toDate == null || toDate.ToLower() == "nan" ? string.Empty : toDate;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"ItemCode\", T0.\"ItemName\", T0.\"U_MNAME\",T1.\"ItmsGrpNam\",T0.\"U_Brand\" ");//
				stringBuilder.Append(" , T0.\"U_DickleSize\",T0.\"U_SheetSizeX\",T0.\"U_SheetSizeY\",T0.\"U_PaperGSM\" ,T0.\"U_Microns\" ");
				stringBuilder.Append(" , Round(case when (ifnull(t0.\"U_DickleSize\",0)/100)<>0 then ifnull(sum(t2.\"Quantity\"),0)/(ifnull(t0.\"U_DickleSize\",0)/100) else 0 end) as \"Rmtr\" ");
				stringBuilder.Append(" , T0.\"U_ThicknessOfFilm\", sum(T2.\"Quantity\") as \"Quantity\" ");
				stringBuilder.Append(" , T2.\"WhsCode\",T0.\"U_SheetSizeX\" * T0.\"U_SheetSizeY\" * T0.\"U_PaperGSM\" * sum(T2.\"Quantity\")/10000000  as \"QtyInkgs\" ");
				stringBuilder.Append(" , T3.\"U_KgPrice\" ");
				stringBuilder.Append(" , coalesce(cast(t3.\"U_JOBDTL\" as nvarchar),cast(t6.\"U_JOBDTL\" as nvarchar)) as \"JobDetails\" ");
				stringBuilder.Append(" , coalesce(cast(t3.\"U_JCText\" as nvarchar),cast(t6.\"U_JCText\" as nvarchar)) as \"JobDetails1\"");
				stringBuilder.Append(" , cast(T3.\"Text\" as nvarchar),T3.\"U_ClientName\",(T3.\"U_NoOfUps\" * T3.\"Quantity\") as \"JobQuantity\" ");
				stringBuilder.Append(" , T3.\"U_NoOfUps\", T7.\"PostDate\", T4.\"DocEntry\" ,T4.\"DocNum\",TO_NVARCHAR(T4.\"DocDate\", 'DD/MM/YYYY')  AS \"DocDate\" ");
				stringBuilder.Append(" , T3.\"LineNum\" , T4.\"CardName\", T5.\"SlpName\", T2.\"SuppSerial\" , T3.\"U_Category\",T0.\"U_QChk\"");
				stringBuilder.Append(" FROM  " + ConfigManager.GetSAPDatabase() + ".\"OITM\" T0   ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"OITB\" T1 on T1.\"ItmsGrpCod\" = T0.\"ItmsGrpCod\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"OIBT\" T2 on T2.\"ItemCode\" = T0.\"ItemCode\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"PDN1\" T3 on T3.\"DocEntry\" = T2.\"BaseEntry\" AND T3.\"ObjType\" = T2.\"BaseType\" AND T3.\"LineNum\" = T2.\"BaseLinNum\"");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"OPDN\" T4 on T4.\"DocEntry\" = T3.\"DocEntry\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"OSLP\" T5 on T5.\"SlpCode\" = T3.\"SlpCode\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"IGN1\" T6 on T6.\"DocEntry\" = T2.\"BaseEntry\" and T6.\"ObjType\" = T2.\"BaseType\" and T6.\"LineNum\" = T2.\"BaseLinNum\" and T6.\"BaseType\"=202 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"OWOR\" T7 on T7.\"DocEntry\"= T6.\"BaseEntry\" and T7.\"ItemCode\"= T6.\"ItemCode\" ");
				stringBuilder.Append(" WHERE T2.\"Quantity\" > 0  AND T2.\"InDate\" <= :ToDate ");
				stringBuilder.Append(" GROUP BY T0.\"ItemCode\",  T0.\"ItemName\", T0.\"U_MNAME\",T1.\"ItmsGrpNam\",T0.\"U_Brand\",T0.\"U_SheetSizeX\",T0.\"U_SheetSizeY\",cast(T6.\"U_JOBDTL\" as nvarchar) ");
				stringBuilder.Append(" ,T0.\"U_PaperGSM\" ,T0.\"U_Microns\",T0.\"U_ThicknessOfFilm\",T3.\"U_KgPrice\" ,cast(T3.\"U_JOBDTL\" as nvarchar),cast(T3.\"U_JCText\" as nvarchar) ");
				stringBuilder.Append(" ,cast(T3.\"Text\" as nvarchar),T3.\"U_ClientName\",T3.\"U_NoOfUps\",T3.\"Quantity\",T3.\"U_NoOfUps\",T4.\"DocNum\",cast(T6.\"U_JCText\" as nvarchar),T7.\"PostDate\" ");
				stringBuilder.Append(" ,T4.\"DocDate\",T3.\"LineNum\",T4.\"CardName\",T4.\"DocEntry\",T0.\"U_DickleSize\",T5.\"SlpName\",T2.\"SuppSerial\",T2.\"WhsCode\",T3.\"U_Category\",T0.\"U_QChk\"");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					_list = ConvertDatatableToList.ConvertToList<InventoryTransferReportModel>(datatable);
				}
			}
			catch
			{
			}
			return _list;
		}

		public List<PORegisterReportModel> GetPORegisterReport(string fromDate, string toDate, string itmsGrpName)
		{
			List<PORegisterReportModel> _list = new List<PORegisterReportModel>();
			try
			{
				HanaParameter[] parameters = new HanaParameter[3];

				parameters[0] = new HanaParameter("FromDate", SqlDbType.VarChar);
				parameters[0].Value = fromDate == null || fromDate.ToLower() == "nan" ? string.Empty : fromDate;

				parameters[1] = new HanaParameter("ToDate", SqlDbType.VarChar);
				parameters[1].Value = toDate == null || toDate.ToLower() == "nan" ? string.Empty : toDate;

				parameters[2] = new HanaParameter("ItmsGrpNam", SqlDbType.VarChar);
				parameters[2].Value = itmsGrpName;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" Select T0.\"DocType\" ,T0.\"DocStatus\",T3.\"ItmsGrpNam\", T0.\"DocNum\",T0.\"DocDate\",T0.\"CardCode\" ");
				stringBuilder.Append(" ,T0.\"CardName\",T1.\"ItemCode\",T1.\"Dscription\",T1.\"Quantity\",T1.\"Price\" ");
				stringBuilder.Append(" ,T1.\"Weight1\",T1.\"U_KgPrice\",T1.\"LineTotal\",T0.\"DocTotal\",T0.\"U_MISNo\" ");
				stringBuilder.Append(" ,T1.\"U_JCText\",T1.\"Text\" ,T1.\"U_Category\",T1.\"WhsCode\",T0.\"U_PriceRemark\" ");
				stringBuilder.Append(" FROM  " + ConfigManager.GetSAPDatabase() + ".\"OPOR\" T0   ");
				stringBuilder.Append(" LEFT OUTER JOIN " + ConfigManager.GetSAPDatabase() + ".\"POR1\" T1 on T1.\"DocEntry\" = T0.\"DocEntry\" ");
				stringBuilder.Append(" LEFT OUTER JOIN " + ConfigManager.GetSAPDatabase() + ".\"OITM\" T2 on T2.\"ItemCode\" = T1.\"ItemCode\" ");
				stringBuilder.Append(" LEFT OUTER JOIN " + ConfigManager.GetSAPDatabase() + ".\"OITB\" T3 on T3.\"ItmsGrpCod\" = T2.\"ItmsGrpCod\" ");
				stringBuilder.Append(" WHERE T0.\"DocDate\" >= :FromDate AND T0.\"DocDate\"  <= :ToDate AND T3.\"ItmsGrpCod\" = :ItmsGrpNam ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					_list = ConvertDatatableToList.ConvertToList<PORegisterReportModel>(datatable);
				}
			}
			catch
			{
			}
			return _list;
		}

		public List<PendingPOReportModel> GetPendingPOReport(string fromDate, string toDate, string cardcode, string itemcode)
		{
			List<PendingPOReportModel> _list = new List<PendingPOReportModel>();
			try
			{
				HanaParameter[] parameters = new HanaParameter[4];
				parameters[0] = new HanaParameter("FromDate", SqlDbType.VarChar);
				parameters[0].Value = fromDate == null || fromDate.ToLower() == "nan" ? DateTime.MinValue.ToString("yyyyMMdd") : fromDate;

				parameters[1] = new HanaParameter("ToDate", SqlDbType.VarChar);
				parameters[1].Value = toDate == null || toDate.ToLower() == "nan" ? DateTime.MaxValue.ToString("yyyyMMdd") : toDate;

				parameters[2] = new HanaParameter("CardCode", SqlDbType.VarChar);
				parameters[2].Value = cardcode == null ? string.Empty : cardcode;

				parameters[3] = new HanaParameter("ItemCode", SqlDbType.VarChar);
				parameters[3].Value = itemcode == null ? string.Empty : itemcode;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT ");
                //stringBuilder.Append(" (SELECT T1.\"LineNum\",T11.\"BPLName\" from " + ConfigManager.GetSAPDatabase() + ".\"OBPL\" T11 where T0.\"BPLId\" = T11.\"BPLId\") as \"Branch\" ");
                stringBuilder.Append(" (SELECT T11.\"BPLName\" from " + ConfigManager.GetSAPDatabase() + ".\"OBPL\" T11 where T0.\"BPLId\" = T11.\"BPLId\") as \"Branch\" ");
				stringBuilder.Append(" ,TO_NVARCHAR(T0.\"DocDate\",'DD/MM/YYYY') AS \"DocDate\" ");
				stringBuilder.Append(" ,T2.\"SeriesName\" || '/' || T0.\"DocNum\" AS \"PONo\" ");//T0.\"TaxDate\",
				stringBuilder.Append(" ,T0.\"DocEntry\",T7.\"CardName\",T1.\"Dscription\",T19.\"ItmsGrpNam\",IFNULL(T1.\"Quantity\",0) AS \"POQty\"");
				stringBuilder.Append(" ,(IFNULL(T18.\"BWeight1\",0) * IFNULL(T1.\"Quantity\",0) ) as \"POQtyInKG\" ");
				stringBuilder.Append(" ,T1.\"U_KgPrice\",IFNULL(T1.\"OpenQty\",0) AS \"BalanceQty\",(IFNULL(T18.\"BWeight1\",0) * IFNULL(T1.\"OpenQty\",0) ) as \"BalQtyInKG\" ");
                stringBuilder.Append(" ,TO_NVARCHAR(T0.\"DocDueDate\",'DD/MM/YYYY') AS \"DocDueDate\" ");
                stringBuilder.Append(" ,(IFNULL(T1.\"Quantity\",0) * IFNULL(T1.\"Price\",0)) as \"TotalValue\" ");
				stringBuilder.Append(" ,T1.\"Text\" as \"ItemDetails\",t1.\"U_JCText\",T1.\"U_JOBDTL\" ,T20.\"U_NAME\" , T1.\"U_NoOfUps\" ");
				stringBuilder.Append(" ,T1.\"LineNum\"");
				
				stringBuilder.Append(" FROM  " + ConfigManager.GetSAPDatabase() + ".\"OPOR\" T0   ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"POR1\" T1 on T1.\"DocEntry\" = T0.\"DocEntry\" ");
				stringBuilder.Append(" LEFT OUTER JOIN " + ConfigManager.GetSAPDatabase() + ".\"NNM1\" T2 ON T2.\"Series\"=T0.\"Series\" ");
				stringBuilder.Append(" LEFT OUTER JOIN " + ConfigManager.GetSAPDatabase() + ".\"OCRD\" T7 ON T7.\"CardCode\"=T0.\"CardCode\" ");
				stringBuilder.Append(" LEFT OUTER JOIN " + ConfigManager.GetSAPDatabase() + ".\"OITM\" T18 ON T18.\"ItemCode\" = T1.\"ItemCode\" ");
				stringBuilder.Append(" LEFT OUTER JOIN " + ConfigManager.GetSAPDatabase() + ".\"OITB\" T19 ON T19.\"ItmsGrpCod\" = T18.\"ItmsGrpCod\" ");
				stringBuilder.Append(" LEFT OUTER JOIN " + ConfigManager.GetSAPDatabase() + ".\"OUSR\" T20 ON T0.\"UserSign\" = T20.\"USERID\" ");
				stringBuilder.Append(" WHERE T0.\"DocStatus\" = 'O' AND T0.\"DocType\"='I' and T18.\"validFor\" = 'Y' and T1.\"LineStatus\" = 'O' ");
				stringBuilder.Append(" AND T0.\"DocDate\" >= :FromDate AND T0.\"DocDate\"  <= :ToDate ");
				if (!string.IsNullOrEmpty(cardcode))
				{
					stringBuilder.Append(" AND T0.\"CardCode\" = :CardCode ");
				}
				else
				{
					stringBuilder.Append(" AND :CardCode='' ");
				}
				if (!string.IsNullOrEmpty(itemcode))
				{
					stringBuilder.Append(" AND T1.\"ItemCode\" = :ItemCode ");
				}
				else
				{
					stringBuilder.Append(" AND :ItemCode='' ");
				}
				//Nilam(10-12-24)
                //stringBuilder.Append(" GROUP BY T1.\"LineNum\" ");

                stringBuilder.Append(" ORDER BY T0.\"DocDate\" ");

                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					_list = ConvertDatatableToList.ConvertToList<PendingPOReportModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}
		public List<GRPORegisterReportModel> GetGRPORegisterReport(string fromDate, string toDate, string itmsGrpName)
		{
			List<GRPORegisterReportModel> _list = new List<GRPORegisterReportModel>();
			try
			{
				HanaParameter[] parameters = new HanaParameter[3];

				parameters[0] = new HanaParameter("FromDate", SqlDbType.VarChar);
				parameters[0].Value = fromDate == null || fromDate.ToLower() == "nan" ? string.Empty : fromDate;

				parameters[1] = new HanaParameter("ToDate", SqlDbType.VarChar);
				parameters[1].Value = toDate == null || toDate.ToLower() == "nan" ? string.Empty : toDate;

				parameters[2] = new HanaParameter("ItmsGrpNam", SqlDbType.VarChar);
				parameters[2].Value = itmsGrpName;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"DocStatus\",T2.\"ItmsGrpCod\",T3.\"ItmsGrpNam\",T0.\"DocEntry\",T0.\"DocNum\",T0.\"DocDate\",T0.\"CardCode\" ");
				stringBuilder.Append(" ,T0.\"CardName\",T0.\"NumAtCard\",T1.\"BaseRef\",T0.\"TaxDate\",T1.\"ItemCode\",T1.\"Dscription\",T2.\"U_SheetSizeX\" ");
				stringBuilder.Append(" ,T2.\"U_SheetSizeY\",T2.\"U_PaperGSM\",T2.\"U_Microns\",T2.\"U_DickleSize\",T2.\"U_Brand\",T1.\"Quantity\" ");
				stringBuilder.Append(" ,T1.\"U_KgPrice\",T1.\"Price\",T1.\"LineTotal\",T1.\"LineNum\",T1.\"U_NoOfUps\",T1.\"U_JCText\",T1.\"U_JOBDTL\" ");
				stringBuilder.Append(" ,T2.\"OnHand\",T1.\"Text\" ");
				stringBuilder.Append(" ,(CASE WHEN coalesce((SELECT MAX(q0.\"DocEntry\") FROM " + ConfigManager.GetSAPDatabase() + ".\"@VCQCM\" q0 WHERE q0.\"U_DocKey\"=CAST(T0.\"DocEntry\" as nvarchar(50)) ");
				stringBuilder.Append(" AND q0.\"U_ItmCode\"=t1.\"ItemCode\" ),0) = 0 then 'QC Pending' else 'QC Done' END) as \"QCStauts\" ");
				stringBuilder.Append(" FROM  " + ConfigManager.GetSAPDatabase() + ".\"OPDN\" T0   ");
				stringBuilder.Append(" LEFT OUTER JOIN " + ConfigManager.GetSAPDatabase() + ".\"PDN1\" T1 ON T1.\"DocEntry\" = T0.\"DocEntry\" ");
				stringBuilder.Append(" LEFT OUTER JOIN " + ConfigManager.GetSAPDatabase() + ".\"OITM\" T2 ON T2.\"ItemCode\" = T1.\"ItemCode\" ");
				stringBuilder.Append(" LEFT OUTER JOIN " + ConfigManager.GetSAPDatabase() + ".\"OITB\" T3 ON T3.\"ItmsGrpCod\" = T2.\"ItmsGrpCod\" ");
				stringBuilder.Append(" WHERE T0.\"DocDate\" >= :FromDate AND T0.\"DocDate\"  <= :ToDate AND T3.\"ItmsGrpCod\" = :ItmsGrpNam  ");
				stringBuilder.Append(" AND T0.\"DocType\" = 'I' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					_list = ConvertDatatableToList.ConvertToList<GRPORegisterReportModel>(datatable);
				}
			}
			catch
			{
			}
			return _list;
		}
		public ResponseModel UpdateRemarkData(string lotno, string remark)
		{
			string message = "";
			ResponseModel responseModel = new ResponseModel();
			query = "UPDATE " + ConfigManager.GetSAPDatabase() + ".\"OBTN\" SET \"U_Remarks\" = '" + remark + "' WHERE \"U_LotNo\" = '" + lotno + "'";
			FillDataTable(query.ToString(), CommandType.Text, out message);
			if (message == string.Empty)
			{
				responseModel.ResponseStatus = true;
				responseModel.ResponseText = "Operation completed successfully";
			}
			else
			{
				responseModel.ResponseStatus = false;
				responseModel.ResponseText = "Error occured during process: " + message;
			}
			return responseModel;
		}

		public ResponseModel GetClientFerreroDispatchReport(string fromDate, string toDate, string cardname, string itmsGrpName, string brand, string variant)
		{
			ResponseModel responseModel = new ResponseModel();
			try
			{
				string outMessage = "";
				ServiceLayer sl = new ServiceLayer();
				sl.endPoint = ConfigManager.GetReportAPIUrl() + "home/PrintClientFerreroDispatch?fromDate=" + fromDate + "&toDate=" + toDate + "&cardname=" + cardname + "&itmsgrpName=" + itmsGrpName + "&brand=" + brand + "&variant=" + variant + "";
				sl.getRequestData(out outMessage);
				responseModel = JsonConvert.DeserializeObject<ResponseModel>(outMessage);
			}
			catch (Exception ex)
			{
				responseModel.ResponseText = ex.Message;
			}
			return responseModel;
		}
        public ResponseModel GetPSSLayoutReport(string itemcode)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                string outMessage = "";
                ServiceLayer sl = new ServiceLayer();
                sl.endPoint = ConfigManager.GetReportAPIUrl() + "home/PrintPSSLayout?itemcode=" + itemcode + "";
                sl.getRequestData(out outMessage);
                responseModel = JsonConvert.DeserializeObject<ResponseModel>(outMessage);
            }
            catch (Exception ex)
            {
                responseModel.ResponseText = ex.Message;
            }
            return responseModel;
        }
        public List<ItemChapterTaxCodeReportModel> GetItemChapterTaxCodeReport()
		{
			List<ItemChapterTaxCodeReportModel> _list = new List<ItemChapterTaxCodeReportModel>();
			string dateTime = DateTime.Now.Date.ToString("yyyyMMdd");
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"ItemCode\",T0.\"ItemName\", T4.\"Code\" as \"TaxCode\", T4.\"Name\" as \"TaxName\",T3.\"ChapterID\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".TCD2 T1 ON T0.\"ChapterID\" = T1.\"KeyFld_1_V\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".TCD3 T2 ON T1.\"AbsId\" = T2.\"Tcd2Id\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T3 ON T0.\"ChapterID\" = T3.\"AbsEntry\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OSTC T4 ON T2.\"TaxCode\" = T4.\"Code\" ");
				stringBuilder.Append(" WHERE IFNULL(T2.\"EfctTo\",'2099-01-01') > '" + dateTime + "' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<ItemChapterTaxCodeReportModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}
        public List<ItemModel> GetItemWiseWarehouseStock(string itemCode)
        {

            List<ItemModel> list = new List<ItemModel>();
            try
            {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"ItemCode\", T0.\"ItemName\", T1.\"WhsCode\" ");
                stringBuilder.Append(" ,T1.\"OnHand\"");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
                stringBuilder.Append(" Inner Join  " + ConfigManager.GetSAPDatabase() + ".OITW T1 ON T0.\"ItemCode\" = T1.\"ItemCode\" ");
                stringBuilder.Append(" WHERE T0.\"ItemCode\" = '" + itemCode + "' AND T1.\"OnHand\" != '0' ");

                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    list = ConvertDatatableToList.ConvertToList<ItemModel>(datatable);
                }
            }
            catch
            {

            }
            return list;
        }
    }
}