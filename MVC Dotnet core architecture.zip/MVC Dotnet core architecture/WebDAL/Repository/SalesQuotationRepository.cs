﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
//using Microsoft.Data.SqlClient;
using System.Linq;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sap.Data.Hana;
using WebDAL.Helper;
using WebDAL.Helpers;
using WebDAL.IRepository;
using WebDAL.Models;

namespace WebDAL.Repository
{
	public class SalesQuotationRepository : clsDataAccess, ISalesQuotationRepository
	{
		string query = "";
		CommonRepository commonRepository = new CommonRepository();
		StringBuilder stringBuilder = new StringBuilder();
		public List<DocumentModel> GetAll(string userId, string type)
		{
			List<DocumentModel> _list = new List<DocumentModel>();
			try
			{
				string isSuperUser = commonRepository.IsUserSuperUser(userId);
				string slpName = commonRepository.GetSlpNameFromEmailAddress(userId);
				string headerTable = CommonTables.SalesQuotationHeaderTable;
				string rowTable = CommonTables.SalesQuotationRowTable;
				if (type.ToUpper() == "DRAFT")
				{
					headerTable = CommonTables.DraftHeaderTable;
					rowTable = CommonTables.DraftRowTable;
				}

				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("@UserId", System.Data.SqlDbType.VarChar);
				parameters[0].Value = userId;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT '" + type + "' AS \"Type\" , \"DocEntry\", \"DocNum\",TO_NVARCHAR(\"DocDate\", 'DD/MM/YYYY')  AS \"DocDate\" ,\"CardName\" ");
				stringBuilder.Append(" ,CASE WHEN \"DocStatus\" = 'O' THEN 'Open' ");
				stringBuilder.Append("  WHEN \"DocStatus\" = 'C' AND \"CANCELED\" = 'Y' THEN 'Cancelled' ELSE 'Closed' END AS \"DocStatus\"");
				stringBuilder.Append(" ,\"Comments\"  ");
				stringBuilder.Append(" ,\"NumAtCard\"  ");
				stringBuilder.Append(" ,T0.\"SlpCode\" AS \"SalesPersonCode\"  ");
				stringBuilder.Append(" ,T1.\"SlpName\"  ");
				if (type.ToUpper() == "DRAFT")
				{
					stringBuilder.Append(" ,CASE WHEN T0.\"U_IsApp\" = 'Y' THEN 'Approved' WHEN T0.\"U_IsApp\" = 'N' THEN 'Rejected' ELSE 'Pending' END \"ApprovalStatus\"  ");
				}
				else
				{
					stringBuilder.Append(" ,'Approved' \"ApprovalStatus\"  ");
				}
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + headerTable + " T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OSLP T1 ON T0.\"SlpCode\"=T1.\"SlpCode\" ");
				stringBuilder.Append(" WHERE ");
				stringBuilder.Append(" \"DocStatus\" = 'O' ");
				stringBuilder.Append(" AND T0.\"ObjType\" ='" + Convert.ToString((int)ObjectType.Quotations) + "' ");
				stringBuilder.Append(" AND (T0.\"U_IsApp\"='Y' OR T0.\"U_IsApp\" IS NULL) ");
				if (type.ToUpper() == "DRAFT")
				{
					stringBuilder.Append(" AND T0.\"DocDate\" >= '2022-12-01' ");
				}
				if (isSuperUser == "Y")
				{
					stringBuilder.Append(" ORDER BY Case When T1.\"SlpName\" Like '" + slpName + "%' then 0 elSe 1 end,T0.\"DocDate\"  Desc  ");
				}
				else
				{
					stringBuilder.Append(" ORDER BY \"DocEntry\" DESC ");
				}
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<DocumentModel>(datatable);
					if (isSuperUser != "Y")
					{
						List<SalesEmployeeModel> teamSalesEmployee = commonRepository.GetAllTeamSalesEmployee(userId);
						_list = _list.Where(x => teamSalesEmployee.Any(y => y.SlpCode == x.SalesPersonCode)).ToList();
					}
					else
					{
						//_list = _list.OrderBy(name => name.Count(c => c == 'b' || c == 'B')).ToList();
					}
				}
			}
			catch
			{

			}
			return _list;
		}
		public DocumentModel Get(string docEntry, string userId, string type)
		{
			DocumentModel model = new DocumentModel();
			try
			{
				string slpcode = commonRepository.GetSlpCodeFromEmailAddress(userId);
				string headerTable = CommonTables.SalesQuotationHeaderTable;
				string rowTable = CommonTables.SalesQuotationRowTable;
				string freightTable = CommonTables.SalesQuotationFreightTable;
				string taxExtensionTable = CommonTables.SalesQuotationAddressTable;

				if (type.ToUpper() == "DRAFT")
				{
					headerTable = CommonTables.DraftHeaderTable;
					rowTable = CommonTables.DraftRowTable;
					freightTable = CommonTables.DraftFreightTable;
					taxExtensionTable = CommonTables.DraftAddressTable;
				}

				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
				parameters[0].Value = docEntry;
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT '" + type.ToUpper() + "' AS \"Type\", T0.\"DocEntry\",T0.\"DocNum\",T0.\"DocCur\" AS \"DocCurrency\",T0.\"DocRate\",T0.\"Series\",T0.\"SlpCode\" AS \"SalesPersonCode\",T2.\"SeriesName\" ");
				stringBuilder.Append(" ,T0.\"CardCode\",T0.\"CardName\",T0.\"NumAtCard\",TO_VARCHAR(T0.\"DocDate\", 'DD-MM-YYYY') \"DocDate\",TO_VARCHAR(T0.\"TaxDate\", 'DD-MM-YYYY') AS \"TaxDate\" ");
				if (type.ToUpper() == "DRAFT")
				{
					stringBuilder.Append(" ,'Draft' AS \"DocStatus\"");
				}
				else
				{
					stringBuilder.Append(" ,CASE WHEN \"DocStatus\" = 'O' THEN 'Open' ");
					stringBuilder.Append("  WHEN \"DocStatus\" = 'C' AND \"CANCELED\" = 'Y' THEN 'Cancelled' ELSE 'Closed' END AS \"DocStatus\"");
				}
				stringBuilder.Append(" ,T0.\"BPLId\" AS \"BPL_IDAssignedToInvoice\",TO_VARCHAR(T0.\"DocDueDate\", 'DD-MM-YYYY') \"DocDueDate\" ");
				stringBuilder.Append(" ,T0.\"ShipToCode\",T0.\"PayToCode\",T0.\"TrnspCode\" AS \"TransportationCode\" ");
				stringBuilder.Append(" ,T0.\"OwnerCode\" AS \"DocumentsOwner\",T0.\"Comments\" ");
				stringBuilder.Append(" ,T0.\"DiscPrcnt\" AS \"DiscountPercent\" ");
				stringBuilder.Append(" ,T0.\"RoundDif\" AS \"RoundingDiffAmount\"  ");

				stringBuilder.Append(" ,CASE WHEN T0.\"DocRate\" = 1 THEN T0.\"VatSum\" ELSE T0.\"VatSumFC\"	END AS \"TaxAmount\" ");
				stringBuilder.Append(" ,CASE WHEN T0.\"DocRate\" = 1 THEN T0.\"DocTotal\" ELSE T0.\"DocTotalFC\" END AS \"DocumentTotal\" ");
				stringBuilder.Append(" ,CASE WHEN T0.\"DocRate\" = 1 THEN T0.\"TotalExpns\" ELSE T0.\"TotalExpFC\" END AS \"TotalExpns\" ");
				stringBuilder.Append(" ,T3.\"State\" AS \"BillTo_State\"  ");
				stringBuilder.Append(" ,T4.\"State\" AS \"ShipTo_State\"  ");
				stringBuilder.Append(" ,T0.\"Address\"  ");
				stringBuilder.Append(" ,T0.\"Address2\"  ");
				stringBuilder.Append(" ,T0.\"AtcEntry\"  ");

				stringBuilder.Append(" ,T0.\"U_MdTrns\",T0.\"U_PortDischarge\",T0.\"U_PortLoad\",T0.\"U_INCOTERMS\"  ");
				stringBuilder.Append(" ,T5.\"U_BPTL\" AS \"BPTolerancePercent\" ");
				stringBuilder.Append(" ,T5.\"U_BPLTL\" AS \"BPLowerTolerancePercent\" ");
				stringBuilder.Append(" ,T0.\"U_IsApp\" ");
				stringBuilder.Append(" ,T6.\"ImpORExp\" ,T6.\"ExportType\" ");
				stringBuilder.Append(" ,T0.\"U_CRBY\" ,T0.\"DutyStatus\"");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + headerTable + " T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OSLP T1 ON T0.\"SlpCode\" = T1.\"SlpCode\"  ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".NNM1 T2 ON T0.\"Series\" = T2.\"Series\"  ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".CRD1 T3 ON T0.\"CardCode\" = T3.\"CardCode\" AND T0.\"PayToCode\" = T3.\"Address\" AND T3.\"AdresType\"='B'  ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".CRD1 T4 ON T0.\"CardCode\" = T4.\"CardCode\" AND T0.\"ShipToCode\" = T4.\"Address\" AND T4.\"AdresType\"='S'  ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCRD T5 ON T0.\"CardCode\" = T5.\"CardCode\"  ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + "." + taxExtensionTable + " T6 ON T0.\"DocEntry\" = T6.\"DocEntry\"  ");

				//stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + "." + addressTable + " T3 ON T0.\"DocEntry\" = T3.\"DocEntry\"  ");
				stringBuilder.Append(" WHERE T0.\"DocEntry\" = :DocEntry ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						model = ConvertDatatableToList.ConvertToEntity<DocumentModel>(datatable);
						if (type.ToUpper() == "DRAFT")
						{
							string isApp = model.U_IsApp;
							if (model.SalesPersonCode == slpcode)
							{
								if (string.IsNullOrEmpty(isApp))
								{
									model.ShowApproval = "Y";
								}
							}
							model.IsEditable = "Y";
						}
						if (model.SalesPersonCode == slpcode)
						{
							model.IsEditable = "Y";
						}
						model.boolImpORExp = model.ImpORExp == "Y" ? true : false;
					}
				}

				#region Row
				double docRate = double.Parse(model.DocRate);
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"VisOrder\" + 1 AS \"Index\",T0.\"LineNum\", T0.\"ItemCode\",T0.\"Dscription\" AS \"ItemName\" ");
				stringBuilder.Append(" ,T0.\"Quantity\",T0.\"TreeType\" ");
				stringBuilder.Append(" ,T0.\"SubCatNum\" \"SupplierCatNum\",T0.\"U_Category\",T0.\"FreeTxt\" AS \"FreeText\" ");
				stringBuilder.Append(" ,T0.\"U_CTOL\",T0.\"U_CTLOL\",T0.\"unitMsr\" \"MeasureUnit\",T0.\"WhsCode\" AS \"WarehouseCode\" ");
				stringBuilder.Append(" ,T0.\"TaxCode\",T2.\"Rate\" AS \"TaxRate\",T1.\"ChapterID\" AS \"HSNEntry\",T3.\"ChapterID\" AS \"HSNName\" ");
				if (docRate == 1)
				{
					stringBuilder.Append(" ,T0.\"PriceBefDi\" AS \"UnitPrice\",T0.\"LineTotal\" AS \"Total\" ");
				}
				else
				{
					stringBuilder.Append(" ,T0.\"Price\" AS \"UnitPrice\",T0.\"TotalFrgn\" AS \"Total\" ");
				}
				stringBuilder.Append(" ,TO_VARCHAR(T0.\"ShipDate\", 'DD-MM-YYYY') \"ShipDate\" ");
				stringBuilder.Append(" ,T0.\"LineStatus\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + rowTable + " T0 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OITM T1 ON T0.\"ItemCode\" = T1.\"ItemCode\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OSTC T2 ON T0.\"TaxCode\" = T2.\"Code\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T3 ON T1.\"ChapterID\" = T3.\"AbsEntry\" ");

				stringBuilder.Append(" WHERE T0.\"DocEntry\" = :DocEntry ");
				stringBuilder.Append(" ORDER BY T0.\"LineNum\" ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
                    List<DocumentRowsModel> modelRows = ConvertDatatableToList.ConvertToList<DocumentRowsModel>(datatable);
                    model.DocumentLines = modelRows;
                    if (datatable.Rows.Count > 0)
					{
						
						model.WarehouseCode = model.DocumentLines.Select(a => a.WarehouseCode).FirstOrDefault();
						model.NetAmount = model.DocumentLines.Select(a => a.Total).Sum();

						bool isAnySalesBOM = modelRows.Where(a => a.TreeType == "S").Any();
						if (isAnySalesBOM == true)
						{
							int baseBomLineId = 0;
							for (int i = 0; i < modelRows.Count; i++)
							{
								int lineId = modelRows[i].Index.Value;
								string treeType = modelRows[i].TreeType;
								if (treeType == "S")
								{
									baseBomLineId = lineId;
								}
								else if (treeType == "I")
								{
									modelRows[i].BaseBOMLine = baseBomLineId.ToString();
								}
							}
						}
					}
				}
				#endregion

				#region Attachment 
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT  T1.\"trgtPath\",T1.\"FileName\", T1.\"FileExt\", T1.\"Line\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + headerTable + " T0 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".ATC1 T1 ON T0.\"AtcEntry\" = T1.\"AbsEntry\" ");
				stringBuilder.Append(" WHERE T0.\"DocEntry\" = :DocEntry ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						List<DocumentModel_Attachment> modelRows = ConvertDatatableToList.ConvertToList<DocumentModel_Attachment>(datatable);
						model.Attachments2_Lines = modelRows;
						for (int i = 0; i < model.Attachments2_Lines.Count; i++)
						{
							model.Attachments2_Lines[i].Index = (i + 1);
							model.Attachments2_Lines[i].trgtPath += "\\" + model.Attachments2_Lines[i].FileName + "." + model.Attachments2_Lines[i].FileExt;
						}
					}
				}
				#endregion

				#region Freight

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT  T1.\"ExpnsCode\" AS \"ExpenseCode\",T1.\"ExpnsName\" AS \"ExpenseName\" ");
				stringBuilder.Append(" ,T0.\"TaxCode\", T0.\"VatPrcnt\" AS \"TaxPercent\" ");
				if (docRate == 1)
				{
					stringBuilder.Append(" , T0.\"LineTotal\",T0.\"VatSum\" AS \"TaxSum\", T0.\"GrsAmount\" AS \"LineGross\" ");
				}
				else
				{
					stringBuilder.Append(" ,T0.\"TotalFrgn\" AS \"LineTotal\",T0.\"VatSumFrgn\" AS \"TaxSum\", T0.\"GrsFC\" AS \"LineGross\" ");
				}
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + freightTable + " T0 ");
				stringBuilder.Append(" RIGHT JOIN " + ConfigManager.GetSAPDatabase() + ".OEXD T1 ON T0.\"ExpnsCode\" = T1.\"ExpnsCode\" AND T0.\"DocEntry\" = :DocEntry ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					List<DocumentModel_Expenses> modelRows = ConvertDatatableToList.ConvertToList<DocumentModel_Expenses>(datatable);
					if (modelRows.Count == 0)
					{
						DocumentModel_Expenses documentModel_Expenses = new DocumentModel_Expenses();
						modelRows.Add(documentModel_Expenses);
					}
					model.DocumentAdditionalExpenses = modelRows;
					double? freightAmount = model.TotalExpns;
					if (freightAmount == 0)
					{
						string itemTaxCode = model.DocumentLines.Select(a => a.TaxCode).FirstOrDefault();
						for (int i = 0; i < model.DocumentAdditionalExpenses.Count; i++)
						{
							model.DocumentAdditionalExpenses[i].TaxCode = itemTaxCode;
						}
					}
				}
				#endregion
			}
			catch
			{

			}
			return model;
		}
		public ResponseModel Add(DocumentModel model)
		{
			string headerTable = CommonTables.SalesQuotationHeaderTable;
			string rowTable = CommonTables.SalesQuotationRowTable;

			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				string slpcode = commonRepository.GetSlpCodeFromEmailAddress(model.UserId);

				DocumentModel _objServiceLayer = new DocumentModel();

				#region Header
				_objServiceLayer.CardCode = model.CardCode;
				_objServiceLayer.CardName = model.CardName;
				_objServiceLayer.Series = model.Series;
				_objServiceLayer.DocCurrency = model.DocCurrency;
				_objServiceLayer.DocRate = model.DocRate;

				_objServiceLayer.DocObjectCode = Convert.ToString((int)ObjectType.Quotations);
				_objServiceLayer.NumAtCard = model.NumAtCard;
				//DateTime dtDocDate = Convert.ToDateTime(model.DocDate);
				//DateTime dtDocDueDate = Convert.ToDateTime(model.DocDueDate);
				//DateTime dtTaxDate = Convert.ToDateTime(model.TaxDate);

				//_objServiceLayer.DocDate = dtDocDate.ToString("yyyyMMdd");
				//_objServiceLayer.DocDueDate = dtDocDueDate.ToString("yyyyMMdd");
				//_objServiceLayer.TaxDate = dtTaxDate.ToString("yyyyMMdd");

				DateTime dtDocDate = DateTime.ParseExact(model.DocDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
				DateTime dtDocDueDate = DateTime.ParseExact(model.DocDueDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
				DateTime dtTaxDate = DateTime.ParseExact(model.TaxDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);

				_objServiceLayer.DocDate = dtDocDate.ToString("yyyyMMdd");
				_objServiceLayer.DocDueDate = dtDocDueDate.ToString("yyyyMMdd");
				_objServiceLayer.TaxDate = dtTaxDate.ToString("yyyyMMdd");

				_objServiceLayer.BPL_IDAssignedToInvoice = model.BPL_IDAssignedToInvoice;
				_objServiceLayer.PayToCode = model.PayToCode;
				_objServiceLayer.ShipToCode = model.ShipToCode;
				//_objServiceLayer.Address = model.Address;
				//_objServiceLayer.Address2 = model.Address2;
				_objServiceLayer.SalesPersonCode = model.SalesPersonCode;
				_objServiceLayer.Comments = model.Comments;
				_objServiceLayer.DiscountPercent = model.DiscountPercent;
				_objServiceLayer.RoundingDiffAmount = model.RoundingDiffAmount;
				_objServiceLayer.TransportationCode = model.TransportationCode;
				_objServiceLayer.DocumentsOwner = model.DocumentsOwner;
				_objServiceLayer.Comments = model.Comments;
				#endregion

				#region UDF
				_objServiceLayer.U_MdTrns = model.U_MdTrns;
				_objServiceLayer.U_PortDischarge = model.U_PortDischarge;
				_objServiceLayer.U_PortLoad = model.U_PortLoad;
				_objServiceLayer.U_INCOTERMS = model.U_INCOTERMS;

				#endregion

				#region Item Rows

				int modelRow = 0;
				List<DocumentRowsModel> modelLines_ServiceLayer = new List<DocumentRowsModel>();
				model.DocumentLines = model.DocumentLines.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();

				for (int i = 0; i < model.DocumentLines.Count; i++)
				{
					string treeType = model.DocumentLines[i].TreeType;
					if (treeType == "I")
					{
						continue;
					}
					if (!string.IsNullOrEmpty(model.DocumentLines[i].ItemCode))
					{
						modelLines_ServiceLayer.Add(new DocumentRowsModel { });
						modelLines_ServiceLayer[modelRow].ItemCode = model.DocumentLines[i].ItemCode;
						modelLines_ServiceLayer[modelRow].Quantity = model.DocumentLines[i].Quantity;
						modelLines_ServiceLayer[modelRow].UnitPrice = model.DocumentLines[i].UnitPrice;
						modelLines_ServiceLayer[modelRow].TaxCode = model.DocumentLines[i].TaxCode;
						modelLines_ServiceLayer[modelRow].HSNEntry = model.DocumentLines[i].HSNEntry;
						modelLines_ServiceLayer[modelRow].U_Category = model.DocumentLines[i].U_Category;
						modelLines_ServiceLayer[modelRow].FreeText = model.DocumentLines[i].FreeText;
						modelLines_ServiceLayer[modelRow].WarehouseCode = model.WarehouseCode;
						try
						{
							modelLines_ServiceLayer[modelRow].U_CTOL = model.DocumentLines[i].U_CTOL;
						}
						catch { }
						try
						{
							modelLines_ServiceLayer[modelRow].U_CTLOL = model.DocumentLines[i].U_CTLOL;
						}
						catch { }
						try
						{
							DateTime dtShipDate = DateTime.ParseExact(model.DocumentLines[i].ShipDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
							modelLines_ServiceLayer[modelRow].ShipDate = dtShipDate.ToString("yyyyMMdd");
						}
						catch { }
						modelRow++;
					}
				}

				#endregion

				#region Freight
				List<DocumentModel_Expenses> model_Expenses_ServiceLayerList = new List<DocumentModel_Expenses>();
				try
				{
                    int expenseRow = 0;
                    //model.DocumentAdditionalExpenses = model.DocumentAdditionalExpenses.Where(a => a.LineGross > 0).ToList();
                    for (int i = 0; i < model.DocumentAdditionalExpenses.Count; i++)
					{
						if (model.DocumentAdditionalExpenses[i].LineGross > 0)
						{
							model_Expenses_ServiceLayerList.Add(new DocumentModel_Expenses { });
							model_Expenses_ServiceLayerList[expenseRow].ExpenseCode = model.DocumentAdditionalExpenses[i].ExpenseCode;
							model_Expenses_ServiceLayerList[expenseRow].TaxCode = model.DocumentAdditionalExpenses[i].TaxCode;
							model_Expenses_ServiceLayerList[expenseRow].LineTotal = model.DocumentAdditionalExpenses[i].LineTotal;
							expenseRow++;

                        }
					}
				}
				catch { }
				#endregion

				#region Tax Extension
				DocumentModel_TaxExtension documentModel_TaxExtension = new DocumentModel_TaxExtension();
				if (model.boolImpORExp == true)
				{
					documentModel_TaxExtension.ImportOrExport = "tYES";
					documentModel_TaxExtension.ImportOrExportType = GetImportExportType(model.ExportType);
				}
				else
				{
					documentModel_TaxExtension.ImportOrExport = "tNO";
				}
				_objServiceLayer.TaxExtension = documentModel_TaxExtension;
				#endregion

				_objServiceLayer.DocumentLines = modelLines_ServiceLayer;
				_objServiceLayer.DocumentAdditionalExpenses = model_Expenses_ServiceLayerList;

				string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
				{
					NullValueHandling = NullValueHandling.Ignore,
				});


				var temp = JsonConvert.DeserializeObject<JObject>(main);

				string serviceLayerObject = "";
				string seriesremark = commonRepository.GetSeriesRemark(model.Series);
				if (slpcode == model.SalesPersonCode || seriesremark.ToUpper().Contains("PROOFING"))
				{
					serviceLayerObject = ServiceLayerEntity.Quotations.ToString();
				}
				else
				{
					serviceLayerObject = ServiceLayerEntity.Drafts.ToString();
					headerTable = CommonTables.DraftHeaderTable;
					rowTable = CommonTables.DraftRowTable;
				}
				rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject;
				rc.patchJSON = main;
				rc.B1SESSION = res;
				string message = "";
				bool result = rc.postRequest(out message);
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
					string userId = commonRepository.GetUserId(model.UserId);

					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string docEntry = jobject["DocEntry"].ToString();
					model.DocEntry = docEntry;
					responseModel.ResponseEntry = docEntry;
					try
					{
						//bool anyAttachment = model.Attachments2_Lines.Any(a => a.IsChanged == "Y");
						bool anyNewAttachment = model.Attachments2_Lines.Any(a => a.trgtPath.Contains("wwwroot"));
						if (anyNewAttachment == true)
						{
							Utility utility = new Utility();
							//SaveAttachment(res, model, serviceLayerObject);
							utility.SaveAttachment(res, model.DocEntry, model.AtcEntry, userId, model.Attachments2_Lines, serviceLayerObject);
						}
					}
					catch { }
					commonRepository.UpdateUserSign("Add", headerTable, "DocEntry", docEntry, userId);
                    commonRepository.UpdateDocumentItemChildLocation(rowTable, docEntry, model);
					UpdateDutyStatus(headerTable, model.DocEntry, model);
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during process: " + jsonMessage;
				}
				rc.LogOut();
			}
			else
			{
				responseModel.ResponseText = "Service layer login failed";
			}
			return responseModel;
		}
		public ResponseModel Update(DocumentModel model)
		{
			string headerTable = CommonTables.SalesQuotationHeaderTable;
			string rowTable = CommonTables.SalesQuotationRowTable;

			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				#region Header

				DocumentModel _objServiceLayer = new DocumentModel();
				//DateTime dtDocDate = Convert.ToDateTime(model.DocDate);

				_objServiceLayer.NumAtCard = model.NumAtCard;
				_objServiceLayer.DocCurrency = model.DocCurrency;
				_objServiceLayer.DocRate = model.DocRate;

				//DateTime dtDocDueDate = DateTime.Now.Date;
				//DateTime dtTaxDate = DateTime.Now.Date;

				DateTime dtDocDate = DateTime.ParseExact(model.DocDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
				DateTime dtDocDueDate = DateTime.ParseExact(model.DocDueDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
				DateTime dtTaxDate = DateTime.ParseExact(model.TaxDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);

				_objServiceLayer.DocDate = dtDocDate.ToString("yyyyMMdd");
				_objServiceLayer.DocDueDate = dtDocDueDate.ToString("yyyyMMdd");
				_objServiceLayer.TaxDate = dtTaxDate.ToString("yyyyMMdd");

				if (model.Type.ToUpper() == "DRAFT")
				{
					_objServiceLayer.DocDate = DateTime.Now.Date.ToString("yyyyMMdd");
				}
				else
				{
					_objServiceLayer.DocDate = dtDocDate.ToString("yyyyMMdd");
				}

				_objServiceLayer.PayToCode = model.PayToCode;
				_objServiceLayer.ShipToCode = model.ShipToCode;
				//_objServiceLayer.Address = model.Address;
				//_objServiceLayer.Address2 = model.Address2;
				_objServiceLayer.SalesPersonCode = model.SalesPersonCode;
				_objServiceLayer.Comments = model.Comments;
				_objServiceLayer.DiscountPercent = model.DiscountPercent;
				_objServiceLayer.RoundingDiffAmount = model.RoundingDiffAmount;
				_objServiceLayer.TransportationCode = model.TransportationCode;
				_objServiceLayer.DocumentsOwner = model.DocumentsOwner;
				_objServiceLayer.Comments = model.Comments;

				#endregion

				#region UDF

				_objServiceLayer.U_MdTrns = model.U_MdTrns;
				_objServiceLayer.U_PortDischarge = model.U_PortDischarge;
				_objServiceLayer.U_PortLoad = model.U_PortLoad;
				_objServiceLayer.U_INCOTERMS = model.U_INCOTERMS;

				#endregion

				#region Item Rows

				int modelRow = 0;
				List<DocumentRowsModel> modelLines_ServiceLayer = new List<DocumentRowsModel>();
				model.DocumentLines = model.DocumentLines.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();

				//model.DocumentLines = model.DocumentLines.Where(a => a.TreeType == null || a.TreeType).ToList();

				for (int i = 0; i < model.DocumentLines.Count; i++)
				{
					string itemcode = model.DocumentLines[i].ItemCode;
					string treeType = model.DocumentLines[i].TreeType;
					int? lineId = model.DocumentLines[i].LineNum;
					//if (treeType == "I")
					//{
					//	continue;
					//}
					if (!string.IsNullOrEmpty(itemcode))
					{
						modelLines_ServiceLayer.Add(new DocumentRowsModel { });
						//modelLines_ServiceLayer[modelRow].LineId = lineId;
						modelLines_ServiceLayer[modelRow].ItemCode = model.DocumentLines[i].ItemCode;
						modelLines_ServiceLayer[modelRow].LineStatus = model.DocumentLines[i].LineStatus;
						modelLines_ServiceLayer[modelRow].Quantity = model.DocumentLines[i].Quantity;
						modelLines_ServiceLayer[modelRow].UnitPrice = model.DocumentLines[i].UnitPrice;
						modelLines_ServiceLayer[modelRow].TaxCode = model.DocumentLines[i].TaxCode;
						modelLines_ServiceLayer[modelRow].HSNEntry = model.DocumentLines[i].HSNEntry;
						modelLines_ServiceLayer[modelRow].U_Category = model.DocumentLines[i].U_Category;
						modelLines_ServiceLayer[modelRow].FreeText = model.DocumentLines[i].FreeText;
						modelLines_ServiceLayer[modelRow].WarehouseCode = model.WarehouseCode;
						if (treeType == "S")
						{
							treeType = "iSalesTree";
						}
						else if (treeType == "I")
						{
							treeType = "iIngredient";
						}
						else if (treeType == "P")
						{
							treeType = "iProductionTree";
						}
						else if (treeType == "N")
						{
							treeType = "iNotATree";
						}
						if (treeType != string.Empty)
						{
							modelLines_ServiceLayer[modelRow].TreeType = treeType;
						}
						try
						{
							modelLines_ServiceLayer[modelRow].U_CTOL = model.DocumentLines[i].U_CTOL;
						}
						catch { }
						try
						{
							modelLines_ServiceLayer[modelRow].U_CTLOL = model.DocumentLines[i].U_CTLOL;
						}
						catch { }
						try
						{
							DateTime dtShipDate = DateTime.ParseExact(model.DocumentLines[i].ShipDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
							modelLines_ServiceLayer[modelRow].ShipDate = dtShipDate.ToString("yyyyMMdd");
						}
						catch { }
						modelRow++;
					}
				}

				#endregion

				#region Freight
				List<DocumentModel_Expenses> model_Expenses_ServiceLayerList = new List<DocumentModel_Expenses>();
				if (model.DocumentAdditionalExpenses != null)
				{
                    int expenseRow = 0;
                    //model.DocumentAdditionalExpenses = model.DocumentAdditionalExpenses.Where(a => a.LineGross > 0).ToList();
                    for (int i = 0; i < model.DocumentAdditionalExpenses.Count; i++)
					{
						if (model.DocumentAdditionalExpenses[i].LineGross > 0)
						{
							model_Expenses_ServiceLayerList.Add(new DocumentModel_Expenses { });
							model_Expenses_ServiceLayerList[expenseRow].ExpenseCode = model.DocumentAdditionalExpenses[i].ExpenseCode;
							model_Expenses_ServiceLayerList[expenseRow].TaxCode = model.DocumentAdditionalExpenses[i].TaxCode;
							model_Expenses_ServiceLayerList[expenseRow].LineTotal = model.DocumentAdditionalExpenses[i].LineTotal;
							expenseRow++;
						}
					}
				}
				#endregion

				#region Tax Extension
				DocumentModel_TaxExtension documentModel_TaxExtension = new DocumentModel_TaxExtension();
				if (model.boolImpORExp == true)
				{
					documentModel_TaxExtension.ImportOrExport = "tYES";
					documentModel_TaxExtension.ImportOrExportType = GetImportExportType(model.ExportType);
				}
				else
				{
					documentModel_TaxExtension.ImportOrExport = "tNO";
				}
				_objServiceLayer.TaxExtension = documentModel_TaxExtension;
				#endregion


				_objServiceLayer.DocumentLines = modelLines_ServiceLayer;
				_objServiceLayer.DocumentAdditionalExpenses = model_Expenses_ServiceLayerList;

				string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
				{
					NullValueHandling = NullValueHandling.Ignore,
				});
				string serviceLayerObject = "";
				if (model.Type.ToUpper() == "DRAFT")
				{
					headerTable = CommonTables.DraftHeaderTable;
					rowTable = CommonTables.DraftRowTable;
					serviceLayerObject = ServiceLayerEntity.Drafts.ToString();
				}
				else
				{
					serviceLayerObject = ServiceLayerEntity.Quotations.ToString();
				}
				rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject + "(" + model.DocEntry + ")";
				rc.patchJSON = main;
				rc.B1SESSION = res;
				rc.httpMethod = httpVerb.PATCH;
				string message = "";
				bool result = rc.patchRequest(out message);
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
					//bool anyAttachment = model.Attachments2_Lines.Any(a => a.IsChanged == "Y");

					bool anyNewAttachment = model.Attachments2_Lines.Any(a => a.trgtPath.Contains("wwwroot"));
					string userId = commonRepository.GetUserId(model.UserId);

					if (anyNewAttachment == true)
					{
						Utility utility = new Utility();
						utility.SaveAttachment(res, model.DocEntry, model.AtcEntry, userId, model.Attachments2_Lines, serviceLayerObject);
					}
					commonRepository.UpdateUserSign("Update", headerTable, "DocEntry", model.DocEntry, userId);
                    commonRepository.UpdateDocumentItemChildLocation(rowTable, model.DocEntry, model);
					UpdateDutyStatus(headerTable, model.DocEntry, model);
					if (serviceLayerObject == ServiceLayerEntity.Drafts.ToString())
					{
						commonRepository.UpdateDocumentItemChildTaxCode(rowTable, model.DocEntry);
					}
				}
				else
				{
					//JObject json = JObject.Parse(message);
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during process: " + jsonMessage;
				}
				rc.LogOut();
			}
			return responseModel;
		}
		private void UpdateDutyStatus(string headerTableName, string docEntry, DocumentModel model)
		{
			HanaParameter[] parameters = new HanaParameter[2];

			parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
			parameters[0].Value = docEntry;

			parameters[1] = new HanaParameter("DutyStatus", System.Data.SqlDbType.VarChar);
			parameters[1].Value = model.DutyStatus;

			//parameters[2] = new HanaParameter("ImpOrExp", System.Data.SqlDbType.VarChar);
			//parameters[2].Value = model.ImpORExp == false ? "N" : "Y";

			//parameters[3] = new HanaParameter("ExportType", System.Data.SqlDbType.VarChar);
			//parameters[3].Value = model.ExportType;

			stringBuilder = new StringBuilder();
			stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + "." + headerTableName + " SET ");
			stringBuilder.Append(" \"DutyStatus\"= :DutyStatus ");
			stringBuilder.Append(" WHERE \"DocEntry\" = :DocEntry ");
			FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters);
		}
		public ResponseModel UpdateStatus(string docEntry, string status, string userId)
		{
			ResponseModel responseModel = new ResponseModel();
			string message = "";
			string query = "";
			try
			{
				List<string> list = new List<string>();
				list = docEntry.Split(',').ToList();
				for (int i = 0; i < list.Count; i++)
				{
					docEntry = list[i].ToString();
					if (status == "Y")
					{
						UpdateDate(docEntry);

						#region If already created then continue
						query = "SELECT \"DocEntry\" FROM  " + ConfigManager.GetSAPDatabase() + ".OQUT WHERE \"draftKey\" = " + docEntry + " ";
						using (DataTable dt = FillDataTable(query, CommandType.Text, out message))
						{
							if (dt.Rows.Count > 0)
							{
								continue;
							}
						}
						#endregion


						#region Update Attachment Entry in Temp field
						query = "SELECT \"AtcEntry\" FROM " + ConfigManager.GetSAPDatabase() + ".ODRF WHERE \"DocEntry\" = " + docEntry + " ";
						string atcEntry = GetRecordValue(query, CommandType.Text, out message);
						if (!string.IsNullOrEmpty(atcEntry))
						{
							query = "UPDATE " + ConfigManager.GetSAPDatabase() + ".ODRF SET \"JrnlMemo\"= " + atcEntry + ", \"AtcEntry\"= NULL WHERE \"DocEntry\" = " + docEntry + " ";
							FillDataTable(query, CommandType.Text, out message);
						}
						#endregion

						responseModel = DraftsService_SaveDraftToDocument(docEntry);
						if (responseModel.ResponseStatus == false)
						{
							if (!string.IsNullOrEmpty(atcEntry))
							{
								query = "UPDATE " + ConfigManager.GetSAPDatabase() + ".ODRF SET \"JrnlMemo\"= NULL, \"AtcEntry\"= " + atcEntry + " WHERE \"DocEntry\" = " + docEntry + " ";
								FillDataTable(query, CommandType.Text, out message);
							}
							return responseModel;
						}
						else
						{
							if (!string.IsNullOrEmpty(atcEntry))
							{
								query = "UPDATE " + ConfigManager.GetSAPDatabase() + ".OQUT SET \"AtcEntry\"= " + atcEntry + " WHERE \"JrnlMemo\" = '" + atcEntry + "' ";
								FillDataTable(query, CommandType.Text, out message);
							}

							query = "UPDATE " + ConfigManager.GetSAPDatabase() + ".OQUT SET \"U_AppBy\"= '" + userId + "' WHERE \"draftKey\" = " + docEntry + " ";
							FillDataTable(query, CommandType.Text, out message);
						}
					}

					HanaParameter[] parameters = new HanaParameter[2];
					int iParameter = 0;
					parameters[iParameter] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
					parameters[iParameter].Value = docEntry;
					iParameter++;

					parameters[iParameter] = new HanaParameter("Status", System.Data.SqlDbType.VarChar);
					parameters[iParameter].Value = status;
					iParameter++;

					query = "UPDATE " + ConfigManager.GetSAPDatabase() + ".ODRF SET \"U_IsApp\"= :Status WHERE \"DocEntry\" = :DocEntry ";

					FillDataTable(query, CommandType.Text, out message, parameters);
					if (message == string.Empty)
					{
						responseModel.ResponseStatus = true;
						responseModel.ResponseText = "Operation completed successfully";
					}
					else
					{
						responseModel.ResponseText = "Error occured while processing record " + message;
						responseModel.ResponseStatus = false;
					}
				}
			}
			catch (Exception ex)
			{
				responseModel.ResponseText = "Error occured while processing record " + ex.Message;
				responseModel.ResponseStatus = false;
			}

			return responseModel;
		}
		public ResponseModel DraftsService_SaveDraftToDocument(string docEntry)
		{
			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				DocumentModel_SaveDraftToDocument _objServiceLayer = new DocumentModel_SaveDraftToDocument();
				DraftDocument draftDocument = new DraftDocument();
				draftDocument.DocEntry = docEntry;
				_objServiceLayer.Document = draftDocument;
				string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
				{
					NullValueHandling = NullValueHandling.Ignore,
				});
				rc.endPoint = ConfigManager.GetServiceLayerURL() + "DraftsService_SaveDraftToDocument";
				rc.patchJSON = main;
				rc.B1SESSION = res;
				rc.httpMethod = httpVerb.PATCH;
				string message = "";
				bool result = rc.patchRequest(out message);
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Sales Quotation DocEntry:" + docEntry.ToString() + " Error occured during process: " + jsonMessage;
				}
			}
			return responseModel;
		}
		public void UpdateDate(string docEntry)
		{

			HanaParameter[] parameters = new HanaParameter[2];
			int iParameter = 0;
			parameters[iParameter] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
			parameters[iParameter].Value = docEntry;
			iParameter++;

			parameters[iParameter] = new HanaParameter("DocDate", System.Data.SqlDbType.VarChar);
			parameters[iParameter].Value = DateTime.Now.Date;
			iParameter++;

			string query = "UPDATE " + ConfigManager.GetSAPDatabase() + ".ODRF SET \"DocDate\"= :DocDate WHERE \"DocEntry\" = :DocEntry ";
			FillDataTable(query, CommandType.Text, out string message, parameters);
		}
		public ResponseModel Close(string docEntry)
		{
			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				DocumentModel_SaveDraftToDocument _objServiceLayer = new DocumentModel_SaveDraftToDocument();
				DraftDocument draftDocument = new DraftDocument();
				draftDocument.DocEntry = docEntry;
				_objServiceLayer.Document = draftDocument;
				string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
				{
					NullValueHandling = NullValueHandling.Ignore,
				});
				rc.endPoint = ConfigManager.GetServiceLayerURL() + ServiceLayerEntity.Quotations.ToString() + "(" + docEntry + ")/Close";
				rc.patchJSON = main;
				rc.B1SESSION = res;
				rc.httpMethod = httpVerb.POST;
				string message = "";
				bool result = rc.postRequest(out message);
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during process: " + jsonMessage;
				}
				rc.LogOut();
			}
			return responseModel;
		}
		public ResponseModel Cancel(string docEntry)
		{
			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				DocumentModel_SaveDraftToDocument _objServiceLayer = new DocumentModel_SaveDraftToDocument();
				DraftDocument draftDocument = new DraftDocument();
				draftDocument.DocEntry = docEntry;
				_objServiceLayer.Document = draftDocument;
				string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
				{
					NullValueHandling = NullValueHandling.Ignore,
				});
				rc.endPoint = ConfigManager.GetServiceLayerURL() + ServiceLayerEntity.Quotations.ToString() + "(" + docEntry + ")/Cancel";
				rc.patchJSON = main;
				rc.B1SESSION = res;
				rc.httpMethod = httpVerb.POST;
				string message = "";
				bool result = rc.postRequest(out message);
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during process: " + jsonMessage;
				}
				rc.LogOut();
			}
			return responseModel;
		}
		private string GetImportExportType(string value)
		{
			string returnValue = "";
			if (value == "E")
			{
				returnValue = "et_IpmortsOrExports";
			}
			else if (value == "S")
			{
				returnValue = "et_SEZ_Developer";
			}
			else if (value == "U")
			{
				returnValue = "et_SEZ_Unit";
			}
			else if (value == "D")
			{
				returnValue = "et_Deemed_ImportsOrExports";
			}
			return returnValue;
		}
		public ResponseModel PDF(string docEntry)
		{
			ResponseModel responseModel = new ResponseModel();
			try
			{
				string outMessage = "";
				ServiceLayer sl = new ServiceLayer();
				string documentType = GetDocumentType(docEntry);
				if (documentType == "D")
				{
					sl.endPoint = ConfigManager.GetReportAPIUrl() + "home/PrintSalesQuotation_Domestic?docEntry=" + docEntry + "";
				}
				else
				{
					sl.endPoint = ConfigManager.GetReportAPIUrl() + "home/PrintSalesQuotation_Export?docEntry=" + docEntry + "";
				}
				sl.getRequestData(out outMessage);
				responseModel = JsonConvert.DeserializeObject<ResponseModel>(outMessage);
			}
			catch (Exception ex)
			{
				responseModel.ResponseText = ex.Message;
			}
			return responseModel;
		}
		public string GetDocumentType(string docEntry)
		{
			//E = Export
			//D = Domestic
			string documentType = "E";
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
				parameters[0].Value = docEntry;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"DocEntry\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OQUT T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OCRD T1 ON T0.\"CardCode\"=T1.\"CardCode\" ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".CRD1 T2 ON T1.\"CardCode\"=T2.\"CardCode\" ");
				stringBuilder.Append(" WHERE T0.\"DocEntry\" = :DocEntry   AND T2.\"Country\" = 'IN' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						documentType = "D";
					}
				}
			}
			catch
			{

			}
			return documentType;
		}

       /* public DocumentModel GetClientPOSQData(string docEntry)
        {
            DocumentModel model = new DocumentModel();
            try
            {
                string headerTable = CommonTables.ClientPORegisterHeaderTable;
                string rowTable = CommonTables.ClientPORegisterRowTable;
                HanaParameter[] parameters = new HanaParameter[1];

                parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
                parameters[0].Value = docEntry;

				string CTOL = "";
				string CTLOL = "";

				stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"U_CardCode\" As \"CardCode\",T0.\"U_CardName\" AS \"CardName\", T2.\"SlpCode\" AS \"SalesPersonCode\"");
				stringBuilder.Append(" ,T1.\"U_BPTL\" As \"U_CTOL\",T1.\"U_BPLTL\" AS \"U_CTLOL\" , T1.\"Currency\" AS \"DocCurrency\"");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + headerTable + "\" T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OCRD T1 ON T0.\"U_CardCode\" = T1.\"CardCode\"");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OSLP T2 ON T1.\"SlpCode\"=T2.\"SlpCode\" ");
				stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    if (datatable.Rows.Count > 0)
                    {
                        model = ConvertDatatableToList.ConvertToEntity<DocumentModel>(datatable);
						CTOL = datatable.Rows[0]["U_CTOL"].ToString();
						CTLOL = datatable.Rows[0]["U_CTLOL"].ToString();
					}
                }

                #region Row
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"U_ItemCode\" As \"ItemCode\", T0.\"U_ItemName\" As \"ItemName\", T0.\"U_Qty\" As \"Quantity\" ,T0.\"U_RateSys\" AS \"UnitPrice\"");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + rowTable + "\" T0 ");
                stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " AND T0.\"U_IsGang\" = 'N' AND T0.\"U_AppArt\" = 'Y'");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    if (datatable.Rows.Count > 0)
                    {
                        List<DocumentRowsModel> modelRows = ConvertDatatableToList.ConvertToList<DocumentRowsModel>(datatable);
                        model.DocumentLines = modelRows;
						try
						{
							for (int i = 0; i < model.DocumentLines.Count; i++)
							{
								model.DocumentLines[i].U_CTOL = double.Parse(CTOL);
								model.DocumentLines[i].U_CTLOL = double.Parse(CTLOL);
							}
						}
						catch
						{

						}
					}
                    else
                    {
                        List<DocumentRowsModel> ClientPORegisterList = new List<DocumentRowsModel>();
                        DocumentRowsModel clientPORegisterRowsModel = new DocumentRowsModel();
                        ClientPORegisterList.Add(clientPORegisterRowsModel);
                        model.DocumentLines = ClientPORegisterList;
                    }
                }
                #endregion
            }
            catch
            {

            }
            return model;
        }
		*/
		public List<DocumentModel> GetSQClientPOData(string cardcode)
		{
			List<DocumentModel> _list = new List<DocumentModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"DocEntry\" ,T0.\"DocNum\" ,TO_NVARCHAR(T0.\"DocDate\", 'DD/MM/YYYY') as \"DocDate\"  ");
				stringBuilder.Append(" ,T0.\"CardName\",T1.\"Dscription\" ");
				stringBuilder.Append(" ,T1.\"Quantity\" ,T1.\"Rate\" ");//, T0.\"U_KLDNo\" 
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + CommonTables.SalesQuotationHeaderTable + "\" T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"" + CommonTables.SalesQuotationRowTable + "\" T1 ON T0.\"DocEntry\"=T1.\"DocEntry\" ");
				stringBuilder.Append(" WHERE T0.\"CardCode\"  = '" + cardcode + "' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<DocumentModel>(datatable);

				}
			}
			catch
			{

			}
			return _list;
		}
		public List<CopyLineModel> GetSQSelectedData(string docEntry)
		{
			List<CopyLineModel> model = new List<CopyLineModel>();
			try
			{
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"ItemCode\", T0.\"Dscription\" AS \"ItemName\", T0.\"Quantity\" ,T0.\"Rate\" AS \"UnitPrice\" "); //, T0.\"U_KLDNo\"
				stringBuilder.Append(" ,T0.\"DocEntry\", T0.\"LineNum\" AS \"LineId\"  ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + CommonTables.SalesQuotationRowTable + "\" T0 ");
				stringBuilder.Append(" WHERE");
				stringBuilder.Append(" T0.\"DocEntry\" = '" + docEntry + "'");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					model = ConvertDatatableToList.ConvertToList<CopyLineModel>(datatable);
				}
			}
			catch
			{
			}
			return model;
		}

		public List<CopyLineModel> GetSQItemsNotAddedInClientPO(string docEntry)
		{
			List<CopyLineModel> model = new List<CopyLineModel>();
			try
			{
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"ItemCode\", T0.\"Dscription\" AS \"ItemName\", T0.\"Quantity\" ,T0.\"Rate\" AS \"UnitPrice\" ");
				stringBuilder.Append(" ,T0.\"DocEntry\", T0.\"LineNum\" AS \"LineId\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + CommonTables.SalesQuotationRowTable + "\" T0 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"" + CommonTables.ClientPORegisterRowTable + "\" T1 ON T0.\"DocEntry\" = T1.\"U_BaseEn\" AND T0.\"LineNum\" = T1.\"U_BaseLine\" ");
				stringBuilder.Append(" WHERE ");
				stringBuilder.Append(" T0.\"DocEntry\" = '" + docEntry + "' AND T1.\"U_BaseEn\" IS NULL ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					model = ConvertDatatableToList.ConvertToList<CopyLineModel>(datatable);
				}
			}
			catch
			{
			}
			return model;
		}

	}
}