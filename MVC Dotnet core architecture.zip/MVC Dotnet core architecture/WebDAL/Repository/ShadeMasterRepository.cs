﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Xml.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sap.Data.Hana;
using WebDAL.Helper;
using WebDAL.Helpers;
using WebDAL.IRepository;
using WebDAL.Models;

namespace WebDAL.Repository
{
	public class ShadeMasterRepository : clsDataAccess, IShadeMasterRepository
	{
		string query = "";
		CommonRepository commonRepository = new CommonRepository();
		StringBuilder stringBuilder = new StringBuilder();

		public List<ShadeMasterModel> GetAll()
		{
			List<ShadeMasterModel> _list = new List<ShadeMasterModel>();
			try
			{
				string headerTable = CommonTables.ShadeMasterHeaderTable;
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"Code\",T0.\"U_CCode\",T0.\"U_CName\", T0.\"U_ICode\", T0.\"U_IName\", T0.\"U_SCNo\",TO_NVARCHAR(T0.\"U_SCDate\", 'DD/MM/YYYY') AS \"U_SCDate\"");
				stringBuilder.Append(" ,T0.\"U_Active\",TO_NVARCHAR(T0.\"U_UpdateDate\", 'DD/MM/YYYY') AS \"U_UpdateDate\" ,T0.\"U_UpdateTime\" , T0.\"U_AppBy\",T0.\"U_STC\",T0.\"U_CRecv\",T0.\"U_Remarks\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@SHADECARDMST\" T0 ");
				stringBuilder.Append(" ORDER BY Cast(T0.\"Code\" as numeric(19,0)) DESC ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<ShadeMasterModel>(datatable);
				}
			}
			catch
			{
			}
			return _list;
		}
		public ResponseModel Add(ShadeMasterModel model)
		{
			ResponseModel responseModel = new ResponseModel();

			string message = "";
			bool isValid = true;

			for (int i = 0; i < model.Rows.Count; i++)
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT \"U_Active\" FROM " + ConfigManager.GetSAPDatabase() + ".\"@SHADECARDMST\" ");
				stringBuilder.Append(" where \"U_ICode\" = '" + model.Rows[i].ItemCode + "' And \"U_Active\" = 'Yes' ");
				DataTable datat = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
				if (datat.Rows.Count > 0)
				{
					responseModel.ResponseStatus = false;
					responseModel.ResponseText = "Already status is Active for seleted Item";
					isValid = false;
				}
			}

			if (isValid == true)
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT \"Code\" FROM " + ConfigManager.GetSAPDatabase() + ".\"@SHADECARDMST\" ");
				DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
				string code = datatable.ToString();

				ServiceLayer rc = new ServiceLayer();
				string res = rc.Login();
				if (res != "" && res.Contains("error") == false)
				{
					if (AddShadeCardData(model, res, rc) == true)
					{
                        UpdateItemShadeData(model.U_ICode, model);
                        UpdateNextNumber("SHADECARDMST", model.Location);
					}
					rc.LogOut();
				}
				else
				{
					responseModel.ResponseText = "Service layer login failed";
				}
			}

			//stringBuilder = new StringBuilder();
			//stringBuilder.Append(" INSERT INTO  " + ConfigManager.GetSAPDatabase() + ".\"@SHADECARDMST\"(\"Code\",\"DocEntry\",\"U_CCode\",\"U_CName\",\"U_ICode\",\"U_IName\",\"U_SCNo\" ");
			//stringBuilder.Append(" ,\"U_SCDate\",\"U_Active\",\"U_UpdateDate\",\"U_UpdateTime\",\"U_AppBy\",\"U_STC\",\"U_CRecv\", \"U_Remarks\") ");//,\"U_Status\" 
			//stringBuilder.Append(" VALUES('" + code + "','" + code + "'");
			//stringBuilder.Append(" ,'" + model.U_CCode + "','" + model.U_CName + "' ");
			//stringBuilder.Append(" ,'" + model.U_ICode + "','" + model.U_IName + "','" + model.U_SCNo + "','" + scDate.ToString("yyyyMMdd") + "','0','0'");
			//stringBuilder.Append(" ,'0','" + model.U_AppBy + "','" + model.U_STC + "' , '" + model.U_CRecv + "','Test') ");//'" + model.U_Status + "',
			//FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
			//if (message == string.Empty)
			//{
			//    responseModel.ResponseText = "Operation completed successfully";
			//}
			//else
			//{
			//    responseModel.ResponseText = "Error occured during process: " + message;
			//}
			return responseModel;
		}
		public ShadeMasterModel Get(string code)
		{
			ShadeMasterModel model = new ShadeMasterModel();
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("Code", System.Data.SqlDbType.VarChar);
				parameters[0].Value = code;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"Code\",T0.\"U_CCode\",T0.\"U_CName\", T0.\"U_ICode\", T0.\"U_IName\", T0.\"U_SCNo\" ,TO_VARCHAR(T0.\"U_SCDate\", 'DD-MM-YYYY') \"U_SCDate\"");
				stringBuilder.Append(" ,T0.\"U_Active\",T0.\"U_UpdateDate\" ,T0.\"U_UpdateTime\" , T0.\"U_AppBy\",T0.\"U_STC\",T0.\"U_CRecv\",T0.\"U_Remarks\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@SHADECARDMST\" T0 ");
				stringBuilder.Append(" WHERE T0.\"Code\" = " + code + " ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					model = ConvertDatatableToList.ConvertToEntity<ShadeMasterModel>(datatable);
				}

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT ROW_NUMBER() OVER (ORDER BY T0.\"Code\") \"Index\", T0.\"Code\",T0.\"U_ICode\" AS \"ItemCode\", T0.\"U_IName\" as \"ItemName\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@SHADECARDMST\" T0 ");
				stringBuilder.Append(" WHERE T0.\"U_SCNo\" = '" + model.U_SCNo + "' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					List<ShadeMasterRowsModel> modelRows = ConvertDatatableToList.ConvertToList<ShadeMasterRowsModel>(datatable);
					model.Rows = modelRows;
				}
			}
			catch
			{

			}
			return model;
		}
		public ResponseModel Update(ShadeMasterModel model)
		{
			ResponseModel responseModel = new ResponseModel();
			string message = "";
			string updateDate = DateTime.Now.Date.ToString("yyyMMdd");
			string updateTime = DateTime.Now.ToString("HH:mm:ss");

			#region Update Data

			stringBuilder = new StringBuilder();
			stringBuilder.Append(" SELECT \"U_Active\" FROM " + ConfigManager.GetSAPDatabase() + ".\"@SHADECARDMST\" ");
			stringBuilder.Append(" WHERE\"U_ICode\" = '" + model.U_ICode + "' And \"U_Active\" = 'Yes'  And \"Code\" != '" + model.Code + "' ");
			DataTable datat = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
			if (datat.Rows.Count > 0 && model.U_Active == "Yes")
			{
				responseModel.ResponseStatus = false;
				responseModel.ResponseText = "Already status is Active for seleted Item";
			}
			else
			{
				//var modelUpdateRows = model.Rows.Where(a => a.Code != null && a.ItemCode == model.U_ICode).ToList();
				//for (int i = 0; i < modelUpdateRows.Count; i++)
				//{
				DateTime scDate = new DateTime();
				if (model.U_SCDate.Contains(":"))
				{
					scDate = DateTime.ParseExact(model.U_SCDate, "dd-MM-yyyy HH:mm:ss", CultureInfo.InvariantCulture);
				}
				else if (model.U_SCDate.Contains("-"))
				{
					scDate = DateTime.ParseExact(model.U_SCDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
				}
				else
				{ 
					scDate = DateTime.ParseExact(model.U_SCDate, "yyyyMMdd", CultureInfo.InvariantCulture);
				}
				//DateTime scDate1 = DateTime.ParseExact(model.U_SCDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
				//string itemname = modelUpdateRows[i].ItemName;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@SHADECARDMST\" ");
				stringBuilder.Append(" SET \"U_CCode\" = '" + model.U_CCode + "' ,\"U_CName\" = '" + model.U_CName + "'  ,\"U_SCNo\" = '" + model.U_SCNo + "'");
				stringBuilder.Append(" , \"U_ICode\" = '" + model.U_ICode + "' , \"U_IName\" = '" + model.U_IName.Replace("'", "") + "' , \"U_SCDate\" = '" + scDate.ToString("yyyMMdd") + "'");
				stringBuilder.Append(" , \"U_AppBy\" = '" + model.U_AppBy + "' , \"U_STC\" = '" + model.U_STC + "' , \"U_CRecv\" = '" + model.U_CRecv + "'");
				stringBuilder.Append(" , \"U_Active\" = '" + model.U_Active + "' , \"U_Remarks\" = '" + model.U_Remarks + "' , \"U_UpdateDate\" = '" + updateDate + "',  \"U_UpdateTime\" = '" + updateTime + "'");
				stringBuilder.Append(" WHERE \"Code\" = '" + model.Code + "'");

				FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
				if (message == string.Empty)
				{
					responseModel.ResponseStatus = true;
					responseModel.ResponseText = "Updated successfully";
					UpdateItemShadeData(model.U_ICode, model);
				}
				else
				{
					responseModel.ResponseStatus = false;
					responseModel.ResponseText = "Error occured during process: " + message;
				}
				//}

				var modelAddRows = model.Rows.Where(a => a.Code == null).ToList();
				if (modelAddRows.Count > 0)
				{
					model.Rows = modelAddRows;
					bool isValid = true;
					for (int i = 0; i < model.Rows.Count; i++)
					{
						stringBuilder = new StringBuilder();
						stringBuilder.Append(" SELECT \"U_Active\" FROM " + ConfigManager.GetSAPDatabase() + ".\"@SHADECARDMST\" ");
						stringBuilder.Append(" where \"U_ICode\" = '" + model.Rows[i].ItemCode + "' And \"U_Active\" = 'Yes' ");
						DataTable dt = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
						if (dt.Rows.Count > 0)
						{
							responseModel.ResponseStatus = false;
							responseModel.ResponseText = "Already status is Active for seleted Item";
							isValid = false;
						}
					}
					if (isValid == true)
					{
						ServiceLayer rc = new ServiceLayer();
						string res = rc.Login();
						if (res != "" && res.Contains("error") == false)
						{
							AddShadeCardData(model, res, rc);
							rc.LogOut();
						}
					}
				}
			}

			#endregion

			return responseModel;
		}
		public void AddBulkImport(List<ShadeMasterModel> list)
		{
			ResponseModel responseModel = new ResponseModel();
			string message = "";

			//for (int i = 0; i < list.Count; i++)
			//{
			//    ShadeMasterModel model = list[i];
			//    stringBuilder = new StringBuilder();
			//    stringBuilder.Append(" INSERT INTO  " + ConfigManager.GetSAPDatabase() + ".\"@SHADECARDMST\"(\"Code\",\"DocEntry\",\"Object\") ");
			//    stringBuilder.Append(" VALUES('" + model.Code + "','" + model.Code + "','SHADECARDMST')");
			//    FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
			//}
			for (int i = 0; i < list.Count; i++)
			{
				ShadeMasterModel model = list[i];

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@SHADECARDMST\" ");
				stringBuilder.Append(" SET \"U_CCode\" = '" + model.U_CCode.Trim() + "'");
				stringBuilder.Append(" ,\"U_CName\" = '" + model.U_CName.Trim().Replace("'", "") + "'");
				stringBuilder.Append(" ,\"U_ICode\" = '" + model.U_ICode.Trim() + "'");
				stringBuilder.Append(" ,\"U_IName\" = '" + model.U_IName.Trim().Replace("'", "") + "'");
				if (model.U_SCNo != null)
				{
					stringBuilder.Append(" ,\"U_SCNo\" = '" + model.U_SCNo.Trim() + "'");
				}
				if (model.U_SCDate != null)
				{
					stringBuilder.Append(" ,\"U_SCDate\" = '" + model.U_SCDate.Trim() + "'");
				}
				if (model.U_Active != null)
				{
					stringBuilder.Append(" ,\"U_Active\" = '" + model.U_Active.Trim() + "'");
				}
				if (model.U_UpdateDate != null)
				{
					stringBuilder.Append(" ,\"U_UpdateDate\" = '" + model.U_UpdateDate.Trim() + "'");
				}
				if (model.U_UpdateTime != null)
				{
					stringBuilder.Append(" ,\"U_UpdateTime\" = '" + model.U_UpdateTime.Trim() + "'");
				}
				if (model.U_AppBy != null)
				{
					stringBuilder.Append(" ,\"U_AppBy\" = '" + model.U_AppBy.Trim() + "'");
				}
				if (model.U_CRec != null)
				{
					stringBuilder.Append(" ,\"U_CRecv\" = '" + model.U_CRec.Trim() + "'");
				}
				if (model.U_Remarks != null)
				{
					stringBuilder.Append(" ,\"U_Remarks\" = '" + model.U_Remarks.Trim() + "'");
				}
				stringBuilder.Append(" WHERE \"Code\" = '" + model.Code + "'");
				FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
				if (message == string.Empty)
				{
					responseModel.ResponseText = "Operation completed successfully";
				}
				else
				{
					responseModel.ResponseText = "Error occured during process: " + message;
				}
			}
		}
		private void UpdateItemShadeData(string itemcode, ShadeMasterModel model)
		{
			DateTime scDate = new DateTime();
			string scNo = "";
			if (model.U_Active == "Yes")
			{
				scNo = model.U_SCNo;

				if (model.U_SCDate.Contains(":"))
				{
					scDate = DateTime.ParseExact(model.U_SCDate, "dd-MM-yyyy HH:mm:ss", CultureInfo.InvariantCulture);
				}
				else
				{
					scDate = DateTime.ParseExact(model.U_SCDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
				}
			}
			stringBuilder = new StringBuilder();
			stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".OITM SET ");
			stringBuilder.Append(" \"U_ShdCrdNo\"= '" + scNo + "' , \"U_ShdCrdDt\"= '" + scDate.ToString("yyyyMMdd") + "' ");
			stringBuilder.Append(" WHERE \"ItemCode\" = '" + itemcode + "' ");
			FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message);
		}
		private void UpdateNextNumber(string objectType, string type)
		{
			stringBuilder = new StringBuilder();
			stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_SERIES1\" SET ");
			stringBuilder.Append(" \"U_NextNo\"= Cast(\"U_NextNo\" as numeric(19,0)) + 1  ");
			stringBuilder.Append(" WHERE \"Code\" = '" + objectType + "' AND \"U_Type\"= '" + type + "' ");
			FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message);
		}

		private bool AddShadeCardData(ShadeMasterModel model, string res, ServiceLayer rc)
		{
			bool result = false;
			string message = "";
			stringBuilder = new StringBuilder();
			stringBuilder.Append(" SELECT MAX(Cast(\"Code\" AS INT))  FROM   " + ConfigManager.GetSAPDatabase() + ".\"@SHADECARDMST\" ");
			DataTable dt = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
			string code = dt.Rows[0][0].ToString();
			if (code == string.Empty)
			{
				code = "0";
			}
			DateTime scDate = new DateTime();
			if (model.U_SCDate.Contains(":"))
			{
				scDate = DateTime.ParseExact(model.U_SCDate, "dd-MM-yyyy HH:mm:ss", CultureInfo.InvariantCulture);
			}
			else
			{
				scDate = DateTime.ParseExact(model.U_SCDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
			}
			Int32 iCode = Convert.ToInt32(code);
			for (int i = 0; i < model.Rows.Count; i++)
			{
				iCode = iCode + 1;
				ShadeMasterModel _objServiceLayer = new ShadeMasterModel();
				_objServiceLayer.Code = iCode.ToString();
				_objServiceLayer.U_CCode = model.U_CCode;
				_objServiceLayer.U_CName = model.U_CName;
				_objServiceLayer.U_ICode = model.Rows[i].ItemCode;
				_objServiceLayer.U_IName = model.Rows[i].ItemName;
				_objServiceLayer.U_SCNo = model.U_SCNo;
				_objServiceLayer.U_SCDate = scDate.ToString("yyyyMMdd");
				_objServiceLayer.U_Active = model.U_Active;
				_objServiceLayer.U_AppBy = model.U_AppBy;
				_objServiceLayer.U_STC = model.U_STC;
				_objServiceLayer.U_CRecv = model.U_CRecv;
				_objServiceLayer.U_Remarks = model.U_Remarks;
				string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
				{
					NullValueHandling = NullValueHandling.Ignore,
				});

				rc.endPoint = ConfigManager.GetServiceLayerURL() + "SHADECARDMST";
				rc.patchJSON = main;
				rc.B1SESSION = res;
				result = rc.postRequest(out message);
				if (result == true)
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					UpdateItemShadeData(_objServiceLayer.U_ICode, model);
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
				}
			}
			return result;
		}

	}
}