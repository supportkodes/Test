﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
//using Microsoft.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sap.Data.Hana;
using WebDAL.Helper;
using WebDAL.IRepository;
using WebDAL.Models;

namespace WebDAL.Repository
{
	public class CRURepository : clsDataAccess, ICRURepository
	{
		string query = "";
		CommonRepository commonRepository = new CommonRepository();
		StringBuilder stringBuilder = new StringBuilder();
		string headerTable = CommonTables.ContractorRateUpdateTable;
		public List<CRUModel> GetAll()
		{
			List<CRUModel> _list = new List<CRUModel>();
			try
			{
				//string headerTable = CommonTables.FLEXOUPHeaderTable;
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"Code\",T1.\"Name\",T2.\"CardName\",T0.\"U_KLDNo\",T0.\"U_PrcType\",T0.\"U_Rate\",T0.\"U_Remarks\",T0.\"U_Status\" ");
				stringBuilder.Append(" ,TO_NVARCHAR(T0.\"U_Date\", 'DD/MM/YYYY')  AS \"U_Date\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_CRU\" T0 ");
				stringBuilder.Append(" LEFT JOIN  " + ConfigManager.GetSAPDatabase() + ".\"@VCCONTR\" T1 ON T0.\"U_ConCode\" = T1.\"Code\"");
				stringBuilder.Append(" LEFT JOIN  " + ConfigManager.GetSAPDatabase() + ".OCRD T2 ON T0.\"U_CardCode\" = T2.\"CardCode\"");
				stringBuilder.Append(" ORDER BY T0.\"Code\" DESC ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				 {
					_list = ConvertDatatableToList.ConvertToList<CRUModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}
		public CRUModel Get(string code)
		{
			CRUModel model = new CRUModel();
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("Code", System.Data.SqlDbType.VarChar);
				parameters[0].Value = code;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"Code\",T0.\"U_ConCode\",T1.\"Name\",T0.\"U_CardCode\",T2.\"CardName\",T0.\"U_KLDNo\",T0.\"U_PrcType\",T0.\"U_Rate\" ");
				stringBuilder.Append(" ,TO_NVARCHAR(T0.\"U_Date\", 'DD/MM/YYYY')  AS \"U_Date\",T0.\"U_Remarks\" ,T0.\"U_Status\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_CRU\" T0 ");
				stringBuilder.Append(" LEFT JOIN  " + ConfigManager.GetSAPDatabase() + ".\"@VCCONTR\" T1 ON T0.\"U_ConCode\" = T1.\"Code\"");
				stringBuilder.Append(" LEFT JOIN  " + ConfigManager.GetSAPDatabase() + ".OCRD T2 ON T0.\"U_CardCode\" = T2.\"CardCode\"");
				stringBuilder.Append(" WHERE T0.\"Code\" = :code ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						model = ConvertDatatableToList.ConvertToEntity<CRUModel>(datatable);
					}
				}
			}
			catch
			{

			}
			return model;
		}
		public ResponseModel Add(CRUModel model)
		{
			string message = "";
			ResponseModel responseModel = new ResponseModel();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT MAX(Cast(\"Code\" AS INT)) + 1 FROM   " + ConfigManager.GetSAPDatabase() + ".\"@WEB_CRU\" ");
				DataTable dt = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
				string code = dt.Rows[0][0].ToString();

				if (code == string.Empty)
				{
					code = "1";
				}
				DateTime date = DateTime.ParseExact(model.U_Date, "dd-MM-yyyy", CultureInfo.InvariantCulture);

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT * FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_CRU\" T0 ");
				stringBuilder.Append(" WHERE T0.\"U_ConCode\" = '" + model.U_ConCode + "' AND T0.\"U_CardCode\" = '" + model.U_CardCode + "'   ");
				stringBuilder.Append(" AND T0.\"U_Rate\" = '" + model.U_Rate + "' AND T0.\"U_KLDNo\" = '" + model.U_KLDNo + "'   ");
				stringBuilder.Append(" AND T0.\"U_PrcType\" = '" + model.U_PrcType + "' AND T0.\"U_Status\" = '" + model.U_Status + "'   ");
				stringBuilder.Append(" AND T0.\"U_Date\" = '" + date.ToString("yyyMMdd") + "'  ");
				DataTable data = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
				if (data.Rows.Count == 0)
				{
					stringBuilder = new StringBuilder();
					stringBuilder.Append(" INSERT INTO  " + ConfigManager.GetSAPDatabase() + ".\"@WEB_CRU\"(\"Code\",\"Name\" ");
					stringBuilder.Append(" ,\"U_ConCode\" ,\"U_CardCode\" , \"U_KLDNo\"");
					stringBuilder.Append(" ,\"U_Rate\",\"U_PrcType\" ,\"U_Remarks\", \"U_Date\" , \"U_Status\" ");
					stringBuilder.Append("  ) ");
					stringBuilder.Append(" VALUES('" + code + "','" + code + "'");
					stringBuilder.Append(" ,'" + model.U_ConCode + "','" + model.U_CardCode + "' ");
					stringBuilder.Append(" ,'" + model.U_KLDNo + "','" + model.U_Rate + "' ");
					stringBuilder.Append(" ,'" + model.U_PrcType + "','" + model.U_Remarks + "' ");
					stringBuilder.Append(" ,'" + date.ToString("yyyMMdd") + "' ");
					stringBuilder.Append(" ,'" + model.U_Status + "' ");
					stringBuilder.Append("  ) ");
					FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
					if (message == string.Empty)
					{
						responseModel.ResponseText = "Operation completed successfully";
						responseModel.ResponseStatus = true;
					}
					else
					{
						responseModel.ResponseText = "Error occured during process: " + message;
					}
				}
				else
				{
					responseModel.ResponseText = "You can't add duplicate entry Please check details";
				}
			}
			catch (Exception ex)
			{
				responseModel.ResponseText = "Error occured during process: " + ex.Message;
				responseModel.ResponseStatus = false;
			}
			return responseModel;
		}
		public ResponseModel Update(CRUModel model)
		{
			try
			{
				ResponseModel responseModel = new ResponseModel();
				string message = "";
				DateTime date = new DateTime();
				if (model.U_Date.Contains("/"))
				{
					date = DateTime.ParseExact(model.U_Date, "dd/MM/yyyy", CultureInfo.InvariantCulture);
				}
				else
				{
					date = DateTime.ParseExact(model.U_Date, "dd-MM-yyyy", CultureInfo.InvariantCulture);
				}
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT * FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_CRU\" T0 ");
                stringBuilder.Append(" WHERE T0.\"U_ConCode\" = '" + model.U_ConCode + "' AND T0.\"U_CardCode\" = '" + model.U_CardCode + "'   ");
                stringBuilder.Append(" AND T0.\"U_Rate\" = '" + model.U_Rate + "' AND T0.\"U_KLDNo\" = '" + model.U_KLDNo + "'   ");
				stringBuilder.Append(" AND T0.\"U_PrcType\" = '" + model.U_PrcType + "' AND T0.\"U_Status\" = '" + model.U_Status + "'   ");
				stringBuilder.Append(" AND T0.\"U_Date\" = '" + date.ToString("yyyMMdd") + "'  ");
				stringBuilder.Append(" AND T0.\"Code\" != '" + model.Code + "'  ");
				DataTable data = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
				if (data.Rows.Count == 0)
				{
					stringBuilder = new StringBuilder();
					stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_CRU\" ");
					stringBuilder.Append("  SET \"U_ConCode\" = '" + model.U_ConCode + "',\"U_CardCode\" = '" + model.U_CardCode + "' ");
					stringBuilder.Append("  ,\"U_KLDNo\" = '" + model.U_KLDNo + "',\"U_Rate\" = '" + model.U_Rate + "' ");
					stringBuilder.Append("  ,\"U_PrcType\" = '" + model.U_PrcType + "',\"U_Remarks\" = '" + model.U_Remarks + "' ");
					stringBuilder.Append(" , \"U_Date\" = '" + date.ToString("yyyMMdd") + "' ");
					stringBuilder.Append(" , \"U_Status\" = '" + model.U_Status + "' ");
					stringBuilder.Append(" WHERE \"Code\" = '" + model.Code + "'");

					FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
					if (message == string.Empty)
					{
						responseModel.ResponseStatus = true;
						responseModel.ResponseText = "Updated successfully";
					}
					else
					{
						responseModel.ResponseStatus = false;
						responseModel.ResponseText = "Error occured during process: " + message;
					}
				}
				else
				{
					responseModel.ResponseStatus = false;
					responseModel.ResponseText = "You can't add duplicate entry Please check details";
				}
				return responseModel;
			}
			catch (Exception ex)
			{
				throw new Exception(ex.ToString());
			}
		}
	}
}