﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.ConstrainedExecution;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sap.Data.Hana;
using WebDAL.Helper;
using WebDAL.Helpers;
using WebDAL.IRepository;
using WebDAL.Models;

namespace WebDAL.Repository
{
    public class ClientPORegisterRepository : clsDataAccess, IClientPORegisterRepository
    {
        string query = "";
        CommonRepository commonRepository = new CommonRepository();
        StringBuilder stringBuilder = new StringBuilder();

        public List<ClientPORegisterModel> GetAll()
        {
            List<ClientPORegisterModel> _list = new List<ClientPORegisterModel>();
            try
            {
                string headerTable = CommonTables.ClientPORegisterHeaderTable;
                StringBuilder sbOpen = new StringBuilder();
                sbOpen.Append(" SELECT T0.\"DocEntry\",T0.\"DocNum\",TO_NVARCHAR(T0.\"U_DocDate\", 'DD/MM/YYYY')  AS \"U_DocDate\",T0.\"U_PORefNo\",T0.\"U_CardCode\",T0.\"U_CardName\" ");
                sbOpen.Append(" ,T2.\"SlpName\" ");
                sbOpen.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + headerTable + "\" T0 ");
                sbOpen.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"OCRD\" T1 ON T0.\"U_CardCode\" = T1.\"CardCode\" ");
                sbOpen.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"OSLP\" T2 ON T1.\"SlpCode\" = T2.\"SlpCode\" ");
                sbOpen.Append(" WHERE T0.\"Status\" = 'O' ");
                sbOpen.Append(" ORDER BY T0.\"DocEntry\" DESC ");
                using (DataTable datatable = FillDataTable(sbOpen.ToString(), CommandType.Text, out string message))
                {
                    _list = ConvertDatatableToList.ConvertToList<ClientPORegisterModel>(datatable);
                }
            }
            catch
            {
            }
            return _list;
        }

		public List<ClientPORegisterModel> GetAllClose()
		{
			List<ClientPORegisterModel> _list = new List<ClientPORegisterModel>();
			try
			{
				string headerTable = CommonTables.ClientPORegisterHeaderTable;
				HanaParameter[] parameters = new HanaParameter[1];

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"DocEntry\",T0.\"DocNum\",TO_NVARCHAR(T0.\"U_DocDate\", 'DD/MM/YYYY')  AS \"U_DocDate\",T0.\"U_PORefNo\",T0.\"U_CardCode\",T0.\"U_CardName\" ");
				stringBuilder.Append(" ,T2.\"SlpName\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + headerTable + "\" T0 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"OCRD\" T1 ON T0.\"U_CardCode\" = T1.\"CardCode\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"OSLP\" T2 ON T1.\"SlpCode\" = T2.\"SlpCode\" ");
				stringBuilder.Append(" WHERE T0.\"Status\" = 'C' ");
				stringBuilder.Append(" ORDER BY T0.\"DocEntry\" DESC ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<ClientPORegisterModel>(datatable);
				}
			}
			catch
			{
			}
			return _list;
		}

		public ClientPORegisterModel Get(string docEntry)
        {
            ClientPORegisterModel model = new ClientPORegisterModel();
            try
            {
                string headerTable = CommonTables.ClientPORegisterHeaderTable;
                string rowTable = CommonTables.ClientPORegisterRowTable;
                HanaParameter[] parameters = new HanaParameter[1];

                parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
                parameters[0].Value = docEntry;

                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"DocEntry\",T0.\"DocNum\",TO_NVARCHAR(T0.\"U_DocDate\", 'DD-MM-YYYY')  AS \"U_DocDate\" ,T0.\"U_CardCode\",T0.\"U_CardName\" ");
                stringBuilder.Append(" ,T0.\"U_PORefNo\",TO_NVARCHAR(T0.\"U_PORefDt\", 'DD-MM-YYYY')  AS \"U_PORefDt\" , T0.\"Series\" ,T1.\"SeriesName\"");
                stringBuilder.Append(" ,T0.\"U_Currency\",T0.\"U_DocRate\"");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + headerTable + "\" T0 ");
                stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".NNM1 T1 ON T0.\"Series\" = T1.\"Series\"  ");
                stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    if (datatable.Rows.Count > 0)
                    {
                        model = ConvertDatatableToList.ConvertToEntity<ClientPORegisterModel>(datatable);
                    }
                }

                #region Row
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT  ROW_NUMBER() OVER (ORDER BY T0.\"LineId\") AS \"Index\",T0.\"LineId\",  T0.\"U_ItemCode\" ,T0.\"U_ItemName\" ");
                stringBuilder.Append(" ,Cast(T0.\"U_Qty\" AS NUMERIC(19,2)) AS \"U_Qty\", T0.\"U_Rate\" , T0.\"U_RateSys\" , T0.\"U_AppArt\" ,T0.\"U_KLDNo\" ");//,T0.\"U_ArtAttach\"
                stringBuilder.Append(",TO_NVARCHAR( T0.\"U_ToDate\", 'DD-MM-YYYY') AS \"U_ToDate\"  ");
                stringBuilder.Append(",TO_NVARCHAR( T0.\"U_FromDate\", 'DD-MM-YYYY') AS \"U_FromDate\"  ");
                stringBuilder.Append(" ,T0.\"U_GangJob\", T0.\"U_BomType\" , T0.\"U_NoOfUPS\" , T0.\"U_RefId\", T0.\"U_IsGang\" ");
                stringBuilder.Append(" ,T0.\"U_BaseEn\", T0.\"U_BaseLine\" ");
                stringBuilder.Append(" ,T0.\"U_TargEn\", T0.\"U_TargLine\" ");
                stringBuilder.Append(" ,T0.\"U_SOEn\" ");
                stringBuilder.Append(" ,T0.\"U_MailSent\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + rowTable + "\" T0 ");
                //stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"" + rowTable + "\" T0 ");
                stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " ");

                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    if (datatable.Rows.Count > 0)
                    {
                        List<ClientPORegisterRowsModel> modelRows = ConvertDatatableToList.ConvertToList<ClientPORegisterRowsModel>(datatable);
                        model.WEB_PO_REGISTER1Collection = modelRows;
                        for (int i = 0; i < model.WEB_PO_REGISTER1Collection.Count; i++)
                        {
                            string isGang = model.WEB_PO_REGISTER1Collection[i].U_IsGang;
                            model.WEB_PO_REGISTER1Collection[i].IsGang = isGang == "Y" ? true : false;
                        }
                    }
                    else
                    {
                        List<ClientPORegisterRowsModel> ClientPORegisterList = new List<ClientPORegisterRowsModel>();
                        ClientPORegisterRowsModel clientPORegisterRowsModel = new ClientPORegisterRowsModel();
                        ClientPORegisterList.Add(clientPORegisterRowsModel);
                        model.WEB_PO_REGISTER1Collection = ClientPORegisterList;

                    }

                    List<ClientPORegisterQtyPerPOModel> qtyPerPOModelList = new List<ClientPORegisterQtyPerPOModel>();
                    ClientPORegisterQtyPerPOModel qtyPerPOModel = new ClientPORegisterQtyPerPOModel();
                    qtyPerPOModel.Index = 1;
                    qtyPerPOModelList.Add(qtyPerPOModel);
                    model.WEB_PO_REGISTER2Collection = qtyPerPOModelList;
                }
                #endregion

                #region Client PO Attachment 
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT \"LineId\", \"U_Attach\" , \"U_DocType\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PO_REGISTER3\" ");

                stringBuilder.Append(" WHERE \"DocEntry\" = :docEntry ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                {
                    List<ClientPORegister_Attachment> modelRows = ConvertDatatableToList.ConvertToList<ClientPORegister_Attachment>(datatable);
                    model.WEB_PO_REGISTER3Collection = modelRows;
                }
                #endregion
            }
            catch
            {

            }
            return model;
        }

        public ResponseModel Add(ClientPORegisterModel model)
        {
            string headerTable = CommonTables.ClientPORegisterHeaderTable;
            string rowTable = CommonTables.ClientPORegisterRowTable;
            ResponseModel responseModel = new ResponseModel();
            ServiceLayer rc = new ServiceLayer();

            //string slpcode = commonRepository.GetSlpCodeFromEmailAddress(model.UserId);
            ClientPORegisterModel _objServiceLayer = new ClientPORegisterModel();

            #region Header
            _objServiceLayer.Series = model.Series;
            _objServiceLayer.DocNum = model.DocNum;
            _objServiceLayer.U_CardCode = model.U_CardCode;
            _objServiceLayer.U_CardName = model.U_CardName;
            _objServiceLayer.U_PORefNo = model.U_PORefNo;
            DateTime dtDate = DateTime.ParseExact(model.U_DocDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
            _objServiceLayer.U_DocDate = dtDate.ToString("yyyyMMdd");
            DateTime podtDate = DateTime.ParseExact(model.U_PORefDt, "dd-MM-yyyy", CultureInfo.InvariantCulture);
            _objServiceLayer.U_PORefDt = podtDate.ToString("yyyyMMdd");
            _objServiceLayer.U_Currency = model.U_Currency;
            #endregion

            #region ClientPORegister Rows

            int modelRow = 0;
            List<ClientPORegisterRowsModel> modelLines_ServiceLayer = new List<ClientPORegisterRowsModel>();
            model.WEB_PO_REGISTER1Collection = model.WEB_PO_REGISTER1Collection.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
            for (int i = 0; i < model.WEB_PO_REGISTER1Collection.Count; i++)
            {
                if (!string.IsNullOrEmpty(model.WEB_PO_REGISTER1Collection[i].U_ItemCode))
                {
                    modelLines_ServiceLayer.Add(new ClientPORegisterRowsModel { });
                    modelLines_ServiceLayer[modelRow].U_ItemCode = model.WEB_PO_REGISTER1Collection[i].U_ItemCode;
                    modelLines_ServiceLayer[modelRow].U_ItemName = model.WEB_PO_REGISTER1Collection[i].U_ItemName;
                    modelLines_ServiceLayer[modelRow].U_Qty = model.WEB_PO_REGISTER1Collection[i].U_Qty;
                    modelLines_ServiceLayer[modelRow].U_Rate = model.WEB_PO_REGISTER1Collection[i].U_Rate;
                    modelLines_ServiceLayer[modelRow].U_AppArt = model.WEB_PO_REGISTER1Collection[i].U_AppArt;
                    // modelLines_ServiceLayer[modelRow].U_ArtAttach = model.WEB_PO_REGISTER1Collection[i].U_ArtAttach;
                    modelLines_ServiceLayer[modelRow].U_RateSys = model.WEB_PO_REGISTER1Collection[i].U_RateSys;
                    modelLines_ServiceLayer[modelRow].U_KLDNo = model.WEB_PO_REGISTER1Collection[i].U_KLDNo;
                    //modelLines_ServiceLayer[modelRow].U_GangJob = model.WEB_PO_REGISTER1Collection[i].U_GangJob;
                    modelLines_ServiceLayer[modelRow].U_IsGang = model.WEB_PO_REGISTER1Collection[i].IsGang == true ? "Y" : "N";

                    modelLines_ServiceLayer[modelRow].U_NoOfUPS = model.WEB_PO_REGISTER1Collection[i].U_NoOfUPS;
                    modelLines_ServiceLayer[modelRow].U_BomType = model.WEB_PO_REGISTER1Collection[i].U_BomType;
                    modelLines_ServiceLayer[modelRow].U_RefId = model.WEB_PO_REGISTER1Collection[i].U_RefId;

                    modelLines_ServiceLayer[modelRow].U_TargEn = model.WEB_PO_REGISTER1Collection[i].U_TargEn;
                    modelLines_ServiceLayer[modelRow].U_TargLine = model.WEB_PO_REGISTER1Collection[i].U_TargLine;
                    modelLines_ServiceLayer[modelRow].U_BaseEn = model.WEB_PO_REGISTER1Collection[i].U_BaseEn;
                    modelLines_ServiceLayer[modelRow].U_BaseLine = model.WEB_PO_REGISTER1Collection[i].U_BaseLine;


                    //DateTime dtFromDate = DateTime.ParseExact(model.WEB_PO_REGISTER1Collection[i].U_FromDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                    //modelLines_ServiceLayer[modelRow].U_FromDate = dtFromDate.ToString("yyyyMMdd");

                    if (!string.IsNullOrEmpty(model.WEB_PO_REGISTER1Collection[i].U_ToDate))
                    {
                        DateTime dtToDate = DateTime.ParseExact(model.WEB_PO_REGISTER1Collection[i].U_ToDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                        modelLines_ServiceLayer[modelRow].U_ToDate = dtToDate.ToString("yyyyMMdd");
                    }
                    if (!string.IsNullOrEmpty(model.WEB_PO_REGISTER1Collection[i].U_FromDate))
                    {
                        DateTime dtFromDate = DateTime.ParseExact(model.WEB_PO_REGISTER1Collection[i].U_FromDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                        modelLines_ServiceLayer[modelRow].U_FromDate = dtFromDate.ToString("yyyyMMdd");
                    }
                    modelRow++;
                }
            }
            #endregion

            #region Attachment Rows

            int modelRow1 = 0;
            List<ClientPORegister_Attachment> ClientPORegister_Attachment_ServiceLayer = new List<ClientPORegister_Attachment>();
            model.WEB_PO_REGISTER3Collection = model.WEB_PO_REGISTER3Collection.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();

            for (int i = 0; i < model.WEB_PO_REGISTER3Collection.Count; i++)
            {
                ClientPORegister_Attachment_ServiceLayer.Add(new ClientPORegister_Attachment { });
                ClientPORegister_Attachment_ServiceLayer[modelRow1].LineId = i + 1;
                ClientPORegister_Attachment_ServiceLayer[modelRow1].U_Attach = model.WEB_PO_REGISTER3Collection[i].U_Attach;
                ClientPORegister_Attachment_ServiceLayer[modelRow1].U_DocType = model.WEB_PO_REGISTER3Collection[i].U_DocType;
                modelRow1++;
            }
            #endregion

            _objServiceLayer.WEB_PO_REGISTER1Collection = modelLines_ServiceLayer;
            _objServiceLayer.WEB_PO_REGISTER3Collection = ClientPORegister_Attachment_ServiceLayer;

            string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
            {
                NullValueHandling = NullValueHandling.Ignore,
            });

            var myJson = JObject.Parse(main);

            myJson.Descendants()
            .OfType<JProperty>()
            .Where(attr => attr.Name.StartsWith("IsSelect"))
            .ToList()
            .ForEach(attr => attr.Remove());

            myJson.Descendants()
            .OfType<JProperty>()
            .Where(attr => attr.Name.StartsWith("IsGang"))
            .ToList()
            .ForEach(attr => attr.Remove());
            main = myJson.ToString();
            var temp = JsonConvert.DeserializeObject<JObject>(main);

            string serviceLayerObject = "";
            string res = rc.Login();
            if (res != "" && res.Contains("error") == false)
            {
                serviceLayerObject = ServiceLayerEntity.WEB_PO_REGISTER.ToString();
                rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject;
                rc.patchJSON = main;
                rc.B1SESSION = res;
                string message = "";
                bool result = rc.postRequest(out message);
                responseModel.ResponseStatus = result;
                if (result == true)
                {
                    responseModel.ResponseText = "Operation completed successfully";

                    var jobject = JsonConvert.DeserializeObject<JObject>(message);
                    string docEntry = jobject["DocEntry"].ToString();

                    string userId = commonRepository.GetUserId(model.UserId);
                    stringBuilder = new StringBuilder();
                    stringBuilder.Append(" UPDATE T0 ");
                    stringBuilder.Append(" SET T0.\"UserSign\" = " + userId + " ");
                    stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + CommonTables.ClientPORegisterHeaderTable + "\" T0 ");
                    stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " ");
                    FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);

                    // Need to change Pravin
                    stringBuilder = new StringBuilder();
                    stringBuilder.Append(" UPDATE T0 ");
                    stringBuilder.Append(" SET T0.\"U_OpenCPORQty\" = IFNULL(T0.\"U_OpenCPORQty\",0) + T1.\"U_Qty\" ");
                    stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".RDR1 T0 ");
                    stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"" + rowTable + "\" T1 ON T0.\"DocEntry\" = T1.\"U_BaseEn\" AND T0.\"LineNum\" = T1.\"U_BaseLine\" ");
                    stringBuilder.Append(" WHERE T1.\"DocEntry\" = " + docEntry + " ");
                    FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);

                }
                else
                {
                    var jobject = JsonConvert.DeserializeObject<JObject>(message);
                    string jsonMessage = jobject["error"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["message"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["value"].ToString();
                    responseModel.ResponseText = "Error occured during process: " + jsonMessage;
                }
                rc.LogOut();
            }
            else
            {
                responseModel.ResponseText = "Service layer login failed";
            }
            return responseModel;
        }
        public ResponseModel Update(ClientPORegisterModel model)
        {

            string headerTable = CommonTables.ClientPORegisterHeaderTable;
            string rowTable = CommonTables.ClientPORegisterRowTable;
            ResponseModel responseModel = new ResponseModel();
            ServiceLayer rc = new ServiceLayer();
            ClientPORegisterModel _objServiceLayer = new ClientPORegisterModel();

            #region Header
            _objServiceLayer.Series = model.Series;
            _objServiceLayer.DocNum = model.DocNum;
            _objServiceLayer.DocEntry = model.DocEntry;
            _objServiceLayer.U_CardCode = model.U_CardCode;
            _objServiceLayer.U_CardName = model.U_CardName;
            _objServiceLayer.U_PORefNo = model.U_PORefNo;
            DateTime dtDate = DateTime.ParseExact(model.U_DocDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
            _objServiceLayer.U_DocDate = dtDate.ToString("yyyyMMdd");
            DateTime podtDate = DateTime.ParseExact(model.U_PORefDt, "dd-MM-yyyy", CultureInfo.InvariantCulture);
            _objServiceLayer.U_PORefDt = podtDate.ToString("yyyyMMdd");
            _objServiceLayer.U_Currency = model.U_Currency;
            _objServiceLayer.U_Remarks = model.U_Remarks;
            #endregion

            #region ClientPORegister Rows

            int modelRow = 0;
            List<ClientPORegisterRowsModel> modelLines_ServiceLayer = new List<ClientPORegisterRowsModel>();
            model.WEB_PO_REGISTER1Collection = model.WEB_PO_REGISTER1Collection.Where(a => string.IsNullOrEmpty(a.IsDeleted)
            || a.IsDeleted == "N").ToList();
            for (int i = 0; i < model.WEB_PO_REGISTER1Collection.Count; i++)
            {
                if (!string.IsNullOrEmpty(model.WEB_PO_REGISTER1Collection[i].U_ItemCode))
                {
                    modelLines_ServiceLayer.Add(new ClientPORegisterRowsModel { });
                    modelLines_ServiceLayer[modelRow].LineId = model.WEB_PO_REGISTER1Collection[i].LineId;
                    //DateTime dtsoDate = DateTime.ParseExact(model.WEB_GANGUP1Collection[i].U_SoDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                    //modelLines_ServiceLayer[modelRow].U_SoDate = dtsoDate.ToString("yyyyMMdd");
                    modelLines_ServiceLayer[modelRow].U_ItemCode = model.WEB_PO_REGISTER1Collection[i].U_ItemCode;
                    modelLines_ServiceLayer[modelRow].U_ItemName = model.WEB_PO_REGISTER1Collection[i].U_ItemName;
                    modelLines_ServiceLayer[modelRow].U_Qty = model.WEB_PO_REGISTER1Collection[i].U_Qty;
                    modelLines_ServiceLayer[modelRow].U_Rate = model.WEB_PO_REGISTER1Collection[i].U_Rate;
                    modelLines_ServiceLayer[modelRow].U_AppArt = model.WEB_PO_REGISTER1Collection[i].U_AppArt;
                    // modelLines_ServiceLayer[modelRow].U_ArtAttach = model.WEB_PO_REGISTER1Collection[i].U_ArtAttach;
                    modelLines_ServiceLayer[modelRow].U_RateSys = model.WEB_PO_REGISTER1Collection[i].U_RateSys;
                    modelLines_ServiceLayer[modelRow].U_KLDNo = model.WEB_PO_REGISTER1Collection[i].U_KLDNo;
                    //modelLines_ServiceLayer[modelRow].U_GangJob = model.WEB_PO_REGISTER1Collection[i].U_GangJob;
                    modelLines_ServiceLayer[modelRow].U_IsGang = model.WEB_PO_REGISTER1Collection[i].IsGang == true ? "Y" : "N";

                    modelLines_ServiceLayer[modelRow].U_NoOfUPS = model.WEB_PO_REGISTER1Collection[i].U_NoOfUPS;
                    modelLines_ServiceLayer[modelRow].U_BomType = model.WEB_PO_REGISTER1Collection[i].U_BomType;
                    modelLines_ServiceLayer[modelRow].U_RefId = model.WEB_PO_REGISTER1Collection[i].U_RefId;

                    modelLines_ServiceLayer[modelRow].U_TargEn = model.WEB_PO_REGISTER1Collection[i].U_TargEn;
                    modelLines_ServiceLayer[modelRow].U_TargLine = model.WEB_PO_REGISTER1Collection[i].U_TargLine;
                    modelLines_ServiceLayer[modelRow].U_BaseEn = model.WEB_PO_REGISTER1Collection[i].U_BaseEn;
                    modelLines_ServiceLayer[modelRow].U_BaseLine = model.WEB_PO_REGISTER1Collection[i].U_BaseLine;

                    if (!string.IsNullOrEmpty(model.WEB_PO_REGISTER1Collection[i].U_ToDate))
                    {
                        DateTime dtToDate = DateTime.ParseExact(model.WEB_PO_REGISTER1Collection[i].U_ToDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                        modelLines_ServiceLayer[modelRow].U_ToDate = dtToDate.ToString("yyyyMMdd");
                    }
                    if (!string.IsNullOrEmpty(model.WEB_PO_REGISTER1Collection[i].U_FromDate))
                    {
                        DateTime dtFromDate = DateTime.ParseExact(model.WEB_PO_REGISTER1Collection[i].U_FromDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                        modelLines_ServiceLayer[modelRow].U_FromDate = dtFromDate.ToString("yyyyMMdd");
                    }
                    modelRow++;
                }
            }
            #endregion

            #region Attachment Rows

            int modelRow1 = 0;
            List<ClientPORegister_Attachment> ClientPORegister_Attachment_ServiceLayer = new List<ClientPORegister_Attachment>();
            model.WEB_PO_REGISTER3Collection = model.WEB_PO_REGISTER3Collection.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();

            for (int i = 0; i < model.WEB_PO_REGISTER3Collection.Count; i++)
            {
                ClientPORegister_Attachment_ServiceLayer.Add(new ClientPORegister_Attachment { });
                ClientPORegister_Attachment_ServiceLayer[modelRow1].LineId = i + 1;
                ClientPORegister_Attachment_ServiceLayer[modelRow1].U_Attach = model.WEB_PO_REGISTER3Collection[i].U_Attach;
                ClientPORegister_Attachment_ServiceLayer[modelRow1].U_DocType = model.WEB_PO_REGISTER3Collection[i].U_DocType;
                modelRow1++;
            }
            #endregion

            _objServiceLayer.WEB_PO_REGISTER1Collection = modelLines_ServiceLayer;
            _objServiceLayer.WEB_PO_REGISTER3Collection = ClientPORegister_Attachment_ServiceLayer;

            string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
            {
                NullValueHandling = NullValueHandling.Ignore,
            });

            var myJson = JObject.Parse(main);

            myJson.Descendants()
            .OfType<JProperty>()
            .Where(attr => attr.Name.StartsWith("IsSelect"))
            .ToList()
            .ForEach(attr => attr.Remove());


            myJson.Descendants()
            .OfType<JProperty>()
            .Where(attr => attr.Name.StartsWith("IsGang"))
            .ToList()
            .ForEach(attr => attr.Remove());
            main = myJson.ToString();

            string serviceLayerObject = "";
            string res = rc.Login();
            if (res != "" && res.Contains("error") == false)
            {
                DeleteLines(model.DocEntry);
                serviceLayerObject = ServiceLayerEntity.WEB_PO_REGISTER.ToString();
                rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject + "(" + model.DocEntry + ")";
                rc.patchJSON = main;
                rc.B1SESSION = res;
                rc.httpMethod = httpVerb.PATCH;
                string message = "";
                bool result = rc.postRequest(out message);
                responseModel.ResponseStatus = result;
                if (result == true)
                {
                    responseModel.ResponseText = "Updated completed successfully";
                }
                else
                {
                    var jobject = JsonConvert.DeserializeObject<JObject>(message);
                    string jsonMessage = jobject["error"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["message"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["value"].ToString();
                    responseModel.ResponseText = "Error occured during process: " + jsonMessage;
                }
                rc.LogOut();
            }
            else
            {
                responseModel.ResponseText = "Service layer login failed";
            }
            return responseModel;
        }
        public DataTable GetMailDraft(string itemcode, string rate)
        {
            try
            {
                HanaParameter[] parameters = new HanaParameter[1];
                parameters[0] = new HanaParameter("U_ItemCode", System.Data.SqlDbType.VarChar);
                parameters[0].Value = itemcode;

                parameters[0] = new HanaParameter("U_Rate", System.Data.SqlDbType.VarChar);
                parameters[0].Value = rate;

                stringBuilder = new StringBuilder();
                stringBuilder.Append(" UPDATE  " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PO_REGISTER1\" T0 ");
                stringBuilder.Append(" SET T0.\"U_Rate\" = '" + rate + "' ");
                stringBuilder.Append(" WHERE T0.\"U_ItemCode\" = '" + itemcode + "' ");

                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    return datatable;
                }
            }
            catch
            {
            }
            return null;
        }
        public List<CopyDocumentModel> GetClientPORegisterData(string cardcode)
        {
            List<CopyDocumentModel> _list = new List<CopyDocumentModel>();
            try
            {
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"DocEntry\" ,T0.\"DocNum\" ,TO_NVARCHAR(T0.\"U_DocDate\", 'DD/MM/YYYY') as \"DocDate\"  ");
                stringBuilder.Append(" ,T0.\"U_CardName\" ,T1.\"U_ItemName\" ,T1.\"U_Qty\" ,T1.\"U_KLDNo\" , T1.\"U_NoOfUPS\" , T1.\"U_RateSys\"");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + CommonTables.ClientPORegisterHeaderTable + "\" T0 ");
                stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"" + CommonTables.ClientPORegisterRowTable + "\" T1 ON T0.\"DocEntry\"=T1.\"DocEntry\" ");

                stringBuilder.Append(" WHERE T0.\"U_CardCode\"  = '" + cardcode + "' ");

                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    _list = ConvertDatatableToList.ConvertToList<CopyDocumentModel>(datatable);

                }
            }
            catch
            {

            }
            return _list;
        }
        public List<ClientPORegisterRowsModel> GetClientPOSelectedData(string docEntry)
        {
            List<ClientPORegisterRowsModel> model = new List<ClientPORegisterRowsModel>();
            try
            {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"U_ItemCode\", T0.\"U_ItemName\", T0.\"U_Qty\" ,T0.\"U_KLDNo\",T0.\"U_NoOfUPS\" , T0.\"U_RateSys\"");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PO_REGISTER1\" T0 ");
                stringBuilder.Append(" WHERE");
                stringBuilder.Append(" T0.\"DocEntry\" = '" + docEntry + "' ");

                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    model = ConvertDatatableToList.ConvertToList<ClientPORegisterRowsModel>(datatable);
                }
            }
            catch
            {
            }
            return model;
        }
        public ResponseModel AddUpdateQtyPerPO(List<ClientPORegisterQtyPerPOModel> model)
        {
            ResponseModel responseModel = new ResponseModel();
            string message = "";
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" DELETE FROM  " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PO_REGISTER2\" T0   ");
            stringBuilder.Append(" WHERE \"U_BaseEn\" ='" + +model[0].U_BaseEn + "' AND \"U_BaseLine\" ='" + model[0].U_BaseLine + "' ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);

            for (int i = 0; i < model.Count; i++)
            {
                if (model[i].U_Qty == null)
                {
                    continue;
                }
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT MAX(Cast(\"Code\" AS INT)) + 1 FROM   " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PO_REGISTER2\" ");
                DataTable dt = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
                string code = dt.Rows[0][0].ToString();
                if (code == string.Empty)
                {
                    code = "1";
                }
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" INSERT INTO  " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PO_REGISTER2\"(\"Code\",\"Name\" ");
                stringBuilder.Append(" ,\"U_BaseEn\",\"U_BaseLine\" ,\"U_Qty\",\"U_PONo\") ");
                stringBuilder.Append(" VALUES('" + code + "','" + code + "' ");
                stringBuilder.Append(" ,'" + model[i].U_BaseEn + "','" + model[i].U_BaseLine + "' ");
                stringBuilder.Append(" ,'" + model[i].U_Qty + "','" + model[i].U_PONo + "')  ");
                FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            }
            if (message == string.Empty)
            {
                responseModel.ResponseText = "Operation completed successfully";
                responseModel.ResponseStatus = true;
            }
            else
            {
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            return responseModel;
        }
        public List<ClientPORegisterQtyPerPOModel> GetQtyPerPOList(string docEntry, string lineNo)
        {
            List<ClientPORegisterQtyPerPOModel> list = new List<ClientPORegisterQtyPerPOModel>();
            try
            {
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"U_Qty\" ,T0.\"U_PONo\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PO_REGISTER2\" T0 ");
                stringBuilder.Append(" WHERE T0.\"U_BaseEn\" = " + docEntry + " AND T0.\"U_BaseLine\" = " + lineNo + " ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    if (datatable.Rows.Count > 0)
                    {
                        list = ConvertDatatableToList.ConvertToList<ClientPORegisterQtyPerPOModel>(datatable);
                    }
                    else
                    {
                        ClientPORegisterQtyPerPOModel qtyPerPOModel = new ClientPORegisterQtyPerPOModel();
                        qtyPerPOModel.Index = 1;
                        list.Add(qtyPerPOModel);
                    }
                }
            }
            catch
            {

            }
            return list;
        }
        public void DeleteLines(string docEntry)
        {
            try
            {
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" DELETE ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PO_REGISTER1\" T0 ");
                stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {

                }
            }
            catch
            {

            }
        }
        public ClientPORegisterModel GetSQToClientPOData(string docEntry)
        {
            ClientPORegisterModel model = new ClientPORegisterModel();
            try
            {
                string headerTable = CommonTables.SalesQuotationHeaderTable;
                string rowTable = CommonTables.SalesQuotationRowTable;
                HanaParameter[] parameters = new HanaParameter[1];

                parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
                parameters[0].Value = docEntry;

                //string CTOL = "";
                //string CTLOL = "";

                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"CardCode\" AS \"U_CardCode\",T0.\"CardName\" AS \"U_CardName\" ");
                //stringBuilder.Append(" ,T1.\"U_BPTL\" As \"U_CTOL\",T1.\"U_BPLTL\" AS \"U_CTLOL\" , T1.\"Currency\" AS \"DocCurrency\"");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + headerTable + "\" T0 ");
                stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OCRD T1 ON T0.\"CardCode\" = T1.\"CardCode\"");
                // stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OSLP T2 ON T1.\"SlpCode\"=T2.\"SlpCode\" ");
                stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    if (datatable.Rows.Count > 0)
                    {
                        model = ConvertDatatableToList.ConvertToEntity<ClientPORegisterModel>(datatable);
                        //CTOL = datatable.Rows[0]["U_CTOL"].ToString();
                        //CTLOL = datatable.Rows[0]["U_CTLOL"].ToString();
                    }
                }
                #region Row
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"VisOrder\" + 1 AS \"LineId\",T0.\"ItemCode\" AS \"U_ItemCode\" , T0.\"Dscription\" AS \"U_ItemName\", Cast(T0.\"Quantity\" AS NUMERIC(19,2)) AS \"U_Qty\",T0.\"Rate\" AS \"U_Rate\"");
                stringBuilder.Append(" ,T0.\"LineNum\" AS \"U_BaseLine\",T0.\"DocEntry\" AS \"U_BaseEn\"");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + rowTable + "\" T0 ");
                stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + "");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    if (datatable.Rows.Count > 0)
                    {
                        List<ClientPORegisterRowsModel> modelRows = ConvertDatatableToList.ConvertToList<ClientPORegisterRowsModel>(datatable);
                        model.WEB_PO_REGISTER1Collection = modelRows;
                        //try
                        //{
                        //    for (int i = 0; i < model.DocumentLines.Count; i++)
                        //    {
                        //        model.DocumentLines[i].U_CTOL = double.Parse(CTOL);
                        //        model.DocumentLines[i].U_CTLOL = double.Parse(CTLOL);
                        //    }
                        //}
                        //catch
                        //{
                        //}
                    }
                    else
                    {
                        List<ClientPORegisterRowsModel> ClientPORegisterList = new List<ClientPORegisterRowsModel>();
                        ClientPORegisterRowsModel clientPORegisterRowsModel = new ClientPORegisterRowsModel();
                        ClientPORegisterList.Add(clientPORegisterRowsModel);
                        model.WEB_PO_REGISTER1Collection = ClientPORegisterList;
                    }
                }
                #endregion
            }
            catch
            {

            }
            return model;
        }
        public string GetCreator(string docEntry)
        {
            string userId = "";
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" SELECT \"UserSign\" FROM  " + ConfigManager.GetSAPDatabase() + ".\"" + CommonTables.ClientPORegisterHeaderTable + "\" T0   ");
            stringBuilder.Append(" WHERE \"DocEntry\" ='" + docEntry + "' ");
            using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
            {
                if (datatable.Rows.Count > 0)
                {
                    userId = datatable.Rows[0][0].ToString();
                }
            }
            return userId;
        }

        public DataTable GetGangUpData(string docEntry, string lineIds)
        {
            string rowTable = CommonTables.ClientPORegisterRowTable;
            try
            {
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T2.\"DocNum\" as \"Doc No\",TO_NVARCHAR(T2.\"U_DocDate\", 'DD/MM/YYYY')  AS \"Doc Date\" ");
                stringBuilder.Append(" ,T1.\"U_ItemCode\" AS \"Item Code\" ,T1.\"U_ItemName\" AS \"Item Name\" ");
                stringBuilder.Append(" ,T1.\"U_KLDNo\" AS \"KLD no\" ,T1.\"U_SOQty\" AS \"SO Qty\" ");
                stringBuilder.Append(" ,T1.\"U_NoOfUPS\" AS \"No Of UPS\" ,T1.\"U_JobQty\" AS \"Job Qty\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + CommonTables.ClientPORegisterRowTable + "\" T0 ");
                stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"" + CommonTables.GangupRowTable + "\" T1 ON T0.\"U_TargEn\" = T1.\"DocEntry\" AND T0.\"U_TargLine\" = T1.\"LineId\"   ");
                stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"" + CommonTables.GangupHeaderTable + "\" T2 ON T1.\"DocEntry\" =T2.\"DocEntry\" ");
                stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " ");
                stringBuilder.Append(" AND T0.\"LineId\" IN ( " + lineIds + ") ");

                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    return datatable;
                }
            }
            catch
            { }
            return null;
        }

        public ItemModel GetClientPOItemDetails(string itemcode)
        {
            ItemModel model = new ItemModel();
            try
            {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT DISTINCT T0.\"ItemCode\", T0.\"ItemName\", T2.\"Price\", TO_NVARCHAR(T2.\"FromDate\", 'DD-MM-YYYY') AS \"FromDate\"");
                stringBuilder.Append(" ,T0.\"U_KLDNo\" ,T0.\"U_NoOfUps\", TO_NVARCHAR(T2.\"ToDate\", 'DD-MM-YYYY') AS \"ToDate\" , T0.\"TreeType\" AS \"BOMType\"");
                stringBuilder.Append(" ,CASE WHEN T0.\"TreeType\"='S' THEN 'Sales'  ");
                stringBuilder.Append(" WHEN T0.\"TreeType\"='P' THEN 'Production'  ");
                stringBuilder.Append(" WHEN T0.\"TreeType\"='N' THEN 'Not BOM' END \"TreeType\"  ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OSPP T1 ON T0.\"ItemCode\" = T1.\"ItemCode\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".SPP1 T2 ON T0.\"ItemCode\" = T2.\"ItemCode\" ");
                stringBuilder.Append(" WHERE T0.\"validFor\" = 'Y' ");
                stringBuilder.Append(" AND T0.\"ItemCode\" = '" + itemcode + "' ");

                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    model = ConvertDatatableToList.ConvertToEntity<ItemModel>(datatable);
                }
            }
            catch
            {

            }
            return model;
        }

        public void UpdateMailSent(string docEntry,string lineIds)
        {
            string message = "";
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE T0 ");
            stringBuilder.Append(" SET T0.\"U_MailSent\" = 'Y' ");
            stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + CommonTables.ClientPORegisterRowTable + "\" T0 ");
            stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " ");
            stringBuilder.Append(" AND T0.\"LineId\" IN (" + lineIds + ") ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);

        }

    }
}