﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Reflection;
using System.Reflection.Emit;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Win32.SafeHandles;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sap.Data.Hana;
using WebDAL.Helper;
using WebDAL.Helpers;
using WebDAL.IRepository;
using WebDAL.Models;
using static WebDAL.Models.PPCDetailsModel;

namespace WebDAL.Repository
{
	public class CommonRepository : clsDataAccess, ICommonRepository
	{
		StringBuilder stringBuilder = new StringBuilder();
		public List<BusinessPartnerModel> GetAllBP(string userId, string cardType)
		{
			List<BusinessPartnerModel> _list = new List<BusinessPartnerModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"CardCode\",T0.\"CardName\",T0.\"SlpCode\" ");
				stringBuilder.Append(" ,T1.\"SlpName\" ,T0.\"Currency\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OCRD T0");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OSLP T1 ON T0.\"SlpCode\"=T1.\"SlpCode\" ");
				if (cardType == "C")
				{
					stringBuilder.Append(" WHERE \"CardType\" IN ('C','L') ");
				}
				else
				{
					stringBuilder.Append(" WHERE \"CardType\" IN ('S') ");
				}
				stringBuilder.Append(" ORDER BY \"CardName\"  ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<BusinessPartnerModel>(datatable);
					if (cardType == "C")
					{
						string isSuperUser = IsUserSuperUser(userId);
						if (isSuperUser != "Y")
						{
							List<SalesEmployeeModel> teamSalesEmployee = GetAllTeamSalesEmployee(userId);
							_list = _list.Where(x => teamSalesEmployee.Any(y => y.SlpCode == x.SlpCode)).ToList();
						}
					}
				}
			}
			catch
			{

			}
			return _list;
		}
		public List<BusinessPartnerModel> GetBP_SalesEmployeeWise(string slpcode, string cardType)
		{
			List<BusinessPartnerModel> _list = new List<BusinessPartnerModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"CardCode\",T0.\"CardName\",T0.\"SlpCode\" ");
				stringBuilder.Append(" ,T1.\"SlpName\" ,T0.\"Currency\",T0.\"U_BPTL\",T0.\"U_BPLTL\"   ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OCRD T0");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OSLP T1 ON T0.\"SlpCode\"=T1.\"SlpCode\" ");

				if (cardType == "C")
				{
					stringBuilder.Append(" WHERE \"CardType\" IN ('C','L') ");
				}
				else
				{
					stringBuilder.Append(" WHERE \"CardType\" IN ('S') ");
				}
				stringBuilder.Append(" AND T0.\"SlpCode\"  = '" + slpcode + "' ");
				stringBuilder.Append(" ORDER BY T0.\"CardName\"  ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<BusinessPartnerModel>(datatable);

				}
			}
			catch
			{

			}
			return _list;
		}
		public List<InventoryTransferModel> GetContractorData()
		{
			List<InventoryTransferModel> _list = new List<InventoryTransferModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT DISTINCT T0.\"U_CntrCd\",T0.\"U_CntrNm\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@CTRPRC1\" T0 ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<InventoryTransferModel>(datatable);

				}
			}
			catch
			{

			}
			return _list;
		}
		public List<BusinessPartnerModel> GetBP_VendorWise()
		{
			List<BusinessPartnerModel> _list = new List<BusinessPartnerModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"CardCode\",T0.\"CardName\",T0.\"Currency\",T0.\"SlpCode\",T0.\"GroupNum\" AS \"PaymentGroupCode\",MAX(T1.\"State\") \"State\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OCRD T0 ");
				stringBuilder.Append(" INNER JOIN  " + ConfigManager.GetSAPDatabase() + ".CRD1 T1 ON T0.\"CardCode\" = T1.\"CardCode\"");
				stringBuilder.Append(" WHERE \"CardType\" IN ('S') AND T0.\"validFor\"  = 'Y'");
				stringBuilder.Append(" GROUP BY T0.\"CardCode\",T0.\"CardName\",T0.\"Currency\",T0.\"SlpCode\",T0.\"GroupNum\"  ");
				stringBuilder.Append(" ORDER BY T0.\"CardName\"  ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<BusinessPartnerModel>(datatable);

				}
			}
			catch
			{

			}
			return _list;
		}
		public List<BusinessPartnerModel> GetAllBP_VendorWise()
		{
			List<BusinessPartnerModel> _list = new List<BusinessPartnerModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT DISTINCT T0.\"CardCode\",T0.\"CardName\",T1.\"Address\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OCRD T0 ");
				stringBuilder.Append(" INNER JOIN  " + ConfigManager.GetSAPDatabase() + ".CRD1 T1 ON T0.\"CardCode\" = T1.\"CardCode\"");
				stringBuilder.Append(" WHERE \"CardType\" IN ('S') AND T0.\"validFor\"  = 'Y'");
				stringBuilder.Append(" ORDER BY T0.\"CardName\"  ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<BusinessPartnerModel>(datatable);

				}
			}
			catch
			{

			}
			return _list;
		}

		public List<BusinessPartnerModel> GetAllContractorVandorWise()
		{
			List<BusinessPartnerModel> _list = new List<BusinessPartnerModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT DISTINCT T1.\"Code\",T1.\"Name\",T1.\"U_VndrCode\" ,T0.\"CardName\"");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OCRD T0 ");
				stringBuilder.Append(" INNER JOIN  " + ConfigManager.GetSAPDatabase() + ".\"@VCCONTR\" T1 ON T0.\"CardCode\" = T1.\"U_VndrCode\"");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<BusinessPartnerModel>(datatable);

				}
			}
			catch
			{

			}
			return _list;
		}
		public List<MachineGrpCodeModel> GetAllMachineGrpCode()
		{
			List<MachineGrpCodeModel> _list = new List<MachineGrpCodeModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"VisResCode\",T0.\"ResName\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".ORSC T0 ");
				stringBuilder.Append(" WHERE T0.\"ResType\"='M' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<MachineGrpCodeModel>(datatable);

				}
			}
			catch
			{

			}
			return _list;
		}
		public List<MachineGrpCodeModel> GetMachineCodeBasedGrpCode(string macmrp)
		{
			List<MachineGrpCodeModel> _list = new List<MachineGrpCodeModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"VisResCode\",T0.\"ResName\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".ORSC T0 ");
				stringBuilder.Append(" WHERE T0.\"ResType\"='M' AND T0.\"U_MACGRP\"= '" + macmrp + "'");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<MachineGrpCodeModel>(datatable);

				}
			}
			catch
			{

			}
			return _list;
		}
		public List<MachineGrpCodeModel> GetAllMachineCode()
		{
			List<MachineGrpCodeModel> _list = new List<MachineGrpCodeModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"VisResCode\",T0.\"ResName\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".ORSC T0 ");
				stringBuilder.Append(" WHERE T0.\"ResType\"='M' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<MachineGrpCodeModel>(datatable);

				}
			}
			catch
			{

			}
			return _list;
		}
		public List<CommonValueModel> GetAllAccount()
		{
			List<CommonValueModel> _list = new List<CommonValueModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"AcctCode\" AS \"ID\",T0.\"AcctName\" AS \"Name\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OACT T0 ");
				stringBuilder.Append(" WHERE T0.\"Postable\" = 'Y' ");
				//stringBuilder.Append(" ORDER BY T0.\"Name\"  ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);

				}
			}
			catch
			{

			}
			return _list;
		}
		public List<CommonValueModel> GetAllProjectData()
		{
			List<CommonValueModel> _list = new List<CommonValueModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"PrjCode\" AS \"ID\",T0.\"PrjName\" AS \"Name\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OPRJ T0");
				//stringBuilder.Append(" ORDER BY T0.\"Name\"  ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}
		public List<CopyDocumentModel> GetSQData(string cardcode)
		{
			List<CopyDocumentModel> _list = new List<CopyDocumentModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"DocNum\",T0.\"DocEntry\",T0.\"DocDate\" ");
				stringBuilder.Append("  ,T0.\"NumAtCard\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OQUT T0");
				stringBuilder.Append(" WHERE T0.\"CardCode\"  = '" + cardcode + "' ");
				stringBuilder.Append(" AND T0.\"DocStatus\"  = 'O' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<CopyDocumentModel>(datatable);

				}
			}
			catch
			{

			}
			return _list;
		}
		public List<CopyDocumentModel> GetSOData(string cardcode)
		{
			List<CopyDocumentModel> _list = new List<CopyDocumentModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"DocNum\",T0.\"DocEntry\",T0.\"DocDate\" ");
				stringBuilder.Append("  ,T0.\"NumAtCard\" ,TO_NVARCHAR(T0.\"TaxDate\", 'DD-MM-YYYY') AS \"TaxDate\" , TO_NVARCHAR(T0.\"DocDueDate\", 'DD-MM-YYYY') AS \"DocDueDate\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".ORDR T0");
				stringBuilder.Append(" WHERE T0.\"CardCode\"  = '" + cardcode + "' ");
				stringBuilder.Append(" AND T0.\"DocStatus\"  = 'O' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<CopyDocumentModel>(datatable);

				}
			}
			catch
			{

			}
			return _list;
		}
		public List<CopyDocumentModel> GetCopyFromITRData(string whscode)
		{
			List<CopyDocumentModel> _list = new List<CopyDocumentModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"DocEntry\" ,T0.\"DocNum\" ,T0.\"U_PPDocNum\",T0.\"U_GRPNAM\" ");
				stringBuilder.Append(" ,T0.\"U_JOBNAME\" , T0.\"DocStatus\",T0.\"DocDate\" ,T0.\"Filler\", T0.\"Comments\" , T0.\"U_ITEMNAME\"");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OWTQ T0");
				stringBuilder.Append(" WHERE T0.\"DocStatus\"  = 'O'  ");
				stringBuilder.Append(" AND T0.\"Filler\"  = '" + whscode + "'  ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<CopyDocumentModel>(datatable);

				}
			}
			catch
			{

			}
			return _list;
		}
		public List<DocumentRowsModel> GetSQLineData(string docEntry)
		{
			List<DocumentRowsModel> _list = new List<DocumentRowsModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"DocNum\",T0.\"DocEntry\",T0.\"DocDate\" ");
				stringBuilder.Append("  ,T0.\"NumAtCard\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OQUT T0");
				stringBuilder.Append(" WHERE T0.\"DocEntry\"  = '" + docEntry + "' ");
				stringBuilder.Append(" AND T0.\"DocStatus\"  = 'O' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<DocumentRowsModel>(datatable);

				}
			}
			catch
			{

			}
			return _list;
		}
		public List<AddressModel> GetBPAddresses(string cardcode, string adresType)
		{
			List<AddressModel> list = new List<AddressModel>();
			try
			{
				HanaParameter[] parameters = new HanaParameter[2];

				parameters[0] = new HanaParameter("@CardCode", System.Data.SqlDbType.VarChar);
				parameters[0].Value = cardcode;

				parameters[1] = new HanaParameter("@AdresType", System.Data.SqlDbType.VarChar);
				parameters[1].Value = adresType;

				stringBuilder = new StringBuilder();
				stringBuilder.Append("select \"Address\" AS \"ID\",\"Address\" from " + ConfigManager.GetSAPDatabase() + ".\"CRD1\" WHERE \"CardCode\"= '" + cardcode + "' AND \"AdresType\" = '" + adresType + "'  ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string messages))
				{
					list = ConvertDatatableToList.ConvertToList<AddressModel>(datatable);
					for (int i = 0; i < list.Count; i++)
					{
						AddressModel addressModel = GetBPAddressDetails(cardcode, adresType, list[i].ID);
						list[i].FullAddress = addressModel.FullAddress;
					}
				}
			}
			catch
			{

			}
			return list;
		}
		public DefaultAddressModel GetDefaultBPAddresses(string cardcode)
		{
			DefaultAddressModel model = new DefaultAddressModel();
			List<DefaultAddressModel> list = new List<DefaultAddressModel>();

			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("CardCode", System.Data.SqlDbType.VarChar);
				parameters[0].Value = cardcode;

				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT \"ShipToDef\",\"BillToDef\" FROM " + ConfigManager.GetSAPDatabase() + ".OCRD T0 WHERE \"CardCode\" = :CardCode ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					list = ConvertDatatableToList.ConvertToList<DefaultAddressModel>(datatable);
					if (list.Count > 0)
					{
						model = list[0];
					}
				}
			}
			catch
			{

			}
			return model;
		}
		public BusinessPartnerModel GetBPDetails(string cardcode)
		{
			BusinessPartnerModel model = new BusinessPartnerModel();
			List<BusinessPartnerModel> list = new List<BusinessPartnerModel>();

			try
			{
				SqlParameter[] parameters = new SqlParameter[1];

				parameters[0] = new SqlParameter("@CardCode", System.Data.SqlDbType.VarChar);
				parameters[0].Value = cardcode;

				stringBuilder = new StringBuilder();
				stringBuilder.Append("Web_Get_BP_Details");

				//using (DataTable datatable = FillDatatable_Params(stringBuilder.ToString(), CommandType.StoredProcedure, openConnection(), out string message, parameters))
				//{
				//    list = ConvertDatatableToList.ConvertTo<BusinessPartnerModel>(datatable);
				//    if (list.Count > 0)
				//    {
				//        model = list[0];
				//    }
				//}
			}
			catch
			{

			}
			return model;
		}
		public AddressModel GetBPAddressDetails(string cardcode, string adresType, string addressId)
		{
			AddressModel model = new AddressModel();
			try
			{
				if (!string.IsNullOrEmpty(addressId))
				{
					addressId = addressId.Replace("'", "");
				}
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT T0.*,T1.\"Name\" \"StateName\",T2.\"Name\"  AS \"CountryName\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".CRD1 T0  ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCST T1 ON T0.\"State\" = T1.\"Code\" AND T0.\"Country\" =T1.\"Country\"  ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCRY T2 ON T0.\"Country\" = T2.\"Code\" ");
				stringBuilder.Append(" WHERE T0.\"CardCode\" ='" + cardcode + "' AND Replace(T0.\"Address\",'''','') ='" + addressId + "'  AND T0.\"AdresType\"='" + adresType + "'  ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					model = ConvertDatatableToList.ConvertToEntity<AddressModel>(datatable);

					model.GSTIN = datatable.Rows[0]["GSTRegnNo"].ToString();
					StringBuilder fullAddress = new StringBuilder();
					//string address = datatable.Rows[0]["Address"].ToString();
					string address2 = datatable.Rows[0]["Address2"].ToString();
					string address3 = datatable.Rows[0]["Address3"].ToString();
					string block = datatable.Rows[0]["Block"].ToString();
					string street = datatable.Rows[0]["Street"].ToString();
					string city = datatable.Rows[0]["City"].ToString();
					string state = datatable.Rows[0]["StateName"].ToString();
					string zipcode = datatable.Rows[0]["ZipCode"].ToString();
					string country = datatable.Rows[0]["CountryName"].ToString();
					//if (address != string.Empty)
					//{
					//    fullAddress.Append(address + " ");
					//}
					if (address2 != string.Empty)
					{
						fullAddress.Append(address2 + " ");
					}
					if (address3 != string.Empty)
					{
						fullAddress.Append(address3 + " ");
					}
					if (block != string.Empty)
					{
						fullAddress.Append(block + " ");
					}
					if (street != string.Empty)
					{
						fullAddress.Append(street + " ");
					}
					if (city != string.Empty)
					{
						fullAddress.Append(city + " ");
					}
					if (zipcode != string.Empty)
					{
						fullAddress.Append("-" + zipcode + " ");
					}
					if (state != string.Empty)
					{
						fullAddress.Append(state + ", ");
					}
					if (country != string.Empty)
					{
						fullAddress.Append(country);
					}

					model.FullAddress = fullAddress.ToString();
					model.StateCode = datatable.Rows[0]["State"].ToString();
				}
			}
			catch
			{

			}
			return model;
		}
		public List<ItemModel> GetAllItem(string series, string cardcode)
		{
			List<ItemModel> _list = new List<ItemModel>();
			try
			{
				string seriesremark = GetSeriesRemark(series);
				string seriesname = GetSeriesName(series);

				stringBuilder = new StringBuilder();
				if (seriesremark.ToUpper().Contains("PROOFING") || seriesremark.ToUpper().Contains("INTERNAL"))
				{
					stringBuilder.Append(" SELECT DISTINCT T0.\"ItemCode\", T0.\"ItemName\", T1.\"ItmsGrpNam\",T0.\"SalUnitMsr\" AS  \"UOM\",T0.\"ChapterID\"  ");
					stringBuilder.Append(" ,T2.\"ChapterID\" AS \"ChapterName\" ,T0.\"U_KLDNo\" ");
					stringBuilder.Append(" ,CASE WHEN T0.\"TreeType\"='S' THEN 'Sales'  ");
					stringBuilder.Append("  WHEN T0.\"TreeType\"='P' THEN 'Production'  ");
					stringBuilder.Append("  WHEN T0.\"TreeType\"='N' THEN 'Not BOM' END \"TreeType\"  ");
					stringBuilder.Append(" ,CASE WHEN T0.\"ManBtchNum\"='Y' THEN 'B' WHEN T0.\"ManSerNum\"='Y' THEN 'S' ELSE 'N' END \"ManagedBy\"  ");
					stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
					stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OITB T1 ON T0.\"ItmsGrpCod\" = T1.\"ItmsGrpCod\" ");
					stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T2 ON T0.\"ChapterID\" = T2.\"AbsEntry\" ");
					stringBuilder.Append(" WHERE T0.\"validFor\" = 'Y'");
					stringBuilder.Append(" AND T0.\"U_A4SO\" = 'Yes'");
				}
				else
				{
					stringBuilder.Append(" SELECT DISTINCT T0.\"ItemCode\", T0.\"ItemName\", T1.\"ItmsGrpNam\",T0.\"SalUnitMsr\" AS  \"UOM\",T0.\"ChapterID\"  ");
					stringBuilder.Append(" ,T2.\"ChapterID\" AS \"ChapterName\"  ,T0.\"U_KLDNo\"");
					stringBuilder.Append(" ,CASE WHEN T0.\"TreeType\"='S' THEN 'Sales'  ");
					stringBuilder.Append("  WHEN T0.\"TreeType\"='P' THEN 'Production'  ");
					stringBuilder.Append("  WHEN T0.\"TreeType\"='N' THEN 'Not BOM' END \"TreeType\"  ");
					stringBuilder.Append(" ,CASE WHEN T0.\"ManBtchNum\"='Y' THEN 'B' WHEN T0.\"ManSerNum\"='Y' THEN 'S' ELSE 'N' END \"ManagedBy\"  ");
					stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
					stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OITB T1 ON T0.\"ItmsGrpCod\" = T1.\"ItmsGrpCod\" ");
					stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T2 ON T0.\"ChapterID\" = T2.\"AbsEntry\" ");
					stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OSPP T3 ON T0.\"ItemCode\" = T3.\"ItemCode\" AND T3.\"CardCode\" = '" + cardcode + "' ");
					stringBuilder.Append(" WHERE T0.\"validFor\" = 'Y'   ");//AND T1.\"ItmsGrpNam\" NOT LIKE '%RM%'
					stringBuilder.Append(" AND T0.\"TreeType\" IN ('N') ");
					stringBuilder.Append(" AND T0.\"U_A4SO\" = 'Yes'");
					if (seriesname.ToUpper().Contains("X"))
					{
						stringBuilder.Append(" AND UPPER(T0.\"U_FLEXO1\") = 'FLEXO YES' ");
					}
					else
					{
						stringBuilder.Append(" AND UPPER(T0.\"U_FLEXO1\") = 'FLEXO NO' ");
					}

					stringBuilder.Append(" UNION ALL ");

					stringBuilder.Append(" SELECT DISTINCT T0.\"ItemCode\", T0.\"ItemName\", T1.\"ItmsGrpNam\",T0.\"SalUnitMsr\" AS  \"UOM\",T0.\"ChapterID\"  ");
					stringBuilder.Append(" ,T2.\"ChapterID\" AS \"ChapterName\" ,T0.\"U_KLDNo\" ");
					stringBuilder.Append(" ,CASE WHEN T0.\"TreeType\"='S' THEN 'Sales'  ");
					stringBuilder.Append("  WHEN T0.\"TreeType\"='P' THEN 'Production'  ");
					stringBuilder.Append("  WHEN T0.\"TreeType\"='N' THEN 'Not BOM' END \"TreeType\"  ");
					stringBuilder.Append(" ,CASE WHEN T0.\"ManBtchNum\"='Y' THEN 'B' WHEN T0.\"ManSerNum\"='Y' THEN 'S' ELSE 'N' END \"ManagedBy\"  ");
					stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
					stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OITB T1 ON T0.\"ItmsGrpCod\" = T1.\"ItmsGrpCod\" ");
					stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T2 ON T0.\"ChapterID\" = T2.\"AbsEntry\" ");
					stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OSPP T3 ON T0.\"ItemCode\" = T3.\"ItemCode\" AND T3.\"CardCode\" = '" + cardcode + "' ");
					stringBuilder.Append(" WHERE T0.\"validFor\" = 'Y'  ");//AND T1.\"ItmsGrpNam\" NOT LIKE '%RM%' 
					stringBuilder.Append(" AND T0.\"TreeType\" IN ('S','P') ");
					stringBuilder.Append(" AND T0.\"U_A4SO\" = 'Yes'");
				}
				if (seriesname.ToUpper().Contains("X"))
				{
					stringBuilder.Append(" AND UPPER(T0.\"U_FLEXO1\") = 'FLEXO YES' ");
				}
				else
				{
					stringBuilder.Append(" AND UPPER(T0.\"U_FLEXO1\") = 'FLEXO NO' ");
				}
				//            if(seriesremark.ToUpper().Contains("INTERNAL"))
				//            {
				//	stringBuilder.Append(" AND T0.\"TreeType\" IN ('N') ");
				//}
				//if (seriesname == String.Empty)
				//{

				//}
				//else if (seriesname.ToUpper().Contains("X"))
				//{
				//    stringBuilder.Append(" AND UPPER(T0.\"U_FLEXO1\") = 'FLEXO YES' ");
				//}
				//else
				//{
				//    stringBuilder.Append(" AND UPPER(T0.\"U_FLEXO1\") = 'FLEXO NO' ");
				//}

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<ItemModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}


		public List<ItemModel> GetAllPurchaseItem()
		{
			List<ItemModel> _list = new List<ItemModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT DISTINCT T0.\"ItemCode\",T0.\"ItemName\",T0.\"ItmsGrpCod\",T1.\"ItmsGrpNam\",T0.\"InvntryUom\" as \"UOM\" ,T0.\"U_QChk\"  ");
				stringBuilder.Append(" ,T3.\"ChapterID\" AS \"ChapterName\",T0.\"BWeight1\" AS \"Weight\" ,to_decimal(T0.\"OnHand\",23,3) as \"OnHand\",T0.\"BuyUnitMsr\" ");
				//,T2.\"TaxCode\"
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OITB T1 ON T0.\"ItmsGrpCod\" = T1.\"ItmsGrpCod\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T3 ON T0.\"ChapterID\" = T3.\"AbsEntry\" ");
				stringBuilder.Append(" WHERE T0.\"PrchseItem\" = 'Y' AND T0.\"validFor\" = 'Y' AND T1.\"U_ItmBrand\"='RM'  ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<ItemModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}
		public List<TaxCodeModel> GetItemTaxCode(string itemcode, string state)
		{
			List<TaxCodeModel> _list = new List<TaxCodeModel>();
			string dateTime = DateTime.Now.Date.ToString("yyyyMMdd");

			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT  T4.\"Code\", T4.\"Name\", T4.\"Rate\"  ");
				//,T2.\"TaxCode\"
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".TCD2 T1 ON T0.\"ChapterID\" = T1.\"KeyFld_1_V\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".TCD3 T2 ON T1.\"AbsId\" = T2.\"Tcd2Id\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T3 ON T0.\"ChapterID\" = T3.\"AbsEntry\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OSTC T4 ON T2.\"TaxCode\" = T4.\"Code\" ");
				stringBuilder.Append(" WHERE T0.\"ItemCode\" = '" + itemcode + "'  ");
				stringBuilder.Append(" AND IFNULL(T2.\"EfctTo\",'2099-01-01') > '" + dateTime + "' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<TaxCodeModel>(datatable);
					if (state.ToUpper() == "MH")
					{
						_list = _list.Where(a => a.Code.Contains("CGST") || a.Code.Contains("CSGST")).ToList();
					}
					else
					{
						_list = _list.Where(a => a.Code.Contains("IGST")).ToList();
					}
				}
			}
			catch
			{

			}
			return _list;
		}
		public List<ItemModel> GetItemDetails(string series, string cardcode, string itemcode)
		{
			List<ItemModel> _list = new List<ItemModel>();
			try
			{
				string seriesremark = GetSeriesRemark(series);
				string seriesname = GetSeriesName(series);

				stringBuilder = new StringBuilder();
				if (seriesremark.ToUpper().Contains("PROOFING"))
				{
					stringBuilder.Append(" SELECT DISTINCT T0.\"ItemCode\", T0.\"ItemName\", T1.\"ItmsGrpNam\",T0.\"SalUnitMsr\" AS  \"UOM\",T0.\"ChapterID\"  ");
					stringBuilder.Append(" ,T2.\"ChapterID\" AS \"ChapterName\"  ");
					stringBuilder.Append(" ,CASE WHEN T0.\"TreeType\"='S' THEN 'Sales'  ");
					stringBuilder.Append("  WHEN T0.\"TreeType\"='P' THEN 'Production'  ");
					stringBuilder.Append("  WHEN T0.\"TreeType\"='N' THEN 'Not BOM' END \"TreeType\"  ");
					stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
					stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OITB T1 ON T0.\"ItmsGrpCod\" = T1.\"ItmsGrpCod\" ");
					stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T2 ON T0.\"ChapterID\" = T2.\"AbsEntry\" ");
					stringBuilder.Append(" WHERE T0.\"validFor\" = 'Y'  ");//AND T1.\"ItmsGrpNam\" NOT LIKE '%RM%' 
				}
				else
				{
					stringBuilder.Append(" SELECT DISTINCT T0.\"ItemCode\", T0.\"ItemName\", T1.\"ItmsGrpNam\",T0.\"SalUnitMsr\" AS  \"UOM\",T0.\"ChapterID\"  ");
					stringBuilder.Append(" ,T2.\"ChapterID\" AS \"ChapterName\"  ");
					stringBuilder.Append(" ,CASE WHEN T0.\"TreeType\"='S' THEN 'Sales'  ");
					stringBuilder.Append("  WHEN T0.\"TreeType\"='P' THEN 'Production'  ");
					stringBuilder.Append("  WHEN T0.\"TreeType\"='N' THEN 'Not BOM' END \"TreeType\"  ");
					stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
					stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OITB T1 ON T0.\"ItmsGrpCod\" = T1.\"ItmsGrpCod\" ");
					stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T2 ON T0.\"ChapterID\" = T2.\"AbsEntry\" ");
					stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OSPP T3 ON T0.\"ItemCode\" = T3.\"ItemCode\" AND T3.\"CardCode\" = '" + cardcode + "' ");
					stringBuilder.Append(" WHERE T0.\"validFor\" = 'Y' ");//AND T1.\"ItmsGrpNam\" NOT LIKE '%RM%'  
					stringBuilder.Append(" AND T0.\"TreeType\" IN ('N') AND T0.\"ItemCode\" = '" + itemcode + "' ");
					if (seriesname.ToUpper().Contains("X"))
					{
						stringBuilder.Append(" AND UPPER(T0.\"U_FLEXO1\") = 'FLEXO YES' ");
					}
					else
					{
						stringBuilder.Append(" AND UPPER(T0.\"U_FLEXO1\") = 'FLEXO NO' ");
					}

					stringBuilder.Append(" UNION ALL ");

					stringBuilder.Append(" SELECT DISTINCT T0.\"ItemCode\", T0.\"ItemName\", T1.\"ItmsGrpNam\",T0.\"SalUnitMsr\" AS  \"UOM\",T0.\"ChapterID\"  ");
					stringBuilder.Append(" ,T2.\"ChapterID\" AS \"ChapterName\"  ");
					stringBuilder.Append(" ,CASE WHEN T0.\"TreeType\"='S' THEN 'Sales'  ");
					stringBuilder.Append("  WHEN T0.\"TreeType\"='P' THEN 'Production'  ");
					stringBuilder.Append("  WHEN T0.\"TreeType\"='N' THEN 'Not BOM' END \"TreeType\"  ");
					stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
					stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OITB T1 ON T0.\"ItmsGrpCod\" = T1.\"ItmsGrpCod\" ");
					stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T2 ON T0.\"ChapterID\" = T2.\"AbsEntry\" ");
					stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OSPP T3 ON T0.\"ItemCode\" = T3.\"ItemCode\" AND T3.\"CardCode\" = '" + cardcode + "' ");
					stringBuilder.Append(" WHERE T0.\"validFor\" = 'Y'   ");//AND T1.\"ItmsGrpNam\" NOT LIKE '%RM%'
					stringBuilder.Append(" AND T0.\"TreeType\" IN ('S','P') AND T0.\"ItemCode\" = '" + itemcode + "' ");
				}
				if (seriesname.ToUpper().Contains("X"))
				{
					stringBuilder.Append(" AND UPPER(T0.\"U_FLEXO1\") = 'FLEXO YES' ");
				}
				else
				{
					stringBuilder.Append(" AND UPPER(T0.\"U_FLEXO1\") = 'FLEXO NO' ");
				}

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<ItemModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}
		public FlexoModel GetItem_FlexoDetails(string cardcode, string adddress, string itemcode)
		{
			FlexoModel model = new FlexoModel();
			try
			{
				//adddress = adddress.Replace(" ", string.Empty);
				//adddress = adddress.Replace(",", string.Empty).Trim();
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT Distinct t1.\"U_RollDrctn\" as \"RollDirection\",t1.\"U_Pckng\" as \"Packing\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@APAFUP\" T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"@APAFUP1\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
				stringBuilder.Append(" WHERE T1.\"U_IsActive\"='Active' AND ");
				stringBuilder.Append(" T0.\"U_CardCode\" = '" + cardcode + "' AND ");
				stringBuilder.Append(" T1.\"U_ItmCd\" = '" + itemcode + "' AND ");
				stringBuilder.Append(" T1.\"U_ShpCd\" = '" + adddress + "'  ");
				//stringBuilder.Append(" trim(replace(replace(t1.\"U_ShpAddr\",',',''),' ','')) = '" + adddress + "' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					model = ConvertDatatableToList.ConvertToEntity<FlexoModel>(datatable);
				}
			}
			catch
			{

			}
			return model;
		}
		public FlexoModel GetPriceofSheetDetails(string cardcode, string itemcode)
		{
			FlexoModel model = new FlexoModel();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT Distinct t1.\"U_RollDrctn\" as \"RollDirection\",t1.\"U_Pckng\" as \"Packing\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@APAFUP\" T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"@APAFUP1\" T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
				stringBuilder.Append(" WHERE T1.\"U_IsActive\"='Active' AND ");
				stringBuilder.Append(" T0.\"U_CardCode\" = '" + cardcode + "' AND ");
				//stringBuilder.Append(" T1.\"U_ItmCd\" = '" + itemcode + "' AND ");
				//stringBuilder.Append(" T1.\"U_ShpCd\" = '" + adddress + "'  ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					model = ConvertDatatableToList.ConvertToEntity<FlexoModel>(datatable);
				}
			}
			catch
			{

			}
			return model;
		}
		public ItemModel GetItemDetails_ItemCode(string itemcode)
		{
			ItemModel _list = new ItemModel();
			try
			{

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT DISTINCT T0.\"ItemCode\", T0.\"ItemName\", T1.\"ItmsGrpNam\",T0.\"SalUnitMsr\" AS  \"UOM\",T0.\"ChapterID\"  ");
				stringBuilder.Append(" ,T2.\"ChapterID\" AS \"ChapterName\"  ");
				stringBuilder.Append(" ,CASE WHEN T0.\"TreeType\"='S' THEN 'Sales'  ");
				stringBuilder.Append("  WHEN T0.\"TreeType\"='P' THEN 'Production'  ");
				stringBuilder.Append("  WHEN T0.\"TreeType\"='N' THEN 'Not BOM' END \"TreeType\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OITB T1 ON T0.\"ItmsGrpCod\" = T1.\"ItmsGrpCod\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T2 ON T0.\"ChapterID\" = T2.\"AbsEntry\" ");
				stringBuilder.Append(" WHERE T0.\"validFor\" = 'Y' AND \"ItemCode\" = '" + itemcode + "'   ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToEntity<ItemModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}
		public List<ItemModel> GetAllSQItem()
		{
			List<ItemModel> _list = new List<ItemModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT DISTINCT T0.\"ItemCode\", T0.\"ItemName\", T1.\"ItmsGrpNam\",T0.\"SalUnitMsr\" AS  \"UOM\",T0.\"ChapterID\"  ");
				stringBuilder.Append(" ,T2.\"ChapterID\" AS \"ChapterName\"  ");
				stringBuilder.Append(" ,CASE WHEN T0.\"TreeType\"='S' THEN 'Sales'  ");
				stringBuilder.Append("  WHEN T0.\"TreeType\"='P' THEN 'Production'  ");
				stringBuilder.Append("  WHEN T0.\"TreeType\"='N' THEN 'Not BOM' END \"TreeType\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OITB T1 ON T0.\"ItmsGrpCod\" = T1.\"ItmsGrpCod\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T2 ON T0.\"ChapterID\" = T2.\"AbsEntry\" ");
				stringBuilder.Append(" WHERE T0.\"validFor\" = 'Y'   ");//AND T1.\"ItmsGrpNam\" NOT LIKE '%RM%'
																		//stringBuilder.Append(" AND T1.\"ItmsGrpNam\" = 'RMS'  ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<ItemModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}
		public List<TaxCodeModel> GetAllTaxCode(string documentType, string address)
		{
			List<TaxCodeModel> list = new List<TaxCodeModel>();
			try
			{
				address = address == null ? string.Empty : address;
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT T0.\"Code\", T0.\"Name\", T0.\"Rate\" FROM " + ConfigManager.GetSAPDatabase() + ".OSTC T0 WHERE ");
				if (documentType == "S")
				{
					stringBuilder.Append(" T0.\"ValidForAR\" ='Y'");
				}
				else
				{
					stringBuilder.Append(" T0.\"ValidForAP\" ='Y'");
				}
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<TaxCodeModel>(datatable);
					//if (state.ToUpper() == "MH")
					//{
					//	list.RemoveAll(a => a.Name.ToUpper().Contains("IGST"));
					//}
					//else
					//{
					//	list.RemoveAll(a => a.Name.ToUpper().Contains("CGST") || a.Name.ToUpper().Contains("SGST"));
					//	if (state == string.Empty)
					//	{
					//		list.RemoveAll(a => a.Code != "IGST0");
					//	}
					//}
				}

			}
			catch
			{

			}
			return list;
		}
		public List<TaxCodeModel> GetAllPurchaseTaxCode(string cardcode, string address)
		{
			List<TaxCodeModel> list = new List<TaxCodeModel>();
			try
			{
				string message = "";
				string isIGST = "no";
				string country = "";
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT  T0.\"U_IGST\", T0.\"Country\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".CRD1 T0 ");
				stringBuilder.Append(" WHERE T0.\"CardCode\" = '" + cardcode + "' AND T0.\"AdresType\" = 'S'   ");
				stringBuilder.Append(" AND T0.\"Address\" = '" + address + "'   ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message))
				{
					if (datatable.Rows.Count > 0)
					{
						isIGST = datatable.Rows[0]["U_IGST"].ToString();
						country = datatable.Rows[0]["Country"].ToString();
					}
				}
				stringBuilder = new StringBuilder();

				stringBuilder.Append(" SELECT  T0.\"Code\", T0.\"Name\", T0.\"Rate\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OSTC T0 ");
				stringBuilder.Append(" WHERE T0.\"Lock\" ='N' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message))
				{
					list = ConvertDatatableToList.ConvertToList<TaxCodeModel>(datatable);
					if (country == "IN")
					{
						if (isIGST.ToLower() == "no")
						{
							list.RemoveAll(a => a.Name.ToUpper().Contains("IGST"));
						}
						else
						{
							list.RemoveAll(a => a.Name.ToUpper().Contains("CGST") || a.Name.ToUpper().Contains("SGST"));
						}
					}
					else
					{
						//list.RemoveAll(a => a.Name.ToUpper().Contains("CGST") || a.Name.ToUpper().Contains("SGST") || a.Name.ToUpper().Contains("IGST"));
						list = list.Where(a => a.Name.Contains("IGST") && a.Rate == 0).ToList();
					}
				}
			}
			catch
			{

			}
			return list;
		}
		public string GetAddressIGST(string cardcode, string address)
		{
			string isIGST = "no";
			try
			{
				string message = "";
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT  T0.\"U_IGST\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".CRD1 T0 ");
				stringBuilder.Append(" WHERE T0.\"CardCode\" = '" + cardcode + "' AND T0.\"AdresType\" = 'S'   ");
				stringBuilder.Append(" AND T0.\"Address\" = '" + address + "'   ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message))
				{
					if (datatable.Rows.Count > 0)
					{
						isIGST = datatable.Rows[0]["U_IGST"].ToString();
					}
				}
			}
			catch { }
			return isIGST;
		}
		public List<TaxCodeModel> GetAllTaxCodeItem(string cardcode, string address, string itemcode, string doctype)
		{
			List<TaxCodeModel> list = new List<TaxCodeModel>();
			string dateTime = DateTime.Now.Date.ToString("yyyyMMdd");
			try
			{
				string message = "";
				string isIGST = "no";
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT  T0.\"U_IGST\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".CRD1 T0 ");
				stringBuilder.Append(" WHERE T0.\"CardCode\" = '" + cardcode + "' AND T0.\"AdresType\" = 'S'   ");
				stringBuilder.Append(" AND T0.\"Address\" = '" + address + "'   ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message))
				{
					if (datatable.Rows.Count > 0)
					{
						isIGST = datatable.Rows[0]["U_IGST"].ToString();
					}
				}
				stringBuilder = new StringBuilder();

				if (doctype == "I")
				{
					stringBuilder.Append(" SELECT  T4.\"Code\", T4.\"Name\", T4.\"Rate\",T3.\"ChapterID\"  ");
					stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
					stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".TCD2 T1 ON T0.\"ChapterID\" = T1.\"KeyFld_1_V\" ");
					stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".TCD3 T2 ON T1.\"AbsId\" = T2.\"Tcd2Id\" ");
					stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T3 ON T0.\"ChapterID\" = T3.\"AbsEntry\" ");
					stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OSTC T4 ON T2.\"TaxCode\" = T4.\"Code\" ");
					stringBuilder.Append(" WHERE T0.\"ItemCode\" = '" + itemcode + "'  ");
					stringBuilder.Append(" AND IFNULL(T2.\"EfctTo\",'2099-01-01') > '" + dateTime + "' ");
				}
				else
				{
					stringBuilder.Append(" SELECT  T0.\"Code\", T0.\"Name\", T0.\"Rate\"  ");
					stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OSTC T0 ");
					stringBuilder.Append(" WHERE T0.\"Lock\" ='N' ");
				}
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message))
				{
					list = ConvertDatatableToList.ConvertToList<TaxCodeModel>(datatable);
					if (isIGST.ToLower() == "no")
					{
						list.RemoveAll(a => a.Name.ToUpper().Contains("IGST"));
					}
					else
					{
						list.RemoveAll(a => a.Name.ToUpper().Contains("CGST") || a.Name.ToUpper().Contains("SGST"));
					}
				}

			}
			catch
			{

			}
			return list;
		}
		public List<ExpenseModel> GetAllExpenses()
		{
			List<ExpenseModel> list = new List<ExpenseModel>();
			try
			{

				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT T0.\"ExpnsCode\", T0.\"ExpnsName\" FROM " + ConfigManager.GetSAPDatabase() + ".OEXD T0 ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<ExpenseModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public string GetUserType(string userId)
		{
			string userType = string.Empty;
			try
			{
				SqlParameter[] parameters = new SqlParameter[1];

				parameters[0] = new SqlParameter("@UserId", System.Data.SqlDbType.VarChar);
				parameters[0].Value = userId;

				stringBuilder = new StringBuilder();
				//using (DataTable datatable = FillDatatable_Params(ConfigManager.GetSAPDatabase() + "Web_Get_UserType", CommandType.StoredProcedure, openConnection(), out string message, parameters))
				//{
				//    if (datatable.Rows.Count > 0)
				//    {
				//        userType = datatable.Rows[0][0].ToString();
				//    }
				//}
			}
			catch
			{

			}
			return userType;
		}
		public string GetTaxRate(string taxcode)
		{
			string rate = string.Empty;
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("@TaxCode", System.Data.SqlDbType.VarChar);
				parameters[0].Value = taxcode;

				stringBuilder = new StringBuilder();
				stringBuilder.Append("select \"Rate\" from " + ConfigManager.GetSAPDatabase() + ".\"OSTC\" WHERE \"Code\"= :TaxCode ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string messages, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						rate = datatable.Rows[0][0].ToString();
					}
				}
			}
			catch
			{

			}
			return rate;
		}
		public string GetEmpId(string emailAddress)
		{
			string empId = string.Empty;
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("EmailAddress", System.Data.SqlDbType.VarChar);
				parameters[0].Value = emailAddress;
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT \"empID\" FROM " + ConfigManager.GetSAPDatabase() + ".OHEM WHERE \"email\" = :EmailAddress");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						empId = datatable.Rows[0][0].ToString();
					}
				}
			}
			catch
			{

			}
			return empId;
		}
		public string GetUserId(string emailAddress)
		{
			string empId = string.Empty;
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("EmailAddress", System.Data.SqlDbType.VarChar);
				parameters[0].Value = emailAddress;
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT \"userId\" FROM " + ConfigManager.GetSAPDatabase() + ".OHEM WHERE \"email\" = '" + emailAddress + "'");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						empId = datatable.Rows[0][0].ToString();
					}
				}
			}
			catch
			{

			}
			return empId;
		}
		public string GetUserName(string userId)
		{
			string empId = string.Empty;
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("UserId", System.Data.SqlDbType.VarChar);
				parameters[0].Value = userId;
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT \"USER_CODE\" FROM " + ConfigManager.GetSAPDatabase() + ".OUSR WHERE \"USERID\" = :UserId");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						empId = datatable.Rows[0][0].ToString();
					}
				}
			}
			catch
			{

			}
			return empId;
		}
		public string GetSlpCodeFromEmailAddress(string emailAddress)
		{
			string empId = string.Empty;
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("EmailAddress", System.Data.SqlDbType.VarChar);
				parameters[0].Value = emailAddress;
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT \"salesPrson\" FROM " + ConfigManager.GetSAPDatabase() + ".OHEM WHERE \"email\" = :EmailAddress");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						empId = datatable.Rows[0][0].ToString();
					}
				}
			}
			catch
			{

			}
			return empId;
		}
		public string GetSlpNameFromEmailAddress(string emailAddress)
		{
			string empId = string.Empty;
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("EmailAddress", System.Data.SqlDbType.VarChar);
				parameters[0].Value = emailAddress;
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT T1.\"SlpName\" FROM " + ConfigManager.GetSAPDatabase() + ".OHEM T0 ");
				stringBuilder.Append("INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OSLP T1 ON T0.\"salesPrson\" = T1.\"SlpCode\" ");
				stringBuilder.Append(" WHERE T0.\"email\" = :EmailAddress");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						empId = datatable.Rows[0][0].ToString();
					}
				}
			}
			catch
			{

			}
			return empId;
		}
		public string GetSlpNameFromSlpCode(string slpcode)
		{
			string empId = string.Empty;
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("SlpCode", System.Data.SqlDbType.VarChar);
				parameters[0].Value = slpcode;
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"SlpName\" FROM " + ConfigManager.GetSAPDatabase() + ".OSLP T0 ");
				stringBuilder.Append(" WHERE T0.\"SlpCode\" = :SlpCode");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						empId = datatable.Rows[0][0].ToString();
					}
				}
			}
			catch
			{

			}
			return empId;
		}
		public string GetSalesEmployeeEmailAddress(string slpcode)
		{
			string empId = string.Empty;
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("slpcode", System.Data.SqlDbType.VarChar);
				parameters[0].Value = slpcode;
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT \"email\" FROM " + ConfigManager.GetSAPDatabase() + ".OHEM WHERE \"salesPrson\" = :slpcode");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						empId = datatable.Rows[0][0].ToString();
					}
				}
			}
			catch
			{

			}
			return empId;
		}
		public List<string> GetECREmailDepartmentWise(string assignto)
		{
			List<string> list = new List<string>();
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("dept", System.Data.SqlDbType.VarChar);
				parameters[0].Value = assignto;
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT \"email\" FROM " + ConfigManager.GetSAPDatabase() + ".OHEM WHERE \"dept\" = :dept AND \"email\" IS NOT NULL ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						for (int i = 0; i < datatable.Rows.Count; i++)
						{
							list.Add(datatable.Rows[i][0].ToString());
						}
					}
				}
			}
			catch
			{

			}
			return list;
		}
		public string GetEmailDepartmentWise(string salesempcode)
		{
			string value = "";
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT \"email\" FROM " + ConfigManager.GetSAPDatabase() + ".OHEM WHERE \"salesPrson\" = '" + salesempcode + "' AND \"email\" IS NOT NULL ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						for (int i = 0; i < datatable.Rows.Count; i++)
						{
							value = datatable.Rows[0][0].ToString();
						}
					}
				}
			}
			catch
			{

			}
			return value;
		}
		public string GetAppDataValue(AppData app)
		{
			string value = "";
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT \"U_Value\" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_APPDATA\" WHERE \"Code\"='" + app.ToString() + "'");
				DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message);
				if (datatable.Rows.Count > 0)
				{
					value = datatable.Rows[0][0].ToString();
				}
			}
			catch
			{

			}
			return value;
		}
		public List<BranchModel> GetAllBranch()
		{
			List<BranchModel> list = new List<BranchModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT T0.\"BPLId\", T0.\"BPLName\" FROM " + ConfigManager.GetSAPDatabase() + ".OBPL T0 ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<BranchModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<CommonValueModel> GetAllShiftMaster()
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT T0.\"U_ShftCode\" AS \"ID\", T0.\"U_ShftName\" AS \"Name\" FROM " + ConfigManager.GetSAPDatabase() + ".\"@VCSFT\" T0 ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public string GetEmployeePosition(string emailAddress)
		{
			string empId = string.Empty;
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("EmailAddress", System.Data.SqlDbType.VarChar);
				parameters[0].Value = emailAddress;
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT \"name\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OHEM T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OHPS T1 ON T0.\"position\" = T1.\"posID\" ");
				stringBuilder.Append(" WHERE T0.\"email\" = :EmailAddress");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						empId = datatable.Rows[0][0].ToString();
					}
				}
			}
			catch
			{

			}
			return empId;
		}
		public List<WarehouseModel> GetAllWarehouse()
		{
			List<WarehouseModel> list = new List<WarehouseModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"WhsCode\",T0.\"WhsCode\" ||' ('|| T0.\"WhsName\" || ')' AS \"WhsName\"");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OWHS T0 ");
				stringBuilder.Append(" WHERE \"Inactive\" ='N' ");
				stringBuilder.Append(" Order By T0.\"WhsName\" ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<WarehouseModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<WarehouseModel> GetWarehouse_BranchWise(string bplId)
		{
			List<WarehouseModel> list = new List<WarehouseModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"WhsCode\", T0.\"WhsName\" FROM " + ConfigManager.GetSAPDatabase() + ".OWHS T0 WHERE \"BPLid\" = '" + bplId + "' ");
				stringBuilder.Append(" AND T0.\"WhsName\" LIKE 'F%' ");
				stringBuilder.Append(" ORDER BY T0.\"WhsCode\"  ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<WarehouseModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<WarehouseModel> GetAllWarehouse_BranchWise(string bplId)
		{
			List<WarehouseModel> list = new List<WarehouseModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"WhsCode\", T0.\"WhsName\" FROM " + ConfigManager.GetSAPDatabase() + ".OWHS T0 WHERE \"BPLid\" = '" + bplId + "' ");
				stringBuilder.Append(" ORDER BY T0.\"WhsCode\"  ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<WarehouseModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public string GetBranchDefaultWarehouse(string bplId)
		{
			string value = "";
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"DflWhs\" FROM " + ConfigManager.GetSAPDatabase() + ".OBPL T0 WHERE \"BPLId\" = '" + bplId + "' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					value = datatable.Rows[0][0].ToString();
				}
			}
			catch
			{

			}
			return value;
		}
		public List<SeriesModel> GetSeries_BranchWise(string bplId, string objCode)
		{
			List<SeriesModel> list = new List<SeriesModel>();
			try
			{
				string currentDate = DateTime.Now.ToString("yyyyMMdd");
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"Series\", T0.\"SeriesName\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"NNM1\" T0  ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"OFPR\" T1 ON T0.\"Indicator\" = T1.\"Indicator\"  ");
				stringBuilder.Append(" WHERE \"ObjectCode\"='" + objCode + "'  AND  \"Locked\" = 'N'  ");
				stringBuilder.Append(" AND \"F_RefDate\" <='" + currentDate + "'  AND \"T_RefDate\" >= '" + currentDate + "'  ");
				if (!string.IsNullOrEmpty(bplId))
				{
					stringBuilder.Append(" AND T0.\"BPLId\" = '" + bplId + "'  ");
				}
				stringBuilder.Append(" GROUP BY T0.\"Series\", T0.\"SeriesName\"  ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<SeriesModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<SeriesModel> GetSeries_WarehouseWise(string whscode, string objCode)
		{
			List<SeriesModel> list = new List<SeriesModel>();
			try
			{
				AddressModel location = GetWarehouseLocation(whscode);
				//string location = whscode.Substring(0, 1);
				string currentDate = DateTime.Now.ToString("yyyyMMdd");
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"Series\", T0.\"SeriesName\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"NNM1\" T0  ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"OFPR\" T1 ON T0.\"Indicator\" = T1.\"Indicator\"  ");
				stringBuilder.Append(" WHERE \"ObjectCode\"='" + objCode + "'  AND  \"Locked\" = 'N'  ");
				stringBuilder.Append(" AND \"F_RefDate\" <='" + currentDate + "'  AND \"T_RefDate\" >= '" + currentDate + "'  ");
				if (!string.IsNullOrEmpty(location.Name))
				{
					string locationName = location.Name;
					if (locationName.ToLower().Contains("taloja"))
					{
						locationName = "J";
					}
					else
					{
						locationName = locationName.Substring(0, 1);
					}
					stringBuilder.Append(" AND T0.\"SeriesName\" LIKE '" + locationName + "%'  ");
				}
				stringBuilder.Append(" GROUP BY T0.\"Series\", T0.\"SeriesName\"  ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<SeriesModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public string GetWarehouseDefaultBinCode(string whscode)
		{
			string value = "";
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T1.\"BinCode\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OWHS T0  ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OBIN T1 ON T0.\"DftBinAbs\" = T1.\"AbsEntry\"  ");
				stringBuilder.Append(" WHERE T0.\"WhsCode\" = '" + whscode + "' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						value = datatable.Rows[0][0].ToString();
					}
				}
			}
			catch
			{

			}
			return value;
		}
		public List<SeriesModel> GetObjectTypeWiseSeries(string objCode)
		{
			List<SeriesModel> list = new List<SeriesModel>();
			try
			{
				string currentDate = DateTime.Now.ToString("yyyyMMdd");
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"Series\", T0.\"SeriesName\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"NNM1\" T0  ");
				stringBuilder.Append(" WHERE T0.\"ObjectCode\"  = '" + objCode + "' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<SeriesModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public string GetNextDocNum(string series)
		{
			string docnum = "";
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"NextNumber\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"NNM1\" T0  ");
				stringBuilder.Append(" WHERE T0.\"Series\" = '" + series + "'");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					docnum = datatable.Rows[0]["NextNumber"].ToString();
				}
			}
			catch
			{
			}
			return docnum;
		}
		public string GetWebSeriesNextNumber(string objectType, string type)
		{
			string docnum = "";
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"U_NextNo\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_SERIES1\" T0  ");
				stringBuilder.Append(" WHERE T0.\"Code\" = '" + objectType + "'");
				if (!string.IsNullOrEmpty(type))
				{
					stringBuilder.Append(" AND T0.\"U_Type\" = '" + type + "'");
				}
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					docnum = datatable.Rows[0]["U_NextNo"].ToString();
				}
			}
			catch
			{
			}
			return docnum;
		}
		public List<ShippingTypeModel> GetAllShippingType()
		{
			List<ShippingTypeModel> list = new List<ShippingTypeModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT T0.\"TrnspCode\", T0.\"TrnspName\" FROM " + ConfigManager.GetSAPDatabase() + ".OSHP T0 ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<ShippingTypeModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<EmployeeModel> GetAllEmployee()
		{
			List<EmployeeModel> list = new List<EmployeeModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT T0.\"empID\",T0.\"Code\",CONCAT(CONCAT(T0.\"firstName\",' '),T0.\"lastName\") AS \"Name\" ");
				stringBuilder.Append("FROM " + ConfigManager.GetSAPDatabase() + ".OHEM T0 ");


				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<EmployeeModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<CommonValueModel> GetAllPrepressEmployee()
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT T0.\"empID\" AS \"ID\",CONCAT(CONCAT(T0.\"firstName\",' '),T0.\"lastName\") AS \"Name\" ");
				stringBuilder.Append("FROM " + ConfigManager.GetSAPDatabase() + ".OHEM T0 ");
				stringBuilder.Append("WHERE T0.\"dept\" = '21'");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{

					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<SalesEmployeeModel> GetAllSalesEmployee()
		{
			List<SalesEmployeeModel> list = new List<SalesEmployeeModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT T0.\"SlpCode\",T0.\"SlpName\" FROM " + ConfigManager.GetSAPDatabase() + ".OSLP T0 ");
				stringBuilder.Append("WHERE T0.\"Active\"='Y' ");
				stringBuilder.Append("ORDER BY T0.\"SlpName\" ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))

				{
					list = ConvertDatatableToList.ConvertToList<SalesEmployeeModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<SalesEmployeeModel> GetAllTeamSalesEmployee(string userId)
		{
			List<SalesEmployeeModel> list = new List<SalesEmployeeModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT  T3.\"SlpCode\" , T3.\"SlpName\", T0.\"empID\", T0.\"firstName\", T0.\"lastName\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OHEM T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".HTM1 T1 ON T0.\"empID\" = T1.\"empID\" ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OHTM T2 ON T1.\"teamID\" = T2.\"teamID\" ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OSLP T3 ON T2.\"name\" = T3.\"SlpName\" ");
				stringBuilder.Append(" WHERE UPPER(T0.\"email\") = '" + userId.ToUpper() + "' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<SalesEmployeeModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public string GetSeriesName(string series)
		{
			string seriesName = string.Empty;
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"SeriesName\"   ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"NNM1\" T0  ");
				stringBuilder.Append(" WHERE \"Series\"='" + series + "' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						seriesName = datatable.Rows[0][0].ToString();
					}
				}
			}
			catch
			{

			}
			return seriesName;
		}
		public string GetSeriesRemark(string series)
		{
			string seriesName = string.Empty;
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"Remark\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"NNM1\" T0  ");
				stringBuilder.Append(" WHERE \"Series\"='" + series + "' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						seriesName = datatable.Rows[0][0].ToString();
					}
				}
			}
			catch
			{

			}
			return seriesName;
		}
		public string GetPrice(string cardcode, string itemcode, string docdate, double? quantity)
		{
			string price = string.Empty;
			//DateTime dtDocDate = Convert.ToDateTime(docdate);
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"Price\",T0.\"LINENUM\"   ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".SPP1 T0 ");
				stringBuilder.Append(" WHERE T0.\"CardCode\" = '" + cardcode + "' AND T0.\"ItemCode\" = '" + itemcode + "' ");
				stringBuilder.Append(" AND '" + docdate + "' >= \"FromDate\" AND '" + docdate + "' <= IFNULL(\"ToDate\",'2099-01-01') ");
				//stringBuilder.Append(" AND '" + dtDocDate.ToString("yyyyMMdd") + "' >= \"FromDate\" AND '" + dtDocDate.ToString("yyyyMMdd") + "' <= IFNULL(\"ToDate\",'2099-01-01') ");

				//SELECT "Price"  FROM "TEST_050422"."SPP1"  T1 WHERE T1."CardCode" = 'C00569' AND  T1."ItemCode"  = '13100000011640001F2006428'
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						price = datatable.Rows[0]["Price"].ToString();
						string spp1LineNo = datatable.Rows[0]["LINENUM"].ToString();

						#region Volume Discount
						stringBuilder = new StringBuilder();
						stringBuilder.Append(" SELECT MAX(T0.\"Amount\") AS \"Amount\"   ");
						stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".SPP2 T0 ");
						stringBuilder.Append(" WHERE T0.\"CardCode\" = '" + cardcode + "' AND T0.\"ItemCode\" = '" + itemcode + "' ");
						stringBuilder.Append(" AND  T0.\"SPP1LNum\" = '" + spp1LineNo + "' ");
						stringBuilder.Append(" AND  T0.\"Amount\" <= '" + quantity + "' ");
						using (DataTable datatable1 = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message))
						{
							if (datatable1.Rows.Count > 0)
							{
								string qty = datatable1.Rows[0]["Amount"].ToString();

								stringBuilder = new StringBuilder();
								stringBuilder.Append(" SELECT T0.\"Price\"   ");
								stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".SPP2 T0 ");
								stringBuilder.Append(" WHERE T0.\"CardCode\" = '" + cardcode + "' AND T0.\"ItemCode\" = '" + itemcode + "' ");
								stringBuilder.Append(" AND  T0.\"SPP1LNum\" = '" + spp1LineNo + "' ");
								stringBuilder.Append(" AND  T0.\"Amount\" = '" + qty + "' ");
								DataTable datatable2 = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
								if (datatable2.Rows.Count > 0)
								{
									price = datatable2.Rows[0]["Price"].ToString();
								}
							}
						}
						#endregion
					}
				}
			}
			catch
			{

			}
			return price;
		}
		public string GetItemwiseKLDNo(string itemcode)
		{
			string kldno = string.Empty;

			stringBuilder = new StringBuilder();
			stringBuilder.Append(" SELECT  T0.\"U_KLDNo\" ");
			stringBuilder.Append(" FROM  " + ConfigManager.GetSAPDatabase() + ".\"@WEB_KLD\" T0 ");
			stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OITM T1 ON T0.\"U_ItemCode\"=T1.\"ItemCode\" ");
			stringBuilder.Append(" WHERE T1.\"ItemCode\" = '" + itemcode + "'");
			DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message);
			if (datatable.Rows.Count > 0)
			{
				kldno = datatable.Rows[0]["U_KLDNo"].ToString();
			}
			return kldno;

		}
		public string GetDocRate(string currency, string docdate)
		{
			string price = string.Empty;
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"Rate\"   ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".ORTT T0 ");
				stringBuilder.Append(" WHERE T0.\"Currency\" = '" + currency + "' AND T0.\"RateDate\" = '" + docdate + "' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						price = datatable.Rows[0][0].ToString();
					}
				}
			}
			catch
			{

			}
			return price;
		}
		public string GetBPPaymentTerm(string cardcode)
		{
			string groupNum = string.Empty;
			try
			{

				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("CardCode", System.Data.SqlDbType.VarChar);
				parameters[0].Value = cardcode;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"GroupNum\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OCTG T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OPOR T1 ON T0.\"GroupNum\" = T1.\"GroupNum\" ");
				stringBuilder.Append(" WHERE T1.\"CardCode\" = :CardCode ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						groupNum = datatable.Rows[0]["GroupNum"].ToString();
					}
				}
			}
			catch
			{

			}
			return groupNum;
		}
		public string GetItemBOMType(string itemcode)
		{
			string value = string.Empty;
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"TreeType\"   ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
				stringBuilder.Append(" WHERE T0.\"ItemCode\" = '" + itemcode + "' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						value = datatable.Rows[0][0].ToString();
					}
				}
			}
			catch
			{

			}
			return value;
		}
		public string IsUserSuperUser(string userId)
		{
			string superUser = string.Empty;
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"SUPERUSER\"   ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OUSR T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OHEM T1 ON T0.\"USERID\" = T1.\"userId\" ");
				stringBuilder.Append(" WHERE T1.\"email\" = '" + userId + "' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						superUser = datatable.Rows[0][0].ToString();
					}
				}
			}
			catch
			{

			}
			return superUser;
		}

		public string GetDepartmentName(string departmentId)
		{
			string value = string.Empty;
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"Name\"   ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OUDP T0 ");
				stringBuilder.Append(" WHERE T0.\"Code\" = '" + departmentId + "' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						value = datatable.Rows[0][0].ToString();
					}
				}
			}
			catch
			{

			}
			return value;
		}
		public List<BranchModel> GetBranchOfUser(string slpcode)
		{
			List<BranchModel> list = new List<BranchModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T4.\"BPLId\" , T4.\"BPLName\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OHEM T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OUSR T1 ON T0.\"userId\" = T1.\"USERID\" ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".USR6 T3 ON T1.\"USER_CODE\" = T3.\"UserCode\" ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OBPL T4 ON T3.\"BPLId\" = T4.\"BPLId\" ");
				stringBuilder.Append("WHERE T0.\"salesPrson\" = '" + slpcode + "' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<BranchModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<HSNModel> GetAllHSN()
		{
			List<HSNModel> list = new List<HSNModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"AbsEntry\" AS \"Chapter\",T0.\"ChapterID\",T0.\"Dscription\" AS \"Name\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OCHP T0 ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<HSNModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<HSNModel> GetAllSAC()
		{
			List<HSNModel> list = new List<HSNModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"AbsEntry\" AS \"Chapter\",T0.\"ServCode\",T0.\"ServName\" AS \"Name\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OSAC T0 ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<HSNModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<CurrencyModel> GetAllCurrency()
		{
			List<CurrencyModel> list = new List<CurrencyModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"CurrCode\",T0.\"CurrName\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OCRN T0 ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<CurrencyModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<PaymentTermsModel> GetAllPaymentTermsList()
		{
			List<PaymentTermsModel> list = new List<PaymentTermsModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"GroupNum\",T0.\"PymntGroup\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OCTG T0 ");
				stringBuilder.Append(" ORDER BY T0.\"PymntGroup\"");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<PaymentTermsModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<BOMModel> GetBOMComponents(string itemcode)
		{
			List<BOMModel> _list = new List<BOMModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T1.\"ItemCode\",T1.\"ItemName\",T0.\"Quantity\" \"Comp_Quantity\" ");
				stringBuilder.Append(" ,T2.\"Qauntity\" \"Header_Quantity\" , T1.\"U_KLDNo\"");
				stringBuilder.Append(" ,T0.\"Quantity\" / T2.\"Qauntity\"  AS \"BOMRatio\",T0.\"Warehouse\" AS \"Comp_WhsCode\" ");
				stringBuilder.Append(" ,T1.\"ChapterID\" as \"HSNEntry\",T3.\"ChapterID\" AS \"HSNName\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".ITT1 T0");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OITM T1 ON T0.\"Code\" = T1.\"ItemCode\" ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OITT T2 ON T0.\"Father\" = T2.\"Code\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T3 ON T1.\"ChapterID\" = T3.\"AbsEntry\" ");

				stringBuilder.Append(" WHERE \"Father\" = '" + itemcode + "' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<BOMModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}
		public string GetAttachmentPath()
		{
			string attachmentFolder = "";
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"AttachPath\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OADP T0");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						attachmentFolder = datatable.Rows[0][0].ToString();
					}
				}
			}
			catch
			{

			}
			return attachmentFolder;
		}
		public List<CommonValueModel> GetAllItemGroup()
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT T0.\"ItmsGrpCod\" AS \"ID\", T0.\"ItmsGrpNam\" AS \"Name\" FROM " + ConfigManager.GetSAPDatabase() + ".OITB T0 ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<CommonValueModel> GetAllGangupItemGroup()
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT T0.\"ItmsGrpCod\" AS \"ID\", T0.\"ItmsGrpNam\" AS \"Name\" FROM " + ConfigManager.GetSAPDatabase() + ".OITB T0 ");
				stringBuilder.Append(" WHERE T0.\"U_ItmBrand\" =  'FG'");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<CommonValueModel> GetAllItemBrand()
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT T0.\"Code\" AS \"ID\", T0.\"Name\" FROM " + ConfigManager.GetSAPDatabase() + ".\"@VCBRNDMST\"  T0 ");
				stringBuilder.Append("ORDER BY T0.\"Name\"");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<CommonValueModel> GetAllUOMGroup()
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT T0.\"UgpEntry\" AS \"ID\", T0.\"UgpCode\" AS \"Name\" FROM " + ConfigManager.GetSAPDatabase() + ".OUGP  T0 ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<BusinessPartnerModel> GetAllPOCustomer()
		{
			List<BusinessPartnerModel> list = new List<BusinessPartnerModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT T0.\"CardCode\", T0.\"CardName\" , T0.\"Currency\" FROM " + ConfigManager.GetSAPDatabase() + ".OCRD T0 WHERE \"CardType\" = 'C' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<BusinessPartnerModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<CommonValueModel> GetAllCustomer()
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT T0.\"CardCode\" AS \"ID\", T0.\"CardName\" AS \"Name\"  FROM " + ConfigManager.GetSAPDatabase() + ".OCRD T0 WHERE \"CardType\" = 'C' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<ItemModel> GetAllKLDItem()
		{
			List<ItemModel> list = new List<ItemModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT T0.\"ItemCode\" , T0.\"ItemName\"   FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<ItemModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<CommonValueModel> GetAllKLDNo()
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT T0.\"U_KLDNo\" As \"ID\" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_KLD\" T0 ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<CommonValueModel> GetAllItemBrand(string itemgroupcode)
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" Select \"Code\" AS \"ID\",\"U_Desc\" AS \"Name\" From " + ConfigManager.GetSAPDatabase() + ".\"@VCBRNDMST\"  ");
				//stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OITB T1 ON T1.\"ItmsGrpCod\" = '" + itemgroupcode + "'  Where \"U_Btype\" = T1.\"U_ItmBrand\"; ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public string GetItemBrand(string itemgroupcode)
		{
			string value = "";
			CommonValueModel commonValueModel = new CommonValueModel();

			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" Select T0.\"U_ItmBrand\" AS \"ID\",T0.\"ItmsGrpNam\" AS \"Name\" From " + ConfigManager.GetSAPDatabase() + ".\"OITB\" T0  ");
				stringBuilder.Append(" WHERE T0.\"ItmsGrpCod\" = '" + itemgroupcode + "' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					commonValueModel = ConvertDatatableToList.ConvertToEntity<CommonValueModel>(datatable);
					if (commonValueModel.Name.ToLower() == "rms" || commonValueModel.Name.ToLower() == "packing material internal" || commonValueModel.Name.ToLower() == "other packing mat")
					{
						value = "BOTH";
					}
					else
					{
						value = commonValueModel.ID;
					}
				}
			}
			catch
			{

			}
			return value;
		}
		public List<CommonValueModel> GetAllUOMCode(string ugpEntry)
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];
				parameters[0] = new HanaParameter("UgpEntry", System.Data.SqlDbType.VarChar);
				parameters[0].Value = ugpEntry;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T2.\"UomCode\" AS \"ID\", T2.\"UomName\" AS \"Name\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OUGP T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".UGP1 T1 ON T0.\"UgpEntry\" = T1.\"UgpEntry\"  ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OUOM T2 ON T1.\"UomEntry\" = T2.\"UomEntry\"  ");
				stringBuilder.Append(" WHERE T0.\"UgpEntry\" = :UgpEntry ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
					if (ugpEntry == "3")
					{
						list = list.Where(a => a.ID == "Thd").ToList();
					}
				}
			}
			catch
			{

			}
			return list;
		}
		public List<CommonValueModel> GetAllPricingUnit(string ugpEntry)
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];
				parameters[0] = new HanaParameter("UgpEntry", System.Data.SqlDbType.VarChar);
				parameters[0].Value = ugpEntry;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T2.\"UomEntry\" AS \"ID\", T2.\"UomName\" AS \"Name\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OUGP T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".UGP1 T1 ON T0.\"UgpEntry\" = T1.\"UgpEntry\"  ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OUOM T2 ON T1.\"UomEntry\" = T2.\"UomEntry\"  ");
				stringBuilder.Append(" WHERE T0.\"UgpEntry\" = :UgpEntry ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<CommonValueModel> GetAllVariant()
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append("Select \"Code\" AS \"ID\",\"U_Desc\" AS \"Name\" From " + ConfigManager.GetSAPDatabase() + ".\"@VCVRMST\" ");
				stringBuilder.Append("where \"Name\" not like '%METRONODAZOLE%' ORDER BY Cast(\"Code\" as int)  ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<CommonValueModel> GetAllProfileCode()
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append("Select \"Code\" AS \"ID\", \"Name\" From " + ConfigManager.GetSAPDatabase() + ".\"@VCPRMST\" ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<CommonValueModel> GetAllSizeCode()
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append("Select \"Code\" AS \"ID\", \"Name\" From " + ConfigManager.GetSAPDatabase() + ".\"@VCSZMST\" ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<CommonValueModel> GetAllMill()
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append("Select \"U_MCODE\" AS \"ID\", \"Name\" From " + ConfigManager.GetSAPDatabase() + ".\"@VCMILMST\" ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<CommonValueModel> GetAllTypeOfSubstrate()
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append("Select \"Name\" AS \"ID\", \"Name\" From " + ConfigManager.GetSAPDatabase() + ".\"@VCSUBST\" ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<CommonValueModel> GetAllVarnish()
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append("Select \"Name\" AS \"ID\", \"Name\" From " + ConfigManager.GetSAPDatabase() + ".\"@VCVARNISH\" ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<CommonValueModel> GetAllUOMMaster()
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT T0.\"UomCode\" AS \"ID\", T0.\"UomName\" AS \"Name\" FROM " + ConfigManager.GetSAPDatabase() + ".OUOM  T0 WHERE T0.\"UomName\"!='Manual' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public string GetUOMAbsEntry(string uomcode)
		{
			string value = "";
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT T0.\"UomEntry\" FROM " + ConfigManager.GetSAPDatabase() + ".OUOM T0 WHERE T0.\"UomCode\" ='" + uomcode + "' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						value = datatable.Rows[0][0].ToString();
					}
				}
			}
			catch
			{

			}
			return value;
		}
		public string GetItemBinQuantity(string itemcode, string whscode)
		{
			string value = "0";
			stringBuilder = new StringBuilder();
			stringBuilder.Append(" SELECT  T0.\"ItemCode\",T1.\"WhsCode\", T1.\"BinCode\",   T0.\"OnHandQty\" ");
			stringBuilder.Append(" FROM  " + ConfigManager.GetSAPDatabase() + ".\"OIBQ\" T0      ");
			stringBuilder.Append(" INNER  JOIN " + ConfigManager.GetSAPDatabase() + ".\"OBIN\" T1  ON  T0.\"BinAbs\" = T1.\"AbsEntry\"  AND  T0.\"OnHandQty\" <> 0  ");
			stringBuilder.Append(" WHERE  T0.\"ItemCode\" = '" + itemcode + "'  AND T1.\"WhsCode\"='" + whscode + "' AND T1.\"SL1Code\"='APP BIN'  ");
			DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message);
			if (datatable.Rows.Count > 0)
			{
				value = datatable.Rows[0]["OnHandQty"].ToString();
			}
			return value;

		}
		public List<InventoryTransferModel> GetWhsBinQuantity(string whscode)
		{
			List<InventoryTransferModel> _list = new List<InventoryTransferModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT  T0.\"BinCode\" ");
				stringBuilder.Append(" FROM  " + ConfigManager.GetSAPDatabase() + ".\"OBIN\" T0      ");
				stringBuilder.Append(" WHERE T0.\"WhsCode\"='" + whscode + "' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<InventoryTransferModel>(datatable);

				}
			}
			catch
			{

			}
			return _list;
		}
		public InventoryTransferModel GetWhsBinLocation(string whscode)
		{
			InventoryTransferModel model = new InventoryTransferModel();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT  T0.\"BinCode\" ");
				stringBuilder.Append(" FROM  " + ConfigManager.GetSAPDatabase() + ".\"OBIN\" T0      ");
				stringBuilder.Append(" WHERE T0.\"WhsCode\"='" + whscode + "' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					model = ConvertDatatableToList.ConvertToEntity<InventoryTransferModel>(datatable);
				}
			}
			catch
			{

			}
			return model;
		}
		public string GetDraftNo(string docEntry)
		{
			string value = "";
			stringBuilder = new StringBuilder();
			stringBuilder.Append(" SELECT  T0.\"DocNum\"");
			stringBuilder.Append(" FROM  " + ConfigManager.GetSAPDatabase() + ".\"ODRF\" T0      ");
			stringBuilder.Append(" WHERE  T0.\"DocEntry\" = '" + docEntry + "'  ");
			DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message);
			if (datatable.Rows.Count > 0)
			{
				value = datatable.Rows[0][0].ToString();
			}
			return value;

		}
		private string GetBrandAutoNo()
		{
			string value = "";
			stringBuilder = new StringBuilder();
			stringBuilder.Append(" Select cast(max((TO_NUMBER(T0.\"Code\")))+1 as nvarchar(50))  ");
			stringBuilder.Append(" FROM  " + ConfigManager.GetSAPDatabase() + ".\"@VCBRNDMST\" T0      ");
			stringBuilder.Append(" WHERE T0.\"Code\" != '*'");
			DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message);
			if (datatable.Rows.Count > 0)
			{
				value = datatable.Rows[0][0].ToString();
			}
			return value;
		}
		private string GetVariantAutoNo()
		{
			string value = "";
			stringBuilder = new StringBuilder();
			//stringBuilder.Append(" Select cast(max((TO_NUMBER(T0.\"Code\")))+1 as nvarchar(50))  from " + ConfigManager.GetSAPDatabase() + ".\"@VCVRMST\" T0 ");
			//stringBuilder.Append("	where t0.\"Name\" not like '%METRONODAZOLE%' ");
			stringBuilder.Append("	 Select TOP 1 T0.\"Code\" from " + ConfigManager.GetSAPDatabase() + ".\"@VCVRMST\" T0 order by Cast(T0.\"DocEntry\" as int) desc ");
			DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message);
			if (datatable.Rows.Count > 0)
			{
				value = Convert.ToString(double.Parse(datatable.Rows[0][0].ToString()) + 1);
			}
			return value;
		}
		private string GetSizeAutoNo()
		{
			string value = "";
			stringBuilder = new StringBuilder();
			stringBuilder.Append(" Select cast(max((TO_NUMBER(T0.\"Code\")))+1 as nvarchar(50))  from " + ConfigManager.GetSAPDatabase() + ".\"@VCSZMST\" T0 ");
			DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message);
			if (datatable.Rows.Count > 0)
			{
				value = datatable.Rows[0][0].ToString();
			}
			return value;
		}
		public ResponseModel RemoveDraft(string docEntry)
		{
			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				rc.endPoint = ConfigManager.GetServiceLayerURL() + "Drafts" + "(" + docEntry + ")";
				rc.B1SESSION = res;
				rc.httpMethod = httpVerb.DELETE;
				string message = "";
				bool result = rc.deleteRequest(out message);
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during process: " + jsonMessage;
				}
				rc.LogOut();
			}
			return responseModel;
		}
		public void UpdateUserSign(string addOrUpdate, string tableName, string primaryColumnName, string docEntry, string userId)
		{
			string query = "";
			try
			{
				if (string.IsNullOrEmpty(userId))
				{
					return;
				}
				HanaParameter[] parameters = new HanaParameter[2];
				int iParameter = 0;
				parameters[iParameter] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
				parameters[iParameter].Value = docEntry;
				iParameter++;

				parameters[iParameter] = new HanaParameter("UserId", System.Data.SqlDbType.VarChar);
				parameters[iParameter].Value = userId;
				iParameter++;
				if (addOrUpdate.ToLower() == "add")
				{
					query = "UPDATE " + ConfigManager.GetSAPDatabase() + ".\"" + tableName + "\" SET \"UserSign\"= :UserId WHERE \"" + primaryColumnName + "\" = :DocEntry ";
				}
				else
				{
					query = "UPDATE " + ConfigManager.GetSAPDatabase() + ".\"" + tableName + "\" SET \"UserSign2\"= :UserId WHERE \"" + primaryColumnName + "\" = :DocEntry ";
				}
				FillDataTable(query, CommandType.Text, out string message, parameters);
			}
			catch
			{

			}
		}
		public ResponseModel AddBrand(BrandModel model)
		{
			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				string brandAutoCode = GetBrandAutoNo();
				BrandModel _objServiceLayer = new BrandModel();
				_objServiceLayer.Code = brandAutoCode;
				_objServiceLayer.U_Code = brandAutoCode;

				_objServiceLayer.Name = model.U_Desc;
				_objServiceLayer.U_Desc = model.U_Desc;
				_objServiceLayer.U_Btype = model.U_Btype;

				string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
				{
					NullValueHandling = NullValueHandling.Ignore,
				});

				var temp = JsonConvert.DeserializeObject<JObject>(main);
				rc.endPoint = ConfigManager.GetServiceLayerURL() + "Brand Master";
				rc.patchJSON = main;
				rc.B1SESSION = res;
				string message = "";
				bool result = rc.postRequest(out message);
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during process: " + jsonMessage;
				}
				rc.LogOut();
			}
			else
			{
				responseModel.ResponseText = "Service layer login failed";
			}
			return responseModel;
		}
		public ResponseModel AddVariant(VariantModel model)
		{
			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				VariantModel _objServiceLayer = new VariantModel();
				string code = GetVariantAutoNo();
				model.U_Code = code;

				_objServiceLayer.Code = model.U_Code;
				_objServiceLayer.U_Code = model.U_Code;

				_objServiceLayer.Name = model.U_Desc;
				_objServiceLayer.U_Desc = model.U_Desc;

				string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
				{
					NullValueHandling = NullValueHandling.Ignore,
				});


				rc.endPoint = ConfigManager.GetServiceLayerURL() + "VariantMst";
				rc.patchJSON = main;
				rc.B1SESSION = res;
				string message = "";
				bool result = rc.postRequest(out message);
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during process: " + jsonMessage;
				}
				rc.LogOut();
			}
			else
			{
				responseModel.ResponseText = "Service layer login failed";
			}
			return responseModel;
		}
		public ResponseModel AddProfile(VariantModel model)
		{
			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				VariantModel _objServiceLayer = new VariantModel();
				_objServiceLayer.Code = model.U_Code;
				_objServiceLayer.Name = model.U_Desc;
				_objServiceLayer.U_Code = model.U_Code;
				_objServiceLayer.U_Desc = model.U_Desc;

				string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
				{
					NullValueHandling = NullValueHandling.Ignore,
				});


				var temp = JsonConvert.DeserializeObject<JObject>(main);
				rc.endPoint = ConfigManager.GetServiceLayerURL() + "Profile Master";
				rc.patchJSON = main;
				rc.B1SESSION = res;
				string message = "";
				bool result = rc.postRequest(out message);
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during process: " + jsonMessage;
				}
				rc.LogOut();
			}
			else
			{
				responseModel.ResponseText = "Service layer login failed";
			}
			return responseModel;
		}
		public ResponseModel AddSize(VariantModel model)
		{
			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				string code = GetSizeAutoNo();
				model.U_Code = code;
				VariantModel _objServiceLayer = new VariantModel();
				_objServiceLayer.Code = model.U_Code;
				_objServiceLayer.Name = model.U_Desc;
				_objServiceLayer.U_Code = model.U_Code;
				_objServiceLayer.U_Desc = model.U_Desc;

				string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
				{
					NullValueHandling = NullValueHandling.Ignore,
				});


				var temp = JsonConvert.DeserializeObject<JObject>(main);
				rc.endPoint = ConfigManager.GetServiceLayerURL() + "Size Master";
				rc.patchJSON = main;
				rc.B1SESSION = res;
				string message = "";
				bool result = rc.postRequest(out message);
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during process: " + jsonMessage;
				}
				rc.LogOut();
			}
			else
			{
				responseModel.ResponseText = "Service layer login failed";
			}
			return responseModel;
		}
		public ResponseModel AddTypeOfSubstrate(VariantModel model)
		{
			ResponseModel responseModel = new ResponseModel();
			stringBuilder = new StringBuilder();
			stringBuilder.Append(" SELECT MAX(Cast(\"Code\" AS INT)) + 1 FROM " + ConfigManager.GetSAPDatabase() + ".\"@VCSUBST\" ");
			DataTable dt = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message);
			string code = dt.Rows[0][0].ToString();

			stringBuilder = new StringBuilder();
			stringBuilder.Append(" INSERT INTO " + ConfigManager.GetSAPDatabase() + ".\"@VCSUBST\"(\"Code\",\"Name\") ");
			stringBuilder.Append(" VALUES('" + code + "','" + model.U_Desc + "') ");
			FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
			if (message == string.Empty)
			{
				responseModel.ResponseText = "Operation completed successfully";
			}
			else
			{
				responseModel.ResponseText = "Error occured during process: " + message;
			}

			return responseModel;
		}
		public ResponseModel AddVarnish(VariantModel model)
		{
			ResponseModel responseModel = new ResponseModel();
			stringBuilder = new StringBuilder();
			stringBuilder.Append(" SELECT MAX(Cast(\"Code\" AS INT)) + 1 FROM   " + ConfigManager.GetSAPDatabase() + ".\"@VCVARNISH\" ");
			DataTable dt = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message);
			string code = dt.Rows[0][0].ToString();
			stringBuilder = new StringBuilder();
			stringBuilder.Append(" INSERT INTO  " + ConfigManager.GetSAPDatabase() + ".\"@VCVARNISH\"(\"Code\",\"Name\") ");
			stringBuilder.Append(" VALUES('" + code + "','" + model.U_Desc + "') ");
			FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
			if (message == string.Empty)
			{
				responseModel.ResponseText = "Operation completed successfully";
			}
			else
			{
				responseModel.ResponseText = "Error occured during process: " + message;
			}

			return responseModel;
		}
		public HSNModel GetHSNDetails(string itemcode)
		{
			HSNModel model = new HSNModel();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T1.\"AbsEntry\" AS \"Chapter\",T1.\"ChapterID\",T1.\"Dscription\" AS \"Name\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T1 ON T0.\"ChapterID\" = T1.\"AbsEntry\" ");
				stringBuilder.Append(" WHERE T0.\"ItemCode\" = '" + itemcode + "' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					model = ConvertDatatableToList.ConvertToEntity<HSNModel>(datatable);
				}
			}
			catch
			{

			}
			return model;
		}
		public string GetRole(string emailId)
		{
			string role = "";
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("UserId", System.Data.SqlDbType.VarChar);
				parameters[0].Value = emailId.ToUpper();
				StringBuilder stringBuilder = new StringBuilder();

				stringBuilder.Append(" SELECT T1.\"role\" AS \"Role\" FROM " + ConfigManager.GetSAPDatabase() + ".OHEM T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".HTM1 T1 ON T0.\"empID\" = T1.\"empID\" ");
				stringBuilder.Append(" WHERE UPPER(T0.\"email\") =:UserId ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						role = datatable.Rows[0]["Role"].ToString();
					}
				}
			}
			catch
			{

			}
			return role;
		}
		public bool IsUserLeader(string emailId)
		{
			bool isLeader = false;
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("UserId", System.Data.SqlDbType.VarChar);
				parameters[0].Value = emailId.ToUpper();
				StringBuilder stringBuilder = new StringBuilder();

				stringBuilder.Append(" SELECT T1.\"role\" AS \"Role\" FROM " + ConfigManager.GetSAPDatabase() + ".OHEM T0 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".HTM1 T1 ON T0.\"empID\" = T1.\"empID\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OUSR T2 ON T0.\"userId\" = T2.\"USERID\" ");
				stringBuilder.Append(" WHERE UPPER(T0.\"email\") =:UserId AND (T1.\"role\" = 'L' OR T2.\"SUPERUSER\" = 'Y') ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						isLeader = true;
					}
				}
			}
			catch
			{

			}
			return isLeader;
		}

		public List<CommonValueModel> GetLeaderSalesEmployee()
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T2.\"SlpCode\" AS \"ID\",T2.\"SlpName\" AS \"Name\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OHEM T0 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".HTM1 T1 ON T0.\"empID\" = T1.\"empID\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OSLP T2 ON T0.\"salesPrson\" = T2.\"SlpCode\" ");
				stringBuilder.Append(" WHERE T1.\"role\" = 'L' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<CommonValueModel> GetAllPriceList()
		{

			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"ListNum\" AS \"ID\" , T0.\"ListName\" AS \"Name\" FROM " + ConfigManager.GetSAPDatabase() + ".OPLN T0 ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<ItemModel> GetAllItemList()
		{
			List<ItemModel> list = new List<ItemModel>();
			try
			{
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"ItemCode\", T0.\"ItemName\" ,T0.\"SalUnitMsr\" AS  \"UOM\" , T0.\"SalPackMsr\" AS \"UOMName\"");
				stringBuilder.Append(" ,CASE WHEN T0.\"TreeType\"='S' THEN 'Sales' ");
				stringBuilder.Append("  WHEN T0.\"TreeType\"='P' THEN 'Production' ");
				stringBuilder.Append("  WHEN T0.\"TreeType\"='N' THEN 'Not BOM' END \"TreeType\", T0.\"OnHand\"");
				stringBuilder.Append(" ,CASE WHEN T0.\"ManBtchNum\"='Y' THEN 'B' WHEN T0.\"ManSerNum\"='Y' THEN 'S' ELSE 'N' END \"ManagedBy\"  ");
				stringBuilder.Append(" ,T0.\"ChapterID\", T1.\"ItmsGrpNam\"  ");
				stringBuilder.Append(" ,T2.\"ChapterID\" AS \"ChapterName\" ,T0.\"U_KLDNo\" ");
				stringBuilder.Append(" ,T0.\"TreeType\" as \"BOMType\" ");

				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OITB T1 ON T0.\"ItmsGrpCod\" = T1.\"ItmsGrpCod\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T2 ON T0.\"ChapterID\" = T2.\"AbsEntry\" ");
				stringBuilder.Append(" WHERE T0.\"validFor\" = 'Y'   ");//AND T1.\"ItmsGrpNam\" NOT LIKE '%RM%'

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<ItemModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}

		//public List<ItemModel> GetAllItem()
		//{
		//    List<ItemModel> list = new List<ItemModel>();
		//    try
		//    {
		//        stringBuilder.Append(" SELECT DISTINCT T0.\"ItemCode\", T0.\"ItemName\"  ");
		//        stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
		//        stringBuilder.Append(" WHERE T0.\"validFor\" = 'Y'   ");
		//        using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
		//        {
		//            list = ConvertDatatableToList.ConvertToList<ItemModel>(datatable);
		//        }
		//    }
		//    catch
		//    {

		//    }
		//    return list;
		//}

		public List<ItemModel> GetClientPOItemList(string docdate)
		{
			List<ItemModel> list = new List<ItemModel>();
			try
			{
				string fromdate = DateTime.Now.ToString("yyyyMMdd");
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT DISTINCT T0.\"ItemCode\", T0.\"ItemName\", T2.\"Price\", TO_NVARCHAR(T2.\"FromDate\", 'DD-MM-YYYY') AS \"FromDate\"");
				stringBuilder.Append(" ,T0.\"U_KLDNo\" ,T0.\"U_NoOfUps\", TO_NVARCHAR(T2.\"ToDate\", 'DD-MM-YYYY') AS \"ToDate\" , T0.\"TreeType\" AS \"BOMType\"");
				stringBuilder.Append(" ,CASE WHEN T0.\"TreeType\"='S' THEN 'Sales'  ");
				stringBuilder.Append(" WHEN T0.\"TreeType\"='P' THEN 'Production'  ");
				stringBuilder.Append(" WHEN T0.\"TreeType\"='N' THEN 'Not BOM' END \"TreeType\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OSPP T1 ON T0.\"ItemCode\" = T1.\"ItemCode\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".SPP1 T2 ON T0.\"ItemCode\" = T2.\"ItemCode\" ");
				stringBuilder.Append(" WHERE T0.\"validFor\" = 'Y' ");
				//stringBuilder.Append(" '" + docdate + "' >= \"FromDate\" AND '" + docdate + "' <= IFNULL(\"ToDate\",'2099-01-01') ");
				// stringBuilder.Append(" AND T0.\"validFor\" = 'Y' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<ItemModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<ItemModel> GetClientPORefItemList(string cardcode)
		{
			List<ItemModel> list = new List<ItemModel>();
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];
				parameters[0] = new HanaParameter("CardCode", System.Data.SqlDbType.VarChar);
				parameters[0].Value = cardcode;

				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T2.\"ItemCode\", T0.\"ItemName\", T2.\"Price\", TO_NVARCHAR(T2.\"FromDate\", 'DD-MM-YYYY') AS \"FromDate\"");
				stringBuilder.Append(" ,T0.\"U_KLDNo\" , TO_NVARCHAR(T2.\"ToDate\", 'DD-MM-YYYY') AS \"ToDate\"");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OSPP T1 ON T0.\"ItemCode\" = T1.\"ItemCode\" ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".SPP1 T2 ON T1.\"ItemCode\" = T2.\"ItemCode\" ");
				stringBuilder.Append(" WHERE T2.\"CardCode\" = :CardCode ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					list = ConvertDatatableToList.ConvertToList<ItemModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}

		public List<ItemModel> GetNoofUpsList(string KLDNo)
		{
			List<ItemModel> list = new List<ItemModel>();
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];
				parameters[0] = new HanaParameter("KLDNo", System.Data.SqlDbType.VarChar);
				parameters[0].Value = KLDNo;

				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"U_NoOfUps\",T0.\"U_PunchNo\",T3.\"U_KLDNo\"");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PUNCH\" T0 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PUNCH1\" T2 ON T2.\"U_BaseCode\"=T0.\"Code\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"@WEB_KLD\" T3 ON T3.\"U_KLDNo\"=T2.\"U_KLDNo\"");
				stringBuilder.Append(" WHERE T3.\"U_KLDNo\" = '" + KLDNo + "' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					list = ConvertDatatableToList.ConvertToList<ItemModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<ItemModel> GetItemsBasedOnItemGroup(string itemgroup)
		{
			List<ItemModel> list = new List<ItemModel>();
			try
			{
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"ItemCode\", T0.\"ItemName\" ");
				stringBuilder.Append(" ,CASE WHEN T0.\"TreeType\"='S' THEN 'Sales'  ");
				stringBuilder.Append("  WHEN T0.\"TreeType\"='P' THEN 'Production'  ");
				stringBuilder.Append("  WHEN T0.\"TreeType\"='N' THEN 'Not BOM' END \"TreeType\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
				stringBuilder.Append(" WHERE T0.\"ItmsGrpCod\"=" + itemgroup + " ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<ItemModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<SoModel> GetAllSOList(string cardcode)
		{
			List<SoModel> list = new List<SoModel>();
			try
			{
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT  Cast(T0.\"DocEntry\" as varchar(100)) || '_'|| Cast(T1.\"LineNum\" as varchar(100)) AS \"UniqueID\", T0.\"CardCode\", T0.\"DocEntry\", T0.\"DocNum\",T0.\"DocDate\",T1.\"LineNum\",T1.\"Quantity\",T1.\"ItemCode\",T1.\"Dscription\",T0.\"DocStatus\"");
				//stringBuilder.Append("  , TO_NVARCHAR(T0.\"DocDate\", 'DD/MM/YYYY')  AS\"DocDate\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".ORDR T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".RDR1 T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
				stringBuilder.Append(" WHERE T0.\"DocStatus\" = 'O' ");
				stringBuilder.Append(" AND T0.\"CardCode\" = '" + cardcode + "' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<SoModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public SoModel GetSOSelectedData(string soUniqueID)
		{
			SoModel model = new SoModel();
			try
			{
				string[] values = soUniqueID.Split('_');
				string docEntry = values[0];
				string lineNum = values[1];
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"DocEntry\", T0.\"DocNum\",T0.\"DocDate\",T1.\"LineNum\",T1.\"Quantity\",T1.\"ItemCode\",T1.\"Dscription\",T0.\"DocStatus\"");
				//stringBuilder.Append("  , TO_NVARCHAR(T0.\"DocDate\", 'DD/MM/YYYY')  AS\"DocDate\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".ORDR T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".RDR1 T1 ON T0.\"DocEntry\" = T1.\"DocEntry\" ");
				stringBuilder.Append(" WHERE   ");
				stringBuilder.Append(" T0.\"DocEntry\" = '" + docEntry + "' ");
				stringBuilder.Append(" AND T1.\"LineNum\" = '" + lineNum + "' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					model = ConvertDatatableToList.ConvertToEntity<SoModel>(datatable);
				}
			}
			catch
			{

			}
			return model;
		}
		public ItemMasterModel GetItemSelectedData(string itemcode)
		{
			ItemMasterModel model = new ItemMasterModel();
			try
			{
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"ItemCode\", T0.\"ItemName\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
				stringBuilder.Append(" WHERE   ");
				stringBuilder.Append(" T0.\"ItemCode\" = '" + itemcode + "' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					model = ConvertDatatableToList.ConvertToEntity<ItemMasterModel>(datatable);
				}
			}
			catch
			{

			}
			return model;
		}
		public List<RouteModel> GetAllRouteStagesList()
		{
			List<RouteModel> list = new List<RouteModel>();
			try
			{
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"Code\", T0.\"Desc\" ,T0.\"U_Type\"");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".ORST T0 ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<RouteModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<CommonValueModel> GetAllWarehouseList()
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"WhsCode\" AS \"ID\" , T0.\"WhsName\" AS \"Name\" FROM " + ConfigManager.GetSAPDatabase() + ".OWHS T0 ");
				stringBuilder.Append(" WHERE T0.\"Inactive\" = 'N' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return list;

		}
		public List<BusinessPartnerModel> GetCardCodeList()
		{
			List<BusinessPartnerModel> list = new List<BusinessPartnerModel>();
			try
			{
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"CardCode\",T0.\"CardName\",T0.\"SlpCode\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OCRD T0");
				stringBuilder.Append(" WHERE \"CardType\" = 'C' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<BusinessPartnerModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<ItemModel> GetAllInvoiceList(string cardcode)
		{
			List<ItemModel> list = new List<ItemModel>();
			try
			{
				DateTime docdate = DateTime.Today.AddMonths(-6);
				string dtdocdate = docdate.ToString("yyyyMMdd");
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("CardCode", System.Data.SqlDbType.VarChar);
				parameters[0].Value = cardcode;

				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"DocNum\", TO_VARCHAR(T0.\"DocDate\", 'DD-MM-YYYY') \"DocDate\" , T1.\"ItemCode\" ");
				stringBuilder.Append(" ,T3.\"ItmsGrpNam\", T1.\"Dscription\", to_decimal(T1.\"Quantity\",23,3) as \"Quantity\", T1.\"LineTotal\",T1.\"LineTotal\" + T1.\"VatSum\" as \"VatSum\"");
				stringBuilder.Append(" ,CASE WHEN \"DocStatus\" = 'O' THEN 'Open' ");
				stringBuilder.Append("  WHEN \"DocStatus\" = 'C' AND \"CANCELED\" = 'Y' THEN 'Cancelled' ELSE 'Closed' END AS \"DocStatus\"");
				stringBuilder.Append(" ,to_decimal(T1.\"PriceBefDi\",23,3) as \"PriceBefDi\", T1.\"LineNum\" ,to_decimal(T4.\"Rate\",23,3) as \"Rate\" ,T0.\"BPLName\" ,T0.\"BPLId\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OINV T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".INV1 T1 ON T0.\"DocEntry\" = T1.\"DocEntry\"");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OITM T2 ON T2.\"ItemCode\" = T1.\"ItemCode\"");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OITB T3 ON T3.\"ItmsGrpCod\" = T2.\"ItmsGrpCod\"");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OSTC T4 ON T1.\"TaxCode\" = T4.\"Code\"");
				stringBuilder.Append(" WHERE T0.\"CardCode\" = :CardCode ");
				stringBuilder.Append(" AND T0.\"DocDate\" >= '" + dtdocdate + "' ");
				stringBuilder.Append(" AND T0.\"DocType\" = 'I' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					list = ConvertDatatableToList.ConvertToList<ItemModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<CommonValueModel> GetPlaceOfSupply()
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT  T0.\"Name\",T0.\"Code\" AS \"ID\", T0.\"Country\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OCST  T0  ");
				stringBuilder.Append(" WHERE T0.\"Country\" ='IN' ");
				stringBuilder.Append(" ORDER BY T0.\"Name\"  ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<CommonValueModel> GetLocationList()
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT  T0.\"Code\" AS \"ID\", T0.\"Location\" AS \"Name\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OLCT  T0  ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}

			return list;
		}
		public AddressModel GetWarehouseLocation(string whscode)
		{
			AddressModel model = new AddressModel();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT   T0.\"Location\",T1.\"Location\" AS \"Name\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OWHS  T0  ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OLCT  T1 ON T0.\"Location\" = T1.\"Code\"  ");
				stringBuilder.Append(" WHERE T0.\"WhsCode\"='" + whscode + "' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					string location = datatable.Rows[0]["Location"].ToString();
					model.Code = location;
					model.Name = datatable.Rows[0]["Name"].ToString();
					model.FullAddress = GetLocationAddress(location);
				}
			}
			catch
			{

			}
			return model;
		}
		public string GetLocationAddress(string location)
		{
			StringBuilder fullAddress = new StringBuilder();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT  T1.* ");
				stringBuilder.Append(" ,T2.\"Name\" \"StateName\",T3.\"Name\"  AS \"CountryName\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OLCT  T1 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCST T2 ON T1.\"State\" = T2.\"Code\" AND T1.\"Country\" =T2.\"Country\"  ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCRY T3 ON T1.\"Country\" = T3.\"Code\" ");
				stringBuilder.Append(" WHERE T1.\"Code\"='" + location + "' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					string block = datatable.Rows[0]["Block"].ToString();
					string street = datatable.Rows[0]["Street"].ToString();
					string city = datatable.Rows[0]["City"].ToString();
					string state = datatable.Rows[0]["StateName"].ToString();
					string zipcode = datatable.Rows[0]["ZipCode"].ToString();
					string country = datatable.Rows[0]["CountryName"].ToString();
					if (block != string.Empty)
					{
						fullAddress.Append(block + " ");
					}
					if (street != string.Empty)
					{
						fullAddress.Append(street + " ");
					}
					if (city != string.Empty)
					{
						fullAddress.Append(city + " ");
					}
					if (zipcode != string.Empty)
					{
						fullAddress.Append("-" + zipcode + " ");
					}
					if (state != string.Empty)
					{
						fullAddress.Append(state + ", ");
					}
					if (country != string.Empty)
					{
						fullAddress.Append(country);
					}
				}
			}
			catch
			{

			}
			return fullAddress.ToString();
		}
		public string GetLocationAddressBasedOnName(string location)
		{
			StringBuilder fullAddress = new StringBuilder();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT  T1.* ");
				stringBuilder.Append(" ,T2.\"Name\" \"StateName\",T3.\"Name\"  AS \"CountryName\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OLCT  T1 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCST T2 ON T1.\"State\" = T2.\"Code\" AND T1.\"Country\" =T2.\"Country\"  ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCRY T3 ON T1.\"Country\" = T3.\"Code\" ");
				stringBuilder.Append(" WHERE T1.\"Location\"='" + location + "' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					string block = datatable.Rows[0]["Block"].ToString();
					string street = datatable.Rows[0]["Street"].ToString();
					string city = datatable.Rows[0]["City"].ToString();
					string state = datatable.Rows[0]["StateName"].ToString();
					string zipcode = datatable.Rows[0]["ZipCode"].ToString();
					string country = datatable.Rows[0]["CountryName"].ToString();
					if (block != string.Empty)
					{
						fullAddress.Append(block + " ");
					}
					if (street != string.Empty)
					{
						fullAddress.Append(street + " ");
					}
					if (city != string.Empty)
					{
						fullAddress.Append(city + " ");
					}
					if (zipcode != string.Empty)
					{
						fullAddress.Append("-" + zipcode + " ");
					}
					if (state != string.Empty)
					{
						fullAddress.Append(state + ", ");
					}
					if (country != string.Empty)
					{
						fullAddress.Append(country);
					}
				}
			}
			catch
			{

			}
			return fullAddress.ToString();
		}
		public List<CommonValueModel> GetUDFValuesList(string tableName, string fieldName)
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				HanaParameter[] parameters = new HanaParameter[2];

				parameters[0] = new HanaParameter("TableName", System.Data.SqlDbType.VarChar);
				parameters[0].Value = tableName;

				parameters[1] = new HanaParameter("FieldName", System.Data.SqlDbType.VarChar);
				parameters[1].Value = fieldName;

				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T1.\"FldValue\" AS \"ID\",T1.\"Descr\" AS \"Name\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"CUFD\" T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"UFD1\" T1 ON T0.\"TableID\" = T1.\"TableID\" AND T0.\"FieldID\" = T1.\"FieldID\" ");
				stringBuilder.Append(" WHERE  T0.\"TableID\" = :TableName AND T0.\"AliasID\" = :FieldName ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public List<ApprovalUsersModel> GetApprovalUserIDs(string originatorID, string objType)
		{
			List<ApprovalUsersModel> list = new List<ApprovalUsersModel>();
			StringBuilder stringBuilder = new StringBuilder();
			string dbName = ConfigManager.GetSAPDatabase();

			stringBuilder.Append(" SELECT T5.\"UserID\", T6.\"USER_CODE\",T6.\"U_NAME\" ");
			stringBuilder.Append(" ,T0.\"WtmCode\",T0.\"Name\" AS \"WtmName\",T0.\"Remarks\",T7.\"QueryId\",T8.\"QString\" ");
			stringBuilder.Append(" FROM \"" + dbName + "\".OWTM T0  ");
			stringBuilder.Append(" INNER JOIN \"" + dbName + "\".WTM1 T1 ON T0.\"WtmCode\" = T1.\"WtmCode\"");
			stringBuilder.Append(" INNER JOIN \"" + dbName + "\".WTM2 T2 ON T0.\"WtmCode\" = T2.\"WtmCode\"");
			stringBuilder.Append(" INNER JOIN \"" + dbName + "\".WTM3 T3 ON T0.\"WtmCode\" = T3.\"WtmCode\"");
			stringBuilder.Append(" INNER JOIN \"" + dbName + "\".OWST T4 ON T2.\"WstCode\" = T4.\"WstCode\"");
			stringBuilder.Append(" INNER JOIN \"" + dbName + "\".WST1 T5 ON T2.\"WstCode\" = T5.\"WstCode\"");

			stringBuilder.Append(" INNER JOIN \"" + dbName + "\".OUSR T6 ON T5.\"UserID\" = T6.\"USERID\" ");
			stringBuilder.Append(" INNER JOIN \"" + dbName + "\".WTM5 T7 ON T0.\"WtmCode\" = T7.\"WtmCode\" ");
			stringBuilder.Append(" INNER JOIN \"" + dbName + "\".OUQR T8 ON T7.\"QueryId\" = T8.\"IntrnalKey\" ");

			stringBuilder.Append(" WHERE  T0.\"U_IsWebApp\" = 'Y' AND T0.\"Active\" = 'N' ");
			stringBuilder.Append(" AND T3.\"TransType\" = '" + objType + "' ");
			stringBuilder.Append(" AND T1.\"UserID\" = '" + originatorID + "' ");
			stringBuilder.Append(" ORDER BY T2.\"SortId\" ");

			using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
			{
				list = ConvertDatatableToList.ConvertToList<ApprovalUsersModel>(datatable);
			}
			return list;
		}
		public List<DocumentApprovalUsersModel> GetApprovalUsers(List<ApprovalUsersModel> approvalUsers, PurchaseOrderModel model)
		{
			List<DocumentApprovalUsersModel> list = new List<DocumentApprovalUsersModel>();
			DocumentApprovalUsersModel entity = new DocumentApprovalUsersModel();
			StringBuilder stringBuilder = new StringBuilder();
			string dbName = ConfigManager.GetSAPDatabase();
			List<PurchaseOrderRowsModel> modelRows = model.DocumentLines;
			for (int i = 0; i < approvalUsers.Count; i++)
			{
				string query = approvalUsers[i].QString;
				string name = approvalUsers[i].WtmName;
				string remarks = approvalUsers[i].Remarks;

				for (int j = 0; j < modelRows.Count; j++)
				{
					stringBuilder = new StringBuilder();
					stringBuilder.Append(query);
					stringBuilder.Replace("$[$38.1.0]", "'" + modelRows[j].ItemCode + "'");
					stringBuilder.Replace("$[opor.\"U_Approval\"]", "'" + model.U_Approval + "'");
					stringBuilder.Replace("$[opor.\"DocType\"]", "'" + model.DocType + "'");
					stringBuilder.Replace("POR1", dbName + "." + "POR1");
					stringBuilder.Replace("OITM", dbName + "." + "OITM");
					stringBuilder.Replace("OITB", dbName + "." + "OITB");
					stringBuilder.Replace("OPOR", dbName + "." + "OPOR");
					//stringBuilder.Replace("$[opor.\"U_Approval\"]", dbName + "." + "OPOR.\"U_Approval\"");
					//stringBuilder.Replace("$[opor.\"U_Approval\"]", dbName + "." + "OPOR.\"U_Approval\"");
					//stringBuilder.Replace("$[opor.\"DocType\"]", dbName + "." + "OPOR.\"DocType\"");
					using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
					{
						if (datatable.Rows.Count > 0)
						{
							entity = new DocumentApprovalUsersModel();
							entity.U_AppUId = approvalUsers[i].UserID;
							entity.U_WtmCode = approvalUsers[i].WtmCode;
							entity.WTMName = name;
							if (!list.Where(a => a.U_AppUId == approvalUsers[i].UserID).Any())
							{
								list.Add(entity);
							}
						}
					}
				}
			}
			return list;
		}
		public List<ApprovalUsersModel> GetDraftApprovalUserIDs(string docEntry)
		{
			List<ApprovalUsersModel> list = new List<ApprovalUsersModel>();
			StringBuilder stringBuilder = new StringBuilder();
			string dbName = ConfigManager.GetSAPDatabase();

			stringBuilder.Append(" SELECT T1.\"USERID\" AS \"UserID\", T1.\"U_NAME\",T2.\"Name\" AS \"Remarks\",T0.\"U_IsApp\"  ");
			stringBuilder.Append(" FROM \"" + dbName + "\".\"@WEB_DOCAU\" T0  ");
			stringBuilder.Append(" INNER JOIN \"" + dbName + "\".OUSR T1 ON T0.\"U_AppUId\" = T1.\"USERID\" ");
			stringBuilder.Append(" INNER JOIN \"" + dbName + "\".OWTM T2 ON T0.\"U_WtmCode\" = T2.\"WtmCode\" ");
			stringBuilder.Append(" WHERE  T0.\"U_DraftEn\" = " + docEntry + " ");
			using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
			{
				list = ConvertDatatableToList.ConvertToList<ApprovalUsersModel>(datatable);
			}
			return list;
		}
		public string GetRouteEntry(string routeCode)
		{
			string value = "";
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("RouteCode", System.Data.SqlDbType.VarChar);
				parameters[0].Value = routeCode;
				StringBuilder stringBuilder = new StringBuilder();

				stringBuilder.Append(" SELECT T0.\"AbsEntry\"   FROM " + ConfigManager.GetSAPDatabase() + ".ORST T0 ");
				stringBuilder.Append(" WHERE T0.\"Code\" =:RouteCode ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						value = datatable.Rows[0]["AbsEntry"].ToString();
					}
				}
			}
			catch
			{

			}
			return value;
		}
		public List<CommonValueModel> GetDistributionList(int dimension)
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("DimCode", System.Data.SqlDbType.VarChar);
				parameters[0].Value = dimension;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"OcrCode\" AS \"ID\", T0.\"OcrName\" AS \"Name\", T0.\"DimCode\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OOCR T0  ");
				stringBuilder.Append(" WHERE T0.\"DimCode\"=:DimCode ");
				stringBuilder.Append(" AND T0.\"Active\"='Y'   ");
				stringBuilder.Append(" ORDER BY T0.\"OcrName\"  ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}

			return list;
		}
		public ResponseModel PDF(string docEntry, PrintForm printForm)
		{
			ResponseModel responseModel = new ResponseModel();
			try
			{
				string outMessage = "";
				ServiceLayer sl = new ServiceLayer();
				if (printForm == PrintForm.SalesOrderLayout)
				{
					sl.endPoint = ConfigManager.GetReportAPIUrl() + "home/PrintCrystal?docEntry=" + docEntry + "";
				}
				else if (printForm == PrintForm.PurchaseOrderLayout)
				{
					sl.endPoint = ConfigManager.GetReportAPIUrl() + "home/PrintPO?docEntry=" + docEntry + "";
				}
				else if (printForm == PrintForm.ECRLayout)
				{
					sl.endPoint = ConfigManager.GetReportAPIUrl() + "home/ECRPrintCrystal?docEntry=" + docEntry + "";
				}
				else if (printForm == PrintForm.ECRCreditNoteLayout)
				{
					sl.endPoint = ConfigManager.GetReportAPIUrl() + "home/ECRCreditMemoPrintCrystal?docEntry=" + docEntry + "";
				}
				sl.getRequestData(out outMessage);
				responseModel = JsonConvert.DeserializeObject<ResponseModel>(outMessage);
			}
			catch (Exception ex)
			{
				responseModel.ResponseText = ex.Message;
			}
			return responseModel;
		}
		public string GetItemWarehouseStock(string itemcode, string whscode)
		{
			try
			{
				string dbName = ConfigManager.GetSAPDatabase();
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT \"OnHand\"  ");
				stringBuilder.Append(" FROM " + dbName + ".\"OITW\" T0  ");
				stringBuilder.Append(" WHERE T0.\"ItemCode\" = '" + itemcode + "' AND  T0.\"WhsCode\" = '" + whscode + "' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						return datatable.Rows[0][0].ToString();
					}
				}
			}
			catch
			{

			}
			return "";
		}
		public List<BatchSerialModel> GetItemAvailableStock(string itemcode, string whscode)
		{
			List<BatchSerialModel> list = new List<BatchSerialModel>();
			try
			{

				//parameters[0] = new HanaParameter("DimCode", System.Data.SqlDbType.VarChar);
				//parameters[0].Value = dimension;

				string dbName = ConfigManager.GetSAPDatabase();
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT A.\"DistNumber\", A.\"MnfSerial\" ,A.\"U_LotNo\" ");
				stringBuilder.Append(" ,Cast(SUM(\"Stock\") as numeric(19,3)) \"Stock\" , A.\"LotNumber\"  ");
				stringBuilder.Append(" ,TO_NVARCHAR(A.\"InDate\", 'DD/MM/YYYY')  AS \"InDate\" ,A.\"CostTotal\" ,A.\"U_NetWt\" ,A.\"U_GrossWt\" ");
				stringBuilder.Append(" ,A.\"U_SONo\" ,A.\"U_Remarks\"  , A.\"U_ContractorName\" ,MAX(A.\"BinCode\") \"BinCode\"");
				stringBuilder.Append(" FROM ( ");

				stringBuilder.Append(" SELECT T2.\"DistNumber\",SUM(T0.\"Quantity\") \"Stock\" ,Cast(0 AS NUMERIC(19,2)) AS \"SelQty\"  ");
				stringBuilder.Append(" , T2.\"MnfSerial\" ,  T2.\"U_LotNo\" ,T2.\"LotNumber\"  ");
				stringBuilder.Append(" ,T2.\"InDate\" ,T2.\"CostTotal\" ,T2.\"U_NetWt\",T2.\"U_GrossWt\" ");
				stringBuilder.Append(" , T2.\"U_SONo\" ,  T2.\"U_Remarks\" ,T2.\"U_ContractorName\" ,T4.\"BinCode\" ,T2.\"SysNumber\" ");
				stringBuilder.Append(" FROM " + dbName + ".\"ITL1\" T0  ");
				stringBuilder.Append(" INNER JOIN " + dbName + ".\"OITL\" T1 ON T0.\"LogEntry\" = T1.\"LogEntry\" ");
				stringBuilder.Append(" INNER JOIN " + dbName + ".\"OBTN\" T2 ON T0.\"ItemCode\" = T2.\"ItemCode\" and T0.\"SysNumber\" = T2.\"SysNumber\"   ");
				stringBuilder.Append(" INNER JOIN " + dbName + ".\"OITM\" T3 ON T0.\"ItemCode\" = T3.\"ItemCode\" ");
				stringBuilder.Append(" LEFT JOIN " + dbName + ".\"B1_SnBTransRptFirstBinView\" T4 ON T0.\"LogEntry\" = T4.\"ITLEntry\" AND T0.\"MdAbsEntry\" = T4.\"SnBMDAbs\" AND T4.\"BinCode\" like '%APP%' ");

				stringBuilder.Append(" WHERE T2.\"ItemCode\" = '" + itemcode + "' AND T1.\"LocCode\" = '" + whscode + "'  ");
				stringBuilder.Append(" AND T3.\"ManBtchNum\" = 'Y' ");
				stringBuilder.Append(" GROUP BY T2.\"DistNumber\",T2.\"MnfSerial\" ,T2.\"U_LotNo\" , T2.\"LotNumber\" ");
				stringBuilder.Append(" ,T2.\"InDate\" ,T2.\"CostTotal\" ,T2.\"U_NetWt\"  ,T2.\"U_GrossWt\"  ");
				stringBuilder.Append(" ,T2.\"U_SONo\" ,T2.\"U_Remarks\" , T2.\"U_ContractorName\" , T4.\"BinCode\" ,T2.\"SysNumber\" ");
				stringBuilder.Append(" Having SUM(T0.\"Quantity\")>0 ");

				stringBuilder.Append(" 	UNION ALL ");

				stringBuilder.Append(" SELECT T2.\"DistNumber\",SUM(T0.\"Quantity\") \"Stock\" ,Cast(0 AS NUMERIC(19,2)) AS \"SelQty\"  ");
				stringBuilder.Append(" , T2.\"MnfSerial\" ,T2.\"U_LotNo\" , T2.\"LotNumber\"  ");
				stringBuilder.Append(" ,T2.\"InDate\" ,  T2.\"CostTotal\" ,T2.\"U_NetWt\",T2.\"U_GrossWt\" ");
				stringBuilder.Append(" , T2.\"U_SONo\" ,  T2.\"U_Remarks\" ,T2.\"U_ContractorName\" , T4.\"BinCode\",T2.\"SysNumber\" ");
				stringBuilder.Append(" FROM " + dbName + ".\"ITL1\" T0  ");
				stringBuilder.Append(" INNER JOIN " + dbName + ".\"OITL\" T1 ON T0.\"LogEntry\" = T1.\"LogEntry\" ");
				stringBuilder.Append(" INNER JOIN " + dbName + ".\"OSRN\" T2 ON T0.\"ItemCode\" = T2.\"ItemCode\" and T0.\"SysNumber\" = T2.\"SysNumber\"  ");
				stringBuilder.Append(" INNER JOIN " + dbName + ".\"OITM\" T3 ON T0.\"ItemCode\" = T3.\"ItemCode\" ");
				stringBuilder.Append(" LEFT JOIN " + dbName + ".\"B1_SnBTransRptFirstBinView\" T4 ON T0.\"LogEntry\" = T4.\"ITLEntry\" AND T0.\"MdAbsEntry\" = T4.\"SnBMDAbs\" AND T4.\"BinCode\" like '%APP%' ");

				stringBuilder.Append(" WHERE T2.\"ItemCode\" = '" + itemcode + "' AND T1.\"LocCode\" = '" + whscode + "'  ");
				stringBuilder.Append(" AND T3.\"ManSerNum\" = 'Y' ");

				stringBuilder.Append(" GROUP BY T2.\"DistNumber\",T2.\"MnfSerial\" ,T2.\"U_LotNo\" , T2.\"LotNumber\"  ");
				stringBuilder.Append(" ,T2.\"InDate\" ,  T2.\"CostTotal\" ,T2.\"U_NetWt\",T2.\"U_GrossWt\" ");
				stringBuilder.Append(" , T2.\"U_SONo\" ,  T2.\"U_Remarks\" ,T2.\"U_ContractorName\" ,T4.\"BinCode\",T2.\"SysNumber\" ");
				stringBuilder.Append(" Having SUM(T0.\"Quantity\")>0 ");

				stringBuilder.Append(" ) AS A GROUP BY A.\"DistNumber\",A.\"MnfSerial\" ,A.\"U_LotNo\" , A.\"LotNumber\" ");
				stringBuilder.Append(" ,A.\"InDate\" ,A.\"CostTotal\" ,A.\"U_NetWt\"  ,A.\"U_GrossWt\"  ");
				stringBuilder.Append(" ,A.\"U_SONo\" ,A.\"U_Remarks\" , A.\"U_ContractorName\" ,A.\"SysNumber\"");
				stringBuilder.Append(" HAVING SUM(\"Stock\") > 0 ");
				stringBuilder.Append(" ORDER BY \"SysNumber\" ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<BatchSerialModel>(datatable);
				}
			}
			catch
			{

			}

			return list;
		}
		public BatchSerialAllocatedModel GetItemAvailableStock_AutoBatchQty(string itemcode, string whscode, double requiredQty)
		{
			BatchSerialAllocatedModel model = new BatchSerialAllocatedModel();
			string batchQty = "";
			string bincode = "";
			string lotno = "";
			double selectedQty = 0;
			try
			{
				List<BatchSerialModel> list = GetItemAvailableStock(itemcode, whscode);
				bool isBreak = false;
				for (int i = 0; i < list.Count; i++)
				{
					double stock = list[i].Stock;
					string batch = list[i].DistNumber;
					string rowBatchQty = "";
					if (requiredQty <= stock)
					{
						rowBatchQty = batch + "{}" + requiredQty.ToString() + "{}" + list[i].U_LotNo + "{}" + list[i].BinCode;
						selectedQty = selectedQty + requiredQty;
						isBreak = true;
					}
					else
					{
						selectedQty = selectedQty + stock;
						rowBatchQty = batch + "{}" + stock.ToString() + "{}" + list[i].U_LotNo + "{}" + list[i].BinCode;
						requiredQty = requiredQty - stock;
					}
					if (batchQty == string.Empty)
					{
						batchQty = rowBatchQty;
					}
					else
					{
						batchQty = batchQty + ";" + rowBatchQty;
					}
					if (isBreak == true)
					{
						break;
					}
				}
			}
			catch
			{

			}
			model.BatchQty = batchQty;
			model.SelectedQty = selectedQty;
			//model.LotNo = lotno;
			//model.BinCode = bincode;
			return model;
		}
		public string IsECRSuperUser(string emailAddress)
		{
			string value = string.Empty;
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("EmailAddress", System.Data.SqlDbType.VarChar);
				parameters[0].Value = emailAddress;
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT \"U_IsECRSU\" FROM " + ConfigManager.GetSAPDatabase() + ".OHEM WHERE \"email\" = :EmailAddress");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						value = datatable.Rows[0][0].ToString();
					}
				}
			}
			catch
			{

			}
			return value;
		}
		public string IsPOSuperUser(string emailAddress)
		{
			string value = string.Empty;
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("EmailAddress", System.Data.SqlDbType.VarChar);
				parameters[0].Value = emailAddress;
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT \"U_IsPOSU\" FROM " + ConfigManager.GetSAPDatabase() + ".OHEM WHERE \"email\" = :EmailAddress");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						value = datatable.Rows[0][0].ToString();
						if (value == string.Empty)
						{
							value = "N";
						}
					}
				}
			}
			catch
			{

			}
			return value;
		}
		public void UpdateDocumentItemChildLocation(string rowTable, string docEntry, DocumentModel model)
		{
			stringBuilder = new StringBuilder();
			stringBuilder.Append(" SELECT T0.\"WhsCode\" ");
			stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + rowTable + " T0 ");
			stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " AND T0.\"WhsCode\" != '" + model.WarehouseCode + "' ");
			DataTable dt = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message);
			if (dt.Rows.Count > 0)
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" UPDATE T0 ");
				stringBuilder.Append(" SET T0.\"WhsCode\" = '" + model.WarehouseCode + "' ");
				stringBuilder.Append(" ,T0.\"LocCode\" = (SELECT \"Location\" FROM " + ConfigManager.GetSAPDatabase() + "." + CommonTables.WarehouseTable + " A WHERE A.\"WhsCode\" = '" + model.WarehouseCode + "' ) ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + rowTable + " T0 ");
				stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " ");
				FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
			}
		}
		public void UpdateDocumentItemChildTaxCode(string rowTable, string docEntry)
		{
			stringBuilder = new StringBuilder();
			stringBuilder.Append(" SELECT T0.\"TaxCode\" ");
			stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + rowTable + " T0 ");
			stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " AND T0.\"TreeType\" =  'S' ");
			DataTable dt = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message);
			if (dt.Rows.Count > 0)
			{
				string taxCode = dt.Rows[0][0].ToString();
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" UPDATE T0 ");
				stringBuilder.Append(" SET T0.\"TaxCode\" = '" + taxCode + "' ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + rowTable + " T0 ");
				stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " AND T0.\"TreeType\" =  'I' ");
				FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
			}
		}
		public List<KLDMasterModel> GetKLDNo()
		{
			List<KLDMasterModel> list = new List<KLDMasterModel>();
			stringBuilder = new StringBuilder();
			stringBuilder.Append(" SELECT  T0.\"U_KLDNo\",T0.\"U_PunchNo\",T0.\"U_ItemCode\" ,T1.\"ItemName\",T0.\"U_Remark\" ");
			stringBuilder.Append(" FROM  " + ConfigManager.GetSAPDatabase() + ".\"@WEB_KLD\" T0 ");
			stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OITM T1 ON T0.\"U_ItemCode\"=T1.\"ItemCode\" ");

			DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message);
			if (datatable.Rows.Count > 0)
			{
				list = ConvertDatatableToList.ConvertToList<KLDMasterModel>(datatable);
			}
			return list;

		}

		public string GetKLDNo(string itemcode)
		{
			string kldNo = "";
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT  T0.\"U_KLDNo\"  ");
				stringBuilder.Append(" FROM  " + ConfigManager.GetSAPDatabase() + ".\"OITM\" T0 ");
				stringBuilder.Append(" WHERE T0.\"ItemCode\" ='" + itemcode + "' ");
				DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message);
				if (datatable.Rows.Count > 0)
				{
					kldNo = datatable.Rows[0][0].ToString();
				}
			}
			catch { }
			return kldNo;
		}

		public string GetAllPOItemGroup(string itemcode)
		{
			string value = "";
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"ItmsGrpCod\" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
				//stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OITM T1 ON T0.\"ItmsGrpCod\" = T1.\"ItmsGrpCod\" ");
				stringBuilder.Append(" WHERE T0.\"ItemCode\" = '" + itemcode + "'");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						value = datatable.Rows[0]["ItmsGrpCod"].ToString();
					}
				}
			}
			catch
			{

			}
			return value;
		}

		public string GetItemGroupName(string itemgroupcode)
		{
			string value = "";
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"ItmsGrpNam\" FROM " + ConfigManager.GetSAPDatabase() + ".OITB T0 ");
				stringBuilder.Append(" WHERE T0.\"ItmsGrpCod\" = '" + itemgroupcode + "'");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						value = datatable.Rows[0]["ItmsGrpNam"].ToString();
					}
				}
			}
			catch
			{

			}
			return value;
		}

		public List<PunchMasterModel> GetClientPOPunchKLDList(string kldno)
		{
			List<PunchMasterModel> list = new List<PunchMasterModel>();
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];
				parameters[0] = new HanaParameter("U_KLDNo", System.Data.SqlDbType.VarChar);
				parameters[0].Value = kldno;

				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T4.\"U_KLDNo\", T0.\"U_PunchNo\", T0.\"U_ItemCode\", T2.\"ItemName\"");
				stringBuilder.Append(" SELECT T0.\"U_NoOfUps\", T0.\"U_Remark\"");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PUNCH\" T0 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PUNCH1\" T1 ON T1.\"U_BaseCode\"=T0.\"Code\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OITM T2 ON T1.\"U_ItemCode\"=T2.\"ItemCode\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"@WEB_KLD1\" T3 ON T3.\"U_BaseCode\"=T0.\"Code\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"@WEB_KLD\" T4 ON T4.\"Code\"=T1.\"U_BaseCode\" ");
				stringBuilder.Append(" WHERE T4.\"U_KLDNo\" = :kldno ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					list = ConvertDatatableToList.ConvertToList<PunchMasterModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}
		public int GetProductionOrder(string docentry)
		{
			int value = 0;
			try
			{
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"DocEntry\" from " + ConfigManager.GetSAPDatabase() + ".\"ORDR\" T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"OWOR\" T1 ON T1.\"OriginAbs\" = T0.\"DocEntry\"");
				stringBuilder.Append(" WHERE T1.\"OriginAbs\"= '" + docentry + "' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string messages))
				{
					if (datatable.Rows.Count > 0)
					{
						value = int.Parse(datatable.Rows[0][0].ToString());
					}
				}
			}
			catch
			{

			}
			return value;
		}
		public List<CommonValueModel> GetDropDownList(string code)
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("Code", System.Data.SqlDbType.VarChar);
				parameters[0].Value = code;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T1.\"U_Value\" AS \"ID\", T1.\"U_Desc\" AS \"Name\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@DDMASTER\" T0  ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"@DDMASTER1\" T1 ON T0.\"Code\" = T1.\"Code\"  ");
				stringBuilder.Append(" WHERE T0.\"Code\"=:Code ");
				stringBuilder.Append(" ORDER BY T1.\"U_Desc\"  ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}

			return list;
		}

		public List<CopyDocumentModel> CreditNoteCardCodeWise(string cardcode)
		{
			List<CopyDocumentModel> _list = new List<CopyDocumentModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"DocEntry\" ,T0.\"DocNum\" ,TO_NVARCHAR(T0.\"DocDate\", 'DD/MM/YYYY') as \"DocDate\"  ");
				stringBuilder.Append(" ,T0.\"CardCode\" ,T0.\"CardName\" ,T0.\"DocTotal\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".ORIN T0 ");
				stringBuilder.Append(" WHERE T0.\"CardCode\"  = '" + cardcode + "' ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<CopyDocumentModel>(datatable);

				}
			}
			catch
			{

			}
			return _list;
		}

		public string GetUserEmailAddress(string userId)
		{
			string emailAddress = string.Empty;
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("UserId", System.Data.SqlDbType.VarChar);
				parameters[0].Value = userId;
				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT \"email\" FROM " + ConfigManager.GetSAPDatabase() + ".OHEM WHERE \"userId\" = '" + userId + "'");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						emailAddress = datatable.Rows[0][0].ToString();
					}
				}
			}
			catch
			{

			}
			return emailAddress;
		}

		public DocumentModel GetClientPOSOData(string docEntry, string lineNo)
		{
			DocumentModel model = new DocumentModel();
			try
			{
				string headerTable = CommonTables.ClientPORegisterHeaderTable;
				string rowTable = CommonTables.ClientPORegisterRowTable;
				HanaParameter[] parameters = new HanaParameter[2];

				parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
				parameters[0].Value = docEntry;

				parameters[1] = new HanaParameter("LineId", System.Data.SqlDbType.VarChar);
				parameters[1].Value = lineNo;

				string CTOL = "";
				string CTLOL = "";

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"U_CardCode\" As \"CardCode\",T0.\"U_CardName\" AS \"CardName\" , T2.\"SlpCode\" AS \"SalesPersonCode\"");
				stringBuilder.Append(" ,T1.\"U_BPTL\" As \"U_CTOL\",T1.\"U_BPLTL\" AS \"U_CTLOL\" , T1.\"Currency\" AS \"DocCurrency\"");
				stringBuilder.Append(" ,T0.\"U_PORefNo\" As \"NumAtCard\",TO_NVARCHAR(T0.\"U_PORefDt\", 'DD-MM-YYYY')  AS \"TaxDate\" ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + headerTable + "\" T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OCRD T1 ON T0.\"U_CardCode\" = T1.\"CardCode\"");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OSLP T2 ON T1.\"SlpCode\"=T2.\"SlpCode\" ");
				stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						model = ConvertDatatableToList.ConvertToEntity<DocumentModel>(datatable);
						CTOL = datatable.Rows[0]["U_CTOL"].ToString();
						CTLOL = datatable.Rows[0]["U_CTLOL"].ToString();
					}
				}

				#region Row

				model.DocumentLines = new List<DocumentRowsModel>();
				List<int> lineIdList = lineNo.Split(',').Select(int.Parse).ToList();
				for (int k = 0; k < lineIdList.Count; k++)
				{
					int lineId = lineIdList[k];
					stringBuilder = new StringBuilder();
					stringBuilder.Append(" SELECT ROW_NUMBER() OVER (ORDER BY T0.\"LineId\") AS \"Index\",T0.\"U_ItemCode\" As \"ItemCode\",T0.\"U_RateSys\" AS \"UnitPrice\"");
					stringBuilder.Append(" ,T0.\"U_KLDNo\" As \"U_KLDNo\", T0.\"U_ItemName\" As \"ItemName\"");
					stringBuilder.Append(" ,T0.\"DocEntry\" \"U_Exp1\", T0.\"LineId\" \"U_Exp2\" ");
					stringBuilder.Append(" ,T1.\"ChapterID\" as \"HSNEntry\",T2.\"ChapterID\" AS \"HSNName\" ");
					stringBuilder.Append(" ,CASE WHEN T0.\"U_IsGang\" ='Y' THEN ");
					stringBuilder.Append(" (SELECT max(\"U_JobQty\") FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_GANGUP1\" WHERE \"U_BaseEn\" = T0.\"DocEntry\" AND \"U_BaseLine\" = T0.\"LineId\") ");
					stringBuilder.Append(" ELSE T0.\"U_Qty\"  END As \"Quantity\" ");
					stringBuilder.Append(" ,T1.\"TreeType\" ");
					stringBuilder.Append(" ,T0.\"U_BomType\" ");
					stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + rowTable + "\" T0 ");
					stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OITM T1 ON T0.\"U_ItemCode\" = T1.\"ItemCode\" ");
					stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T2 ON T1.\"ChapterID\" = T2.\"AbsEntry\" ");
					stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " "); //AND T0.\"U_IsGang\" = 'N' AND T0.\"U_AppArt\" = 'Y'
					stringBuilder.Append(" AND IFNULL(T1.\"TreeType\",'') NOT IN ('I') ");
					stringBuilder.Append(" AND IFNULL(T0.\"U_BomType\",'') NOT IN ('I') ");
					stringBuilder.Append(" AND T0.\"LineId\" in (" + lineId + ")"); //AND T0.\"U_IsGang\" = 'N' AND T0.\"U_AppArt\" = 'Y'

					//AND T0.\"U_IsGang\" = 'N' AND T0.\"U_AppArt\" = 'Y'
					using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
					{
						if (datatable.Rows.Count > 0)
						{
							List<DocumentRowsModel> modelRows = ConvertDatatableToList.ConvertToList<DocumentRowsModel>(datatable);
							string treeType = modelRows[0].TreeType;
							//model.DocumentLines = modelRows;
							try
							{
								if (treeType == "S")
								{
									ICommonRepository commonRepository = new CommonRepository();
									for (int i = 0; i < modelRows.Count; i++)
									{
										modelRows[0].Index = model.DocumentLines.Count + 1;
										model.DocumentLines.AddRange(modelRows);

										List<BOMModel> bomModel = commonRepository.GetBOMComponents(modelRows[0].ItemCode);
										for (int j = 0; j < bomModel.Count; j++)
										{
											//index = index + 1;
											DocumentRowsModel documentRowsModel = new DocumentRowsModel();
											documentRowsModel.Index = model.DocumentLines.Count + 1;
											documentRowsModel.ItemCode = bomModel[j].ItemCode;
											documentRowsModel.ItemName = bomModel[j].ItemName;
											documentRowsModel.Quantity = bomModel[j].BOMRatio * modelRows[0].Quantity;
											documentRowsModel.BOMRatio = bomModel[j].BOMRatio.ToString();
											documentRowsModel.TreeType = "I";
											documentRowsModel.BaseBOMLine = modelRows[0].Index.Value.ToString();
											documentRowsModel.U_UnwDrctn = modelRows[0].U_UnwDrctn;
											documentRowsModel.U_Packng = modelRows[0].U_Packng;
											documentRowsModel.BOMWarehouseCode = modelRows[0].BOMWarehouseCode;
											documentRowsModel.U_Exp2 = modelRows[0].U_Exp2;
											documentRowsModel.U_Exp1 = modelRows[0].U_Exp1;
											documentRowsModel.HSNName = bomModel[j].HSNName;
											try
											{
												documentRowsModel.HSNEntry = int.Parse(bomModel[j].HSNEntry);
											}
											catch { }
											model.DocumentLines.Add(documentRowsModel);
										}
										//itemIndex = model.DocumentLines[i].Index.Value;
										//int index = model.DocumentLines[i].Index.Value;
										//if (model.DocumentLines[i].TreeType == "S")
										//{
										//	loopCount = loopCount + 1;
										//	if (loopCount > 1)
										//	{
										//		index = model.DocumentLines.Count;
										//	}

										//}
									}
								}
								//else if(treeType == "N")
								//{
								//}
								else
								{
									modelRows[0].Index = model.DocumentLines.Count + 1;
									model.DocumentLines.AddRange(modelRows);
								}
							}
							catch { }
						}
						else
						{
							//List<DocumentRowsModel> ClientPORegisterList = new List<DocumentRowsModel>();
							//DocumentRowsModel clientPORegisterRowsModel = new DocumentRowsModel();
							//ClientPORegisterList.Add(clientPORegisterRowsModel);
							//model.DocumentLines.AddRange(ClientPORegisterList);
						}
					}

					for (int i = 0; i < model.DocumentLines.Count; i++)
					{
						model.DocumentLines[i].U_CTOL = double.Parse(CTOL);
						model.DocumentLines[i].U_CTLOL = double.Parse(CTLOL);
					}

				}

				#endregion

				#region Client PO Attachment 
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"LineId\" AS \"Line\", T0.\"U_Attach\" AS \"trgtPath\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PO_REGISTER3\" T0 ");
				stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " AND T0.\"U_DocType\" IN ('1','4')");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					List<DocumentModel_Attachment> modelRows = ConvertDatatableToList.ConvertToList<DocumentModel_Attachment>(datatable);
					model.Attachments2_Lines = modelRows;
					for (int i = 0; i < model.Attachments2_Lines.Count; i++)
					{
						model.Attachments2_Lines[i].Index = (i + 1);
						model.Attachments2_Lines[i].trgtPath += "\\" + model.Attachments2_Lines[i].FileName + "." + model.Attachments2_Lines[i].FileExt;
					}
				}
				#endregion
			}
			catch
			{

			}
			return model;
		}

		public List<ItemModel> GetAllInksItem(string group)
		{
			List<ItemModel> _list = new List<ItemModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T1.\"ItemCode\" ,T1.\"ItemName\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T1 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OITB T2 ON T1.\"ItmsGrpCod\" = T2.\"ItmsGrpCod\" ");
				stringBuilder.Append(" WHERE T1.\"validFor\" = 'Y' ");
				if (group == "I")
				{
					stringBuilder.Append(" AND UPPER(T2.\"ItmsGrpNam\") LIKE 'INK%' ");
				}
				else if (group == "V")
				{
					stringBuilder.Append(" AND T2.\"ItmsGrpNam\" = 'Coating' ");
				}
				else if (group == "R")
				{
					stringBuilder.Append(" AND T2.\"ItmsGrpNam\" IN ('Board - Grey Back','Board - White Back','Board - FBB','Board - Others','Paper - Art Paper'  ");
					stringBuilder.Append(" ,'Paper - Maplitho Pap','Paper - Others','PVC Sheets','IML (Inmould Label)','PP Sheets' ");
					stringBuilder.Append(" ,'Gumming Sheets','Sticker Sheets','PlayCard RM - PP','PlayCard RM - Board','Jobwork (lab) Sheet' ");
					stringBuilder.Append(" ,'Other Pack Mat Sheet','Board - Artcard','IML(Inmould Roll)','Paper - Roll','PET Sheets' ");
					stringBuilder.Append(" ,'Board - Roll','PET Roll','MET - PET - Board','PRNT- Corrug Sheet','GUMMING SHEET ( ROLL ) FLEXO' ");
					stringBuilder.Append(" ,'PC PRINTED SHEET','GUMMING SHEET - ROLL','PP/PVC Roll') ");
				}
				else if (group == "C")
				{
					stringBuilder.Append(" AND T2.\"ItmsGrpNam\" = 'Corrugation Box' ");
				}
				else if (group == "L")
				{
					stringBuilder.Append(" AND T2.\"ItmsGrpNam\" = 'Lamination Film' ");
				}
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<ItemModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}

		public string GetBPSalesEmployee(string cardcode)
		{
			string value = string.Empty;
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];
				parameters[0] = new HanaParameter("CardCode", System.Data.SqlDbType.VarChar);
				parameters[0].Value = cardcode;

				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT \"SlpCode\" FROM " + ConfigManager.GetSAPDatabase() + ".OCRD WHERE \"CardCode\" = :CardCode");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						value = datatable.Rows[0][0].ToString();
					}
				}
			}
			catch
			{

			}
			return value;
		}

		public string GetArtworkApprovedDate(string itemcode)
		{
			string value = string.Empty;
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];
				parameters[0] = new HanaParameter("ItemCode", System.Data.SqlDbType.VarChar);
				parameters[0].Value = itemcode;

				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT \"U_ArtRelDt\" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\" WHERE \"U_ItemCode\" = :ItemCode");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						value = datatable.Rows[0][0].ToString();
					}
				}
			}
			catch
			{

			}
			return value;
		}

		public string GetArtworkApproved(string itemcode)
		{
			string value = string.Empty;
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];
				parameters[0] = new HanaParameter("ItemCode", System.Data.SqlDbType.VarChar);
				parameters[0].Value = itemcode;

				stringBuilder = new StringBuilder();
				stringBuilder.Append("SELECT \"U_IsArtApp\",\"U_ArtRelDt\" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PREPRESS\" WHERE \"U_ItemCode\" = :ItemCode");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						string isArtApp = datatable.Rows[0]["U_IsArtApp"].ToString();
						string artRelDt = datatable.Rows[0]["U_ArtRelDt"].ToString();
						if (!string.IsNullOrEmpty(artRelDt))
						{
							value = "Y";
						}
					}
				}
			}
			catch
			{

			}
			return value;
		}


		public List<CommonValueModel> GetAllKLDData()
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT ROW_NUMBER() OVER(order by cast(T0.\"Code\" As int)) AS \"RowNo\"");
				stringBuilder.Append(" ,T0.\"U_KLDNo\",T2.\"U_PunchNo\",T2.\"U_SizeX\",T2.\"U_SizeY\"");
				stringBuilder.Append(" ,T0.\"U_Lmm\", T0.\"U_Wmm\" , T0.\"U_Hmm\", T0.\"U_TuckInflap\", T0.\"U_DustFlap\" ");
				stringBuilder.Append("  , T2.\"U_PunchTyp\", T0.\"U_Remark\", T0.\"U_Desc\"");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_KLD\" T0 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PUNCH1\" T1 ON T1.\"U_KLDNo\"=T0.\"U_KLDNo\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"@WEB_PUNCH\" T2 ON T2.\"Code\"=T1.\"U_BaseCode\" ");
				//stringBuilder.Append(" where T0.\"U_Status\" = '" + status + "' ");

				stringBuilder.Append(" ORDER BY \"RowNo\" desc ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{

					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}

		public string GetItemUOMEntry(string itemcode)
		{
			string value = string.Empty;
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"UgpEntry\"   ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
				stringBuilder.Append(" WHERE T0.\"ItemCode\" = '" + itemcode + "' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						value = datatable.Rows[0][0].ToString();
					}
				}
			}
			catch
			{

			}
			return value;
		}

		public List<DocumentModel_Attachment> GetEmptyFileNameList()
		{
			List<DocumentModel_Attachment> list = new List<DocumentModel_Attachment>();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT * ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".ATC1 T0 ");
				stringBuilder.Append(" WHERE T0.\"FileName\" = '' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<DocumentModel_Attachment>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}

		public void UpdateAttachementFileName(string atcEntry, string fileName)
		{
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".ATC1 ");
				stringBuilder.Append(" SET \"FileName\" = '" + fileName + "' ");
				stringBuilder.Append(" WHERE \"AbsEntry\" = " + atcEntry + " ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
				}
			}
			catch
			{

			}
		}

		public string GetWarehousePhysicalLocation(string whscode)
		{
			string value = string.Empty;
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T1.\"U_ShortCode\"   ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OWHS T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OLCT T1 ON T0.\"U_PysiclLoc\" = T1.\"Code\" ");
				stringBuilder.Append(" WHERE T0.\"WhsCode\" = '" + whscode + "' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						value = datatable.Rows[0][0].ToString();
					}
				}
			}
			catch
			{

			}
			return value;
		}

		public List<CommonValueModel> GetAllBOMWarehouseList()
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"WhsCode\" AS \"ID\" , T0.\"WhsName\" AS \"Name\" FROM " + ConfigManager.GetSAPDatabase() + ".\"OWHS\" T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"@WEB_BOMWHS_MAP\" T1 ON T0.\"WhsCode\" = T1.\"U_FGWhs\" ");
				stringBuilder.Append(" WHERE T0.\"Inactive\" = 'N' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}

		public List<CommonValueModel> GetBOMUDTRowWarehouse(string whscode)
		{
			List<CommonValueModel> list = new List<CommonValueModel>();
			try
			{
				StringBuilder stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"WhsCode\" AS \"ID\" , T0.\"WhsName\" AS \"Name\" FROM " + ConfigManager.GetSAPDatabase() + ".\"OWHS\" T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"@WEB_BOMWHS_MAP\" T1 ON T0.\"WhsCode\" = T1.\"U_SFGWhs\" ");
				stringBuilder.Append(" WHERE T1.\"U_FGWhs\" = '" + whscode + "' ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					list = ConvertDatatableToList.ConvertToList<CommonValueModel>(datatable);
				}
			}
			catch
			{

			}
			return list;
		}

		public void InsertInLog(ErrorLogModel model)
		{
			stringBuilder = new StringBuilder();
			stringBuilder.Append(" SELECT MAX(Cast(\"Code\" AS INT)) + 1 FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_ERROR_LOG\" ");
			DataTable dt = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message);
			string code = dt.Rows[0][0].ToString();
			if (code == string.Empty)
			{
				code = "1";
			}
			stringBuilder = new StringBuilder();
			stringBuilder.Append(" INSERT INTO " + ConfigManager.GetSAPDatabase() + ".\"@WEB_ERROR_LOG\"(\"Code\",\"Name\",\"U_User\",\"U_Date\",\"U_Form\",\"U_Desc\") ");
			stringBuilder.Append(" VALUES('" + code + "','" + code + "','" + model.U_User + "','" + DateTime.Now + "','" + model.U_Form + "','" + model.U_Desc + "') ");
			FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
		}
	}
}