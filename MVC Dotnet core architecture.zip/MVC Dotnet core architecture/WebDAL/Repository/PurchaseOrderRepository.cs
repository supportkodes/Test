﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sap.Data.Hana;
using WebDAL.Helper;
using WebDAL.Helpers;
using WebDAL.IRepository;
using WebDAL.Models;

namespace WebDAL.Repository
{
    public class PurchaseOrderRepository : clsDataAccess, IPurchaseOrderRepository
    {
        string query = "";
        CommonRepository commonRepository = new CommonRepository();
        StringBuilder stringBuilder = new StringBuilder();
        public List<PurchaseOrderModel> GetAllDraft(string userId)
        {
            List<PurchaseOrderModel> _list = new List<PurchaseOrderModel>();
            try
            {
                string isSuperUser = commonRepository.IsUserSuperUser(userId);
                string dbUserId = commonRepository.GetUserId(userId);
                string isPOSuperUser = commonRepository.IsPOSuperUser(userId);

                string headerTable = CommonTables.DraftHeaderTable;
                string rowTable = CommonTables.DraftRowTable;

                HanaParameter[] parameters = new HanaParameter[1];
                parameters[0] = new HanaParameter("@UserId", System.Data.SqlDbType.VarChar);
                parameters[0].Value = userId;


                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT 'DRAFT' AS \"Type\" , T0.\"DocEntry\", T0.\"DocNum\",TO_NVARCHAR(T0.\"DocDate\", 'DD/MM/YYYY')  AS \"DocDate\" ,\"CardName\" ");
                stringBuilder.Append(" ,CASE WHEN \"DocStatus\" = 'O' THEN 'Open' ");
                //stringBuilder.Append(" CASE WHEN \"DocStatus\" = 'O' THEN 'Open' ");
                stringBuilder.Append(" WHEN \"DocStatus\" = 'C' AND \"CANCELED\" = 'Y' THEN 'Cancelled' ELSE 'Closed' END AS \"DocStatus\"");
                stringBuilder.Append(" ,CASE WHEN \"DocType\" = 'I' THEN 'Item' ELSE 'Service' END AS \"DocType\"");
                stringBuilder.Append(" ,T0.\"draftKey\" ");

                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + headerTable + " T0 ");
                stringBuilder.Append(" WHERE T0.\"DocStatus\" = 'O' AND T0.\"ObjType\" ='" + Convert.ToString((int)ObjectType.PurchaseOrders) + "' ");
                stringBuilder.Append(" AND T0.\"DocDate\" >= '2024-05-30' ");
                if (isSuperUser == "N")
                {
                    stringBuilder.Append(" AND (T0.\"U_CRBY\" = '" + dbUserId + "' OR T0.\"UserSign\" = " + dbUserId + " ) ");
                }

                stringBuilder.Append(" ORDER BY T0.\"DocEntry\" DESC ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    _list = ConvertDatatableToList.ConvertToList<PurchaseOrderModel>(datatable);
                }
            }
            catch
            {

            }
            return _list;
        }

        public List<PurchaseOrderModel> GetAllDocument(string userId)
        {
            List<PurchaseOrderModel> _list = new List<PurchaseOrderModel>();
            try
            {
                string isSuperUser = commonRepository.IsUserSuperUser(userId);
                string dbUserId = commonRepository.GetUserId(userId);
                string isPOSuperUser = commonRepository.IsPOSuperUser(userId);

                string headerTable = CommonTables.PurchaseOrderHeaderTable;
                string rowTable = CommonTables.PurchaseOrderRowTable;

                HanaParameter[] parameters = new HanaParameter[1];
                parameters[0] = new HanaParameter("@UserId", System.Data.SqlDbType.VarChar);
                parameters[0].Value = userId;


                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT 'Document' AS \"Type\" , T0.\"DocEntry\", T0.\"DocNum\",TO_NVARCHAR(T0.\"DocDate\", 'DD/MM/YYYY')  AS \"DocDate\" ,\"CardName\" ");
                stringBuilder.Append(" ,CASE WHEN \"DocStatus\" = 'O' THEN 'Open' ");
                stringBuilder.Append(" WHEN \"DocStatus\" = 'C' AND \"CANCELED\" = 'Y' THEN 'Cancelled' ELSE 'Closed' END AS \"DocStatus\"");
                stringBuilder.Append(" ,CASE WHEN \"DocType\" = 'I' THEN 'Item' ELSE 'Service' END AS \"DocType\"");
                stringBuilder.Append(" ,T0.\"draftKey\" ");

                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + headerTable + " T0 ");
                stringBuilder.Append(" WHERE T0.\"ObjType\" ='" + Convert.ToString((int)ObjectType.PurchaseOrders) + "' ");//T0.\"DocStatus\" = 'O' 
                if (isSuperUser == "N" && isPOSuperUser == "N")
                {
                    stringBuilder.Append(" AND (T0.\"U_CRBY\" = '" + dbUserId + "' OR T0.\"UserSign\" = " + dbUserId + " ) ");
                }
                //Add by Nilam
                stringBuilder.Append("AND (T0.\"DocStatus\" = 'O' OR T0.\"Printed\" = 'Y' )");
                stringBuilder.Append(" ORDER BY T0.\"DocEntry\" DESC ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    _list = ConvertDatatableToList.ConvertToList<PurchaseOrderModel>(datatable);
                }
            }
            catch
            {

            }
            return _list;
        }

        public PurchaseOrderModel Get(string docEntry, string userId, string type)
        {
            PurchaseOrderModel model = new PurchaseOrderModel();
            try
            {
                string headerTable = CommonTables.PurchaseOrderHeaderTable;
                string rowTable = CommonTables.PurchaseOrderRowTable;
                string freightTable = CommonTables.PurchaseOrderFreightTable;
                string taxExtensionTable = CommonTables.PurchaseOrderAddressTable;

                if (type.ToUpper() == "DRAFT")
                {
                    headerTable = CommonTables.DraftHeaderTable;
                    rowTable = CommonTables.DraftRowTable;
                    freightTable = CommonTables.DraftFreightTable;
                    taxExtensionTable = CommonTables.DraftAddressTable;
                }

                HanaParameter[] parameters = new HanaParameter[1];

                parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
                parameters[0].Value = docEntry;

                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT  '" + type.ToUpper() + "' AS \"Type\",T0.\"DocEntry\",T0.\"DocNum\",T0.\"DocType\",T0.\"DocCur\" AS \"DocCurrency\",T0.\"DocRate\",T0.\"Series\",T0.\"SlpCode\" AS \"SalesPersonCode\",T2.\"SeriesName\" ");
                stringBuilder.Append(" ,T0.\"CardCode\",T0.\"CardName\",T0.\"NumAtCard\",TO_VARCHAR(T0.\"DocDate\", 'DD-MM-YYYY') \"DocDate\",TO_VARCHAR(T0.\"TaxDate\", 'DD-MM-YYYY') AS \"TaxDate\" ");

                if (type.ToUpper() == "DRAFT")
                {
                    stringBuilder.Append(" ,'Draft' AS \"DocStatus\"");
                }
                else
                {
                    stringBuilder.Append(" ,CASE WHEN \"DocStatus\" = 'O' THEN 'Open' ");
                    stringBuilder.Append(" WHEN \"DocStatus\" = 'C' AND \"CANCELED\" = 'Y' THEN 'Cancelled' ELSE 'Closed' END AS \"DocStatus\"");
                }
                stringBuilder.Append(" ,T0.\"BPLId\" AS \"BPL_IDAssignedToInvoice\",TO_VARCHAR(T0.\"DocDueDate\", 'DD-MM-YYYY') \"DocDueDate\" ");
                stringBuilder.Append(" ,TO_VARCHAR(T0.\"DocDate\", 'DD-MM-YYYY') \"DocDate\" ");
                stringBuilder.Append(" ,TO_VARCHAR(T0.\"TaxDate\", 'DD-MM-YYYY') \"TaxDate\" ");
                stringBuilder.Append(" ,TO_VARCHAR(T0.\"U_InvDate\", 'DD-MM-YYYY') \"U_InvDate\" ");
                stringBuilder.Append(" ,TO_VARCHAR(T0.\"U_GatePassDate\", 'DD-MM-YYYY') \"U_GatePassDate\" ");
                stringBuilder.Append(" ,T0.\"ShipToCode\",T0.\"PayToCode\",T0.\"TrnspCode\" AS \"TransportationCode\" ");
                stringBuilder.Append(" ,T0.\"OwnerCode\" AS \"DocumentsOwner\",T0.\"Comments\" ,T0.\"U_Approval\" ");
                stringBuilder.Append(" ,T0.\"DiscPrcnt\" AS \"DiscountPercent\" ");
                stringBuilder.Append(" ,T0.\"RoundDif\" AS \"RoundingDiffAmount\"  ");

                stringBuilder.Append(" ,CASE WHEN T0.\"DocRate\" = 1 THEN T0.\"VatSum\" ELSE T0.\"VatSumFC\"	END AS \"TaxAmount\" ");
                stringBuilder.Append(" ,CASE WHEN T0.\"DocRate\" = 1 THEN T0.\"DocTotal\" ELSE T0.\"DocTotalFC\" END AS \"DocumentTotal\" ");
                stringBuilder.Append(" ,CASE WHEN T0.\"DocRate\" = 1 THEN T0.\"TotalExpns\" ELSE T0.\"TotalExpFC\" END AS \"TotalExpns\" ");
                stringBuilder.Append(" ,T0.\"TotalExpns\"  ");
                stringBuilder.Append(" ,T0.\"U_LOC\",T0.\"U_BillLoc\",T0.\"U_InvNo\",T0.\"U_GatePassNo\" ,T0.\"U_SAddress\" ,T6.\"LocStatCod\" as \"PlaceOfSupply\"");
                stringBuilder.Append(" ,T0.\"Address\",T0.\"Address2\" ");
                stringBuilder.Append(" ,T3.\"State\" AS \"BillTo_State\",T4.\"State\" AS \"ShipTo_State\"  ");
                stringBuilder.Append(" ,T0.\"U_CRBY\" ");
                stringBuilder.Append(" ,T7.\"GroupNum\" AS \"PaymentGroupCode\", T7.\"PymntGroup\"");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + headerTable + " T0 ");
                stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".NNM1 T2 ON T0.\"Series\" = T2.\"Series\"  ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".CRD1 T3 ON T0.\"CardCode\" = T3.\"CardCode\" AND T0.\"PayToCode\" = T3.\"Address\" AND T3.\"AdresType\"='B'  ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".CRD1 T4 ON T0.\"CardCode\" = T4.\"CardCode\" AND T0.\"ShipToCode\" = T4.\"Address\" AND T4.\"AdresType\"='S'  ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCRD T5 ON T0.\"CardCode\" = T5.\"CardCode\"  ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + "." + taxExtensionTable + " T6 ON T0.\"DocEntry\" = T6.\"DocEntry\"  ");
                //stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCTG T7 ON T5.\"GroupNum\" = T7.\"GroupNum\"  ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCTG T7 ON T0.\"GroupNum\" = T7.\"GroupNum\"  ");
                stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " ");

                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    if (datatable.Rows.Count > 0)
                    {
                        model = ConvertDatatableToList.ConvertToEntity<PurchaseOrderModel>(datatable);
                        if (type.ToUpper() == "DRAFT")
                        {
                            List<ApprovalUsersModel> approvalUsers = commonRepository.GetDraftApprovalUserIDs(docEntry);
                            bool isExists = approvalUsers.Where(a => a.UserID == userId && a.U_IsApp == "Q").Any();
                            if (isExists == true)
                            {
                                model.ShowApproval = "Y";
                            }
                            model.IsEditable = "Y";
                        }
                        model.IsEditable = "Y";
                        model.boolImpORExp = model.ImpORExp == "Y" ? true : false;
                    }
                }

                #region Row
                double docRate = double.Parse(model.DocRate);
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"VisOrder\" + 1 AS \"Index\",T0.\"LineNum\",T0.\"U_QChk\",T0.\"ItemCode\",T0.\"Dscription\" AS \"ItemDescription\",T0.\"Project\" AS \"ProjectCode\"  ");
                stringBuilder.Append(" ,T0.\"WhsCode\" as \"WarehouseCode\",T0.\"LocCode\" as \"LocationCode\", T0.\"U_Category\" , T0.\"Quantity\", T0.\"unitMsr2\", T0.\"Weight1\",T1.\"BWeight1\" as \"ItemWeight\" , T1.\"InvntryUom\", T0.\"U_KgPrice\"");
                stringBuilder.Append(" , T0.\"DiscPrcnt\" AS \"DiscountPercent\",T0.\"TaxCode\", T0.\"U_DocTotal\", T0.\"PriceAfVAT\",  T0.\"VatSum\" ,T2.\"Rate\" AS \"TaxRate\" , T1.\"BuyUnitMsr\"");
                stringBuilder.Append(" ,T0.\"AssblValue\",T1.\"ChapterID\" AS \"HSNEntry\",T3.\"ChapterID\" AS \"ChapterName\", T0.\"U_NoOfUps\" ");
                stringBuilder.Append(" , T0.\"U_JCText\",T0.\"Text\" ,T0.\"U_JOBDTL\",T0.\"OcrCode4\" as \"CostingCode4\" ,T0.\"U_ClientName\"  ");
                if (docRate == 1)
                {
                    stringBuilder.Append(" ,T0.\"PriceBefDi\" AS \"UnitPrice\",T0.\"LineTotal\" AS \"Total\" ");
                }
                else
                {
                    stringBuilder.Append(" ,T0.\"Price\" AS \"UnitPrice\",T0.\"TotalFrgn\" AS \"Total\" ");
                }
                stringBuilder.Append(" ,T0.\"AcctCode\" AS \"AccountCode\",T4.\"AcctName\" AS \"AccountName\" ");
                stringBuilder.Append(" ,T0.\"OcrCode\" AS \"CostingCode\",T0.\"OcrCode2\" AS \"CostingCode2\" ");
                stringBuilder.Append(" ,T0.\"U_JobQty\",T0.\"U_JobRate\",T0.\"Text\" AS \"ItemDetails\" ");
                stringBuilder.Append(" ,T0.\"SacEntry\" AS \"SACEntry\",T5.\"ServCode\" AS \"SacServCode\"  ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + rowTable + " T0 ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OITM T1 ON T0.\"ItemCode\" = T1.\"ItemCode\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OSTC T2 ON T0.\"TaxCode\" = T2.\"Code\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T3 ON T1.\"ChapterID\" = T3.\"AbsEntry\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OACT T4 ON T0.\"AcctCode\" = T4.\"AcctCode\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OSAC T5 ON T0.\"SacEntry\" = T5.\"AbsEntry\" ");
                stringBuilder.Append(" WHERE T0.\"DocEntry\" = :DocEntry ");
                stringBuilder.Append(" ORDER BY T0.\"VisOrder\" ");

                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                {
                    if (datatable.Rows.Count > 0)
                    {
                        List<PurchaseOrderRowsModel> modelRows = ConvertDatatableToList.ConvertToList<PurchaseOrderRowsModel>(datatable);
                        model.DocumentLines = modelRows;
                        model.NetAmount = model.DocumentLines.Select(a => a.Total).Sum();

                        if (datatable.Rows.Count > 0)
                        {
                            if (type.ToUpper() == "DRAFT")
                            {
                                model.IsEditable = "Y";
                            }
                            model.boolImpORExp = model.ImpORExp == "Y" ? true : false;
                        }
                    }
                }
                #endregion

                #region Attachment 
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT  T1.\"trgtPath\",T1.\"FileName\", T1.\"FileExt\", T1.\"Line\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + headerTable + " T0 ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".ATC1 T1 ON T0.\"AtcEntry\" = T1.\"AbsEntry\" ");
                stringBuilder.Append(" WHERE T0.\"DocEntry\" = :DocEntry ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                {
                    if (datatable.Rows.Count > 0)
                    {
                        List<POModel_Attachment> modelRows = ConvertDatatableToList.ConvertToList<POModel_Attachment>(datatable);
                        model.Attachments2_Lines = modelRows;
                        for (int i = 0; i < model.Attachments2_Lines.Count; i++)
                        {
                            model.Attachments2_Lines[i].Index = (i + 1);
                            model.Attachments2_Lines[i].trgtPath += "\\" + model.Attachments2_Lines[i].FileName + "." + model.Attachments2_Lines[i].FileExt;
                        }
                    }
                }
                #endregion

                #region Freight

                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT  T1.\"ExpnsCode\" AS \"ExpenseCode\",T1.\"ExpnsName\" AS \"ExpenseName\" ");
                stringBuilder.Append(" ,T0.\"TaxCode\", T0.\"VatPrcnt\" AS \"TaxPercent\" ");
                if (docRate == 1)
                {
                    stringBuilder.Append(" , T0.\"LineTotal\",T0.\"VatSum\" AS \"TaxSum\", T0.\"GrsAmount\" AS \"LineGross\" ");
                }
                else
                {
                    stringBuilder.Append(" ,T0.\"TotalFrgn\" AS \"LineTotal\",T0.\"VatSumFrgn\" AS \"TaxSum\", T0.\"GrsFC\" AS \"LineGross\" ");
                }
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + freightTable + " T0 ");
                stringBuilder.Append(" RIGHT JOIN " + ConfigManager.GetSAPDatabase() + ".OEXD T1 ON T0.\"ExpnsCode\" = T1.\"ExpnsCode\" AND T0.\"DocEntry\" = :DocEntry ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                {
                    List<POModel_Expenses> modelRows = ConvertDatatableToList.ConvertToList<POModel_Expenses>(datatable);
                    if (modelRows.Count == 0)
                    {
                        POModel_Expenses documentModel_Expenses = new POModel_Expenses();
                        modelRows.Add(documentModel_Expenses);
                    }
                    model.DocumentAdditionalExpenses = modelRows;
                    double? freightAmount = model.TotalExpns;
                    if (freightAmount == 0)
                    {
                        string itemTaxCode = model.DocumentLines.Select(a => a.TaxCode).FirstOrDefault();
                        for (int i = 0; i < model.DocumentAdditionalExpenses.Count; i++)
                        {
                            model.DocumentAdditionalExpenses[i].TaxCode = itemTaxCode;
                        }
                    }
                }
                #endregion
            }
            catch
            {

            }
            return model;
        }
        public ResponseModel Add(PurchaseOrderModel model)
        {
            string headerTable = CommonTables.PurchaseOrderHeaderTable;
            string rowTable = CommonTables.PurchaseOrderRowTable;
            string objectType = Convert.ToString((int)ObjectType.PurchaseOrders);
            ResponseModel responseModel = new ResponseModel();
            ServiceLayer rc = new ServiceLayer();

            string slpcode = commonRepository.GetSlpCodeFromEmailAddress(model.UserId);
            PurchaseOrderModel _objServiceLayer = new PurchaseOrderModel();

            #region Header
            _objServiceLayer.CardCode = model.CardCode;
            _objServiceLayer.CardName = model.CardName;
            _objServiceLayer.Series = model.Series;
            _objServiceLayer.DocCurrency = model.DocCurrency;
            _objServiceLayer.DocRate = model.DocRate;
            _objServiceLayer.U_BillLoc = model.U_BillLoc;
            _objServiceLayer.U_CRBY = model.U_CRBY;
            _objServiceLayer.U_LOC = model.U_LOC;
            _objServiceLayer.DocType = model.DocType;
            string doctype = _objServiceLayer.DocType;
            _objServiceLayer.DocStatus = model.DocStatus;
            _objServiceLayer.NumAtCard = model.NumAtCard;
            _objServiceLayer.Country = model.Country;
            _objServiceLayer.DocNum = model.DocNum;
            _objServiceLayer.BPL_IDAssignedToInvoice = model.BPL_IDAssignedToInvoice;
            _objServiceLayer.PaymentGroupCode = model.PaymentGroupCode;
            _objServiceLayer.DocObjectCode = objectType;

            DateTime dtDocDate = DateTime.ParseExact(model.DocDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
            DateTime dtDocDueDate = DateTime.ParseExact(model.DocDueDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
            DateTime dtTaxDate = DateTime.ParseExact(model.TaxDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
            //DateTime dtinvoiceDate = DateTime.ParseExact(model.U_InvDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
            //DateTime dtgatepassDate = DateTime.ParseExact(model.U_GatePassDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);

            _objServiceLayer.DocDate = dtDocDate.ToString("yyyyMMdd");
            _objServiceLayer.DocDueDate = dtDocDueDate.ToString("yyyyMMdd");
            _objServiceLayer.TaxDate = dtTaxDate.ToString("yyyyMMdd");
            //_objServiceLayer.U_InvDate = dtinvoiceDate.ToString("yyyyMMdd");
            //_objServiceLayer.U_GatePassDate = dtgatepassDate.ToString("yyyyMMdd");

            _objServiceLayer.PayToCode = model.PayToCode;
            _objServiceLayer.ShipToCode = model.ShipToCode;
            //_objServiceLayer.Address = model.Address;
            //_objServiceLayer.Address2 = model.Address2;
            _objServiceLayer.SalesPersonCode = model.SalesPersonCode;
            _objServiceLayer.PlaceOfSupply = model.PlaceOfSupply;

            _objServiceLayer.U_InvNo = model.U_InvNo;
            _objServiceLayer.U_SAddress = model.U_SAddress;
            _objServiceLayer.U_GatePassNo = model.U_GatePassNo;
            _objServiceLayer.SlpName = model.SlpName;
            _objServiceLayer.OwnerCode = model.OwnerCode;
            _objServiceLayer.Comments = model.Comments;
            _objServiceLayer.U_Approval = model.U_Approval;
            _objServiceLayer.DiscountPercent = model.DiscountPercent;
            _objServiceLayer.RoundingDiffAmount = model.RoundingDiffAmount;
            _objServiceLayer.TotalExpns = model.TotalExpns;
            _objServiceLayer.DocumentsOwner = model.DocumentsOwner;
            _objServiceLayer.DocumentTotal = model.DocumentTotal;
            _objServiceLayer.NetAmount = model.NetAmount;
            _objServiceLayer.TaxAmount = model.TaxAmount;

            #endregion

            #region Tax

            _objServiceLayer.DutyStatus = model.DutyStatus;

            #endregion

            #region Item Rows

            int modelRow = 0;
            List<PurchaseOrderRowsModel> modelLines_ServiceLayer = new List<PurchaseOrderRowsModel>();
            model.DocumentLines = model.DocumentLines.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
            for (int i = 0; i < model.DocumentLines.Count; i++)
            {
                if (doctype == "I" && !string.IsNullOrEmpty(model.DocumentLines[i].ItemCode))
                {
                    modelLines_ServiceLayer.Add(new PurchaseOrderRowsModel { });
                    modelLines_ServiceLayer[modelRow].ItemCode = model.DocumentLines[i].ItemCode;
                    modelLines_ServiceLayer[modelRow].U_QChk = model.DocumentLines[i].U_QChk;
                    modelLines_ServiceLayer[modelRow].ProjectCode = model.DocumentLines[i].ProjectCode;
                    modelLines_ServiceLayer[modelRow].ItemDescription = model.DocumentLines[i].ItemDescription;
                    modelLines_ServiceLayer[modelRow].U_Category = string.IsNullOrEmpty(model.DocumentLines[i].U_Category) ? "1004" : model.DocumentLines[i].U_Category;
                    modelLines_ServiceLayer[modelRow].Quantity = model.DocumentLines[i].Quantity;
                    modelLines_ServiceLayer[modelRow].U_ClientName = model.DocumentLines[i].U_ClientName;
                    modelLines_ServiceLayer[modelRow].OnHand = model.DocumentLines[i].OnHand;
                }
                else if (doctype == "S" && !string.IsNullOrEmpty(model.DocumentLines[i].AccountCode))
                {
                    modelLines_ServiceLayer.Add(new PurchaseOrderRowsModel { });
                    modelLines_ServiceLayer[modelRow].AccountCode = model.DocumentLines[i].AccountCode;
                    modelLines_ServiceLayer[modelRow].AccountName = model.DocumentLines[i].AccountName;
                    modelLines_ServiceLayer[modelRow].U_JobQty = model.DocumentLines[i].U_JobQty;
                    modelLines_ServiceLayer[modelRow].U_JobRate = model.DocumentLines[i].U_JobRate;
                    modelLines_ServiceLayer[modelRow].SACEntry = model.DocumentLines[i].SACEntry;
                    modelLines_ServiceLayer[modelRow].U_JOBDTL = model.DocumentLines[i].U_JOBDTL;
                    //modelLines_ServiceLayer[modelRow].OcrCode4 = model.DocumentLines[i].OcrCode4;
                    modelLines_ServiceLayer[modelRow].CostingCode4 = model.DocumentLines[i].CostingCode4;
                }
                modelLines_ServiceLayer[modelRow].ProjectCode = model.DocumentLines[i].ProjectCode == null ? string.Empty : model.DocumentLines[i].ProjectCode;
                modelLines_ServiceLayer[modelRow].ItemDescription = model.DocumentLines[i].ItemDescription;

                modelLines_ServiceLayer[modelRow].unitMsr2 = model.DocumentLines[i].unitMsr2;
                modelLines_ServiceLayer[modelRow].InvntryUom = model.DocumentLines[i].InvntryUom;
                modelLines_ServiceLayer[modelRow].Weight1 = model.DocumentLines[i].Weight1;
                modelLines_ServiceLayer[modelRow].UnitPrice = model.DocumentLines[i].UnitPrice;
                modelLines_ServiceLayer[modelRow].U_KgPrice = model.DocumentLines[i].U_KgPrice;
                modelLines_ServiceLayer[modelRow].DiscountPercent = model.DocumentLines[i].DiscountPercent;
                modelLines_ServiceLayer[modelRow].TaxCode = model.DocumentLines[i].TaxCode;
                modelLines_ServiceLayer[modelRow].U_DocTotal = model.DocumentLines[i].U_DocTotal;
                modelLines_ServiceLayer[modelRow].PriceAfVAT = model.DocumentLines[i].PriceAfVAT;
                modelLines_ServiceLayer[modelRow].Total = model.DocumentLines[i].Total;
                modelLines_ServiceLayer[modelRow].WarehouseCode = model.DocumentLines[i].WarehouseCode;
                modelLines_ServiceLayer[modelRow].VatSum = model.DocumentLines[i].VatSum;
                modelLines_ServiceLayer[modelRow].VatPrcnt = model.DocumentLines[i].VatPrcnt;
                modelLines_ServiceLayer[modelRow].AssblValue = model.DocumentLines[i].AssblValue;
                modelLines_ServiceLayer[modelRow].LocationCode = model.DocumentLines[i].LocationCode;
                modelLines_ServiceLayer[modelRow].ChapterName = model.DocumentLines[i].ChapterName;
                modelLines_ServiceLayer[modelRow].U_NoOfUps = model.DocumentLines[i].U_NoOfUps;
                modelLines_ServiceLayer[modelRow].U_JCText = model.DocumentLines[i].U_JCText;
                modelLines_ServiceLayer[modelRow].ItemDetails = model.DocumentLines[i].ItemDetails;
                modelLines_ServiceLayer[modelRow].CostingCode = model.DocumentLines[i].CostingCode;
                modelLines_ServiceLayer[modelRow].CostingCode2 = model.DocumentLines[i].CostingCode2;
                modelLines_ServiceLayer[modelRow].BuyUnitMsr = model.DocumentLines[i].BuyUnitMsr;

                modelRow++;
            }
            #endregion

            #region Freight
            List<POModel_Expenses> model_Expenses_ServiceLayerList = new List<POModel_Expenses>();
            try
            {
                int expenseRow = 0;
                //model.DocumentAdditionalExpenses = model.DocumentAdditionalExpenses.Where(a => a.LineGross > 0).ToList();
                for (int i = 0; i < model.DocumentAdditionalExpenses.Count; i++)
                {
                    if (model.DocumentAdditionalExpenses[i].LineGross > 0)
                    {
                        model_Expenses_ServiceLayerList.Add(new POModel_Expenses { });
                        model_Expenses_ServiceLayerList[expenseRow].ExpenseCode = model.DocumentAdditionalExpenses[i].ExpenseCode;
                        model_Expenses_ServiceLayerList[expenseRow].TaxCode = model.DocumentAdditionalExpenses[i].TaxCode;
                        model_Expenses_ServiceLayerList[expenseRow].LineTotal = model.DocumentAdditionalExpenses[i].LineTotal;
                        expenseRow++;
                    }
                }
            }
            catch { }
            #endregion

            _objServiceLayer.DocumentLines = modelLines_ServiceLayer;
            _objServiceLayer.DocumentAdditionalExpenses = model_Expenses_ServiceLayerList;

            List<ApprovalUsersModel> approvalUsers = commonRepository.GetApprovalUserIDs(model.OriginatorId, objectType);
            List<DocumentApprovalUsersModel> documentApprovalUsers = commonRepository.GetApprovalUsers(approvalUsers, model);

            string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
            {
                NullValueHandling = NullValueHandling.Ignore,
            });

            string serviceLayerObject = "";
            string res = rc.Login();
            if (res != "" && res.Contains("error") == false)
            {
                if (documentApprovalUsers.Count > 0)
                {
                    serviceLayerObject = ServiceLayerEntity.Drafts.ToString();
                    headerTable = CommonTables.DraftHeaderTable;
                }
                else
                {
                    serviceLayerObject = ServiceLayerEntity.PurchaseOrders.ToString();
                    headerTable = CommonTables.PurchaseOrderHeaderTable;
                }
                rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject;
                rc.patchJSON = main;
                rc.B1SESSION = res;
                string message = "";
                bool result = rc.postRequest(out message);
                responseModel.ResponseStatus = result;
                if (result == true)
                {
                    responseModel.ResponseText = "Operation completed successfully";
                    var jobject = JsonConvert.DeserializeObject<JObject>(message);
                    string docEntry = jobject["DocEntry"].ToString();
                    model.DocEntry = docEntry;
                    responseModel.ResponseEntry = docEntry;
                    commonRepository.UpdateUserSign("Add", headerTable, "DocEntry", docEntry, model.OriginatorId);
                    if (documentApprovalUsers.Count > 0)
                    {
                        AddDocumentApprovalUsers(documentApprovalUsers, docEntry);
                    }
                }
                else
                {
                    var jobject = JsonConvert.DeserializeObject<JObject>(message);
                    string jsonMessage = jobject["error"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["message"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["value"].ToString();
                    responseModel.ResponseText = "Error occured during process: " + jsonMessage;
                }
                rc.LogOut();
            }
            else
            {
                responseModel.ResponseText = "Service layer login failed";
            }
            return responseModel;
        }
        public ResponseModel Update(PurchaseOrderModel model)
        {
            string headerTable = CommonTables.PurchaseOrderHeaderTable;
            string rowTable = CommonTables.PurchaseOrderRowTable;
            string objectType = Convert.ToString((int)ObjectType.PurchaseOrders);
            ResponseModel responseModel = new ResponseModel();
            ServiceLayer rc = new ServiceLayer();

            string slpcode = commonRepository.GetSlpCodeFromEmailAddress(model.UserId);
            PurchaseOrderModel _objServiceLayer = new PurchaseOrderModel();

            #region Header
            _objServiceLayer.CardCode = model.CardCode;
            _objServiceLayer.CardName = model.CardName;
            _objServiceLayer.Series = model.Series;
            _objServiceLayer.DocCurrency = model.DocCurrency;
            _objServiceLayer.DocRate = model.DocRate;
            _objServiceLayer.U_BillLoc = model.U_BillLoc;
            _objServiceLayer.U_LOC = model.U_LOC;
            _objServiceLayer.U_CRBY = model.U_CRBY;
            _objServiceLayer.DocType = model.DocType;
            string doctype = _objServiceLayer.DocType;
            _objServiceLayer.DocStatus = model.DocStatus;
            _objServiceLayer.NumAtCard = model.NumAtCard;
            _objServiceLayer.Country = model.Country;
            _objServiceLayer.DocNum = model.DocNum;
            _objServiceLayer.BPL_IDAssignedToInvoice = model.BPL_IDAssignedToInvoice;
            _objServiceLayer.PaymentGroupCode = model.PaymentGroupCode;
            _objServiceLayer.DocObjectCode = objectType;

            DateTime dtDocDate = DateTime.ParseExact(model.DocDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
            DateTime dtDocDueDate = DateTime.ParseExact(model.DocDueDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
            DateTime dtTaxDate = DateTime.ParseExact(model.TaxDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);

            _objServiceLayer.DocDate = dtDocDate.ToString("yyyyMMdd");
            _objServiceLayer.DocDueDate = dtDocDueDate.ToString("yyyyMMdd");
            _objServiceLayer.TaxDate = dtTaxDate.ToString("yyyyMMdd");
            //try
            //{
            //	//	DateTime dtgatepassDate = DateTime.ParseExact(model.U_GatePassDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
            //	//	_objServiceLayer.U_GatePassDate = dtgatepassDate.ToString("yyyyMMdd");
            //	//}
            //	//catch { }

            //	//try
            //	//{
            //	//	DateTime dtinvoiceDate = DateTime.ParseExact(model.U_InvDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
            //	//	_objServiceLayer.U_InvDate = dtinvoiceDate.ToString("yyyyMMdd");
            //}
            //catch { }
            _objServiceLayer.PayToCode = model.PayToCode;
            _objServiceLayer.ShipToCode = model.ShipToCode;

            //_objServiceLayer.Address = model.Address;
            //_objServiceLayer.Address2 = model.Address2;

            _objServiceLayer.SalesPersonCode = model.SalesPersonCode;
            _objServiceLayer.PlaceOfSupply = model.PlaceOfSupply;

            _objServiceLayer.U_InvNo = model.U_InvNo;
            _objServiceLayer.U_SAddress = model.U_SAddress;
            _objServiceLayer.U_GatePassNo = model.U_GatePassNo;
            _objServiceLayer.SlpName = model.SlpName;
            _objServiceLayer.OwnerCode = model.OwnerCode;
            _objServiceLayer.Comments = model.Comments;
            _objServiceLayer.U_Approval = model.U_Approval;
            _objServiceLayer.DiscountPercent = model.DiscountPercent;
            _objServiceLayer.RoundingDiffAmount = model.RoundingDiffAmount;
            _objServiceLayer.TotalExpns = model.TotalExpns;
            _objServiceLayer.DocumentsOwner = model.DocumentsOwner;
            _objServiceLayer.DocumentTotal = model.DocumentTotal;
            _objServiceLayer.NetAmount = model.NetAmount;
            _objServiceLayer.TaxAmount = model.TaxAmount;

            #endregion

            #region Tax

            //_objServiceLayer.DutyStatus = model.DutyStatus;

            #endregion

            #region Item Rows

            int modelRow = 0;
            List<PurchaseOrderRowsModel> modelLines_ServiceLayer = new List<PurchaseOrderRowsModel>();
            model.DocumentLines = model.DocumentLines.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
            for (int i = 0; i < model.DocumentLines.Count; i++)
            {
                if (doctype == "I" && !string.IsNullOrEmpty(model.DocumentLines[i].ItemCode))
                {
                    modelLines_ServiceLayer.Add(new PurchaseOrderRowsModel { });
                    modelLines_ServiceLayer[modelRow].ItemCode = model.DocumentLines[i].ItemCode;
                    modelLines_ServiceLayer[modelRow].U_QChk = model.DocumentLines[i].U_QChk;
                    modelLines_ServiceLayer[modelRow].ItemDescription = model.DocumentLines[i].ItemDescription;
                    modelLines_ServiceLayer[modelRow].U_Category = string.IsNullOrEmpty(model.DocumentLines[i].U_Category) ? "1004" : model.DocumentLines[i].U_Category;
                    modelLines_ServiceLayer[modelRow].Quantity = model.DocumentLines[i].Quantity;
                    modelLines_ServiceLayer[modelRow].U_ClientName = model.DocumentLines[i].U_ClientName;
                    modelLines_ServiceLayer[modelRow].OnHand = model.DocumentLines[i].OnHand;
                }
                else if (doctype == "S" && !string.IsNullOrEmpty(model.DocumentLines[i].AccountCode))
                {
                    modelLines_ServiceLayer.Add(new PurchaseOrderRowsModel { });
                    modelLines_ServiceLayer[modelRow].AccountCode = model.DocumentLines[i].AccountCode;
                    modelLines_ServiceLayer[modelRow].AccountName = model.DocumentLines[i].AccountName;
                    modelLines_ServiceLayer[modelRow].U_JobQty = model.DocumentLines[i].U_JobQty;
                    modelLines_ServiceLayer[modelRow].U_JobRate = model.DocumentLines[i].U_JobRate;
                    modelLines_ServiceLayer[modelRow].SACEntry = model.DocumentLines[i].SACEntry;
                    modelLines_ServiceLayer[modelRow].U_JOBDTL = model.DocumentLines[i].U_JOBDTL;
                    //modelLines_ServiceLayer[modelRow].OcrCode4 = model.DocumentLines[i].OcrCode4;
                    modelLines_ServiceLayer[modelRow].CostingCode4 = model.DocumentLines[i].CostingCode4;
                }
                modelLines_ServiceLayer[modelRow].ProjectCode = model.DocumentLines[i].ProjectCode == null ? string.Empty : model.DocumentLines[i].ProjectCode;
                modelLines_ServiceLayer[modelRow].ItemDescription = model.DocumentLines[i].ItemDescription;

                modelLines_ServiceLayer[modelRow].unitMsr2 = model.DocumentLines[i].unitMsr2;
                modelLines_ServiceLayer[modelRow].InvntryUom = model.DocumentLines[i].InvntryUom;
                modelLines_ServiceLayer[modelRow].Weight1 = model.DocumentLines[i].Weight1;
                modelLines_ServiceLayer[modelRow].UnitPrice = model.DocumentLines[i].UnitPrice;
                modelLines_ServiceLayer[modelRow].U_KgPrice = model.DocumentLines[i].U_KgPrice;
                modelLines_ServiceLayer[modelRow].DiscountPercent = model.DocumentLines[i].DiscountPercent;
                modelLines_ServiceLayer[modelRow].TaxCode = model.DocumentLines[i].TaxCode;
                modelLines_ServiceLayer[modelRow].U_DocTotal = model.DocumentLines[i].U_DocTotal;
                modelLines_ServiceLayer[modelRow].PriceAfVAT = model.DocumentLines[i].PriceAfVAT;
                modelLines_ServiceLayer[modelRow].Total = model.DocumentLines[i].Total;
                modelLines_ServiceLayer[modelRow].WarehouseCode = model.DocumentLines[i].WarehouseCode;
                modelLines_ServiceLayer[modelRow].VatSum = model.DocumentLines[i].VatSum;
                modelLines_ServiceLayer[modelRow].VatPrcnt = model.DocumentLines[i].VatPrcnt;
                modelLines_ServiceLayer[modelRow].AssblValue = model.DocumentLines[i].AssblValue;
                modelLines_ServiceLayer[modelRow].LocationCode = model.DocumentLines[i].LocationCode;
                modelLines_ServiceLayer[modelRow].ChapterName = model.DocumentLines[i].ChapterName;
                modelLines_ServiceLayer[modelRow].U_NoOfUps = model.DocumentLines[i].U_NoOfUps;
                modelLines_ServiceLayer[modelRow].U_JCText = model.DocumentLines[i].U_JCText == null ? string.Empty : model.DocumentLines[i].U_JCText;
                modelLines_ServiceLayer[modelRow].ItemDetails = model.DocumentLines[i].ItemDetails;
                modelLines_ServiceLayer[modelRow].CostingCode = model.DocumentLines[i].CostingCode;
                modelLines_ServiceLayer[modelRow].CostingCode2 = model.DocumentLines[i].CostingCode2;
                modelLines_ServiceLayer[modelRow].BuyUnitMsr = model.DocumentLines[i].BuyUnitMsr;

                int? lineId = model.DocumentLines[i].LineNum;
                modelLines_ServiceLayer[modelRow].LineNum = lineId;
                modelRow++;
            }
            #endregion

            #region Freight
            List<POModel_Expenses> model_Expenses_ServiceLayerList = new List<POModel_Expenses>();
            try
            {
                int expenseRow = 0;
                //model.DocumentAdditionalExpenses = model.DocumentAdditionalExpenses.Where(a => a.LineGross > 0).ToList();
                for (int i = 0; i < model.DocumentAdditionalExpenses.Count; i++)
                {
                    if (model.DocumentAdditionalExpenses[i].LineGross > 0)
                    {
                        model_Expenses_ServiceLayerList.Add(new POModel_Expenses { });
                        model_Expenses_ServiceLayerList[expenseRow].ExpenseCode = model.DocumentAdditionalExpenses[i].ExpenseCode;
                        model_Expenses_ServiceLayerList[expenseRow].TaxCode = model.DocumentAdditionalExpenses[i].TaxCode;
                        model_Expenses_ServiceLayerList[expenseRow].LineTotal = model.DocumentAdditionalExpenses[i].LineTotal;
                        expenseRow++;
                    }
                }
            }
            catch { }
            #endregion

            _objServiceLayer.DocumentLines = modelLines_ServiceLayer;
            _objServiceLayer.DocumentAdditionalExpenses = model_Expenses_ServiceLayerList;

            string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
            {
                NullValueHandling = NullValueHandling.Ignore,
            });
            string serviceLayerObject = "";
            string res = rc.Login();
            if (res != "" && res.Contains("error") == false)
            {
                if (model.Type.ToUpper() == "DRAFT")
                {
                    serviceLayerObject = ServiceLayerEntity.Drafts.ToString();
                    headerTable = CommonTables.DraftHeaderTable;
                    rowTable = CommonTables.DraftRowTable;
                }
                else
                {
                    serviceLayerObject = ServiceLayerEntity.PurchaseOrders.ToString();
                }
                //serviceLayerObject = ServiceLayerEntity.Drafts.ToString();
                //if (serviceLayerObject.ToUpper() == "DRAFTS")
                //{
                //	headerTable = CommonTables.DraftHeaderTable;
                //}
                //else
                //{
                //	serviceLayerObject = ServiceLayerEntity.Orders.ToString();
                //}
                rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject + "(" + model.DocEntry + ")";
                rc.patchJSON = main;
                rc.B1SESSION = res;
                rc.httpMethod = httpVerb.PATCH;
                string message = "";
                bool result = rc.patchRequest(out message);
                responseModel.ResponseStatus = result;
                if (result == true)
                {
                    responseModel.ResponseText = "Operation completed successfully";
                    var jobject = JsonConvert.DeserializeObject<JObject>(message);
                    commonRepository.UpdateUserSign("Update", headerTable, "DocEntry", model.DocEntry, model.UserId);
                }
                else
                {
                    var jobject = JsonConvert.DeserializeObject<JObject>(message);
                    string jsonMessage = jobject["error"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["message"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["value"].ToString();
                    responseModel.ResponseText = "Error occured during process: " + jsonMessage;
                }
                rc.LogOut();
            }
            else
            {
                responseModel.ResponseText = "Service layer login failed";
            }
            return responseModel;
        }
        public ResponseModel AddDocumentApprovalUsers(List<DocumentApprovalUsersModel> list, string draftEntry)
        {
            string message = "";
            ResponseModel responseModel = new ResponseModel();
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" DELETE FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_DOCAU\" WHERE \"U_DraftEn\"=" + draftEntry + "  ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);

            for (int i = 0; i < list.Count; i++)
            {
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT MAX(Cast(\"Code\" AS INT)) + 1 FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_DOCAU\" ");
                DataTable dt = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
                string code = dt.Rows[0][0].ToString();
                code = code == string.Empty ? "1" : code;
                int rank = i + 1;
                string isApp = "";
                if (rank == 1)
                {
                    // Q : Queue
                    isApp = "Q";
                }
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" INSERT INTO " + ConfigManager.GetSAPDatabase() + ".\"@WEB_DOCAU\" ");
                stringBuilder.Append(" (\"Code\",\"Name\",\"U_DraftEn\",\"U_WtmCode\",\"U_AppUId\",\"U_IsApp\",\"U_Rank\") ");
                stringBuilder.Append(" VALUES('" + code + "','" + code + "','" + draftEntry + "','" + list[i].U_WtmCode + "','" + list[i].U_AppUId + "','" + isApp + "','" + rank.ToString() + "') ");
                FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
                if (message == string.Empty)
                {
                    responseModel.ResponseText = "Operation completed successfully";
                }
                else
                {
                    responseModel.ResponseText = "Error occured during process: " + message;
                }
            }
            return responseModel;
        }

        public ResponseModel UpdateStatus(string docEntry, string status, string userId)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                List<string> list = new List<string>();
                list = docEntry.Split(',').ToList();

                for (int i = 0; i < list.Count; i++)
                {
                    docEntry = list[i].ToString();
                    UpdateDate(docEntry);

                    HanaParameter[] parameters = new HanaParameter[3];
                    int iParameter = 0;
                    parameters[iParameter] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
                    parameters[iParameter].Value = docEntry;
                    iParameter++;

                    parameters[iParameter] = new HanaParameter("Status", System.Data.SqlDbType.VarChar);
                    parameters[iParameter].Value = status;
                    iParameter++;

                    parameters[iParameter] = new HanaParameter("UserId", System.Data.SqlDbType.VarChar);
                    parameters[iParameter].Value = userId;
                    iParameter++;

                    string query = "UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_DOCAU\" SET \"U_IsApp\"= :Status WHERE \"U_DraftEn\" = :DocEntry AND  \"U_AppUId\" = :UserId ";
                    FillDataTable(query, CommandType.Text, out string message, parameters);
                    if (message == string.Empty)
                    {
                        responseModel.ResponseStatus = true;
                        responseModel.ResponseText = "Operation completed successfully";
                        if (status == "Y")
                        {
                            int noofApproval = 0;
                            query = "SELECT \"Code\" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_DOCAU\" WHERE \"U_DraftEn\" = " + docEntry + " ";
                            using (DataTable dtCount = FillDataTable(query, CommandType.Text, out message))
                            {
                                noofApproval = dtCount.Rows.Count;
                            }

                            query = "SELECT \"Code\" FROM " + ConfigManager.GetSAPDatabase() + ".\"@WEB_DOCAU\" WHERE (\"U_IsApp\" IS NULL OR \"U_IsApp\" = 'N' OR \"U_IsApp\" = 'Q' OR \"U_IsApp\" = '') AND \"U_DraftEn\" = " + docEntry + " ";
                            DataTable dt = FillDataTable(query, CommandType.Text, out message);
                            if (dt.Rows.Count == 0)
                            {
                                #region If already created then continue

                                query = "SELECT \"DocEntry\" FROM  " + ConfigManager.GetSAPDatabase() + ".OPOR WHERE \"draftKey\" = " + docEntry + " ";
                                using (DataTable dtOpor = FillDataTable(query, CommandType.Text, out message))
                                {
                                    if (dtOpor.Rows.Count > 0)
                                    {
                                        continue;
                                    }
                                }
                                #endregion

                                responseModel = DraftsService_SaveDraftToDocument(docEntry);
                                if (responseModel.ResponseStatus == true)
                                {
                                    //query = "UPDATE " + ConfigManager.GetSAPDatabase() + ".ODRF SET \"U_IsApp\"= 'Y' WHERE \"DocEntry\" = " + docEntry + " ";
                                    //FillDataTable(query, CommandType.Text, out message);
                                    if (noofApproval == 1)
                                    {
                                        query = "UPDATE " + ConfigManager.GetSAPDatabase() + ".OPOR SET \"U_AppBy\"= '" + userId + "' WHERE \"draftKey\" = " + docEntry + " ";
                                        FillDataTable(query, CommandType.Text, out message);
                                    }
                                    else
                                    {
                                        query = "UPDATE " + ConfigManager.GetSAPDatabase() + ".OPOR SET \"U_AuthBy\"= '" + userId + "' WHERE \"draftKey\" = " + docEntry + " ";
                                        FillDataTable(query, CommandType.Text, out message);
                                    }
                                    commonRepository.UpdateUserSign("Add", "OPOR", "draftKey", docEntry, userId);
                                }
                                else
                                {
                                    query = "UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_DOCAU\" SET \"U_IsApp\"= 'Q' WHERE \"U_DraftEn\" = " + docEntry + " AND  \"U_AppUId\" = " + userId + " ";
                                    FillDataTable(query, CommandType.Text, out message, parameters);
                                }
                            }
                            else
                            {
                                query = "UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@WEB_DOCAU\" SET \"U_IsApp\"= 'Q' WHERE \"U_DraftEn\" = " + docEntry + " AND (\"U_IsApp\" IS NULL OR \"U_IsApp\"='') ";
                                FillDataTable(query, CommandType.Text, out message);

                                query = "UPDATE " + ConfigManager.GetSAPDatabase() + ".ODRF SET \"U_AppBy\"= '" + userId + "' WHERE \"DocEntry\" = " + docEntry + " ";
                                FillDataTable(query, CommandType.Text, out message);
                            }
                        }
                    }
                    else
                    {
                        responseModel.ResponseText = "PO DocEntry: " + docEntry + " Error occured while processing record " + message;
                        responseModel.ResponseStatus = false;
                    }
                }
            }
            catch (Exception ex)
            {
                responseModel.ResponseText = "PO DocEntry: " + docEntry + " Error occured while processing record " + ex.Message;
                responseModel.ResponseStatus = false;
            }
            return responseModel;
        }

        public ResponseModel DraftsService_SaveDraftToDocument(string docEntry)
        {
            ResponseModel responseModel = new ResponseModel();
            ServiceLayer rc = new ServiceLayer();
            string res = rc.Login();
            if (res != "" && res.Contains("error") == false)
            {
                DocumentModel_SaveDraftToDocument _objServiceLayer = new DocumentModel_SaveDraftToDocument();
                DraftDocument draftDocument = new DraftDocument();
                draftDocument.DocEntry = docEntry;
                _objServiceLayer.Document = draftDocument;
                string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
                {
                    NullValueHandling = NullValueHandling.Ignore,
                });
                rc.endPoint = ConfigManager.GetServiceLayerURL() + "DraftsService_SaveDraftToDocument";
                rc.patchJSON = main;
                rc.B1SESSION = res;
                rc.httpMethod = httpVerb.POST;
                string message = "";
                bool result = rc.postRequest(out message);
                responseModel.ResponseStatus = result;
                if (result == true)
                {
                    responseModel.ResponseText = "Operation completed successfully";
                }
                else
                {
                    var jobject = JsonConvert.DeserializeObject<JObject>(message);
                    string jsonMessage = jobject["error"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["message"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["value"].ToString();
                    responseModel.ResponseText = "Error occured during process: " + jsonMessage;
                }
            }
            return responseModel;
        }

        public void IsApprovalApplicable(PurchaseOrderModel model)
        {
            string objectType = Convert.ToString((int)ObjectType.PurchaseOrders);
            List<ApprovalUsersModel> approvalUsers = commonRepository.GetApprovalUserIDs(model.OriginatorId, objectType);
            List<DocumentApprovalUsersModel> documentApprovalUsers = commonRepository.GetApprovalUsers(approvalUsers, model);
            if (documentApprovalUsers.Count > 0)
            {
                AddDocumentApprovalUsers(documentApprovalUsers, model.DocEntry);
            }
        }

        public void UpdateDate(string docEntry)
        {

            HanaParameter[] parameters = new HanaParameter[2];
            int iParameter = 0;
            parameters[iParameter] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
            parameters[iParameter].Value = docEntry;
            iParameter++;

            parameters[iParameter] = new HanaParameter("DocDate", System.Data.SqlDbType.VarChar);
            parameters[iParameter].Value = DateTime.Now.Date;
            iParameter++;

            string query = "UPDATE " + ConfigManager.GetSAPDatabase() + ".ODRF SET \"DocDate\"= :DocDate WHERE \"DocEntry\" = :DocEntry ";
            FillDataTable(query, CommandType.Text, out string message, parameters);
        }

        public ResponseModel Cancel(string docEntry)
        {
            ResponseModel responseModel = new ResponseModel();
            ServiceLayer rc = new ServiceLayer();
            string res = rc.Login();
            if (res != "" && res.Contains("error") == false)
            {
                DocumentModel_SaveDraftToDocument _objServiceLayer = new DocumentModel_SaveDraftToDocument();
                DraftDocument draftDocument = new DraftDocument();
                draftDocument.DocEntry = docEntry;
                _objServiceLayer.Document = draftDocument;
                string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
                {
                    NullValueHandling = NullValueHandling.Ignore,
                });
                rc.endPoint = ConfigManager.GetServiceLayerURL() + ServiceLayerEntity.PurchaseOrders.ToString() + "(" + docEntry + ")/Cancel";
                rc.patchJSON = main;
                rc.B1SESSION = res;
                rc.httpMethod = httpVerb.POST;
                string message = "";
                bool result = rc.postRequest(out message);
                responseModel.ResponseStatus = result;
                if (result == true)
                {
                    responseModel.ResponseText = "Operation completed successfully";
                }
                else
                {
                    var jobject = JsonConvert.DeserializeObject<JObject>(message);
                    string jsonMessage = jobject["error"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["message"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["value"].ToString();
                    responseModel.ResponseText = "Error occured during process: " + jsonMessage;
                }
                rc.LogOut();
            }
            return responseModel;
        }
        public ResponseModel Close(string docEntry)
        {
            ResponseModel responseModel = new ResponseModel();
            ServiceLayer rc = new ServiceLayer();
            string res = rc.Login();
            if (res != "" && res.Contains("error") == false)
            {
                DocumentModel_SaveDraftToDocument _objServiceLayer = new DocumentModel_SaveDraftToDocument();
                DraftDocument draftDocument = new DraftDocument();
                draftDocument.DocEntry = docEntry;
                _objServiceLayer.Document = draftDocument;
                string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
                {
                    NullValueHandling = NullValueHandling.Ignore,
                });
                rc.endPoint = ConfigManager.GetServiceLayerURL() + ServiceLayerEntity.PurchaseOrders.ToString() + "(" + docEntry + ")/Close";
                rc.patchJSON = main;
                rc.B1SESSION = res;
                rc.httpMethod = httpVerb.POST;
                string message = "";
                bool result = rc.postRequest(out message);
                responseModel.ResponseStatus = result;
                if (result == true)
                {
                    responseModel.ResponseText = "Operation completed successfully";
                }
                else
                {
                    var jobject = JsonConvert.DeserializeObject<JObject>(message);
                    string jsonMessage = jobject["error"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["message"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["value"].ToString();
                    responseModel.ResponseText = "Error occured during process: " + jsonMessage;
                }
                rc.LogOut();
            }
            return responseModel;
        }

        public ResponseModel UpdateLineStatus(string docEntry, int linenum)
        {
            ResponseModel responseModel = new ResponseModel();
            string res = "";
            ServiceLayer rc = new ServiceLayer();
            res = rc.Login();
            if (res != "" && res.Contains("error") == false)
            {
                DocumentModel_LineStatus_Close _objServiceLayer = new DocumentModel_LineStatus_Close();
                List<DocumentModel_LineStatus_CloseLines> _objServiceLayerLinesList = new List<DocumentModel_LineStatus_CloseLines>();

                DocumentModel_LineStatus_CloseLines _objServiceLayerLines = new DocumentModel_LineStatus_CloseLines();
                _objServiceLayerLines.LineNum = linenum;
                _objServiceLayerLines.LineStatus = "bost_Close";
                _objServiceLayerLinesList.Add(_objServiceLayerLines);
                _objServiceLayer.DocumentLines = _objServiceLayerLinesList;

                string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
                {
                    NullValueHandling = NullValueHandling.Ignore,
                });
                rc.endPoint = ConfigManager.GetServiceLayerURL() + ServiceLayerEntity.PurchaseOrders.ToString() + "(" + docEntry + ")";
                rc.patchJSON = main;
                rc.B1SESSION = res;
                rc.httpMethod = httpVerb.PATCH;
                string message = "";
                bool result = rc.postRequest(out message);
                responseModel.ResponseStatus = result;
                if (result == true)
                {
                    var jobject = JsonConvert.DeserializeObject<JObject>(message);
                    responseModel.ResponseText = "Operation completed successfully";
                }
                else
                {
                    var jobject = JsonConvert.DeserializeObject<JObject>(message);
                    string jsonMessage = jobject["error"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["message"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["value"].ToString();
                    responseModel.ResponseText = "Purchase Order DocEntry:" + docEntry.ToString() + " Error occured during process: " + jsonMessage;
                }
            }
            return responseModel;
        }

        public int GetOpenDocumentRowCount(string docEntry)
        {
            int count = 0;
            try
            {
                HanaParameter[] parameters = new HanaParameter[1];
                int iParameter = 0;
                parameters[iParameter] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
                parameters[iParameter].Value = docEntry;
                iParameter++;
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT \"DocEntry\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + CommonTables.PurchaseOrderRowTable + " ");
                stringBuilder.Append(" WHERE \"DocEntry\" = :DocEntry AND \"LineStatus\" ='O' ");
                using (DataTable dt = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                {
                    count = dt.Rows.Count;
                }
            }
            catch (Exception ex)
            {
            }
            return count;
        }
    }
}