﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Reflection.Emit;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sap.Data.Hana;
using WebDAL.Helper;
using WebDAL.Helpers;
using WebDAL.IRepository;
using WebDAL.Models;
using static System.Net.Mime.MediaTypeNames;

namespace WebDAL.Repository
{
    public class ItemMasterRepository : clsDataAccess, IItemMasterRepository
    {
        CommonRepository commonRepository = new CommonRepository();
        StringBuilder stringBuilder = new StringBuilder();
        const string headerTable = "OITM";
        string message = "";
        public List<ItemModel> GetAll(int noofRows, string itembrand)
        {
            List<ItemModel> _list = new List<ItemModel>();
            try
            {
                stringBuilder = new StringBuilder();
                //if (noofRows > 0)
                //{
                //	stringBuilder.Append(" SELECT TOP " + noofRows + "");
                //}
                //else
                //{
                //}
                stringBuilder.Append(" SELECT ");
                stringBuilder.Append(" T0.\"DocEntry\", T0.\"ItemCode\", T0.\"ItemName\", T1.\"ItmsGrpNam\",T0.\"SalUnitMsr\" AS  \"UOM\",T0.\"ChapterID\",T2.\"ChapterID\" as \"ChapterName\",  ");
                stringBuilder.Append(" CASE WHEN T0.\"TreeType\"='S' THEN 'Sales'  ");
                stringBuilder.Append("  WHEN T0.\"TreeType\"='P' THEN 'Production'  ");
                stringBuilder.Append("  WHEN T0.\"TreeType\"='N' THEN 'Not BOM' END \"TreeType\",  ");
                stringBuilder.Append("  \"U_CustName\",\"OnHand\",\"U_PrintItemDesc\",\"U_ARTSTT\",\"CreateDate\",T0.\"U_KLDNo\",   ");
                stringBuilder.Append(" CASE WHEN T0.\"validFor\"='Y' THEN 'Yes' ELSE 'No' END \"validFor\" ");
                //stringBuilder.Append(" CASE WHEN T0.\"U_A4SO\"='Y' THEN 'Yes' ELSE 'No' END \"U_A4SO\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
                stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OITB T1 ON T0.\"ItmsGrpCod\" = T1.\"ItmsGrpCod\" ");
                stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T2 ON T0.\"ChapterID\" = T2.\"AbsEntry\" ");

                stringBuilder.Append(" WHERE T1.\"U_ItmBrand\" = '" + itembrand + "' ");
                //stringBuilder.Append(" WHERE T1.\"ItmsGrpNam\" LIKE 'FG%' OR UPPER(T1.\"ItmsGrpNam\") LIKE '%OTH%' ");
                //stringBuilder.Append(" OR T1.\"ItmsGrpNam\" IN ('Packing Material Internal','RMS') ");
                stringBuilder.Append(" ORDER BY T0.\"DocEntry\" DESC ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    _list = ConvertDatatableToList.ConvertToList<ItemModel>(datatable);
                    //if (noofRows > 0)
                    //{
                    //	_list = _list.Take(noofRows).OrderByDescending(a => a.DocEntry).ToList();
                    //}
                }
            }
            catch
            {

            }
            return _list;
        }

        public ItemMasterModel Get(string itemcode)
        {
            ItemMasterModel model = new ItemMasterModel();
            try
            {
                string docEntry = "";
                HanaParameter[] parameters = new HanaParameter[1];
                parameters[0] = new HanaParameter("ItemCode", System.Data.SqlDbType.VarChar);
                parameters[0].Value = itemcode;
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.*, ");
                stringBuilder.Append(" T1.\"Dscription\" AS \"HSNName\",  ");
                stringBuilder.Append(" T1.\"ChapterID\" AS \"HSNChapterID\" ,  ");
                stringBuilder.Append(" T2.\"U_ItmBrand\" AS \"ItemGroup_ItemBrand\"  ");

                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T1 ON T0.\"ChapterID\" = T1.\"AbsEntry\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OITB T2 ON T0.\"ItmsGrpCod\" = T2.\"ItmsGrpCod\" ");

                stringBuilder.Append(" WHERE T0.\"ItemCode\" = :ItemCode ");

                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                {
                    model = ConvertDatatableToList.ConvertToEntity<ItemMasterModel>(datatable);

                    #region Header
                    docEntry = datatable.Rows[0]["DocEntry"].ToString();
                    model.DocEntry = docEntry;
                    model.AtcEntry = datatable.Rows[0]["AtcEntry"].ToString();
                    model.ForeignName = datatable.Rows[0]["FrgnName"].ToString();
                    model.ItemsGroupCode = datatable.Rows[0]["ItmsGrpCod"].ToString();

                    if (datatable.Rows[0]["InvntItem"].ToString() == "Y")
                    {
                        model.IsInventoryItem = true;
                    }
                    if (datatable.Rows[0]["SellItem"].ToString() == "Y")
                    {
                        model.IsSalesItem = true;
                    }
                    if (datatable.Rows[0]["PrchseItem"].ToString() == "Y")
                    {
                        model.IsPurchaseItem = true;
                    }
                    model.UoMGroupEntry = datatable.Rows[0]["UgpEntry"].ToString();
                    if (model.UoMGroupEntry == "-1")
                    {
                        model.PricingUnit = "-1";
                    }
                    else
                    {
                        model.PricingUnit = datatable.Rows[0]["PriceUnit"].ToString();
                    }
                    #endregion

                    #region General

                    model.ManageItemBy = "0";
                    string managedBySeries = datatable.Rows[0]["ManSerNum"].ToString();
                    string managedByBatch = datatable.Rows[0]["ManBtchNum"].ToString();
                    if (managedBySeries == "Y")
                    {
                        model.ManageItemBy = "1";
                    }
                    if (managedByBatch == "Y")
                    {
                        model.ManageItemBy = "2";
                    }

                    model.Valid = datatable.Rows[0]["ValidFor"].ToString();
                    model.U_A4SO = datatable.Rows[0]["U_A4SO"].ToString();
                    model.MaterialType = datatable.Rows[0]["MatType"].ToString();
                    model.GSTTaxCategory = datatable.Rows[0]["GstTaxCtg"].ToString();
                    model.HSNName = datatable.Rows[0]["HSNName"].ToString();
                    model.ChapterID = datatable.Rows[0]["HSNChapterID"].ToString();
                    model.SACEntry = datatable.Rows[0]["ChapterID"].ToString();
                    model.SWW = datatable.Rows[0]["SWW"].ToString();
                    model.U_HSNCode = datatable.Rows[0]["U_HSNCode"].ToString();


                    #endregion

                    #region Purchasing

                    model.PurchaseUnit = datatable.Rows[0]["BuyUnitMsr"].ToString();

                    //model.PurchaseUnit = datatable.Rows[0]["BuyUnitMsr"].ToString();
                    model.BuyUnitMsr = datatable.Rows[0]["BuyUnitMsr"].ToString();
                    model.PurchaseItemsPerUnit = datatable.Rows[0]["NumInBuy"].ToString();
                    //model.PurchasePackagingUnit = datatable.Rows[0]["PurPackMsr"].ToString();
                    model.PurchaseQtyPerPackUnit = datatable.Rows[0]["PurPackUn"].ToString();

                    model.PurchasePackagingUnit = datatable.Rows[0]["PurPackMsr"].ToString();
                    //model.PurchaseQtyPerPackUnit = datatable.Rows[0]["PurPackMsr"].ToString();
                    model.PurchaseUnitWeight = datatable.Rows[0]["BWeight1"].ToString();

                    #endregion

                    #region Sales

                    model.SalesUnit = datatable.Rows[0]["SalUnitMsr"].ToString();
                    model.SalesUnitMsr = datatable.Rows[0]["SalUnitMsr"].ToString();
                    //model.SalesItemsPerUnit = datatable.Rows[0]["NumInSal"].ToString();
                    //model.SalesPackagingUnit = datatable.Rows[0]["SalPackMsr"].ToString();
                    //model.SalesQtyPerPackUnit = datatable.Rows[0]["SalPackUn"].ToString();

                    #endregion

                    #region Inventory Data

                    model.GLMethod = datatable.Rows[0]["GLMethod"].ToString();
                    model.InventoryUOM = datatable.Rows[0]["InvntryUom"].ToString();
                    model.CostAccountingMethod = datatable.Rows[0]["EvalSystem"].ToString();
                    //model.ManageStockByWarehouse = datatable.Rows[0]["ByWhs"].ToString();
                    model.DefaultWarehouse = datatable.Rows[0]["DfltWH"].ToString();

                    #endregion

                    #region Properties

                    if (datatable.Rows[0]["QryGroup1"].ToString() == "Y")
                    {
                        model.IsProperties1 = true;
                    }
                    if (datatable.Rows[0]["QryGroup2"].ToString() == "Y")
                    {
                        model.IsProperties2 = true;
                    }
                    #endregion

                    string treeType = datatable.Rows[0]["TreeType"].ToString();
                    if (treeType == "P")
                    {
                        model.IsEditable = "N";
                    }
                }
                #region Attachment 


                parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
                parameters[0].Value = docEntry;

                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT  T1.\"trgtPath\",T1.\"FileName\", T1.\"FileExt\", T1.\"Line\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".OITM T0 ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".ATC1 T1 ON T0.\"AtcEntry\" = T1.\"AbsEntry\" ");
                stringBuilder.Append(" WHERE T0.\"DocEntry\" = :DocEntry ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                {
                    if (datatable.Rows.Count > 0)
                    {
                        List<DocumentModel_Attachment> modelRows = ConvertDatatableToList.ConvertToList<DocumentModel_Attachment>(datatable);
                        model.Attachments2_Lines = modelRows;
                        for (int i = 0; i < model.Attachments2_Lines.Count; i++)
                        {
                            model.Attachments2_Lines[i].Index = (i + 1);
                            model.Attachments2_Lines[i].trgtPath += "\\" + model.Attachments2_Lines[i].FileName + "." + model.Attachments2_Lines[i].FileExt;
                        }
                    }
                }
                #endregion

            }
            catch
            {

            }
            return model;
        }

        public ResponseModel Add(ItemMasterModel model)
        {
            ResponseModel responseModel = new ResponseModel();
            ServiceLayer rc = new ServiceLayer();
            string res = rc.Login();
            if (res != "" && res.Contains("error") == false)
            {
                ItemMasterModel_ServiceLayer _objServiceLayer = new ItemMasterModel_ServiceLayer();
                #region Header

                _objServiceLayer.ItemName = model.ItemName;
                _objServiceLayer.ForeignName = model.ForeignName;
                _objServiceLayer.InventoryItem = model.IsInventoryItem == true ? "tYES" : "tNO";
                _objServiceLayer.SalesItem = model.IsSalesItem == true ? "tYES" : "tNO";
                _objServiceLayer.PurchaseItem = model.IsPurchaseItem == true ? "tYES" : "tNO";
                _objServiceLayer.ItemType = GetItemType_ServiceValue(model.ItemType);
                _objServiceLayer.ItemsGroupCode = model.ItemsGroupCode;
                _objServiceLayer.UoMGroupEntry = model.UoMGroupEntry;
                if (model.UoMGroupEntry == "-1")
                {
                    _objServiceLayer.PricingUnit = "-1";
                }
                else
                {
                    _objServiceLayer.PricingUnit = model.PricingUnit;
                }
                _objServiceLayer.SWW = model.SWW;
                _objServiceLayer.ShipType = model.ShipType;

                _objServiceLayer.Valid = model.Valid == "Y" ? "tYES" : "tNO";
                //_objServiceLayer.U_A4SO = model.U_A4SO == "Yes" ? "tYES" : "tNO";
                _objServiceLayer.U_A4SO = model.U_A4SO;
                _objServiceLayer.GSTRelevnt = model.GSTRelevnt == "Y" ? "tYES" : "tNO";
                _objServiceLayer.MaterialType = GetMaterialType_ServiceValue(model.MaterialType);
                _objServiceLayer.GSTTaxCategory = GetTaxCategory_ServiceValue(model.GSTTaxCategory);
                _objServiceLayer.ChapterID = model.SACEntry;
                _objServiceLayer.DefaultWarehouse = model.DefaultWarehouse;
                if (model.ManageItemBy != null)
                {
                    if (model.ManageItemBy == "1")
                    {
                        _objServiceLayer.ManageSerialNumbers = "tYES";

                    }
                    if (model.ManageItemBy == "2")
                    {
                        _objServiceLayer.ManageBatchNumbers = "tYES";
                        model.CostAccountingMethod = "B";

                    }
                }
                #endregion

                #region Purchasing

                _objServiceLayer.PurchaseUnit = model.PurchaseUnit;
                //_objServiceLayer.BuyUnitMsr = model.PurchaseUnit;
                _objServiceLayer.PurchaseItemsPerUnit = model.PurchaseItemsPerUnit;
                _objServiceLayer.PurchasePackagingUnit = model.PurchasePackagingUnit;
                _objServiceLayer.PurchaseQtyPerPackUnit = model.PurchaseQtyPerPackUnit;
                _objServiceLayer.PurchaseUnitWeight = model.PurchaseUnitWeight;

                #endregion

                #region Sales

                if (model.UoMGroupEntry == "-1")
                {
                    _objServiceLayer.SalesUnit = model.SalesUnitMsr;
                }
                else
                {
                    _objServiceLayer.DefaultSalesUoMEntry = commonRepository.GetUOMAbsEntry(model.SalesUnit);
                    _objServiceLayer.SalesUnit = model.SalesUnit;
                }

                //_objServiceLayer.SalesItemsPerUnit = model.SalesItemsPerUnit;
                //_objServiceLayer.SalesPackagingUnit = model.SalesPackagingUnit;
                //_objServiceLayer.SalesQtyPerPackUnit = model.SalesQtyPerPackUnit;

                #endregion

                #region Inventory Data

                try
                {
                    if (model.UoMGroupEntry == "-1")
                    {
                        _objServiceLayer.InventoryUOM = model.InventoryUOM;
                    }
                    else
                    {
                        _objServiceLayer.DefaultCountingUoMEntry = commonRepository.GetUOMAbsEntry(model.InventoryUOM);
                        _objServiceLayer.DefaultCountingUnit = model.InventoryUOM;
                    }
                }
                catch { }

                _objServiceLayer.GLMethod = GetGLMethod_ServiceValue(model.GLMethod);
                _objServiceLayer.CostAccountingMethod = GetCostAccountingMethod_ServiceValue(model.CostAccountingMethod);
                //_objServiceLayer.ManageStockByWarehouse = model.ManageStockByWarehouse == "Y" ? "tYES" : "tNO";
                _objServiceLayer.SRIAndBatchManageMethod = "bomm_OnEveryTransaction";
                #endregion

                #region Properties

                _objServiceLayer.Properties1 = model.IsProperties1 == true ? "tYES" : "tNO";
                _objServiceLayer.Properties2 = model.IsProperties2 == true ? "tYES" : "tNO";

                _objServiceLayer.U_FLEXO1 = model.IsProperties1 == true ? "Flexo Yes" : "Flexo No";

				#endregion

				#region UDF
				try
				{
                    _objServiceLayer.U_Company = model.U_Company;
                    _objServiceLayer.U_PaperGSM = model.U_PaperGSM;
                    _objServiceLayer.U_Microns = model.U_Microns;
                    _objServiceLayer.U_Brand = model.U_Brand;
                    _objServiceLayer.U_LamiType = model.U_LamiType;
                    _objServiceLayer.U_Finishing = model.U_Finishing;
                    _objServiceLayer.U_DickleSize = model.U_DickleSize;
                    _objServiceLayer.U_Ply = model.U_Ply;
                    _objServiceLayer.U_CartType = model.U_CartType;
                    _objServiceLayer.U_BPName = model.U_BPName;
                    _objServiceLayer.U_QChk = model.U_QChk;
                    _objServiceLayer.U_MacItem = model.U_MacItem;
                    _objServiceLayer.U_ByPrd = model.U_ByPrd;
                    _objServiceLayer.U_SmplPer = model.U_SmplPer;
                    _objServiceLayer.U_BurStr = model.U_BurStr;
                    _objServiceLayer.U_MatType = model.U_MatType;
                    _objServiceLayer.U_SheetSizeX = model.U_SheetSizeX;
                    _objServiceLayer.U_SheetSizeY = model.U_SheetSizeY;
                    _objServiceLayer.U_ItmNat = model.U_ItmNat;
                    _objServiceLayer.U_Industry = model.U_Industry;
                    _objServiceLayer.U_CustCode = model.U_CustCode;
                    _objServiceLayer.U_CustName = model.U_CustName;
                    _objServiceLayer.U_TypeOfProduct = model.U_TypeOfProduct;
                    _objServiceLayer.U_TypeOfFlute = model.U_TypeOfFlute;
                    _objServiceLayer.U_Profile = model.U_Profile;
                    _objServiceLayer.U_NoOfUps = model.U_NoOfUps;
                    _objServiceLayer.U_TypeOfSubstrate = model.U_TypeOfSubstrate;
                    _objServiceLayer.U_Matelized = model.U_Matelized;
                    _objServiceLayer.U_NoOfColors = model.U_NoOfColors;
                    _objServiceLayer.U_InkDesc = model.U_InkDesc;
                    _objServiceLayer.U_PantoneNo = model.U_PantoneNo;
                    _objServiceLayer.U_TypeOfVarnish = model.U_TypeOfVarnish;
                    _objServiceLayer.U_VarnishNo = model.U_VarnishNo;
                    _objServiceLayer.U_SpotVarnish = model.U_SpotVarnish;
                    _objServiceLayer.U_VarnishGSM = model.U_VarnishGSM;
                    _objServiceLayer.U_NoOfPasses = model.U_NoOfPasses;
                    _objServiceLayer.U_TypeOfLami = model.U_TypeOfLami;
                    _objServiceLayer.U_ThicknessOfLami = model.U_ThicknessOfLami;
                    _objServiceLayer.U_SurfaceFinish = model.U_SurfaceFinish;
                    _objServiceLayer.U_LamiAdhesive = model.U_LamiAdhesive;
                    _objServiceLayer.U_DiePunch = model.U_DiePunch;
                    _objServiceLayer.U_Embossing = model.U_Embossing;
                    _objServiceLayer.U_MCODE = model.U_MCODE;
                    _objServiceLayer.U_MNAME = model.U_MNAME;
                    _objServiceLayer.U_WinPatch = model.U_WinPatch;
                    _objServiceLayer.U_TypeOfFilm = model.U_TypeOfFilm;
                    _objServiceLayer.U_ThicknessOfFilm = model.U_ThicknessOfFilm;
                    _objServiceLayer.U_WinPatAdhesive = model.U_WinPatAdhesive;
                    _objServiceLayer.U_BoxLength = model.U_BoxLength;
                    _objServiceLayer.U_BoxWidth = model.U_BoxWidth;
                    _objServiceLayer.U_BoxHeight = model.U_BoxHeight;
                    _objServiceLayer.U_PrintingSide = model.U_PrintingSide;
                    _objServiceLayer.U_VCode = model.U_VCode;
                    _objServiceLayer.U_Variant = model.U_Variant;
                    _objServiceLayer.U_SCode = model.U_SCode;
                    _objServiceLayer.U_Size = model.U_Size;
                    _objServiceLayer.U_PCode = model.U_PCode;
                    _objServiceLayer.U_Repeat = model.U_Repeat;
                    _objServiceLayer.U_OpenLength = model.U_OpenLength;
                    _objServiceLayer.U_OpenWidth = model.U_OpenWidth;
                    _objServiceLayer.U_BCode = model.U_BCode;
                    _objServiceLayer.U_Corr_Length = model.U_Corr_Length;
                    _objServiceLayer.U_Corr_Width = model.U_Corr_Width;
                    _objServiceLayer.U_Corr_Height = model.U_Corr_Height;
                    _objServiceLayer.U_AddiInfo = model.U_AddiInfo;
                    _objServiceLayer.U_PrintItemDesc = model.U_PrintItemDesc;
                    _objServiceLayer.U_Yield = model.U_Yield;
                    _objServiceLayer.U_Grain = model.U_Grain;
                    _objServiceLayer.U_DieCutting = model.U_DieCutting;
                    _objServiceLayer.U_Pasting = model.U_Pasting;
                    _objServiceLayer.U_PastingInst = model.U_PastingInst;
                    _objServiceLayer.U_LeafletFold = model.U_LeafletFold;
                    _objServiceLayer.U_VertFold = model.U_VertFold;
                    _objServiceLayer.U_HoriFold = model.U_HoriFold;
                    _objServiceLayer.U_LeftletInst = model.U_LeftletInst;
                    _objServiceLayer.U_KLDNo = model.U_KLDNo;
                    _objServiceLayer.U_Cutting = model.U_Cutting;
                    _objServiceLayer.U_VarnishInst = model.U_VarnishInst;
                    _objServiceLayer.U_LamiInst = model.U_LamiInst;
                    _objServiceLayer.U_CuttingInst = model.U_CuttingInst;
                    _objServiceLayer.U_Trial = model.U_Trial;
                    _objServiceLayer.U_MoisCont = model.U_MoisCont;
                    _objServiceLayer.U_FoilStamp = model.U_FoilStamp;
                    _objServiceLayer.U_Perforations = model.U_Perforations;
                    _objServiceLayer.U_Shade = model.U_Shade;
                    _objServiceLayer.U_Wettability = model.U_Wettability;
                    _objServiceLayer.U_SHDCRD = model.U_SHDCRD;
                    _objServiceLayer.U_weight = model.U_weight;
                    _objServiceLayer.U_sheets = model.U_sheets;
                    _objServiceLayer.U_SPINPRINT = model.U_SPINPRINT;
                    _objServiceLayer.U_SPINFOIL = model.U_SPINFOIL;
                    _objServiceLayer.U_MICREM = model.U_MICREM;
                    _objServiceLayer.U_DEBOS = model.U_DEBOS;
                    _objServiceLayer.U_FLTST = model.U_FLTST;
                    _objServiceLayer.U_CRTGSM = model.U_CRTGSM;
                    _objServiceLayer.U_NOPIEC = model.U_NOPIEC;
                    _objServiceLayer.U_QTBOX = model.U_QTBOX;
                    _objServiceLayer.U_SPINPACK = model.U_SPINPACK;
                    _objServiceLayer.U_TaxPer = model.U_TaxPer;
                    _objServiceLayer.U_PLENTRY = model.U_PLENTRY;
                    _objServiceLayer.U_VENDOR = model.U_VENDOR;
                    _objServiceLayer.U_FrntColor = model.U_FrntColor;
                    _objServiceLayer.U_BackColor = model.U_BackColor;
                    _objServiceLayer.U_Coating = model.U_Coating;
                    _objServiceLayer.U_Braille = model.U_Braille;
                    _objServiceLayer.U_ItemKit = model.U_ItemKit;
                    _objServiceLayer.U_TestRptNo = model.U_TestRptNo;
                    _objServiceLayer.U_LTS = model.U_LTS;
                    _objServiceLayer.U_PRRM = model.U_PRRM;
                    _objServiceLayer.U_PRSPRM = model.U_PRSPRM;
                    _objServiceLayer.U_PROTRM = model.U_PROTRM;
                    _objServiceLayer.U_PRCT = model.U_PRCT;
                    _objServiceLayer.U_PRFR = model.U_PRFR;
                    _objServiceLayer.U_PRMU = model.U_PRMU;
                    _objServiceLayer.U_PRTC = model.U_PRTC;
                    _objServiceLayer.U_ARTSTT = model.U_ARTSTT;
                    _objServiceLayer.U_ITEMSTAT = model.U_ITEMSTAT;
                    //_objServiceLayer.U_FLEXO1 = model.U_FLEXO1;
                    _objServiceLayer.U_CoreD = model.U_CoreD;
                    _objServiceLayer.U_CoreT = model.U_CoreT;
                    _objServiceLayer.U_CoreS = model.U_CoreS;
                    _objServiceLayer.U_Brust = model.U_Brust;
                    _objServiceLayer.U_ItemGroup = model.U_ItemGroup;
                    _objServiceLayer.U_RQty = model.U_RQty;
                    _objServiceLayer.U_RPoint = model.U_RPoint;
                    _objServiceLayer.U_WHcode = model.U_WHcode;
                    _objServiceLayer.U_HSNCode = model.U_HSNCode;
                    _objServiceLayer.U_InkType = model.U_InkType;
                    _objServiceLayer.U_PSSRmrk = model.U_PSSRmrk;

                }
                catch { }

                #endregion

                NewItemCodeModel newItemCodeModel = GetAutoItemCode(model);
                //UserWiseItemGrpData(model.ItemCode);

                _objServiceLayer.ItemCode = newItemCodeModel.ItemCode;

                string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
                {
                    NullValueHandling = NullValueHandling.Ignore,
                });
                var temp = JsonConvert.DeserializeObject<JObject>(main);
                string serviceLayerObject = "";

                serviceLayerObject = ServiceLayerEntity.Items.ToString();
                rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject;
                rc.patchJSON = main;
                rc.B1SESSION = res;
                string message = "";
                bool result = rc.postRequest(out message);
                responseModel.ResponseStatus = result;
                if (result == true)
                {
                    responseModel.ResponseText = "Operation completed successfully. New Itemcode is " + model.ItemCode;
                    commonRepository.UpdateUserSign("Add", headerTable, "ItemCode", model.ItemCode, model.UserId);
                }
                else
                {
                    var jobject = JsonConvert.DeserializeObject<JObject>(message);
                    string jsonMessage = jobject["error"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["message"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["value"].ToString();
                    responseModel.ResponseText = "Error occured during process: " + jsonMessage;
                }
                rc.LogOut();
            }
            else
            {
                responseModel.ResponseText = "Service layer login failed";
            }
            return responseModel;
        }

        public ResponseModel Update(ItemMasterModel model)
        {
            ResponseModel responseModel = new ResponseModel();
            ServiceLayer rc = new ServiceLayer();
            string res = rc.Login();
            if (res != "" && res.Contains("error") == false)
            {
                ItemMasterModel_ServiceLayer _objServiceLayer = new ItemMasterModel_ServiceLayer();

                #region Header

                _objServiceLayer.ItemCode = model.ItemCode;
                _objServiceLayer.ItemName = model.ItemName;
                _objServiceLayer.ForeignName = model.ForeignName;
                //_objServiceLayer.AtcEntry = null;
                _objServiceLayer.InventoryItem = model.IsInventoryItem == true ? "tYES" : "tNO";
                _objServiceLayer.SalesItem = model.IsSalesItem == true ? "tYES" : "tNO";
                _objServiceLayer.PurchaseItem = model.IsPurchaseItem == true ? "tYES" : "tNO";

                _objServiceLayer.ItemType = GetItemType_ServiceValue(model.ItemType);
                _objServiceLayer.ItemsGroupCode = model.ItemsGroupCode;
                _objServiceLayer.UoMGroupEntry = model.UoMGroupEntry;
                if (model.UoMGroupEntry == "-1")
                {
                    _objServiceLayer.PricingUnit = "-1";
                }
                else
                {
                    _objServiceLayer.PricingUnit = model.PricingUnit;
                }
                _objServiceLayer.SWW = model.SWW;
                _objServiceLayer.ShipType = model.ShipType;

                _objServiceLayer.Valid = model.Valid == "Y" ? "tYES" : "tNO";
                //_objServiceLayer.U_A4SO = model.U_A4SO == "Yes" ? "tYES" : "tNO";
                _objServiceLayer.U_A4SO = model.U_A4SO;
                _objServiceLayer.Frozen = model.Valid == "Y" ? "tNO" : "tYES";

                _objServiceLayer.GSTRelevnt = model.GSTRelevnt == "Y" ? "tYES" : "tNO";
                _objServiceLayer.MaterialType = GetMaterialType_ServiceValue(model.MaterialType);
                _objServiceLayer.GSTTaxCategory = GetTaxCategory_ServiceValue(model.GSTTaxCategory);
                _objServiceLayer.ChapterID = model.SACEntry;
                _objServiceLayer.DefaultWarehouse = model.DefaultWarehouse;
                if (model.ManageItemBy != null)
                {
                    if (model.ManageItemBy == "1")
                    {
                        _objServiceLayer.ManageSerialNumbers = "tYES";

                    }
                    if (model.ManageItemBy == "2")
                    {
                        _objServiceLayer.ManageBatchNumbers = "tYES";
                    }
                }
                #endregion

                #region Purchasing

                _objServiceLayer.PurchaseUnit = model.PurchaseUnit;
                _objServiceLayer.DefaultPurchasingUoMEntry = GetUOMEntry(model.PurchaseUnit);

                //_objServiceLayer.BuyUnitMsr = model.PurchaseUnit;
                //_objServiceLayer.PurchaseItemsPerUnit = model.PurchaseItemsPerUnit;
                _objServiceLayer.PurchasePackagingUnit = model.PurchasePackagingUnit;
                _objServiceLayer.PurchaseQtyPerPackUnit = model.PurchaseQtyPerPackUnit;
                _objServiceLayer.PurchaseUnitWeight = model.PurchaseUnitWeight;

                #endregion

                #region Sales

                if (model.UoMGroupEntry == "-1")
                {
                    _objServiceLayer.SalesUnit = model.SalesUnitMsr;
                }
                else
                {
                    _objServiceLayer.DefaultSalesUoMEntry = commonRepository.GetUOMAbsEntry(model.SalesUnit);
                    _objServiceLayer.SalesUnit = model.SalesUnit;
                }

                //_objServiceLayer.SalesPackagingUnit = model.SalesPackagingUnit;

                #endregion

                #region Inventory Data

                _objServiceLayer.InventoryUOM = model.InventoryUOM;
                _objServiceLayer.GLMethod = GetGLMethod_ServiceValue(model.GLMethod);
                _objServiceLayer.CostAccountingMethod = GetCostAccountingMethod_ServiceValue(model.CostAccountingMethod);
                //_objServiceLayer.ManageStockByWarehouse = model.ManageStockByWarehouse == "Y" ? "tYES" : "tNO";
                _objServiceLayer.SRIAndBatchManageMethod = "bomm_OnEveryTransaction";
                #endregion

                #region Properties

                _objServiceLayer.Properties1 = model.IsProperties1 == true ? "tYES" : "tNO";
                _objServiceLayer.Properties2 = model.IsProperties2 == true ? "tYES" : "tNO";

				_objServiceLayer.U_FLEXO1 = model.IsProperties1 == true ? "Flexo Yes" : "Flexo No";

				#endregion

				#region UDF
				try
				{
                    _objServiceLayer.U_Company = model.U_Company;
                    _objServiceLayer.U_PaperGSM = model.U_PaperGSM;
                    _objServiceLayer.U_Microns = model.U_Microns;
                    _objServiceLayer.U_Brand = model.U_Brand;
                    _objServiceLayer.U_LamiType = model.U_LamiType;
                    _objServiceLayer.U_Finishing = model.U_Finishing;
                    _objServiceLayer.U_DickleSize = model.U_DickleSize;
                    _objServiceLayer.U_Ply = model.U_Ply;
                    _objServiceLayer.U_CartType = model.U_CartType;
                    _objServiceLayer.U_BPName = model.U_BPName;
                    _objServiceLayer.U_QChk = model.U_QChk;
                    _objServiceLayer.U_MacItem = model.U_MacItem;
                    _objServiceLayer.U_ByPrd = model.U_ByPrd;
                    _objServiceLayer.U_SmplPer = model.U_SmplPer;
                    _objServiceLayer.U_BurStr = model.U_BurStr;
                    _objServiceLayer.U_MatType = model.U_MatType;
                    _objServiceLayer.U_SheetSizeX = model.U_SheetSizeX;
                    _objServiceLayer.U_SheetSizeY = model.U_SheetSizeY;
                    _objServiceLayer.U_ItmNat = model.U_ItmNat;
                    _objServiceLayer.U_Industry = model.U_Industry;
                    _objServiceLayer.U_CustCode = model.U_CustCode;
                    _objServiceLayer.U_CustName = model.U_CustName;
                    _objServiceLayer.U_TypeOfProduct = model.U_TypeOfProduct;
                    _objServiceLayer.U_TypeOfFlute = model.U_TypeOfFlute;
                    _objServiceLayer.U_Profile = model.U_Profile;
                    _objServiceLayer.U_NoOfUps = model.U_NoOfUps;
                    _objServiceLayer.U_TypeOfSubstrate = model.U_TypeOfSubstrate;
                    _objServiceLayer.U_Matelized = model.U_Matelized;
                    _objServiceLayer.U_NoOfColors = model.U_NoOfColors;
                    _objServiceLayer.U_InkDesc = model.U_InkDesc;
                    _objServiceLayer.U_PantoneNo = model.U_PantoneNo;
                    _objServiceLayer.U_TypeOfVarnish = model.U_TypeOfVarnish;
                    _objServiceLayer.U_VarnishNo = model.U_VarnishNo;
                    _objServiceLayer.U_SpotVarnish = model.U_SpotVarnish;
                    _objServiceLayer.U_VarnishGSM = model.U_VarnishGSM;
                    _objServiceLayer.U_NoOfPasses = model.U_NoOfPasses;
                    _objServiceLayer.U_TypeOfLami = model.U_TypeOfLami;
                    _objServiceLayer.U_ThicknessOfLami = model.U_ThicknessOfLami;
                    _objServiceLayer.U_SurfaceFinish = model.U_SurfaceFinish;
                    _objServiceLayer.U_LamiAdhesive = model.U_LamiAdhesive;
                    _objServiceLayer.U_DiePunch = model.U_DiePunch;
                    _objServiceLayer.U_Embossing = model.U_Embossing;
                    _objServiceLayer.U_MCODE = model.U_MCODE;
                    _objServiceLayer.U_MNAME = model.U_MNAME;
                    _objServiceLayer.U_WinPatch = model.U_WinPatch;
                    _objServiceLayer.U_TypeOfFilm = model.U_TypeOfFilm;
                    _objServiceLayer.U_ThicknessOfFilm = model.U_ThicknessOfFilm;
                    _objServiceLayer.U_WinPatAdhesive = model.U_WinPatAdhesive;
                    _objServiceLayer.U_BoxLength = model.U_BoxLength;
                    _objServiceLayer.U_BoxWidth = model.U_BoxWidth;
                    _objServiceLayer.U_BoxHeight = model.U_BoxHeight;
                    _objServiceLayer.U_PrintingSide = model.U_PrintingSide;
                    _objServiceLayer.U_VCode = model.U_VCode;
                    _objServiceLayer.U_Variant = model.U_Variant;
                    _objServiceLayer.U_SCode = model.U_SCode;
                    _objServiceLayer.U_Size = model.U_Size;
                    _objServiceLayer.U_PCode = model.U_PCode;
                    _objServiceLayer.U_Repeat = model.U_Repeat;
                    _objServiceLayer.U_OpenLength = model.U_OpenLength;
                    _objServiceLayer.U_OpenWidth = model.U_OpenWidth;
                    _objServiceLayer.U_BCode = model.U_BCode;
                    _objServiceLayer.U_Corr_Length = model.U_Corr_Length;
                    _objServiceLayer.U_Corr_Width = model.U_Corr_Width;
                    _objServiceLayer.U_Corr_Height = model.U_Corr_Height;
                    _objServiceLayer.U_AddiInfo = model.U_AddiInfo;
                    _objServiceLayer.U_PrintItemDesc = model.U_PrintItemDesc;
                    _objServiceLayer.U_Yield = model.U_Yield;
                    _objServiceLayer.U_Grain = model.U_Grain;
                    _objServiceLayer.U_DieCutting = model.U_DieCutting;
                    _objServiceLayer.U_Pasting = model.U_Pasting;
                    _objServiceLayer.U_PastingInst = model.U_PastingInst;
                    _objServiceLayer.U_LeafletFold = model.U_LeafletFold;
                    _objServiceLayer.U_VertFold = model.U_VertFold;
                    _objServiceLayer.U_HoriFold = model.U_HoriFold;
                    _objServiceLayer.U_LeftletInst = model.U_LeftletInst;
                    _objServiceLayer.U_KLDNo = model.U_KLDNo;
                    _objServiceLayer.U_Cutting = model.U_Cutting;
                    _objServiceLayer.U_VarnishInst = model.U_VarnishInst;
                    _objServiceLayer.U_LamiInst = model.U_LamiInst;
                    _objServiceLayer.U_CuttingInst = model.U_CuttingInst;
                    _objServiceLayer.U_Trial = model.U_Trial;
                    _objServiceLayer.U_MoisCont = model.U_MoisCont;
                    _objServiceLayer.U_FoilStamp = model.U_FoilStamp;
                    _objServiceLayer.U_Perforations = model.U_Perforations;
                    _objServiceLayer.U_Shade = model.U_Shade;
                    _objServiceLayer.U_Wettability = model.U_Wettability;
                    _objServiceLayer.U_SHDCRD = model.U_SHDCRD;
                    _objServiceLayer.U_weight = model.U_weight;
                    _objServiceLayer.U_sheets = model.U_sheets;
                    _objServiceLayer.U_SPINPRINT = model.U_SPINPRINT;
                    _objServiceLayer.U_SPINFOIL = model.U_SPINFOIL;
                    _objServiceLayer.U_MICREM = model.U_MICREM;
                    _objServiceLayer.U_DEBOS = model.U_DEBOS;
                    _objServiceLayer.U_FLTST = model.U_FLTST;
                    _objServiceLayer.U_CRTGSM = model.U_CRTGSM;
                    _objServiceLayer.U_NOPIEC = model.U_NOPIEC;
                    _objServiceLayer.U_QTBOX = model.U_QTBOX;
                    _objServiceLayer.U_SPINPACK = model.U_SPINPACK;
                    _objServiceLayer.U_TaxPer = model.U_TaxPer;
                    _objServiceLayer.U_PLENTRY = model.U_PLENTRY;
                    _objServiceLayer.U_VENDOR = model.U_VENDOR;
                    _objServiceLayer.U_FrntColor = model.U_FrntColor;
                    _objServiceLayer.U_BackColor = model.U_BackColor;
                    _objServiceLayer.U_Coating = model.U_Coating;
                    _objServiceLayer.U_Braille = model.U_Braille;
                    _objServiceLayer.U_ItemKit = model.U_ItemKit;
                    _objServiceLayer.U_TestRptNo = model.U_TestRptNo;
                    _objServiceLayer.U_LTS = model.U_LTS;
                    _objServiceLayer.U_PRRM = model.U_PRRM;
                    _objServiceLayer.U_PRSPRM = model.U_PRSPRM;
                    _objServiceLayer.U_PROTRM = model.U_PROTRM;
                    _objServiceLayer.U_PRCT = model.U_PRCT;
                    _objServiceLayer.U_PRFR = model.U_PRFR;
                    _objServiceLayer.U_PRMU = model.U_PRMU;
                    _objServiceLayer.U_PRTC = model.U_PRTC;
                    _objServiceLayer.U_ARTSTT = model.U_ARTSTT;
                    _objServiceLayer.U_ITEMSTAT = model.U_ITEMSTAT;
                    //_objServiceLayer.U_FLEXO1 = model.U_FLEXO1;
                    _objServiceLayer.U_CoreD = model.U_CoreD;
                    _objServiceLayer.U_CoreT = model.U_CoreT;
                    _objServiceLayer.U_CoreS = model.U_CoreS;
                    _objServiceLayer.U_Brust = model.U_Brust;
                    _objServiceLayer.U_ItemGroup = model.U_ItemGroup;
                    _objServiceLayer.U_RQty = model.U_RQty;
                    _objServiceLayer.U_RPoint = model.U_RPoint;
                    _objServiceLayer.U_WHcode = model.U_WHcode;
                    _objServiceLayer.U_HSNCode = model.U_HSNCode;
                    _objServiceLayer.U_InkType = model.U_InkType;
                    _objServiceLayer.U_PSSRmrk = model.U_PSSRmrk;
                }
                catch { }

                #endregion

                string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
                {
                    NullValueHandling = NullValueHandling.Ignore,
                });

                var temp = JsonConvert.DeserializeObject<JObject>(main);

                string serviceLayerObject = "";

                serviceLayerObject = ServiceLayerEntity.Items.ToString();
                rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject + "('" + model.ItemCode + "')";
                rc.patchJSON = main;
                rc.B1SESSION = res;
                rc.httpMethod = httpVerb.PATCH;

                string message = "";
                bool result = rc.patchRequest(out message);
                responseModel.ResponseStatus = result;
                if (result == true)
                {
                    responseModel.ResponseText = "Operation completed successfully";
                    commonRepository.UpdateUserSign("Update", headerTable, "ItemCode", model.ItemCode, model.UserId);
                    bool anyNewAttachment = model.Attachments2_Lines.Any(a => a.trgtPath.Contains("wwwroot"));
                    if (anyNewAttachment == true)
                    {
                        Utility utility = new Utility();
                        utility.SaveAttachment(res, model.ItemCode, model.AtcEntry, model.UserId, model.Attachments2_Lines, serviceLayerObject);
                    }
                    UpdateKLDNoInClientPO(model.ItemCode, model.U_KLDNo);
                }
                else
                {
                    var jobject = JsonConvert.DeserializeObject<JObject>(message);
                    string jsonMessage = jobject["error"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["message"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["value"].ToString();
                    responseModel.ResponseText = "Error occured during process: " + jsonMessage;
                }
                rc.LogOut();
            }
            else
            {
                responseModel.ResponseText = "Service layer login failed";
            }
            return responseModel;
        }

        private string GetItemType_ServiceValue(string value)
        {
            string newValue = "";
            if (value == "I")
            {
                newValue = "itItems";
            }
            else if (value == "L")
            {
                newValue = "itLabor";
            }
            else if (value == "T")
            {
                newValue = "itTravel";
            }
            return newValue;
        }

        private string GetMaterialType_ServiceValue(string value)
        {
            string newValue = "";
            if (value == "3")
            {
                newValue = "mt_RawMaterial";
            }
            else if (value == "2")
            {
                newValue = "mt_CapitalGoods";
            }
            else if (value == "1")
            {
                newValue = "mt_FinishedGoods";
            }
            return newValue;
        }

        private string GetTaxCategory_ServiceValue(string value)
        {
            string newValue = "";
            if (value == "R")
            {
                newValue = "gtc_Regular";
            }
            else if (value == "N")
            {
                newValue = "gtc_NilRated";
            }
            else if (value == "E")
            {
                newValue = "gtc_Exempt";
            }
            return newValue;
        }

        private string GetGLMethod_ServiceValue(string glMethod)
        {
            string newValue = "";
            if (glMethod == "W")
            {
                newValue = "glm_WH";
            }
            else if (glMethod == "C")
            {
                newValue = "glm_ItemClass";
            }
            else if (glMethod == "L")
            {
                newValue = "glm_ItemLevel";
            }
            return newValue;
        }

        private string GetCostAccountingMethod_ServiceValue(string value)
        {
            string newValue = "";
            if (value == "A")
            {
                newValue = "bis_MovingAverage";
            }
            else if (value == "S")
            {
                newValue = "bis_Standard";
            }
            else if (value == "F")
            {
                newValue = "bis_FIFO";
            }
            else if (value == "B")
            {
                newValue = "bis_SNB";
            }
            return newValue;
        }

        private string GetTwoDigitStr(string d)
        {
            double result = 0.0;
            double.TryParse(d, out result);
            return $"{result:0.00}";
        }

        public NewItemCodeModel GetAutoItemCode(ItemMasterModel itemMasterModel)
        {
            NewItemCodeModel newItemCodeModel = new NewItemCodeModel();
            string itemCode = "";
            try
            {

                List<ItemMasterModel> itemMasterList = new List<ItemMasterModel>();
                itemMasterList.Add(itemMasterModel);
                DataTable itemMasterDatatable = ToDataTable(itemMasterList);
                string message = "";

                string FGCode = itemMasterModel.ItemsGroupCode;
                string ItemName = "";
                string itemBrand = "";
                //string printItem = "";
                string printItem = itemMasterModel.U_PrintItemDesc;
                string FGSpec1 = "";
                //string VariantN = "";
                string SizeN = "";
                string AddInfo = "";
                string brand = itemMasterModel.U_BCode;// ((dynamic) oForm1.Items.Item("U_BCode").Specific).Value;
                string brandName = itemMasterModel.U_Brand;// ((dynamic) oForm1.Items.Item("U_BCode").Specific).Value;
                string profile = itemMasterModel.U_PCode;//((dynamic) oForm1.Items.Item("U_PCode").Specific).Value;
                string variant = itemMasterModel.U_VCode;//((dynamic) oForm1.Items.Item("U_VCode").Specific).Value;
                string variantCode = itemMasterModel.U_VCode;//((dynamic) oForm1.Items.Item("U_VCode").Specific).Value;
                string size = itemMasterModel.U_SCode;//((dynamic) oForm1.Items.Item("U_SCode").Specific).Value;
                string repeat = itemMasterModel.U_Repeat;//((dynamic) oForm1.Items.Item("U_Repeat").Specific).Value;
                string mill = itemMasterModel.U_MCODE;//((dynamic) oForm1.Items.Item("U_Repeat").Specific).Value;
                string foreignName = itemMasterModel.ForeignName;
                string sww = itemMasterModel.SWW;
				string flexo = itemMasterModel.IsProperties1 == true ? "Flexo Yes" : "Flexo No";

				//string flexo = itemMasterModel.U_FLEXO1;
				string FY = "";// (dynamic) oRec.Fields.Item(0).Value;
                string queryStr = "Select (SELECT Right(Year(ADD_MONTHS(NOW(), -3)),2) FROM DUMMY) as \"FY\",* From  " + ConfigManager.GetSAPDatabase() + ".OITB Where \"ItmsGrpCod\" = '" + FGCode + "'";
                DataTable dataTableItemGroup = FillDataTable(queryStr, CommandType.Text, out message);

                FY = dataTableItemGroup.Rows[0]["FY"].ToString();
                itemBrand = dataTableItemGroup.Rows[0]["U_ItmBrand"].ToString();
                string FGSpec = dataTableItemGroup.Rows[0]["ItmsGrpNam"].ToString();
                if (FGSpec.Contains("FG"))
                {
                    FGSpec1 = FGSpec.Substring(5, FGSpec.Length - 5);
                }
                else
                {
                    FGSpec1 = FGSpec;
                }
                string queryStr2 = "SELECT * FROM " + ConfigManager.GetSAPDatabase() + ".\"@ITMMAP1\" WHERE \"Code\"='" + FGCode + "' and IFNULL(\"U_FIELD\",'')<>'' Order By \"LineId\" ";
                DataTable dataTable = FillDataTable(queryStr2, CommandType.Text, out message);

                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    try
                    {
                        string text2 = dataTable.Rows[i]["U_FIELDNM"].ToString();
                        string index = dataTable.Rows[i]["U_FIELD"].ToString();
                        string decimalType = dataTable.Rows[i]["U_DTYPE"].ToString();
                        string prefix = dataTable.Rows[i]["U_PREFIX"].ToString();
                        string suffix = dataTable.Rows[i]["U_SUFFIX"].ToString();
                        if (text2 == "OITB")
                        {
                            text2 = dataTableItemGroup.Rows[0][index].ToString();
                            if (decimalType == "DECIMAL")
                            {
                                text2 = GetTwoDigitStr(text2);
                            }
                            text2 = text2.Trim();
                            ItemName = ItemName + (" " + prefix + text2 + " " + suffix);
                        }
                        if (text2 == "OITM")
                        {
                            if (index.Contains("U_"))
                            {
                                string value = itemMasterDatatable.Rows[0][index].ToString();// Convert.ToString(((dynamic)oForm1.Items.Item(index).Specific).Value);
                                text2 = value;

                                if (decimalType == "DECIMAL")
                                {
                                    text2 = GetTwoDigitStr(text2);
                                }
                                text2 = text2.Trim();
                                ItemName = ItemName + (" " + prefix + text2 + " " + suffix);
                                if (index.Contains("Variant"))
                                {
                                    variant = text2;
                                    if (!string.IsNullOrEmpty(variant))
                                    {
                                        variant = " - " + variant;
                                    }
                                }
                                else if (index.Contains("Size"))
                                {
                                    SizeN = text2;
                                    if (!string.IsNullOrEmpty(SizeN))
                                    {
                                        SizeN = " - " + SizeN;
                                    }
                                }
                                else if (index.Contains("AddiInfo"))
                                {
                                    AddInfo = text2;
                                    if (!string.IsNullOrEmpty(AddInfo))
                                    {
                                        AddInfo = " - " + AddInfo;
                                    }
                                }
                                else if (index.Contains("Brand"))
                                {
                                    if (!string.IsNullOrEmpty(brandName))
                                    {
                                        brandName = " - " + brandName;
                                    }
                                }
                            }

                            else if (index == "FrgnName" && !string.IsNullOrEmpty(foreignName))
                            {
                                text2 = foreignName;
                                ItemName = ItemName + (" " + prefix + text2 + " " + suffix);
                            }
                            else if (index == "SWW" && !string.IsNullOrEmpty(sww))
                            {
                                text2 = sww;
                                ItemName = ItemName + (" " + prefix + text2 + " " + suffix);
                            }
                            //else if (index == "ValidComm" && !string.IsNullOrEmpty(foreignName))
                            //{
                            //	text2 = "ValidComm";
                            //	ItemName = ItemName + (" " + prefix + text2 + " " + suffix);
                            //}
                        }
                    }
                    catch (Exception ex)
                    {

                    }
                }

                // Changed by Pravin - 08-08-23
                //string queryStr3 = "Select Count(*) + 1 From " + ConfigManager.GetSAPDatabase() + ".OITM T0 Inner Join " + ConfigManager.GetSAPDatabase() + ".OITB T1 On T1.\"ItmsGrpCod\" = T0.\"ItmsGrpCod\" Where T1.\"U_ItmBrand\" = '" + itemBrand + "' And Left(Right(\"ItemCode\",7),2) = (SELECT Right(Year(ADD_MONTHS(NOW(), -3)),2) FROM DUMMY)";
                //string queryStr3 = "Select Count(*) + 1 From " + ConfigManager.GetSAPDatabase() + ".OITM T0 Inner Join " + ConfigManager.GetSAPDatabase() + ".OITB T1 On T1.\"ItmsGrpCod\" = T0.\"ItmsGrpCod\" Where Left(Right(\"ItemCode\",7),2) = (SELECT Right(Year(ADD_MONTHS(NOW(), -3)),2) FROM DUMMY)";
                stringBuilder = new StringBuilder();
                if (itemBrand == "FG")
                {
                    stringBuilder.Append(" Select IFNULL(MAX(Cast(Left(Right(\"ItemCode\",5),5) AS NUMERIC(19,0))),0) + 1 ");
                    stringBuilder.Append(" From " + ConfigManager.GetSAPDatabase() + ".OITM T0");
                    stringBuilder.Append(" Inner Join " + ConfigManager.GetSAPDatabase() + ".OITB T1 On T1.\"ItmsGrpCod\" = T0.\"ItmsGrpCod\" ");
                    stringBuilder.Append(" Where T0.\"ItemType\" = 'I' AND Left(Right(\"ItemCode\",7),2) = (SELECT Right(Year(ADD_MONTHS(NOW(), -3)),2) FROM DUMMY) ");
                }
                else if (itemBrand == "RM")
                {
                    stringBuilder.Append(" Select TOP 1 IFNULL((Cast(Left(Right(\"ItemCode\",5),5) AS NUMERIC(19,0))),0) + 1 ");
                    stringBuilder.Append(" From " + ConfigManager.GetSAPDatabase() + ".OITM T0");
                    stringBuilder.Append(" Inner Join " + ConfigManager.GetSAPDatabase() + ".OITB T1 On T1.\"ItmsGrpCod\" = T0.\"ItmsGrpCod\" ");
                    stringBuilder.Append(" Where T0.\"ItemType\" = 'I'  ");
                    stringBuilder.Append(" AND Left(Right(\"ItemCode\",7),2) = (SELECT Right(Year(ADD_MONTHS(NOW(), -3)),2) FROM DUMMY) ");
                    stringBuilder.Append(" AND Left(Right(\"ItemCode\",8),1) = 'R' ");
                    stringBuilder.Append(" ORDER BY T0.\"DocEntry\" DESC ");
                }
                dataTable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
                string uniqueCode = "";
                if (dataTable.Rows.Count > 0)
                {
                    uniqueCode = dataTable.Rows[0][0].ToString();
                }
                else
                {
                    uniqueCode = "1";
                }
                uniqueCode = uniqueCode.PadLeft(5, '0');
                if (flexo.ToLower() == "flexo yes" && itemBrand == "FG")
                {
                    //if (itemBrand == "FG")
                    //{
                    if (brand == null)
                    {
                        newItemCodeModel.ReturnMessage = "Brand not selected";
                        newItemCodeModel.ReturnType = false;
                        return newItemCodeModel;
                    }
                    else if (profile == null)
                    {
                        newItemCodeModel.ReturnMessage = "profile not selected";
                        newItemCodeModel.ReturnType = false;
                        return newItemCodeModel;
                    }
                    else if (variantCode == null)
                    {
                        newItemCodeModel.ReturnMessage = "variant not selected";
                        newItemCodeModel.ReturnType = false;
                        return newItemCodeModel;
                    }
                    else if (size == null)
                    {
                        newItemCodeModel.ReturnMessage = "size not selected";
                        newItemCodeModel.ReturnType = false;
                        return newItemCodeModel;
                    }
                    else
                    {
                        itemCode = FGCode + brand.PadLeft(3, '0') + profile.PadLeft(3, '0') + variantCode.PadLeft(3, '0')
                            + size.PadLeft(3, '0') + repeat + "X" + FY + uniqueCode;
                        printItem = FGSpec1 + brandName + variant + SizeN + AddInfo;
                    }
                    //}
                    //else
                    //{
                    //    brand = string.IsNullOrEmpty(brand) ? "000" : brand;
                    //    profile = string.IsNullOrEmpty(profile) ? "000" : profile;
                    //    variantCode = string.IsNullOrEmpty(variantCode) ? "000" : variantCode;
                    //    size = string.IsNullOrEmpty(size) ? "000" : size;

                    //    brandName = string.IsNullOrEmpty(mill) ? "" : mill; ;
                    //    variant = string.IsNullOrEmpty(variant) ? "" : variant;
                    //    SizeN = string.IsNullOrEmpty(SizeN) ? "" : SizeN;
                    //    AddInfo = string.IsNullOrEmpty(AddInfo) ? "" : AddInfo;

                    //    itemCode = FGCode + brand + profile + variantCode + size + "X" + FY + uniqueCode;
                    //    printItem = FGSpec1 + brandName + variant + SizeN + AddInfo;
                    //}
                }
                else
                {
                    if (itemBrand == "FG")
                    {
                        if (brand == null)
                        {
                            newItemCodeModel.ReturnMessage = "Brand not selected";
                            newItemCodeModel.ReturnType = false;
                            return newItemCodeModel;
                        }
                        else if (profile == null)
                        {
                            newItemCodeModel.ReturnMessage = "Profile not selected";
                            newItemCodeModel.ReturnType = false;
                            return newItemCodeModel;
                        }
                        else if (variantCode == null)
                        {
                            newItemCodeModel.ReturnMessage = "Variant not selected";
                            newItemCodeModel.ReturnType = false;
                            return newItemCodeModel;
                        }
                        else if (size == null)
                        {
                            newItemCodeModel.ReturnMessage = "Size not selected";
                            newItemCodeModel.ReturnType = false;
                            return newItemCodeModel;
                        }
                        itemCode = FGCode + brand.PadLeft(3, '0') + profile.PadLeft(3, '0') + variantCode.PadLeft(3, '0')
                            + size.PadLeft(3, '0') + repeat + "F" + FY + uniqueCode;
                        printItem = FGSpec1 + brandName + variant + SizeN + AddInfo;
                    }
                    else if (itemBrand == "RM")
                    {
                        mill = string.IsNullOrEmpty(mill) ? "000" : mill;
                        brand = string.IsNullOrEmpty(brand) ? "000" : brand;
                        itemCode = mill + brand + FGCode + "R" + FY + uniqueCode;

                    }
                }
                newItemCodeModel.ItemCode = itemCode;
                newItemCodeModel.ItemName = ItemName;
                if (printItem == null)
                {
                    printItem = "";
                }
                else
                {
                    newItemCodeModel.PrintItemName = printItem.Replace("-", " ");
                }
                newItemCodeModel.ReturnMessage = "Success";
                newItemCodeModel.ReturnType = true;
            }
            catch (Exception ex)
            {
                newItemCodeModel.ReturnMessage = ex.Message;
                newItemCodeModel.ReturnType = false;
            }
            return newItemCodeModel;
        }

        public ResponseModel Validate(ItemMasterModel itemMasterModel)
        {
            ResponseModel model = new ResponseModel();
            try
            {
                string userName = commonRepository.GetUserName(itemMasterModel.UserId);
                if (itemMasterModel.ItemsGroupCode == "165")
                {
                    if (userName == "LOGI14" || userName == "LOGI15" || userName == "LOGI16" || userName == "LOGI1" || userName == "LOGI2" || userName == "LOGI29" || userName == "PRO2" || userName == "PRO3")
                    {
                        model.ResponseStatus = false;
                        model.ResponseText = "You are not authorized person Other packing mat..";
                    }
                }
                //HanaParameter[] parameters = new HanaParameter[1];

                //parameters[0] = new HanaParameter("@ItemsGroupCode", System.Data.SqlDbType.VarChar);
                //parameters[0].Value = itemMasterModel.ItemsGroupCode;

                //stringBuilder = new StringBuilder();
                //stringBuilder.Append(" Select T0.\"ItmsGrpCod\" ");
                //stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"OITB\" T0 ");
                ////stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"OITM\" T0 ");
                ////stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"OITB\" T1 ON T0.\"ItmsGrpCod\" = T1.\"ItmsGrpCod\" ");
                ////stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".\"OUSR\" T2 ON T2.\"USERID\" = " + itemMasterModel.UserId + "");
                ////stringBuilder.Append(" WHERE T0.\"frozenFor\" = 'N' AND T1.\"ItmsGrpNam\" like '%Other packing mat%' ");
                ////stringBuilder.Append(" AND T2.\"USER_CODE\" NOT IN ('LOGI14','LOGI15', 'LOGI16', 'LOGI1', 'LOGI2','LOGI29', 'PRO2', 'PRO3')  ");
                ////stringBuilder.Append(" AND T2.\"USER_CODE\" = 'manager' ");
                ////stringBuilder.Append(" AND T0.\"ItemCode\" = :ItemCode ");
                //using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))//parameters
                //{
                //	if (datatable.Rows.Count > 0)
                //	{
                //		model.ResponseStatus = false;
                //		model.ResponseText = "You are not authorized person Other packing mat..";
                //	}
                //}
            }
            catch
            {

            }
            return model;
        }

        public string GetUOMEntry(string uomcode)
        {
            string value = "";
            try
            {
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"UomEntry\" FROM " + ConfigManager.GetSAPDatabase() + ".OUOM T0 ");
                stringBuilder.Append(" WHERE T0.\"UomCode\" = '" + uomcode + "'");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    if (datatable.Rows.Count > 0)
                    {
                        value = datatable.Rows[0][0].ToString();
                    }
                }
            }
            catch
            {

            }
            return value;
        }

        private void UpdateKLDNoInClientPO(string itemcode, string kldNo)
        {
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE T0 ");
            stringBuilder.Append(" SET T0.\"U_KLDNo\" = '" + kldNo + "' ");
            stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + CommonTables.ClientPORegisterRowTable + "\" T0 ");
            stringBuilder.Append(" WHERE T0.\"U_ItemCode\" = '" + itemcode + "' ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
        }
    }
}