﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
//using Microsoft.Data.SqlClient;
using System.Linq;
using System.Net.Mail;
using System.Reflection;
using System.Runtime.ConstrainedExecution;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sap.Data.Hana;
using WebDAL.Helper;
using WebDAL.Helpers;
using WebDAL.IRepository;
using WebDAL.Models;

namespace WebDAL.Repository
{
    public class ECRRepository : clsDataAccess, IECRRepository
    {
        string query = "";
        CommonRepository commonRepository = new CommonRepository();
        StringBuilder stringBuilder = new StringBuilder();
        string headerTable = CommonTables.ECRHeaderTable;
        string rowTable = CommonTables.ECRRowTable;

        public List<ECRMasterModel> GetAll(string userId, string department, string status)
        {
            List<ECRMasterModel> _list = new List<ECRMasterModel>();
            try
            {
                string slpcode = commonRepository.GetSlpCodeFromEmailAddress(userId);
                string isECRSuperUser = commonRepository.IsECRSuperUser(userId);
                string position = commonRepository.GetEmployeePosition(userId);

                //HanaParameter[] parameters = new HanaParameter[2];

                //parameters[0] = new HanaParameter("SlpCode", System.Data.SqlDbType.VarChar);
                //parameters[0].Value = slpcode;

                //parameters[0] = new HanaParameter("Status", System.Data.SqlDbType.VarChar);
                //parameters[0].Value = status;

                //parameters[1] = new HanaParameter("DepartmentId", System.Data.SqlDbType.VarChar);
                //parameters[1].Value = department;

                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT T0.\"Code\",T0.\"U_CardCode\",T0.\"U_CardName\",T1.\"SlpName\",TO_NVARCHAR(\"U_Date\", 'DD/MM/YYYY')  AS \"U_Date\" ");
                stringBuilder.Append(",to_decimal(T0.\"U_TotTRej\",23,3) as \"U_TotTRej\" ");
                //stringBuilder.Append(" ,CASE WHEN \"U_Status\" = 'O' THEN 'Open' WHEN \"U_Status\" = 'C' THEN 'Closed'  ELSE 'Closed' END AS \"U_Status\" ");
                stringBuilder.Append(" ,CASE WHEN \"U_Status\" = 'O' THEN 'Open' WHEN \"U_Status\" = 'C' THEN 'Closed' WHEN \"U_Status\" = 'N' THEN 'Cancelled' END AS \"U_Status\" ");
                if (status == "O")
                {
                    stringBuilder.Append(" ,DAYS_BETWEEN(T0.\"U_Date\",CURRENT_DATE)  AS \"Age\"");
                    stringBuilder.Append(" ,DAYS_BETWEEN(T0.\"U_AssignDt\",CURRENT_DATE)  AS \"ProcessedAge\"  ");
                }
                else
                {
                    stringBuilder.Append(" ,DAYS_BETWEEN(T0.\"U_Date\",T0.\"U_CDate\")  AS \"Age\"");
                    stringBuilder.Append(" ,DAYS_BETWEEN(T0.\"U_AssignDt\",T0.\"U_CDate\")  AS \"ProcessedAge\"  ");
                }
                //stringBuilder.Append(" ,DAYS_BETWEEN(T0.\"U_Date\",CURRENT_DATE)  AS \"Age\"");
                //stringBuilder.Append(" ,DAYS_BETWEEN(T0.\"U_AssignDt\",CURRENT_DATE)  AS \"ProcessedAge\"  ");

                stringBuilder.Append(" ,T0.\"U_SlpCode\",T0.\"U_AssignTo\",T2.\"Name\" AS \"Department\"  ");
                //stringBuilder.Append(" ,T3.\"U_BPLId\" ");
                stringBuilder.Append(" ,(SELECT DAYS_BETWEEN(T0.\"U_Date\",CURRENT_DATE) FROM " + ConfigManager.GetSAPDatabase() + " .\"@ECR\" T0 WHERE T0.\"U_AssignTo\" = '11' AND T2.\"Code\" = T0.\"Code\")  AS \"QCAge\" ");
                stringBuilder.Append(" ,T0.\"U_CrDocNum\",T4.\"DocEntry\" as \"CreditDocEntry\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@ECR\" T0 ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OSLP T1 ON T0.\"U_SlpCode\" = T1.\"SlpCode\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OUDP T2 ON T0.\"U_AssignTo\" = T2.\"Code\" ");
                //stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"@ECR1\" T3 ON T3.\"Code\" = T0.\"Code\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".ORIN T4 ON T4.\"DocNum\" = T0.\"U_CrDocNum\" ");
                stringBuilder.Append(" WHERE T0.\"U_Status\"= '" + status + "'");
                if (isECRSuperUser != "Y")
                {
                    if (department == Convert.ToString((int)Department.Sales))
                    {
                        if (position.ToUpper() != "MANAGER")
                        {
                            //return _list;
                        }
                    }
                    else if (department == Convert.ToString((int)Department.Account))
                    {
                        if (position.ToUpper() != "MANAGER")
                        {
                            return _list;
                        }
                    }
                    else if (department == Convert.ToString((int)Department.SALESCOORDINATOR))
                    {

                    }
                    else
                    {
                        if (position.ToUpper() != "MANAGER")
                        {
                            return _list;
                        }
                        stringBuilder.Append(" AND T0.\"U_AssignTo\" = " + department + " ");
                    }
                }

                stringBuilder.Append(" ORDER BY Cast(T0.\"Code\" as numeric(19,0)) DESC , T0.\"U_Status\" ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    _list = ConvertDatatableToList.ConvertToList<ECRMasterModel>(datatable);
                    if (department == Convert.ToString((int)Department.Sales))
                    {
                        List<SalesEmployeeModel> teamSalesEmployee = commonRepository.GetAllTeamSalesEmployee(userId);
                        _list = _list.Where(x => teamSalesEmployee.Any(y => y.SlpCode == x.U_SlpCode)).ToList();
                    }
                }
            }
            catch
            {

            }
            return _list;
        }

        public ECRMasterModel Get(string code, string userId, string department)
        {
            ECRMasterModel model = new ECRMasterModel();
            try
            {
                string departmentName = commonRepository.GetDepartmentName(department);
                HanaParameter[] parameters = new HanaParameter[1];

                parameters[0] = new HanaParameter("Code", System.Data.SqlDbType.VarChar);
                parameters[0].Value = code;

                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT 'N' AS \"IsEditable\",T0.\"Code\",T0.\"U_CardCode\",T0.\"U_CardName\",T1.\"SlpName\",T0.\"U_SlpCode\",TO_NVARCHAR(T0.\"U_Date\", 'DD/MM/YYYY')  AS \"U_Date\" ");

                stringBuilder.Append(" ,CASE WHEN T0.\"U_Status\" = 'O' THEN 'Open' ");
                stringBuilder.Append("  WHEN \"U_Status\" = 'C' THEN 'Closed' WHEN \"U_Status\" = 'N' THEN 'Cancelled' END AS \"StatusName\" ");

                stringBuilder.Append(" ,T0.\"U_Status\", T0.\"U_AssignTo\",T0.\"U_DebNRec\",T0.\"U_CreNIss\"");
                stringBuilder.Append(" ,T2.\"Name\" AS \"Department\"  ");
                stringBuilder.Append(",to_decimal(T0.\"U_TotWRej\",23,3) as \"U_TotWRej\" ");
                stringBuilder.Append(",to_decimal(T0.\"U_TotTRej\",23,3) as \"U_TotTRej\" ");
                stringBuilder.Append(" ,T0.\"U_ComplBy\", T0.\"U_Designt\",T0.\"U_MOC\" ,T0.\"U_CrDocNum\"");

                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@ECR\" T0 ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OSLP T1 ON T0.\"U_SlpCode\" = T1.\"SlpCode\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OUDP T2 ON T0.\"U_AssignTo\" = T2.\"Code\" ");
                stringBuilder.Append(" WHERE T0.\"Code\" = '" + code + "' ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                {
                    model = ConvertDatatableToList.ConvertToEntity<ECRMasterModel>(datatable);
                    // Update by Kodeslab - 06 April 24
                    if (model.Department.ToUpper() == departmentName.ToUpper() && model.U_Status == "O")
                    {
                        model.IsEditable = "Y";
                    }
                }

                #region Row
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT ROW_NUMBER() OVER (ORDER BY T0.\"LineId\") AS \"Index\",T0.\"LineId\", T0.\"U_InvNo\",TO_NVARCHAR(T0.\"U_InvDt\", 'DD/MM/YYYY')  AS \"U_InvDt\",T0.\"U_ItemCode\",T0.\"U_ItemGrp\",T0.\"U_ItemName\" ");
                stringBuilder.Append(" ,to_decimal(T0.\"U_InvQty\",23,3) as \"U_InvQty\",T0.\"U_IsWithTax\",T0.\"U_MatRern\",T0.\"U_InvLineId\",T0.\"U_InvSts\" ,T0.\"U_BasOfVle\",T0.\"U_Reason\"  ");
                stringBuilder.Append(" ,to_decimal(T0.\"U_ValWTRej\",23,2) as \"U_ValWTRej\"");
                stringBuilder.Append(",to_decimal(T0.\"U_ValTRej\",23,2) as \"U_ValTRej\"");
                stringBuilder.Append(",to_decimal(T0.\"U_RejQty\",23,3) as \"U_RejQty\" ");
                stringBuilder.Append(",to_decimal(T0.\"U_Per\",23,3) as \"U_Per\" ");
                stringBuilder.Append(",to_decimal(T0.\"U_Rate\",23,3) as \"U_Rate\" ");
                stringBuilder.Append(",to_decimal(T0.\"U_Oth\",23,3) as \"U_Oth\" ");
                stringBuilder.Append(",to_decimal(T0.\"U_InvTax\",23,3) as \"U_InvTax\" ");
                stringBuilder.Append(",T0.\"U_BPLId\"  ");
                //stringBuilder.Append(",T0.\"U_Rate\",T0.\"U_Per\",T0.\"U_Oth\"");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@ECR1\" T0 ");
                stringBuilder.Append(" WHERE T0.\"Code\" = :code ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text,
                    out string message, parameters))
                {
                    List<ECRRowModel> modelRows = ConvertDatatableToList.ConvertToList<ECRRowModel>(datatable);
                    model.ECR1Collection = modelRows;
                    for (int i = 0; i < model.ECR1Collection.Count; i++)
                    {
                        string isWithTax = model.ECR1Collection[i].U_IsWithTax;
                        model.ECR1Collection[i].IsWithTax = isWithTax == "Y" ? true : false;
                    }
                }
                #endregion

                #region ECR2 Header 
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT \"LineId\", \"U_Attach\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@ECR2\" ");

                stringBuilder.Append(" WHERE \"Code\" = :code ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                {
                    List<ECRModel_Attachment> modelRows = ConvertDatatableToList.ConvertToList<ECRModel_Attachment>(datatable);
                    model.ECR2Collection = modelRows;
                }
                #endregion

                #region ECR3 Header 
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT \"U_Rem\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@ECR3\" ");

                stringBuilder.Append(" WHERE \"Code\" = :code ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
                {
                    List<ECRModel_RemarkDetails> modelRows = ConvertDatatableToList.ConvertToList<ECRModel_RemarkDetails>(datatable);
                    model.ECR_RemarkDetails_Lines = modelRows;
                }
                #endregion
            }
            catch
            {

            }
            return model;
        }

        public ResponseModel Add(ECRMasterModel model)
        {
            string headerTable = CommonTables.ECRHeaderTable;

            ResponseModel responseModel = new ResponseModel();
            ServiceLayer rc = new ServiceLayer();
            string res = rc.Login();
            if (res != "" && res.Contains("error") == false)
            {
                ECRMasterModel _objServiceLayer = new ECRMasterModel();

                #region Header
                string code = GetECRAutoNo();
                _objServiceLayer.Code = code;
                _objServiceLayer.U_CardCode = model.U_CardCode;
                _objServiceLayer.U_CardName = model.U_CardName;
                _objServiceLayer.U_SlpCode = model.U_SlpCode;
                _objServiceLayer.U_Status = "O";

                DateTime dtDocDate = DateTime.ParseExact(model.U_Date, "dd-MM-yyyy", CultureInfo.InvariantCulture);

                //DateTime dtDocDate = Convert.ToDateTime(model.U_Date);
                _objServiceLayer.U_Date = dtDocDate.ToString("yyyyMMdd");
                _objServiceLayer.U_AssignDt = DateTime.Now.ToString("yyyyMMdd");
                _objServiceLayer.U_TotTRej = model.U_TotTRej;
                _objServiceLayer.U_TotWRej = model.U_TotWRej;
                _objServiceLayer.U_AssignTo = model.U_AssignTo;
                _objServiceLayer.U_DebNRec = model.U_DebNRec;
                _objServiceLayer.U_CreNIss = model.U_CreNIss;
                _objServiceLayer.U_ComplBy = model.U_ComplBy;
                _objServiceLayer.U_Designt = model.U_Designt;
                _objServiceLayer.U_MOC = model.U_MOC;
                _objServiceLayer.U_CrDocNum = model.U_CrDocNum;


                #endregion

                #region Item Rows

                int modelRow = 0;
                List<ECRRowModel> ECRRowModel_ServiceLayer = new List<ECRRowModel>();
                model.ECR1Collection = model.ECR1Collection.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
                for (int i = 0; i < model.ECR1Collection.Count; i++)
                {
                    if (!string.IsNullOrEmpty(model.ECR1Collection[i].U_InvNo))
                    {
                        ECRRowModel_ServiceLayer.Add(new ECRRowModel { });

                        ECRRowModel_ServiceLayer[modelRow].U_InvNo = model.ECR1Collection[i].U_InvNo;
                        DateTime dtInvDate = DateTime.ParseExact(model.ECR1Collection[i].U_InvDt, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                        ECRRowModel_ServiceLayer[modelRow].U_InvDt = dtInvDate.ToString("yyyyMMdd");
                        ECRRowModel_ServiceLayer[modelRow].U_ItemCode = model.ECR1Collection[i].U_ItemCode;
                        ECRRowModel_ServiceLayer[modelRow].U_InvLineId = model.ECR1Collection[i].U_InvLineId;
                        ECRRowModel_ServiceLayer[modelRow].U_ItemGrp = model.ECR1Collection[i].U_ItemGrp;
                        ECRRowModel_ServiceLayer[modelRow].U_ItemName = model.ECR1Collection[i].U_ItemName;
                        ECRRowModel_ServiceLayer[modelRow].U_InvQty = model.ECR1Collection[i].U_InvQty;
                        ECRRowModel_ServiceLayer[modelRow].U_Reason = model.ECR1Collection[i].U_Reason;
                        ECRRowModel_ServiceLayer[modelRow].U_ValTRej = model.ECR1Collection[i].U_ValTRej;
                        ECRRowModel_ServiceLayer[modelRow].U_ValWTRej = model.ECR1Collection[i].U_ValWTRej;
                        ECRRowModel_ServiceLayer[modelRow].U_IsWithTax = model.ECR1Collection[i].IsWithTax == true ? "Y" : "N";
                        ECRRowModel_ServiceLayer[modelRow].U_MatRern = model.ECR1Collection[i].U_MatRern;
                        ECRRowModel_ServiceLayer[modelRow].U_RejQty = model.ECR1Collection[i].U_RejQty;
                        ECRRowModel_ServiceLayer[modelRow].U_BasOfVle = model.ECR1Collection[i].U_BasOfVle;
                        ECRRowModel_ServiceLayer[modelRow].U_InvSts = model.ECR1Collection[i].U_InvSts;
                        ECRRowModel_ServiceLayer[modelRow].U_Rate = model.ECR1Collection[i].U_Rate;
                        ECRRowModel_ServiceLayer[modelRow].U_Per = model.ECR1Collection[i].U_Per;
                        ECRRowModel_ServiceLayer[modelRow].U_Oth = model.ECR1Collection[i].U_Oth;
                        ECRRowModel_ServiceLayer[modelRow].U_InvTax = model.ECR1Collection[i].U_InvTax;
                        ECRRowModel_ServiceLayer[modelRow].U_BPLId = model.ECR1Collection[i].U_BPLId;
                        //ECRRowModel_ServiceLayer[modelRow].BPLId = model.ECR1Collection[i].BPLId;
                        modelRow++;
                    }
                }
                #endregion

                #region Attachment Rows

                int modelRow1 = 0;
                List<ECRModel_Attachment> ECRModel_Attachment_ServiceLayer = new List<ECRModel_Attachment>();
                model.ECR2Collection = model.ECR2Collection.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();

                for (int i = 0; i < model.ECR2Collection.Count; i++)
                {
                    ECRModel_Attachment_ServiceLayer.Add(new ECRModel_Attachment { });
                    ECRModel_Attachment_ServiceLayer[modelRow1].LineId = i + 1;
                    ECRModel_Attachment_ServiceLayer[modelRow1].U_Attach = model.ECR2Collection[i].U_Attach;
                    modelRow1++;
                }
                #endregion

                _objServiceLayer.ECR1Collection = ECRRowModel_ServiceLayer;
                _objServiceLayer.ECR2Collection = ECRModel_Attachment_ServiceLayer;

                string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
                {
                    NullValueHandling = NullValueHandling.Ignore,
                });

                var myJson = JObject.Parse(main);
                myJson.Descendants()
                .OfType<JProperty>()
                .Where(attr => attr.Name.StartsWith("IsWithTax"))
                .ToList()
                .ForEach(attr => attr.Remove());
                main = myJson.ToString();

                rc.endPoint = ConfigManager.GetServiceLayerURL() + "ECR";
                rc.patchJSON = main;
                rc.B1SESSION = res;
                string message = "";
                bool result = rc.postRequest(out message);
                responseModel.ResponseStatus = result;
                if (result == true)
                {
                    responseModel.ResponseText = "Operation completed successfully";
                    var jobject = JsonConvert.DeserializeObject<JObject>(message);
                    responseModel.ResponseEntry = code;

                    string userId = commonRepository.GetUserId(model.UserId);
                    commonRepository.UpdateUserSign("Add", headerTable, "Code", code, userId);
                    for (int i = 0; i < model.ECR1Collection.Count; i++)
                    {
                        if (!string.IsNullOrEmpty(model.ECR1Collection[i].U_InvNo))
                        {
                            string remark = model.ECR1Collection[i].U_Rem;
                            string invNo = model.ECR1Collection[i].U_InvNo;
                            string invLineId = model.ECR1Collection[i].U_InvLineId;
                            if (!string.IsNullOrEmpty(remark))
                            {
                                stringBuilder = new StringBuilder();
                                stringBuilder.Append(" SELECT \"LineId\" ");
                                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@ECR1\" T0");
                                stringBuilder.Append(" WHERE \"Code\" = '" + code + "' AND \"U_InvNo\" = '" + invNo + "' ");
                                stringBuilder.Append(" AND \"U_InvLineId\" = '" + invLineId + "'  ");
                                string lineId = GetRecordValue(stringBuilder.ToString(), CommandType.Text, out string outmessage);
                                UpdateRemark(code, lineId, remark, model.EmpId, model.AssignTo);
                            }
                        }
                    }

                }
                else
                {
                    var jobject = JsonConvert.DeserializeObject<JObject>(message);
                    string jsonMessage = jobject["error"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["message"].ToString();
                    jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                    jsonMessage = jobject["value"].ToString();
                    responseModel.ResponseText = "Error occured during process: " + jsonMessage;
                }
                rc.LogOut();
            }
            else
            {
                responseModel.ResponseText = "Service layer login failed";
            }
            return responseModel;
        }

        public ResponseModel Update(ECRMasterModel model)
        {
            try
            {
                string headerTable = CommonTables.ECRHeaderTable;
                string rowTable = CommonTables.ECRRowTable;

                ResponseModel responseModel = new ResponseModel();
                ServiceLayer rc = new ServiceLayer();
                string res = rc.Login();
                if (res != "" && res.Contains("error") == false)
                {
                    ECRMasterModel _objServiceLayer = new ECRMasterModel();


                    #region Header
                    //string code = GetECRAutoNo();
                    //_objServiceLayer.Code = code;
                    if (model.Department == Convert.ToString((int)Department.Account))
                    {
                        if (model.U_CreNIss == "Y")
                        {
                            _objServiceLayer.U_Status = "C";
                        }
                    }
                    else if (model.Department == Convert.ToString((int)Department.ADMINISTRATION))
                    {
                        if (model.U_CreNIss == "N")
                        {
                            _objServiceLayer.U_Status = "C";
                        }
                    }
                    else
                    {
                        _objServiceLayer.U_Status = model.U_Status;

                    }
                    _objServiceLayer.U_CardCode = model.U_CardCode;
                    _objServiceLayer.U_CardName = model.U_CardName;
                    _objServiceLayer.U_SlpCode = model.U_SlpCode;


                    DateTime dtDocDate = DateTime.ParseExact(model.U_Date, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    _objServiceLayer.U_Date = dtDocDate.ToString("yyyyMMdd");
                    _objServiceLayer.U_AssignDt = DateTime.Now.ToString("yyyyMMdd");

                    _objServiceLayer.U_TotTRej = model.U_TotTRej;
                    _objServiceLayer.U_TotWRej = model.U_TotWRej;
                    _objServiceLayer.U_AssignTo = model.U_AssignTo;
                    _objServiceLayer.U_DebNRec = model.U_DebNRec;
                    _objServiceLayer.U_CreNIss = model.U_CreNIss;
                    _objServiceLayer.U_ComplBy = model.U_ComplBy;
                    _objServiceLayer.U_Designt = model.U_Designt;
                    _objServiceLayer.U_MOC = model.U_MOC;
                    #endregion

                    #region Item Rows

                    int modelRow = 0;
                    List<ECRRowModel> ECRRowModel_ServiceLayer = new List<ECRRowModel>();
                    try

                    {
                        model.ECR1Collection = model.ECR1Collection.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
                        for (int i = 0; i < model.ECR1Collection.Count; i++)
                        {
                            if (!string.IsNullOrEmpty(model.ECR1Collection[i].U_ItemCode))
                            {
                                ECRRowModel_ServiceLayer.Add(new ECRRowModel { });

                                ECRRowModel_ServiceLayer[modelRow].U_InvNo = model.ECR1Collection[i].U_InvNo;
                                ECRRowModel_ServiceLayer[modelRow].U_InvLineId = model.ECR1Collection[i].U_InvLineId;
                                ECRRowModel_ServiceLayer[modelRow].LineId = model.ECR1Collection[i].LineId;
                                //ECRRowModel_ServiceLayer[modelRow].U_InvDt = Convert.ToDateTime(model.ECR1Collection[i].U_InvDt).ToString("yyyyMMdd");
                                DateTime dtInvDate = DateTime.ParseExact(model.ECR1Collection[i].U_InvDt, "dd/MM/yyyy", CultureInfo.InvariantCulture);

                                ECRRowModel_ServiceLayer[modelRow].U_InvDt = dtInvDate.ToString("yyyyMMdd");
                                ECRRowModel_ServiceLayer[modelRow].U_ItemCode = model.ECR1Collection[i].U_ItemCode;
                                ECRRowModel_ServiceLayer[modelRow].U_ItemGrp = model.ECR1Collection[i].U_ItemGrp;
                                ECRRowModel_ServiceLayer[modelRow].U_ItemName = model.ECR1Collection[i].U_ItemName;
                                ECRRowModel_ServiceLayer[modelRow].U_InvQty = model.ECR1Collection[i].U_InvQty;
                                ECRRowModel_ServiceLayer[modelRow].U_Reason = model.ECR1Collection[i].U_Reason;
                                ECRRowModel_ServiceLayer[modelRow].U_ValTRej = model.ECR1Collection[i].U_ValTRej;
                                ECRRowModel_ServiceLayer[modelRow].U_ValWTRej = model.ECR1Collection[i].U_ValWTRej;

                                ECRRowModel_ServiceLayer[modelRow].U_IsWithTax = model.ECR1Collection[i].U_IsWithTax;
                                ECRRowModel_ServiceLayer[modelRow].U_MatRern = model.ECR1Collection[i].U_MatRern;
                                ECRRowModel_ServiceLayer[modelRow].U_RejQty = model.ECR1Collection[i].U_RejQty;
                                ECRRowModel_ServiceLayer[modelRow].U_BasOfVle = model.ECR1Collection[i].U_BasOfVle;
                                ECRRowModel_ServiceLayer[modelRow].U_InvSts = model.ECR1Collection[i].U_InvSts;
                                ECRRowModel_ServiceLayer[modelRow].U_Rate = model.ECR1Collection[i].U_Rate;
                                ECRRowModel_ServiceLayer[modelRow].U_Per = model.ECR1Collection[i].U_Per;
                                ECRRowModel_ServiceLayer[modelRow].U_Oth = model.ECR1Collection[i].U_Oth;
                                ECRRowModel_ServiceLayer[modelRow].U_InvTax = model.ECR1Collection[i].U_InvTax;
                                //ECRRowModel_ServiceLayer[modelRow].U_BPLId = model.ECR1Collection[i].U_BPLId;
                                ECRRowModel_ServiceLayer[modelRow].BPLId = model.ECR1Collection[i].BPLId;

                                modelRow++;
                            }
                        }
                    }
                    catch { }
                    #endregion

                    #region Attachment Rows

                    int modelRow1 = 0;
                    List<ECRModel_Attachment> ECRModel_Attachment_ServiceLayer = new List<ECRModel_Attachment>();
                    model.ECR2Collection = model.ECR2Collection.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();

                    for (int i = 0; i < model.ECR2Collection.Count; i++)
                    {
                        ECRModel_Attachment_ServiceLayer.Add(new ECRModel_Attachment { });
                        ECRModel_Attachment_ServiceLayer[modelRow1].LineId = i + 1;
                        ECRModel_Attachment_ServiceLayer[modelRow1].U_Attach = model.ECR2Collection[i].U_Attach;
                        modelRow1++;
                    }
                    #endregion


                    _objServiceLayer.ECR1Collection = ECRRowModel_ServiceLayer;
                    _objServiceLayer.ECR2Collection = ECRModel_Attachment_ServiceLayer;

                    string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
                    {
                        NullValueHandling = NullValueHandling.Ignore,
                    });

                    var myJson = JObject.Parse(main);
                    myJson.Descendants()
                        .OfType<JProperty>()
                        .Where(attr => attr.Name.StartsWith("IsWithTax"))
                        .ToList()
                    .ForEach(attr => attr.Remove());
                    main = myJson.ToString();
                    string serviceLayerObject = ServiceLayerEntity.ECR.ToString();
                    rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject + "('" + model.Code + "')";
                    rc.patchJSON = main;
                    rc.B1SESSION = res;
                    rc.httpMethod = httpVerb.PATCH;
                    string message = "";
                    string code = model.Code;
                    bool result = rc.patchRequest(out message);
                    responseModel.ResponseStatus = result;
                    if (result == true)
                    {
                        responseModel.ResponseText = "Operation completed successfully";
                        for (int i = 0; i < model.ECR1Collection.Count; i++)
                        {
                            if (!string.IsNullOrEmpty(model.ECR1Collection[i].U_InvNo))
                            {
                                string remark = model.ECR1Collection[i].U_Rem;
                                string invNo = model.ECR1Collection[i].U_InvNo;
                                string invLineId = model.ECR1Collection[i].U_InvLineId;
                                //if (!string.IsNullOrEmpty(remark))
                                //{
                                stringBuilder = new StringBuilder();
                                stringBuilder.Append(" SELECT \"LineId\" ");
                                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@ECR1\" T0");
                                stringBuilder.Append(" WHERE \"Code\" = '" + code + "' AND \"U_InvNo\" = '" + invNo + "' ");
                                stringBuilder.Append(" AND \"U_InvLineId\" = '" + invLineId + "'  ");
                                string lineId = GetRecordValue(stringBuilder.ToString(), CommandType.Text, out string outmessage);
                                UpdateRemark(code, lineId, remark, model.EmpId, model.U_AssignTo);
                                //}
                            }
                        }
                    }
                    else
                    {
                        var jobject = JsonConvert.DeserializeObject<JObject>(message);
                        string jsonMessage = jobject["error"].ToString();
                        jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                        jsonMessage = jobject["message"].ToString();
                        jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
                        jsonMessage = jobject["value"].ToString();
                        responseModel.ResponseText = "Error occured during process: " + jsonMessage;
                    }
                    rc.LogOut();
                }
                return responseModel;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public string GetECRAutoNo()
        {
            string value = "";
            stringBuilder = new StringBuilder();
            stringBuilder.Append("SELECT IFNULL(MAX(Cast(\"Code\" as NUMERIC(19,0))),0) + 1   FROM " + ConfigManager.GetSAPDatabase() + ".\"@ECR\" ");
            DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message);
            if (datatable.Rows.Count > 0)
            {
                value = datatable.Rows[0][0].ToString();
            }
            return value;
        }

        public string GetECRAttachAutoNo()
        {
            string value = "";
            stringBuilder = new StringBuilder();
            stringBuilder.Append("SELECT IFNULL(MAX(Cast(\"Code\" as NUMERIC(19,0))),0) + 1   FROM " + ConfigManager.GetSAPDatabase() + ".\"@ECR2\" ");
            DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message);
            if (datatable.Rows.Count > 0)
            {
                value = datatable.Rows[0][0].ToString();
            }
            return value;
        }

        public ResponseModel UpdateRemark(string basecode, string baseline, string remarks, string empId, string assignTo)
        {
            string message = "";
            //string TableECR2 = "@ECR2";
            stringBuilder = new StringBuilder();
            ResponseModel responseModel = new ResponseModel();
            stringBuilder.Append(" Select cast(max((TO_NUMBER(T0.\"Code\")))+1 as nvarchar(50))  ");
            stringBuilder.Append(" FROM  " + ConfigManager.GetSAPDatabase() + ".\"@ECR3\" T0      ");
            DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            string code = datatable.Rows[0][0].ToString();
            code = code == string.Empty ? "1" : code;
            double dblCode = double.Parse(code);

            DateTime date = DateTime.Now;
            string remdate = date.ToString("yyyyMMdd");
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" INSERT INTO " + ConfigManager.GetSAPDatabase() + ".\"@ECR3\"(\"Code\",\"Name\",\"U_BaseCode\",\"U_BaseLine\",\"U_Rem\",\"U_UserId\",\"U_RemDate\",\"U_AssignTo\") ");
            stringBuilder.Append(" VALUES('" + dblCode.ToString() + "','" + dblCode.ToString() + "','" + basecode + "',");
            stringBuilder.Append(" '" + baseline + "','" + remarks + "','" + empId + "','" + remdate + "', '" + assignTo + "')");
            //stringBuilder.Append(" ); ");
            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (message == string.Empty)
            {
                responseModel.ResponseStatus = true;
                responseModel.ResponseText = "Operation completed successfully";
            }
            else
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            return responseModel;
        }

        public ResponseModel CloseECR(string code)
        {
            string message = "";
            ResponseModel responseModel = new ResponseModel();
            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE  " + ConfigManager.GetSAPDatabase() + ".\"@ECR\" T0 ");
            stringBuilder.Append(" SET T0.\"U_Status\" = 'C', T0.\"U_CDate\" = '" + DateTime.Now.ToString("yyyyMMdd") + "'");
            stringBuilder.Append(" WHERE T0.\"Code\" =  '" + code + "'");

            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (message == string.Empty)
            {
                responseModel.ResponseStatus = true;
                responseModel.ResponseText = "Operation completed successfully";
            }
            else
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            return responseModel;
        }

        public ResponseModel CancelECR(string code)
        {
            string message = "";
            ResponseModel responseModel = new ResponseModel();

            stringBuilder = new StringBuilder();
            stringBuilder.Append(" UPDATE  " + ConfigManager.GetSAPDatabase() + ".\"@ECR\" T0 ");
            stringBuilder.Append(" SET T0.\"U_Status\" = 'N' ");
            stringBuilder.Append(" WHERE T0.\"Code\" =  '" + code + "'");

            FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
            if (message == string.Empty)
            {
                responseModel.ResponseStatus = true;
                responseModel.ResponseText = "Operation completed successfully";
            }
            else
            {
                responseModel.ResponseStatus = false;
                responseModel.ResponseText = "Error occured during process: " + message;
            }
            return responseModel;
        }


        public List<ECRModel_RemarkDetails> GetAllRemarkDetails(string basecode, string baseline, string empId)
        {
            List<ECRModel_RemarkDetails> _list = new List<ECRModel_RemarkDetails>();
            try
            {
                stringBuilder = new StringBuilder();
                stringBuilder.Append(" SELECT ROW_NUMBER() OVER(order by cast(T0.\"Code\" As int)) AS \"RowNo\" ");
                stringBuilder.Append(" ,T0.\"U_Rem\",TO_NVARCHAR(T0.\"U_RemDate\", 'DD/MM/YYYY') AS \"U_RemDate\", T1.\"firstName\" || ' ' || T1.\"lastName\" AS \"UserName\" ");
                stringBuilder.Append(" ,T2.\"Name\" as \"Department\"  ");
                stringBuilder.Append(" ,\'\' as \"AssignTo\"  ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"@ECR3\" T0 ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".\"OHEM\" T1 ON T0.\"U_UserId\" = T1.\"empID\" ");
                stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OUDP T2 ON T1.\"dept\" = T2.\"Code\" ");

                stringBuilder.Append(" WHERE T0.\"U_BaseCode\" = '" + basecode + "'");
                if (!string.IsNullOrEmpty(baseline))
                {
                    stringBuilder.Append(" AND T0.\"U_BaseLine\" = '" + baseline + "' ");
                }
                //stringBuilder.Append(" ORDER BY T0.\"U_RemDate\" DESC ");
                stringBuilder.Append(" ORDER BY \"RowNo\" ASC ");
                //stringBuilder.Append(" ORDER BY Cast(T0.\"Code\" as int) DESC ");
                using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
                {
                    _list = ConvertDatatableToList.ConvertToList<ECRModel_RemarkDetails>(datatable);

                }
            }
            catch
            {

            }
            return _list;
        }

        public DataTable GetMailDraft(string code)
        {
            try
            {
                HanaParameter[] parameters = new HanaParameter[1];
                parameters[0] = new HanaParameter("Code", System.Data.SqlDbType.VarChar);
                parameters[0].Value = code;

                string query = ConfigManager.GetSAPDatabase() + ".\"Web_ECR_EMail\"";

                using (DataTable datatable = FillDataTable(query, CommandType.StoredProcedure, out string message, parameters))
                {
                    return datatable;
                }
            }
            catch
            {
            }
            return null;
        }
    }
}