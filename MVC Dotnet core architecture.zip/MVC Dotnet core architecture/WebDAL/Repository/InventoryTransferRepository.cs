﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sap.Data.Hana;
using WebDAL.Helper;
using WebDAL.Helpers;
using WebDAL.IRepository;
using WebDAL.Models;

namespace WebDAL.Repository
{
	public class InventoryTransferRepository : clsDataAccess, IInventoryTransferRepository
	{
		string query = "";
		CommonRepository commonRepository = new CommonRepository();
		StringBuilder stringBuilder = new StringBuilder();
		public List<InventoryTransferModel> GetAll(string userId)
		{
			List<InventoryTransferModel> _list = new List<InventoryTransferModel>();
			try
			{
				string isSuperUser = commonRepository.IsUserSuperUser(userId);
				string slpName = commonRepository.GetSlpNameFromEmailAddress(userId);
				string headerTable = CommonTables.InventoryTransferHeaderTable;
				string rowTable = CommonTables.InventoryTransferRowTable;

				HanaParameter[] parameters = new HanaParameter[1];
				parameters[0] = new HanaParameter("@UserId", System.Data.SqlDbType.VarChar);
				parameters[0].Value = userId;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT  T0.\"DocEntry\", T0.\"DocNum\", TO_NVARCHAR(T0.\"DocDate\", 'DD/MM/YYYY')  AS \"DocDate\", T0.\"Series\"  ");
				stringBuilder.Append(" ,T0.\"CardName\", '' As \"FromWarehouse\", '' As \"ToWarehouse\" ");
                stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + headerTable + " T0 ");
				stringBuilder.Append(" ORDER BY Cast(T0.\"DocEntry\" as numeric(19,0)) DESC ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<InventoryTransferModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}
		public InventoryTransferModel Get(string docEntry, string userId, string type)
		{
			InventoryTransferModel model = new InventoryTransferModel();
			try
			{
				string headerTable = CommonTables.InventoryTransferHeaderTable;
				string rowTable = CommonTables.InventoryTransferRowTable;
				
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
				parameters[0].Value = docEntry;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT '" + type.ToUpper() + "' AS \"Type\", T0.\"DocEntry\",T0.\"DocNum\",T0.\"DocCur\" AS \"DocCurrency\",T0.\"DocRate\",T0.\"Series\",T0.\"SlpCode\" AS \"SalesPersonCode\",T2.\"SeriesName\" ");
				stringBuilder.Append(" ,T0.\"CardCode\",T0.\"CardName\",T0.\"NumAtCard\",TO_VARCHAR(T0.\"DocDate\", 'DD-MM-YYYY') \"DocDate\",TO_VARCHAR(T0.\"TaxDate\", 'DD-MM-YYYY') AS \"TaxDate\" ");
				if (type.ToUpper() == "DRAFT")
				{
					stringBuilder.Append(" ,'Draft' AS \"DocStatus\"");
				}
				else
				{
					stringBuilder.Append(" ,CASE WHEN \"DocStatus\" = 'O' THEN 'Open' ");
					stringBuilder.Append("  WHEN \"DocStatus\" = 'C' AND \"CANCELED\" = 'Y' THEN 'Cancelled' ELSE 'Closed' END AS \"DocStatus\"");
				}
				stringBuilder.Append(" ,T0.\"BPLId\" AS \"BPL_IDAssignedToInvoice\",TO_VARCHAR(T0.\"DocDueDate\", 'DD-MM-YYYY') \"DocDueDate\" ");
				stringBuilder.Append(" ,T0.\"ShipToCode\",T0.\"PayToCode\",T0.\"TrnspCode\" AS \"TransportationCode\" ");
				stringBuilder.Append(" ,T0.\"OwnerCode\" AS \"DocumentsOwner\",T0.\"Comments\" ");
				stringBuilder.Append(" ,T0.\"DiscPrcnt\" AS \"DiscountPercent\" ");
				stringBuilder.Append(" ,T0.\"RoundDif\" AS \"RoundingDiffAmount\"  ");

				stringBuilder.Append(" ,CASE WHEN T0.\"DocRate\" = 1 THEN T0.\"VatSum\" ELSE T0.\"VatSumFC\"	END AS \"TaxAmount\" ");
				stringBuilder.Append(" ,CASE WHEN T0.\"DocRate\" = 1 THEN T0.\"DocTotal\" ELSE T0.\"DocTotalFC\" END AS \"DocumentTotal\" ");
				stringBuilder.Append(" ,CASE WHEN T0.\"DocRate\" = 1 THEN T0.\"TotalExpns\" ELSE T0.\"TotalExpFC\" END AS \"TotalExpns\" ");
				stringBuilder.Append(" ,T0.\"TotalExpns\"  ");

				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + headerTable + " T0 ");
				stringBuilder.Append(" INNER JOIN " + ConfigManager.GetSAPDatabase() + ".NNM1 T2 ON T0.\"Series\" = T2.\"Series\"  ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".CRD1 T3 ON T0.\"CardCode\" = T3.\"CardCode\" AND T0.\"PayToCode\" = T3.\"Address\" AND T3.\"AdresType\"='B'  ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".CRD1 T4 ON T0.\"CardCode\" = T4.\"CardCode\" AND T0.\"ShipToCode\" = T4.\"Address\" AND T4.\"AdresType\"='S'  ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCRD T5 ON T0.\"CardCode\" = T5.\"CardCode\"  ");

				stringBuilder.Append(" WHERE T0.\"DocEntry\" = " + docEntry + " ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					if (datatable.Rows.Count > 0)
					{
						model = ConvertDatatableToList.ConvertToEntity<InventoryTransferModel>(datatable);
						if (type.ToUpper() == "DRAFT")
						{
							List<ApprovalUsersModel> approvalUsers = commonRepository.GetDraftApprovalUserIDs(docEntry);
							bool isExists = approvalUsers.Where(a => a.UserID == userId).Any();
							model.IsEditable = "Y";
						}
					}
				}

				#region Row
				//double docRate = double.Parse(model.DocRate);
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"VisOrder\" + 1 AS \"Index\",T0.\"U_QChk\",T0.\"ItemCode\",T0.\"Dscription\" AS \"ItemDescription\",T0.\"Project\" AS \"ProjectCode\"  ");
				stringBuilder.Append(" ,T0.\"WhsCode\", T0.\"U_Category\" , T0.\"Quantity\", T0.\"unitMsr2\", T0.\"Weight1\", T0.\"unitMsr\" AS \"InvntryUom\", T0.\"U_KgPrice\"");
				stringBuilder.Append(" , T0.\"DiscPrcnt\" , T0.\"TaxCode\", T0.\"U_DocTotal\", T0.\"PriceAfVAT\",  T0.\"VatSum\"");
				stringBuilder.Append(" ,T0.\"AssblValue\",T1.\"ChapterID\" AS \"HSNEntry\",T3.\"ChapterID\" AS \"ChapterName\", T0.\"U_NoOfUps\" ");
				//if (docRate == 1)
				//{
				//	stringBuilder.Append(" ,T0.\"PriceBefDi\" AS \"UnitPrice\",T0.\"LineTotal\" AS \"Total\" ");
				//}
				//else
				//{
				//	stringBuilder.Append(" ,T0.\"Price\" AS \"UnitPrice\",T0.\"TotalFrgn\" AS \"Total\" ");
				//}
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + rowTable + " T0 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OITM T1 ON T0.\"ItemCode\" = T1.\"ItemCode\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OSTC T2 ON T0.\"TaxCode\" = T2.\"Code\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T3 ON T1.\"ChapterID\" = T3.\"AbsEntry\" ");

				stringBuilder.Append(" WHERE T0.\"DocEntry\" = :DocEntry ");
				stringBuilder.Append(" ORDER BY T0.\"VisOrder\" ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						List<PurchaseOrderRowsModel> modelRows = ConvertDatatableToList.ConvertToList<PurchaseOrderRowsModel>(datatable);
						
					}
				}
				#endregion
			}
			catch
			{

			}
			return model;
		}
		public ResponseModel Add(InventoryTransferModel model)
		{
			string headerTable = CommonTables.InventoryTransferHeaderTable;
			string rowTable = CommonTables.InventoryTransferRowTable;
			string objectType = Convert.ToString((int)ObjectType.StockTransfers);
			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();

			InventoryTransferModel _objServiceLayer = new InventoryTransferModel();

            #region Header
            _objServiceLayer.CardCode = model.CardCode;
            _objServiceLayer.CardName = model.CardName;
            _objServiceLayer.DocNum = model.DocNum;
            _objServiceLayer.Name = model.Name;
            _objServiceLayer.Address = model.Address;
            _objServiceLayer.Series = model.Series;
            //_objServiceLayer.RefDocNum = model.RefDocNum;
            _objServiceLayer.BPLID = model.BPLID;
            DateTime dtDocDate = DateTime.ParseExact(model.DocDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
            DateTime dtTaxDate = DateTime.ParseExact(model.TaxDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
            _objServiceLayer.DocDate = dtDocDate.ToString("yyyyMMdd");
            _objServiceLayer.TaxDate = dtTaxDate.ToString("yyyyMMdd");
            _objServiceLayer.FromWarehouse = model.FromWarehouse;
            _objServiceLayer.ToWarehouse = model.ToWarehouse;
           // _objServiceLayer.BinCode = model.BinCode;
            //_objServiceLayer.U_CntrCd = model.U_CntrCd;
            //_objServiceLayer.U_CntrNm = model.U_CntrNm;
            //_objServiceLayer.U_PPNo = model.U_PPNo;
            //_objServiceLayer.U_PPDocNum = model.BinCode;

			#endregion

			#region Item Rows

			int modelRow = 0;
			List<InventoryTransferRowsModel> modelLines_ServiceLayer = new List<InventoryTransferRowsModel>();
			model.StockTransferLines = model.StockTransferLines.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
			for (int i = 0; i < model.StockTransferLines.Count; i++)
			{
				if (!string.IsNullOrEmpty(model.StockTransferLines[i].ItemCode))
				{
                    modelLines_ServiceLayer.Add(new InventoryTransferRowsModel { });
                    modelLines_ServiceLayer[modelRow].ItemCode = model.StockTransferLines[i].ItemCode;
                    modelLines_ServiceLayer[modelRow].ItemDescription = model.StockTransferLines[i].ItemDescription;
                    modelLines_ServiceLayer[modelRow].Quantity = model.StockTransferLines[i].Quantity;
                    modelLines_ServiceLayer[modelRow].U_NoOfUps = model.StockTransferLines[i].U_NoOfUps;
                    modelLines_ServiceLayer[modelRow].LocCode = model.StockTransferLines[i].LocCode;
                    modelLines_ServiceLayer[modelRow].UoMCode = model.StockTransferLines[i].UoMCode;
                    //Model_ServiceLayer[modelRow].unitMsr = model.StockTransferLines[i].unitMsr;
                    modelLines_ServiceLayer[modelRow].MeasureUnit = model.StockTransferLines[i].MeasureUnit;
                    modelLines_ServiceLayer[modelRow].U_JCText = model.StockTransferLines[i].U_JCText;
                    modelLines_ServiceLayer[modelRow].U_JobCardNo = model.StockTransferLines[i].U_JobCardNo;
                    //Model_ServiceLayer[modelRow].ToBinLoc = model.StockTransferLines[i].ToBinLoc;
                    modelLines_ServiceLayer[modelRow].FromBinLoc = model.StockTransferLines[i].FromBinLoc;


					#region Batches

					int BatchmodelRow = 0;
					List<InventoryTransferBatchNumbersModel> modelLinesbatchs_ServiceLayer = new List<InventoryTransferBatchNumbersModel>();
					for (int j = 0; j < model.StockTransferLines[i].BatchNumbers.Count; j++)
					{
						modelLinesbatchs_ServiceLayer.Add(new InventoryTransferBatchNumbersModel { });
						modelLinesbatchs_ServiceLayer[BatchmodelRow].BatchNumber = model.StockTransferLines[i].BatchNumbers[j].BatchNumber;
						modelLinesbatchs_ServiceLayer[BatchmodelRow].BaseLineNumber = model.StockTransferLines[i].BatchNumbers[j].BaseLineNumber;
						modelLinesbatchs_ServiceLayer[BatchmodelRow].ItemCode = model.StockTransferLines[i].BatchNumbers[j].ItemCode;
						modelLinesbatchs_ServiceLayer[BatchmodelRow].Quantity = model.StockTransferLines[i].BatchNumbers[j].Quantity;
						BatchmodelRow++;
					}
					modelLines_ServiceLayer[modelRow].BatchNumbers = modelLinesbatchs_ServiceLayer;

					#endregion

					modelRow++;
				}
			}
			#endregion


			_objServiceLayer.StockTransferLines = modelLines_ServiceLayer;

			string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
			{
				NullValueHandling = NullValueHandling.Ignore,
			});

			string serviceLayerObject = "";
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				serviceLayerObject = ServiceLayerEntity.StockTransfers.ToString();
				rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject;
				rc.patchJSON = main;
				rc.B1SESSION = res;
				string message = "";
				bool result = rc.postRequest(out message);
				
				responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during process: " + jsonMessage;
				}
				rc.LogOut();
			}
			else
			{
				responseModel.ResponseText = "Service layer login failed";
			}
			return responseModel;
		}
		public ResponseModel Update(InventoryTransferModel model)
		{
			string headerTable = CommonTables.InventoryTransferHeaderTable;
			string rowTable = CommonTables.InventoryTransferRowTable;
			string objectType = Convert.ToString((int)ObjectType.StockTransfers);
			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();



			string slpcode = commonRepository.GetSlpCodeFromEmailAddress(model.UserId);
			InventoryTransferModel _objServiceLayer = new InventoryTransferModel();

            #region Header
            _objServiceLayer.CardCode = model.CardCode;
            _objServiceLayer.CardName = model.CardName;
            _objServiceLayer.DocNum = model.DocNum;
            _objServiceLayer.Name = model.Name;
            _objServiceLayer.Address = model.Address;
            _objServiceLayer.Series = model.Series;
            //_objServiceLayer.RefDocNum = model.RefDocNum;
            _objServiceLayer.BPLID = model.BPLID;
            DateTime dtDocDate = DateTime.ParseExact(model.DocDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
            DateTime dtTaxDate = DateTime.ParseExact(model.TaxDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
            _objServiceLayer.DocDate = dtDocDate.ToString("yyyyMMdd");
            _objServiceLayer.TaxDate = dtTaxDate.ToString("yyyyMMdd");
            _objServiceLayer.FromWarehouse = model.FromWarehouse;
            _objServiceLayer.ToWarehouse = model.ToWarehouse;
            _objServiceLayer.BinCode = model.BinCode;
            _objServiceLayer.U_CntrCd = model.U_CntrCd;
            _objServiceLayer.U_CntrNm = model.U_CntrNm;
            _objServiceLayer.U_PPNo = model.U_PPNo;
            _objServiceLayer.U_PPDocNum = model.BinCode;

            #endregion

            #region Item Rows

            int modelRow = 0;
            List<InventoryTransferRowsModel> Model_ServiceLayer = new List<InventoryTransferRowsModel>();
            model.StockTransferLines = model.StockTransferLines.Where(a => string.IsNullOrEmpty(a.IsDeleted) || a.IsDeleted == "N").ToList();
            for (int i = 0; i < model.StockTransferLines.Count; i++)
            {
                if (!string.IsNullOrEmpty(model.StockTransferLines[i].ItemCode))
                {
                    Model_ServiceLayer.Add(new InventoryTransferRowsModel { });

                    Model_ServiceLayer[modelRow].ItemCode = model.StockTransferLines[i].ItemCode;
                    Model_ServiceLayer[modelRow].ItemDescription = model.StockTransferLines[i].ItemDescription;
                    Model_ServiceLayer[modelRow].FromWhsCod = model.StockTransferLines[i].FromWhsCod;
                    Model_ServiceLayer[modelRow].WhsCode = model.StockTransferLines[i].WhsCode;
                    Model_ServiceLayer[modelRow].Quantity = model.StockTransferLines[i].Quantity;
                    Model_ServiceLayer[modelRow].OnHand = model.StockTransferLines[i].OnHand;
                    Model_ServiceLayer[modelRow].U_NoOfUps = model.StockTransferLines[i].U_NoOfUps;
                    Model_ServiceLayer[modelRow].LocCode = model.StockTransferLines[i].LocCode;
                    Model_ServiceLayer[modelRow].UoMCode = model.StockTransferLines[i].UoMCode;
					//Model_ServiceLayer[modelRow].unitMsr = model.StockTransferLines[i].unitMsr;
					Model_ServiceLayer[modelRow].MeasureUnit = model.StockTransferLines[i].MeasureUnit;
					Model_ServiceLayer[modelRow].U_JCText = model.StockTransferLines[i].U_JCText;
                    Model_ServiceLayer[modelRow].U_JobCardNo = model.StockTransferLines[i].U_JobCardNo;
                    Model_ServiceLayer[modelRow].ToBinLoc = model.StockTransferLines[i].ToBinLoc;
                    Model_ServiceLayer[modelRow].FromBinLoc = model.StockTransferLines[i].FromBinLoc;
                    modelRow++;
                }
            }
            #endregion


            _objServiceLayer.StockTransferLines = Model_ServiceLayer;

            string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
			{
				NullValueHandling = NullValueHandling.Ignore,
			});
			var temp = JsonConvert.DeserializeObject<JObject>(main);

			string serviceLayerObject = "";
			string res = rc.Login();
			if (res != "" && res.Contains("error") == false)
			{
				serviceLayerObject = ServiceLayerEntity.StockTransfers.ToString();
				//rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject + "(" + model.DocEntry + ")";
				rc.patchJSON = main;
				rc.B1SESSION = res;
				string message = "";
                bool result = rc.patchRequest(out message);
                responseModel.ResponseStatus = result;
				if (result == true)
				{
					responseModel.ResponseText = "Operation completed successfully";
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string docEntry = jobject["DocEntry"].ToString();
				}
				else
				{
					var jobject = JsonConvert.DeserializeObject<JObject>(message);
					string jsonMessage = jobject["error"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["message"].ToString();
					jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
					jsonMessage = jobject["value"].ToString();
					responseModel.ResponseText = "Error occured during process: " + jsonMessage;
				}
				rc.LogOut();
			}
			else
			{
				responseModel.ResponseText = "Service layer login failed";
			}
			return responseModel;
		}

		public DocumentModel GetITROpenRows(string itdocEntry)
		{
			DocumentModel model = new DocumentModel();
			try
			{
				string headerTable = CommonTables.InventoryTransferRequestHeaderTable;
				string rowTable = CommonTables.InventoryTransferRequestRowTable;

				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("DocEntry", System.Data.SqlDbType.VarChar);
				parameters[0].Value = itdocEntry;

				#region Row
				string rowTaxCode = "";
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"VisOrder\" + 1 AS \"Index\",T0.\"LineNum\" AS \"LineId\", T0.\"ItemCode\",T0.\"Dscription\" AS \"ItemName\" ");
				stringBuilder.Append(" ,T0.\"OpenQty\" AS \"Quantity\",T0.\"FromWhsCod\",T0.\"WhsCode\",T1.\"OnHand\" ");
				stringBuilder.Append(" ,T0.\"U_NoOfUps\" ,T0.\"U_Category\",T0.\"UomCode\"  ");//,T2\"LocCode\"
				stringBuilder.Append(" ,T0.\"unitMsr\" As \"MeasureUnit\" ");
				stringBuilder.Append(" ,T0.\"U_JobCardNo\",T0.\"U_JCText\",T3.\"ToWhsCode\" ");
				//stringBuilder.Append(" , CASE WHEN T4.\"DocRate\" = 1 THEN T0.\"PriceBefDi\" ELSE T0.\"Price\"  END AS \"UnitPrice\"  ");
				//stringBuilder.Append(" , CASE WHEN T4.\"DocRate\" = 1 THEN T0.\"LineTotal\" ELSE T0.\"TotalFrgn\"  END AS \"Total\" ");
				//stringBuilder.Append(" ,TO_VARCHAR(T0.\"ShipDate\", 'DD-MM-YYYY') \"ShipDate\" ");
				stringBuilder.Append(" ,T0.\"DocEntry\" AS \"BaseEntry\",T0.\"LineNum\" AS \"BaseLine\" ");
				stringBuilder.Append(" ,T3.\"U_PPNo\" AS \"ProPlanNo\",T3.\"U_PPDocNum\" AS \"JobCardNo\" ");
				//stringBuilder.Append(" ,CASE WHEN T1.\"ManBtchNum\"='Y' THEN 'B' WHEN T1.\"ManSerNum\"='Y' THEN 'S' ELSE 'N' END \"ManagedBy\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + "." + rowTable + " T0 ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OITM T1 ON T0.\"ItemCode\" = T1.\"ItemCode\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OLCT T2 ON T0.\"LocCode\" = T2.\"Code\" ");
				//stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + ".OCHP T3 ON T1.\"ChapterID\" = T3.\"AbsEntry\" ");
				stringBuilder.Append(" LEFT JOIN " + ConfigManager.GetSAPDatabase() + "." + headerTable + " T3 ON T0.\"DocEntry\" = T3.\"DocEntry\" ");
				stringBuilder.Append(" WHERE T0.\"DocEntry\" = :DocEntry ");
				stringBuilder.Append(" AND T0.\"OpenQty\" > 0 AND T0.\"LineStatus\" = 'O' ");
				stringBuilder.Append(" ORDER BY T0.\"VisOrder\" ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						List<DocumentRowsModel> modelRows = ConvertDatatableToList.ConvertToList<DocumentRowsModel>(datatable);
						model.DocumentLines = modelRows;
						rowTaxCode = model.DocumentLines.Select(a => a.TaxCode).FirstOrDefault();
						model.WarehouseCode = model.DocumentLines.Select(a => a.WarehouseCode).FirstOrDefault();
						model.NetAmount = model.DocumentLines.Select(a => a.Total).Sum();
					}
				}
				#endregion
			}
			catch
			{

			}
			return model;
		}

	}
}