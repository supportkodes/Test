﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
//using Microsoft.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Sap.Data.Hana;
using WebDAL.Helper;
using WebDAL.IRepository;
using WebDAL.Models;

namespace WebDAL.Repository
{
	public class ItemWeightCalculatorRepository : clsDataAccess, IItemWeightCalculatorRepository
	{
		string query = "";
		CommonRepository commonRepository = new CommonRepository();
		StringBuilder stringBuilder = new StringBuilder();
		string headerTable = CommonTables.ItemWeightCalculatorTable;
		public List<ItemWeightCalculatorModel> GetAll()
		{
			List<ItemWeightCalculatorModel> _list = new List<ItemWeightCalculatorModel>();
			try
			{
				//string headerTable = CommonTables.FLEXOUPHeaderTable;
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"Code\",T0.\"U_ItemCode\",T1.\"ItemName\",T0.\"U_KLDNo\",T0.\"U_PktWt\",T0.\"U_PktQty\"  ");
				stringBuilder.Append(" ,T0.\"U_PktWt\"/ T0.\"U_PktQty\" AS \"PerPcsWeight\"  ");
				stringBuilder.Append(" ,T2.\"U_PerPckQty\" AS \"PerBoxQty\"  ");
				stringBuilder.Append(" ,(T0.\"U_PktWt\"/ T0.\"U_PktQty\") * T2.\"U_PerPckQty\"  AS \"BoxWeight\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + headerTable + "\" T0 ");
				stringBuilder.Append(" LEFT JOIN  " + ConfigManager.GetSAPDatabase() + ".\"OITM\" T1 ON T0.\"U_ItemCode\" = T1.\"ItemCode\"");
				stringBuilder.Append(" LEFT JOIN  " + ConfigManager.GetSAPDatabase() + ".\"OITT\" T2 ON T0.\"U_ItemCode\" = T2.\"Code\"");
				stringBuilder.Append(" ORDER BY T0.\"Code\" DESC ");
				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message))
				{
					_list = ConvertDatatableToList.ConvertToList<ItemWeightCalculatorModel>(datatable);
				}
			}
			catch
			{

			}
			return _list;
		}
		public ItemWeightCalculatorModel Get(string code)
		{
			ItemWeightCalculatorModel model = new ItemWeightCalculatorModel();
			try
			{
				HanaParameter[] parameters = new HanaParameter[1];

				parameters[0] = new HanaParameter("Code", System.Data.SqlDbType.VarChar);
				parameters[0].Value = code;

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT T0.\"Code\",T0.\"U_ItemCode\",T1.\"ItemName\",T0.\"U_KLDNo\",Cast(T0.\"U_PktWt\" as float) as \"U_PktWt\" ");
				stringBuilder.Append(" ,Cast(T0.\"U_PktQty\" as float) as \"U_PktQty\"  ");
				stringBuilder.Append(" FROM " + ConfigManager.GetSAPDatabase() + ".\"" + headerTable + "\" T0 ");
				stringBuilder.Append(" LEFT JOIN  " + ConfigManager.GetSAPDatabase() + ".\"OITM\" T1 ON T0.\"U_ItemCode\" = T1.\"ItemCode\"");
				stringBuilder.Append(" WHERE T0.\"Code\" = :code ");

				using (DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out string message, parameters))
				{
					if (datatable.Rows.Count > 0)
					{
						model = ConvertDatatableToList.ConvertToEntity<ItemWeightCalculatorModel>(datatable);
					}
				}
			}
			catch
			{

			}
			return model;
		}
		public ResponseModel Add(ItemWeightCalculatorModel model)
		{
			string message = "";
			ResponseModel responseModel = new ResponseModel();
			try
			{
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" SELECT MAX(Cast(\"Code\" AS INT)) + 1 FROM   " + ConfigManager.GetSAPDatabase() + ".\"" + headerTable + "\" ");
				DataTable dt = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
				string code = dt.Rows[0][0].ToString();

				if (code == string.Empty)
				{
					code = "1";
				}

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" INSERT INTO  " + ConfigManager.GetSAPDatabase() + ".\"" + headerTable + "\"(\"Code\",\"Name\" ");
				stringBuilder.Append(" ,\"U_ItemCode\" ,\"U_PktWt\" , \"U_PktQty\", \"U_KLDNo\"");
				stringBuilder.Append("  ) ");
				stringBuilder.Append(" VALUES('" + code + "','" + code + "'");
				stringBuilder.Append(" ,'" + model.U_ItemCode + "','" + model.U_PktWt + "' ");
				stringBuilder.Append(" ,'" + model.U_PktQty + "','" + model.U_KLDNo + "' ");
				stringBuilder.Append("  ) ");
				FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
				if (message == string.Empty)
				{
					responseModel.ResponseText = "Operation completed successfully";
					responseModel.ResponseStatus = true;
				}
				else
				{
					responseModel.ResponseText = "Error occured during process: " + message;
				}

			}
			catch (Exception ex)
			{
				responseModel.ResponseText = "Error occured during process: " + ex.Message;
				responseModel.ResponseStatus = false;
			}
			return responseModel;
		}
		public ResponseModel Update(ItemWeightCalculatorModel model)
		{
			try
			{
				ResponseModel responseModel = new ResponseModel();
				string message = "";

				stringBuilder = new StringBuilder();
				stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"" + headerTable + "\" ");
				stringBuilder.Append("  SET \"U_ItemCode\" = '" + model.U_ItemCode + "',\"U_PktWt\" = '" + model.U_PktWt + "' ");
				stringBuilder.Append("  ,\"U_PktQty\" = '" + model.U_PktQty + "',\"U_KLDNo\" = '" + model.U_KLDNo + "' ");
				stringBuilder.Append(" WHERE \"Code\" = '" + model.Code + "'");
				FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
				if (message == string.Empty)
				{
					responseModel.ResponseStatus = true;
					responseModel.ResponseText = "Updated successfully";
				}
				else
				{
					responseModel.ResponseStatus = false;
					responseModel.ResponseText = "Error occured during process: " + message;
				}

				return responseModel;
			}
			catch (Exception ex)
			{
				throw new Exception(ex.ToString());
			}
		}
	}
}