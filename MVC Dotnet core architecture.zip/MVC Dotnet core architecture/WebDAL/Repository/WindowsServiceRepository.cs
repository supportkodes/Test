﻿using WebDAL.IRepository;
using WebDAL.Models;
using WebDAL.Helper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Sap.Data.Hana;
using System.Text;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using WebDAL.Helpers;
using System.Globalization;

namespace WebDAL.Repository
{
	public class WindowsServiceRepository : clsDataAccess
	{
		string query = "";
		StringBuilder stringBuilder = new StringBuilder();
		CommonRepository commonRepository = new CommonRepository();

		public void CallWindowsService()
		{ 
		
		}

		public List<PaymentProjectionRowsModel> GetPaymentProjection(string userId, string fromDate, string toDate, string year, string weekNo)
		{
			List<PaymentProjectionRowsModel> _list = new List<PaymentProjectionRowsModel>();
			try
			{
				string slpcode = commonRepository.GetSlpCodeFromEmailAddress(userId);

				HanaParameter[] parameters = new HanaParameter[5];

				parameters[0] = new HanaParameter("Year", SqlDbType.VarChar);
				parameters[0].Value = year == null ? string.Empty : year;

				parameters[1] = new HanaParameter("WeekNo", SqlDbType.VarChar);
				parameters[1].Value = weekNo == null ? string.Empty : weekNo;

				parameters[2] = new HanaParameter("SlpCode", SqlDbType.VarChar);
				parameters[2].Value = slpcode == null ? string.Empty : slpcode;

				parameters[3] = new HanaParameter("FromDate", SqlDbType.VarChar);
				parameters[3].Value = fromDate == null ? string.Empty : fromDate;

				parameters[4] = new HanaParameter("ToDate", SqlDbType.VarChar);
				parameters[4].Value = toDate == null ? string.Empty : toDate;

				query = ConfigManager.GetSAPDatabase() + ".\"Web_Payment_Projection\"";
				using (DataTable datatable = FillDataTable(query, CommandType.StoredProcedure, out string message, parameters))
				{
					_list = ConvertDatatableToList.ConvertToList<PaymentProjectionRowsModel>(datatable);
					for (int i = 0; i < _list.Count; i++)
					{
						double dblProjection = _list[i].U_ProAmt == null ? 0 : _list[i].U_ProAmt.Value;

						double dblAccountBalance= Math.Round(double.Parse(_list[i].U_AccBal), 2);
						_list[i].U_AccBal = dblAccountBalance.ToString("N0");

						double dblOverDue = Math.Round(double.Parse(_list[i].U_OverDue), 2);
						_list[i].U_OverDue = dblOverDue.ToString("N0");

						double dblAmtReceived = Math.Round(double.Parse(_list[i].U_AmtRecd), 2);
						_list[i].U_AmtRecd = dblAmtReceived.ToString("N0");

						double dblBalance = dblProjection - dblAmtReceived;
						dblBalance = Math.Round(dblBalance, 2);
						_list[i].Balance = dblBalance.ToString("N0");

						double collPerAgainstProjection = 0;
						double collPerAgainstOverDue = 0;
						if (dblProjection > 0)
						{
							collPerAgainstProjection = dblAmtReceived * 100 / dblProjection;
						}
						_list[i].CollProj = Math.Round(collPerAgainstProjection, 2);
						if (dblOverDue > 0)
						{
							collPerAgainstOverDue = dblAmtReceived * 100 / dblOverDue;
						}
						_list[i].CollOD = Math.Round(collPerAgainstOverDue, 2);
					}

				}
			}
			catch
			{

			}
			return _list;
		}

		public ResponseModel ConfirmProjection(string userId, string year, string weekNo)
		{
			string message = "";
			string slpcode = commonRepository.GetSlpCodeFromEmailAddress(userId);

			ResponseModel responseModel = new ResponseModel();
			stringBuilder = new StringBuilder();
			stringBuilder.Append(" UPDATE " + ConfigManager.GetSAPDatabase() + ".\"@PAYPROJ\" T0   ");
			stringBuilder.Append(" SET \"U_IsConfirm\"='Y'   ");
			stringBuilder.Append(" WHERE \"Name\" ='" + slpcode + "' AND \"U_Year\" ='" + year + "' AND \"U_WeekNo\" ='" + weekNo + "'      ");
			FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);

			if (message == string.Empty)
			{
				responseModel.ResponseText = "Operation completed successfully";
			}
			else
			{
				responseModel.ResponseText = "Error occured during process: " + message;
			}

			return responseModel;
		}

		public ResponseModel AddPaymentProjection(PaymentProjectionModel model)
		{
			string message = "";
			string isConfirm = "N";
			string slpcode = commonRepository.GetSlpCodeFromEmailAddress(model.UserId);
			string fromDate = model.FromDate;
			string toDate = model.ToDate;

			DateTime dtFromDate = DateTime.ParseExact(fromDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
			fromDate = dtFromDate.ToString("yyyyMMdd");

			DateTime dtToDate = DateTime.ParseExact(toDate, "dd-MM-yyyy", CultureInfo.InvariantCulture);
			toDate = dtToDate.ToString("yyyyMMdd");

			ResponseModel responseModel = new ResponseModel();
			stringBuilder = new StringBuilder();
			stringBuilder.Append(" SELECT * FROM  " + ConfigManager.GetSAPDatabase() + ".\"@PAYPROJ\" T0   ");
			stringBuilder.Append(" WHERE \"Name\" ='" + slpcode + "' AND \"U_Year\" ='" + model.U_Year + "' AND \"U_WeekNo\" ='" + model.U_WeekNo + "'      ");
			DataTable dtConfrim = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
			if (dtConfrim.Rows.Count > 0)
			{
				isConfirm = dtConfrim.Rows[0]["U_IsConfirm"].ToString();
				isConfirm = isConfirm == "" ? "N" : isConfirm;
			}
			stringBuilder = new StringBuilder();
			stringBuilder.Append(" DELETE FROM  " + ConfigManager.GetSAPDatabase() + ".\"@PAYPROJ\" T0   ");
			stringBuilder.Append(" WHERE \"Name\" ='" + slpcode + "' AND \"U_Year\" ='" + model.U_Year + "' AND \"U_WeekNo\" ='" + model.U_WeekNo + "'      ");
			FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);

			stringBuilder = new StringBuilder();
			stringBuilder.Append(" Select cast(max((TO_NUMBER(T0.\"Code\")))+1 as nvarchar(50))  ");
			stringBuilder.Append(" FROM  " + ConfigManager.GetSAPDatabase() + ".\"@PAYPROJ\" T0      ");
			DataTable datatable = FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
			string code = datatable.Rows[0][0].ToString();
			code = code == string.Empty ? "1" : code;
			double dblCode = double.Parse(code);

			model.PaymentProjectionRows = model.PaymentProjectionRows.Where(a => !string.IsNullOrEmpty(a.U_CardCode)).ToList();
			//model.PaymentProjectionRows.Count
			for (int i = 0; i < model.PaymentProjectionRows.Count; i++)
			{
				double dblProjectionAmt = model.PaymentProjectionRows[i].U_ProAmt == null ? 0 : model.PaymentProjectionRows[i].U_ProAmt.Value;
				string dblAmtReceived = model.PaymentProjectionRows[i].U_AmtRecd == null ? "0" : model.PaymentProjectionRows[i].U_AmtRecd.Replace(",", "");
				stringBuilder = new StringBuilder();
				stringBuilder.Append(" INSERT INTO " + ConfigManager.GetSAPDatabase() + ".\"@PAYPROJ\"(\"Code\",\"Name\",\"U_CardCode\",\"U_Year\",\"U_WeekNo\",\"U_AccBal\",\"U_OverDue\",\"U_ProAmt\",\"U_AmtRecd\",\"U_IsConfirm\",\"U_FromDate\",\"U_ToDate\") ");
				stringBuilder.Append(" VALUES('" + dblCode.ToString() + "','" + slpcode + "', ");
				stringBuilder.Append(" '" + model.PaymentProjectionRows[i].U_CardCode + "',"); ;
				stringBuilder.Append(" '" + model.U_Year + "', ");
				stringBuilder.Append(" '" + model.U_WeekNo + "', ");
				stringBuilder.Append(" '" + model.PaymentProjectionRows[i].U_AccBal.Replace(",", "") + "', ");
				stringBuilder.Append(" '" + model.PaymentProjectionRows[i].U_OverDue.Replace(",", "") + "', ");
				stringBuilder.Append(" '" + dblProjectionAmt + "', ");
				stringBuilder.Append(" '" + dblAmtReceived + "', ");
				stringBuilder.Append(" '" + isConfirm + "', ");
				stringBuilder.Append(" '" + fromDate + "', ");
				stringBuilder.Append(" '" + toDate + "' ");
				stringBuilder.Append(" ); ");
				FillDataTable(stringBuilder.ToString(), CommandType.Text, out message);
				dblCode = dblCode + 1;
			}
			if (message == string.Empty)
			{
				responseModel.ResponseText = "Operation completed successfully";
			}
			else
			{
				responseModel.ResponseText = "Error occured during process: " + message;
			}

			return responseModel;
		}
	
	}
}