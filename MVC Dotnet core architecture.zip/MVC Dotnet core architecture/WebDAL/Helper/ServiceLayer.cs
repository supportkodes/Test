﻿using System;
using System.IO;
using System.Net;
using System.Collections.Generic;
using System.Text;
using WebDAL.Helper;
using Newtonsoft.Json;
using RestSharp;

namespace WebDAL.Helpers
{
	class ServiceLayer
	{
		public string endPoint { get; set; }
		public string serviceURL { get; set; }
		public httpVerb httpMethod { get; set; }
		public string postJSON { get; set; }
		public string patchJSON { get; set; }
		public string HeaderSecretKey { get; set; }
		public string HeaderGSTIN { get; set; }
		public string HeaderUserId { get; set; }
		public string HeaderPassword { get; set; }
		public string HeaderClient { get; set; }
		public string HeaderAccept { get; set; }
		public string HeaderRequest { get; set; }
		public string AppPath { get; set; }
		public string B1SESSION { get; set; }
		public string ROUTID { get; set; }

		string strSID = "";
		public string responseAfterSuccess { get; set; }

		public ServiceLayer()
		{
			endPoint = string.Empty;
			httpMethod = httpVerb.GET;
		}

		public string Login()
		{
			LoginServiceLayerModel _clsEntity_ServiceLayerLogin = new LoginServiceLayerModel();
			_clsEntity_ServiceLayerLogin.CompanyDB = ConfigManager.GetSAPDatabase();
			_clsEntity_ServiceLayerLogin.UserName = ConfigManager.GetSAPUserCode();
			_clsEntity_ServiceLayerLogin.Password = ConfigManager.GetSAPPassword();

			var login = JsonConvert.SerializeObject(_clsEntity_ServiceLayerLogin);
			httpMethod = httpVerb.POST;
			endPoint = ConfigManager.GetServiceLayerURL() + "Login";
			postJSON = login;
			ServicePointManager.Expect100Continue = true;
			//ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;
			ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
			ServicePointManager.ServerCertificateValidationCallback = (sender, x509Certificate, chain, sslPolicyErrors) => true;

			string stringResponseValue = string.Empty;

			try
			{
				HttpWebRequest request = (HttpWebRequest)
				WebRequest.Create(endPoint);
				request.KeepAlive = false;
				request.ProtocolVersion = HttpVersion.Version10;
				request.Method = httpMethod.ToString();
				byte[] postBytes = Encoding.ASCII.GetBytes(postJSON);
				request.ContentType = "application/json";
				request.ContentLength = postBytes.Length;
				Stream requestStream = request.GetRequestStream();
				requestStream.Write(postBytes, 0, postBytes.Length);
				requestStream.Close();
				HttpWebResponse response = null;
				try
				{
					using (response = (HttpWebResponse)request.GetResponse())
					{
						if (response.StatusCode.Equals(HttpStatusCode.OK))
						{
							stringResponseValue = response.Headers.Get("Set-Cookie");
						}
					}
				}
				catch (WebException ex)
				{
					stringResponseValue = new StreamReader(ex.Response.GetResponseStream()).ReadToEnd();
				}
			}
			catch (Exception ex)
			{
				return ex.Message;
			}
			return stringResponseValue;
		}

		public bool getRequest(out string _message)
		{
			_message = "";
			ServicePointManager.Expect100Continue = true;
			ServicePointManager.ServerCertificateValidationCallback = (sender, x509Certificate, chain, sslPolicyErrors) => true;
			string stringResponseValue = string.Empty;
			try
			{
				HttpWebRequest request = (HttpWebRequest)WebRequest.Create(endPoint);
				request.KeepAlive = false;
				request.ProtocolVersion = HttpVersion.Version10;
				request.Method = httpMethod.ToString();
				request.Headers.Add("Prefer", "odata.maxpagesize=0");
				request.Headers.Add("Cookie", B1SESSION);
				request.Headers.Add("B1S-CaseInsensitive", "true");
				request.ContentType = "application/json";

				HttpWebResponse response = null;
				try
				{
					response = (HttpWebResponse)request.GetResponse();
					using (Stream responseStream = response.GetResponseStream())
					{
						if (responseStream != null)
						{
							using (StreamReader reader = new StreamReader(responseStream))
							{
								_message = reader.ReadToEnd();
							}
						}
					}
				}
				catch (WebException ex)
				{
					string message = new StreamReader(ex.Response.GetResponseStream()).ReadToEnd();
					stringResponseValue = message;
					_message = message;
					return false;
				}
				finally
				{
					//LogOut(serviceURL);
				}

			}
			catch (Exception ex)
			{
				return false;
			}


			return true;
		}

		public bool postRequest(out string _message)
		{
			_message = "";
			//ServicePointManager.ServerCertificateValidationCallback += (sender, certificate, chain, sslPolicyErrors) => true;
			ServicePointManager.Expect100Continue = true;
			//ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls;
			ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
			ServicePointManager.ServerCertificateValidationCallback = (sender, x509Certificate, chain, sslPolicyErrors) => true;
			try
			{
				HttpWebRequest request = (HttpWebRequest)WebRequest.Create(endPoint);
				request.KeepAlive = false;
				request.ProtocolVersion = HttpVersion.Version10;
				request.Method = httpMethod.ToString();
				request.Headers.Add("Cookie", B1SESSION);
				request.ContentType = "application/json";
				using (StreamWriter swJSONPayload = new StreamWriter(request.GetRequestStream()))
				{
					swJSONPayload.Write(patchJSON);
					swJSONPayload.Close();
				}
				HttpWebResponse response = null;
				try
				{
					response = (HttpWebResponse)request.GetResponse();
					using (Stream responseStream = response.GetResponseStream())
					{
						if (responseStream != null)
						{
							using (StreamReader reader = new StreamReader(responseStream))
							{
								_message = reader.ReadToEnd();
							}
						}
					}
				}
				catch (WebException ex)
				{
					_message = new StreamReader(ex.Response.GetResponseStream()).ReadToEnd();
					return false;
				}
				finally
				{
					//LogOut();
				}
			}
			catch (Exception ex)
			{
				_message = ex.Message;
				return false;
			}
			return true;
		}

		public bool patchRequest(out string _message)
		{
			_message = "";
			ServicePointManager.Expect100Continue = true;
			ServicePointManager.ServerCertificateValidationCallback = (sender, x509Certificate, chain, sslPolicyErrors) => true;
			string stringResponseValue = string.Empty;
			try
				{
				HttpWebRequest request = (HttpWebRequest)WebRequest.Create(endPoint);
				request.KeepAlive = false;
				request.ProtocolVersion = HttpVersion.Version10;
				request.Method = httpMethod.ToString();
				request.Headers.Add("B1S-ReplaceCollectionsOnPatch", "true");
				request.Headers.Add("Cookie", B1SESSION);
				request.ContentType = "application/json";
				using (StreamWriter swJSONPayload = new StreamWriter(request.GetRequestStream()))
				{
					swJSONPayload.Write(patchJSON);
					swJSONPayload.Close();
				}

				HttpWebResponse response = null;
				try
				{
					response = (HttpWebResponse)request.GetResponse();
					using (Stream responseStream = response.GetResponseStream())
					{
						if (responseStream != null)
						{
							using (StreamReader reader = new StreamReader(responseStream))
							{
								stringResponseValue = reader.ReadToEnd();
							}
						}
					}
				}
				catch (WebException ex)
				{
					string message = new StreamReader(ex.Response.GetResponseStream()).ReadToEnd();
					stringResponseValue = message;
					_message = message;
					return false;
				}
				finally
				{
					//LogOut();
				}
			}
			catch(Exception ex)
			{
				_message = ex.Message;
				return false;
			}


			return true;
		}

		public bool deleteRequest(out string _message)
		{
			_message = string.Empty;
			try
			{
				HttpWebRequest request = (HttpWebRequest)WebRequest.Create(endPoint);
				request.Method = httpMethod.ToString();
				request.Headers.Add("Cookie", B1SESSION);
				HttpWebResponse Logoutresponse = null;
				try
				{
					Logoutresponse = (HttpWebResponse)request.GetResponse();
				}
				catch (WebException ex)
				{
					_message = new StreamReader(ex.Response.GetResponseStream()).ReadToEnd();
					return false;
				}
			}
			catch (Exception ex)
			{
				_message = ex.Message;
				return false;
			}
			return true;
		}

		public void LogOut()
		{
			try
			{
				HttpWebRequest LogoutRequest = (HttpWebRequest)WebRequest.Create(ConfigManager.GetServiceLayerURL() + "Logout");
				LogoutRequest.Method = "POST";
				LogoutRequest.Headers.Add("Cookie", strSID);
				HttpWebResponse Logoutresponse = null;
				try
				{
					Logoutresponse = (HttpWebResponse)LogoutRequest.GetResponse();
				}
				catch (WebException ex)
				{
					string message = new StreamReader(ex.Response.GetResponseStream()).ReadToEnd();
				}
			}
			catch { }
		}

		public string ReportLogin()
		{
			LoginServiceLayerModel _clsEntity_ServiceLayerLogin = new LoginServiceLayerModel();
			_clsEntity_ServiceLayerLogin.CompanyDB = ConfigManager.GetSAPDatabase();
			_clsEntity_ServiceLayerLogin.UserName = ConfigManager.GetSAPUserCode();
			_clsEntity_ServiceLayerLogin.Password = ConfigManager.GetSAPPassword();
			_clsEntity_ServiceLayerLogin.DBInstance = ConfigManager.GetDBInstance();

			var login = JsonConvert.SerializeObject(_clsEntity_ServiceLayerLogin);
			httpMethod = httpVerb.POST;
			endPoint = ConfigManager.GetReportServiceLayerURL() + "login";
			postJSON = login;
			ServicePointManager.Expect100Continue = true;
			//ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls;
			ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
			ServicePointManager.ServerCertificateValidationCallback = (sender, x509Certificate, chain, sslPolicyErrors) => true;

			string stringResponseValue = string.Empty;

			try
			{
				HttpWebRequest request = (HttpWebRequest)
				WebRequest.Create(endPoint);
				request.KeepAlive = false;
				request.ProtocolVersion = HttpVersion.Version10;
				request.Method = httpMethod.ToString();
				byte[] postBytes = Encoding.ASCII.GetBytes(postJSON);
				request.ContentType = "application/json";
				request.ContentLength = postBytes.Length;
				Stream requestStream = request.GetRequestStream();
				requestStream.Write(postBytes, 0, postBytes.Length);
				requestStream.Close();
				HttpWebResponse response = null;
				try
				{
					using (response = (HttpWebResponse)request.GetResponse())
					{
						if (response.StatusCode.Equals(HttpStatusCode.OK))
						{
							stringResponseValue = response.Headers.Get("Set-Cookie");
						}
					}
				}
				catch (WebException ex)
				{
					stringResponseValue = new StreamReader(ex.Response.GetResponseStream()).ReadToEnd();
				}
			}
			catch (Exception ex)
			{
				return ex.Message;
			}
			return stringResponseValue;
		}

		public bool ReportLoginGetRequest(out string _message)
		{
			//ServicePointManager.Expect100Continue = true;
			//ServicePointManager.SecurityProtocol = SecurityProtocolType.Ssl3 | SecurityProtocolType.Tls;
			//ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
			//ServicePointManager.ServerCertificateValidationCallback = (sender, x509Certificate, chain, sslPolicyErrors) => true;

			//ServicePointManager.ServerCertificateValidationCallback +=
			//(sender, certificate, chain, sslPolicyErrors) => true;

			var options = new RestClientOptions(endPoint)
			{
				RemoteCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) => true
			};
			var restClient = new RestClient(options);

			_message = "";
			//var client = new RestClient(endPoint);
			var request = new RestRequest();
			request.Method = Method.Get;
			request.AddHeader("Content-Type", "application/json");
			request.AddHeader("Cookie", B1SESSION);
			//if (!string.IsNullOrEmpty(patchJSON))
			//{
			//	var body = patchJSON;
			//	request.AddParameter("application/json", body, ParameterType.RequestBody);
			//}
			RestSharp.RestResponse response = restClient.Execute(request);
			Console.WriteLine(response.Content);
			return true;
		}

		public void Test()
		{
			string url = "https://192.168.2.5:60000/rs/v1/ExportPDFData?DocCode=RCRI011";
			var options = new RestClientOptions(url)
			{
				RemoteCertificateValidationCallback = (sender, certificate, chain, sslPolicyErrors) => true
			};
			var client = new RestClient(options);

			var request = new RestRequest();
			request.Method = Method.Post;
			request.AddHeader("Content-Type", "application/json");
			request.AddHeader("Cookie", B1SESSION);
			var body = @"[    {
" + "\n" +
			@"        ""name"": ""DocKey@"",
" + "\n" +
			@"        ""type"": ""xsd:decimal"",
" + "\n" +
			@"        ""value"": [ [""23""]]                
" + "\n" +
			@"    },
" + "\n" +
			@"    {
" + "\n" +
			@"        ""name"": ""ObjectID@"",
" + "\n" +
			@"        ""type"": ""xsd:string"",
" + "\n" +
			@"        ""value"": [ [""23""]]                
" + "\n" +
			@"    },
" + "\n" +
			@"    {
" + "\n" +
			@"        ""name"": ""Schema@"",
" + "\n" +
			@"        ""type"": ""xsd:string"",
" + "\n" +
			@"        ""value"": [ [""APA_LIVE""]]                
" + "\n" +
			@"    }
" + "\n" +
			@"]";
			request.AddParameter("application/json", body, ParameterType.RequestBody);
			RestSharp.RestResponse response = client.Execute(request);
			Console.WriteLine(response.Content);
		}

		public bool getRequestData(out string _message)
		{
			_message = "";
			ServicePointManager.Expect100Continue = true;
			ServicePointManager.ServerCertificateValidationCallback = (sender, x509Certificate, chain, sslPolicyErrors) => true;
			string stringResponseValue = string.Empty;
			try
			{
				HttpWebRequest request = (HttpWebRequest)WebRequest.Create(endPoint);
				request.KeepAlive = false;
				request.ProtocolVersion = HttpVersion.Version10;
				request.Method = "GET";
				request.ContentType = "application/json";
				HttpWebResponse response = null;
				try
				{
					response = (HttpWebResponse)request.GetResponse();
					using (Stream responseStream = response.GetResponseStream())
					{
						if (responseStream != null)
						{
							using (StreamReader reader = new StreamReader(responseStream))
							{
								_message = reader.ReadToEnd();
							}
						}
					}
				}
				catch (WebException ex)
				{
					//string message = new StreamReader(ex.Response.GetResponseStream()).ReadToEnd();
					//stringResponseValue = message;
					//_message = message;
					return false;
				}
				finally
				{
					//LogOut(serviceURL);
				}

			}
			catch (Exception ex)
			{
				return false;
			}


			return true;
		}

	}
}
