﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebDAL.Helper
{
    public enum ServiceLayerEntity
    {
        Drafts,
        Orders,
        Quotations,
        DeliveryNotes,
        Items,
        ProductTrees,
        ECR,
        PurchaseOrders,
        StockTransfers,
        VCJBSM,
        VCDPM,
        WEB_GANGUP,
        WEB_PO_REGISTER,
        WEB_KLD
    }

    public enum ObjectType
    {
        Orders = 17,
        Quotations = 23,
        PurchaseOrders = 22,
        StockTransfers = 67,
        //JobSequences = VCJBSM
    }

    public enum DistributionDimension
    {
        General = 1,
        Machine = 2,
        ClientWise = 4,
    }

    public enum httpVerb
    {
        GET,
        POST,
        PUT,
        DELETE,
        PATCH
    }

    public enum Department
    {
        General = -2,
        Sales = 1,
        DieCutting = 2,
        Offline = 3,
        Pasting = 4,
        Lamination = 5,
        Purchase = 6,
        PlayingCard = 7,
        Dispatch = 8,
        Stores = 9,
        Account = 10,
        QC = 11,
        PrductionPrinting = 12,
        Cutting = 13,
        Printing = 14,
        FOIL = 15,
        PACKING = 16,
        Operation = 17,
        Ink = 18,
        NPD = 19,
        PPC = 20,
        CONTRACTOR = 23,
        POSTPRESS = 22,
        FOLDING = 24,
        ADMINISTRATION = 25,
        BACKOFFICE = 26,
        PREPRESS = 21,
        LAMINATORMC = 27,
        FLEXOPRINTING = 28,
        CORRUGATION = 29,
        SALESCOORDINATOR = 34
    }
    public enum PrintForm
    {
        SalesOrderLayout,
        PurchaseOrderLayout,
        ECRLayout,
        ECRCreditNoteLayout
    }

    public enum AppData
    {
        ECREmailAddress,
        ExportSalesQuotationEmailAddress,
        ProjectionEmailAddress,
        ClientPOEmailAddress
    }

    public enum DropDown
    {
        CARTONTYPE,
        ECRREASON,
        REFSAMPLE,
        INKTYPE,
    }

    public enum MasterGroup
    {
        ConsumableStore = 1,
        Dispatch = 2,
        InkStore = 3,
        PaperStock = 4,
        PaperStore = 4,
        ServiceItems = 5,
        OtherStores = 6,
    }
}
