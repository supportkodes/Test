﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Helper
{
    public static class ConfigManager
    {
        static IConfigurationRoot dbconfig = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json").Build();

		public static string GetHanaConnectionString()
		{
			return dbconfig["ConnectionString:DbConnection"].ToString();
		}
		public static string GetSMTP_Host()
        {
            return dbconfig["SMTP:Host"].ToString();
        }

        public static string GetSMTP_UserName()
        {
            return dbconfig["SMTP:UserName"].ToString();
        }

        public static string GetSMTP_Password()
        {
            return dbconfig["SMTP:Password"].ToString();
        }

        public static int GetSMTP_Port()
        {
            return int.Parse(dbconfig["SMTP:Port"].ToString());
        }

        public static string GetSMTP_FromMail()
        {
            return dbconfig["SMTP:FromMail"].ToString(); 
        }

        public static string GetSMTP_EnableSsl()
        {
            return dbconfig["SMTP:EnableSsl"].ToString();
        }

        public static string GetWebSiteURL()
        {
            return dbconfig["URL:WebSiteUrl"].ToString(); 
        }

        public static string GetSAPDatabase()
        {
            return dbconfig["SAP:SAPDatabase"].ToString();
        }

        public static string GetSAPUserCode()
        {
            return dbconfig["SAP:SAPUserCode"].ToString();
        }
        public static string GetSAPPassword()
        {
            return dbconfig["SAP:SAPPassword"].ToString();
        }
		public static string GetDBInstance()
		{
			return dbconfig["SAP:DBInstance"].ToString();
		}
		public static string GetServiceLayerURL()
        {
            return dbconfig["SAP:ServiceLayerURL"].ToString();
        }
		public static string GetEmail_BCCEmailAddress()
		{
			return dbconfig["Email:BCCEmailAddress"].ToString();
		}
        //public static string GetECREmailAddress()
		//{
		//	return dbconfig["Email:ECREmailAddress"].ToString();
		//}
		public static string GetEmail_ExportSalesQuotationEmailAddress()
		{
			return dbconfig["Email:ExportSalesQuotationEmailAddress"].ToString();
		}
		public static string GetEmail_ProjectionEmailAddress()
		{
			return dbconfig["Email:ProjectionEmailAddress"].ToString();
		}
		public static string GetReportServiceLayerURL()
		{
			return dbconfig["SAP:ReportServiceLayerURL"].ToString();
		}
		public static string GetReportAPIUrl()
		{
			return dbconfig["URL:ReportAPIUrl"].ToString();
		}

        public static string GetUploadPath()
        {
            return dbconfig["Path:UploadPath"].ToString();
        }

        public static string GetEnvironment()
		{
			return dbconfig["Environment"].ToString();
		}
	}
}