﻿using Microsoft.Extensions.Configuration;
using Sap.Data.Hana;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace WebDAL.Helper
{
    public class clsDataAccess
    {
        SqlConnection con;
        HanaConnection hanaconn;

        public clsDataAccess()
        {

        }

        public string HanaConnectionString()
        {
            string connectionstring = "";
            try
            {
                var dbconfig = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json").Build();
                connectionstring = dbconfig["ConnectionString:DbConnection"];
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return connectionstring;
        }

        public HanaConnection OpenConnection()
        {
            try
            {
                var dbconfig = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json").Build();
                string dbconnectionStr = dbconfig["ConnectionString:DbConnection"];
                hanaconn = new HanaConnection(dbconnectionStr);
                //HanaConnectionStringBuilder builder = new HanaConnectionStringBuilder(SQLConnectionString);
                //string sqlconnstring = @"UserID=" + builder.UserName + ";Password=" + builder.Password + ";Server=" + builder.Server + "";
                //hanaconn = new HanaConnection();
                //hanaconn.ConnectionString = sqlconnstring;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return hanaconn;
        }

		//public DataTable FillDataSet(string commandText, CommandType commandType, HanaConnection conn, out string message, params HanaParameter[] parameters)
		//{
		//    message = string.Empty;
		//    DataTable ods = new DataTable();
		//    HanaDataAdapter da = null;
		//    HanaCommand cmd = null;
		//    try
		//    {

		//        cmd = new HanaCommand();
		//        cmd.Parameters.AddRange(parameters);
		//        cmd.CommandType = commandType;
		//        cmd.CommandText = commandText;
		//        cmd.Connection = conn;
		//        da = new HanaDataAdapter(cmd);
		//        da.Fill(ods);
		//        return ods;

		//    }
		//    catch (Exception ex)
		//    {
		//        message = ex.Message;
		//    }
		//    finally
		//    {
		//        conn.Close();
		//        if (ods != null)
		//        {
		//            ods.Dispose();
		//        }
		//        if (cmd != null)
		//        {
		//            cmd.Dispose();
		//        }
		//        if (da != null)
		//        {
		//            da.Dispose();
		//        }
		//    }
		//    return ods;

		//}

		public string GetRecordValue(string commandText, CommandType commandType, out string message, params HanaParameter[] parameters)
		{
			message = string.Empty;
            string value = "";
            DataTable dt =  FillDataTable( commandText,  commandType, out  message, parameters);
            if (dt.Rows.Count > 0)
            {
                value = dt.Rows[0][0].ToString();
            }
			return value;
		}
		public DataTable FillDataTable(string commandText, CommandType commandType, out string message, params HanaParameter[] parameters)
        {
            message = string.Empty;
            DataTable ods = new DataTable();
            using (HanaConnection conn = new HanaConnection(HanaConnectionString()))
            {
                try
                {
                    using (HanaCommand cmd = new HanaCommand(commandText, conn))
                    {
                        conn.Open();
                        cmd.Parameters.AddRange(parameters);
                        cmd.CommandType = commandType;
                        cmd.CommandText = commandText;
                        using (HanaDataAdapter da = new HanaDataAdapter(cmd))
                        {
                            da.Fill(ods);
                            cmd.Dispose();
                            da.Dispose();
                            return ods;
                        }
                    }
                }
                catch (Exception ex)
                {
                    message = ex.Message;
                }
                finally
                {
                    if (conn != null && conn.State == ConnectionState.Closed)
                    {
                        conn.Close();
                    }
                    if (ods != null)
                    {
                        ods.Dispose();
                    }
                }
            }
            return ods;
        }

		public DataTable ToDataTable<T>(List<T> items)
		{
			DataTable dataTable = new DataTable(typeof(T).Name);
			//Get all the properties
			PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
			foreach (PropertyInfo prop in Props)
			{
				//Setting column names as Property names
				dataTable.Columns.Add(prop.Name);
			}
			foreach (T item in items)
			{
				var values = new object[Props.Length];
				for (int i = 0; i < Props.Length; i++)
				{
					//inserting property values to datatable rows
					values[i] = Props[i].GetValue(item, null);
				}
				dataTable.Rows.Add(values);
			}
			//put a breakpoint here and check datatable
			return dataTable;
		}
	}
}
