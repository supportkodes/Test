﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http.Headers;
using System.Text;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using WebDAL.Helpers;
using WebDAL.Models;
using WebDAL.Repository;

namespace WebDAL.Helper
{
	public class Utility : clsDataAccess
	{

		public ResponseModel SaveAttachment(string res, string docEntry, string atcEntry, string userId, List<DocumentModel_Attachment> _Attachments2_Lines, string serviceLayerObject)
		{
			ResponseModel responseModel = new ResponseModel();
			string attachmentEntry = atcEntry;
			try
			{
				ServiceLayer rc = new ServiceLayer();
				CommonRepository commonRepository = new CommonRepository();
				DocumentModel_Attachment_ServiceLayer _objServiceLayer = new DocumentModel_Attachment_ServiceLayer();
				string attachmentPath = commonRepository.GetAttachmentPath();
				List<DocumentModel_AttachmentLines_ServiceLayer> _clsEntity_AttachmentLines_ServiceLayer = new List<DocumentModel_AttachmentLines_ServiceLayer>();
				for (int i = 0; i < _Attachments2_Lines.Count; i++)
				{
					string lineNum = _Attachments2_Lines[i].Line;
					string filePath = _Attachments2_Lines[i].trgtPath;
					_clsEntity_AttachmentLines_ServiceLayer.Add(new DocumentModel_AttachmentLines_ServiceLayer { });
					if (!string.IsNullOrEmpty(lineNum))
					{
						string directoryName = System.IO.Path.GetDirectoryName(filePath);
						string fileName = Path.GetFileName(filePath);
						System.IO.FileInfo fi = new System.IO.FileInfo(filePath);

						//_clsEntity_AttachmentLines_ServiceLayer[i].LineNum = int.Parse(_clsEntity_Document.Attachments2_Lines[i].Line);
						_clsEntity_AttachmentLines_ServiceLayer[i].SourcePath = directoryName;
						_clsEntity_AttachmentLines_ServiceLayer[i].FileName = Path.GetFileNameWithoutExtension(filePath);
						_clsEntity_AttachmentLines_ServiceLayer[i].FileExtension = fi.Extension.Replace(".", "");
					}
					else
					{
						string directoryName = System.IO.Path.GetDirectoryName(filePath);
						string fileName = Path.GetFileName(filePath);
						System.IO.FileInfo fi = new System.IO.FileInfo(filePath);

						_clsEntity_AttachmentLines_ServiceLayer[i].SourcePath = directoryName;
						_clsEntity_AttachmentLines_ServiceLayer[i].FileName = Path.GetFileNameWithoutExtension(filePath);
						_clsEntity_AttachmentLines_ServiceLayer[i].FileExtension = fi.Extension.Replace(".", "");

						string destFilePath = attachmentPath + fileName;
						File.Copy(filePath, destFilePath, true);
					}
				}

				_objServiceLayer.Attachments2_Lines = _clsEntity_AttachmentLines_ServiceLayer;
				string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
				{
					NullValueHandling = NullValueHandling.Ignore,
				});
				var temp = JsonConvert.DeserializeObject<JObject>(main);
				string message = "";
				bool result = false;
				rc.patchJSON = main;
				rc.B1SESSION = res;

				if (attachmentEntry == null)
				{
					rc.endPoint = ConfigManager.GetServiceLayerURL() + "Attachments2";
					rc.httpMethod = httpVerb.POST;
					result = rc.postRequest(out message);
					if (result == true)
					{
						var jobject = JsonConvert.DeserializeObject<JObject>(message);
						string absEntry = jobject["AbsoluteEntry"].ToString();
						Int32 iAtcEntry = Int32.Parse(absEntry);
						UpdateAttachmentEntry_AgainstDocument(res, serviceLayerObject, docEntry, iAtcEntry.ToString());
						responseModel.ResponseStatus = true;
					}
					else
					{
						var jobject = JsonConvert.DeserializeObject<JObject>(message);
						string jsonMessage = jobject["error"].ToString();
						jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
						jsonMessage = jobject["message"].ToString();
						jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
						jsonMessage = jobject["value"].ToString();
						responseModel.ResponseStatus = false;
						responseModel.ResponseText = jsonMessage;

						//if (ConfigManager.GetEnvironment() == "Development")
						//{
						string outMessage = "";
						string query = "SELECT MAX(\"AbsEntry\") FROM " + ConfigManager.GetSAPDatabase() + ".OATC";
						string absEntry = GetRecordValue(query, System.Data.CommandType.Text, out outMessage);
						if (!string.IsNullOrEmpty(absEntry))
						{
							long labsEntry = long.Parse(absEntry) + 1;
							query = "INSERT INTO " + ConfigManager.GetSAPDatabase() + ".OATC(\"AbsEntry\") VALUES(" + labsEntry + ")";
							GetRecordValue(query, System.Data.CommandType.Text, out outMessage);
							string date = DateTime.Now.Date.ToString("yyyyMMdd");
							for (int i = 0; i < _clsEntity_AttachmentLines_ServiceLayer.Count; i++)
							{
								StringBuilder stringBuilder = new StringBuilder();
								stringBuilder.Append("INSERT INTO " + ConfigManager.GetSAPDatabase() + ".ATC1");
								stringBuilder.Append("(\"AbsEntry\",\"Line\",\"srcPath\", \"trgtPath\", \"FileName\"");
								stringBuilder.Append(", \"FileExt\", \"Date\", \"UsrID\", \"Copied\", \"Override\"");
								stringBuilder.Append(", \"CopyToTrgt\", \"CopyToProd\", \"EDocSign\")  ");
								stringBuilder.Append(" VALUES  ");

								stringBuilder.Append("(" + labsEntry + "," + (i + 1).ToString() + ", '" + _clsEntity_AttachmentLines_ServiceLayer[i].SourcePath + "',  '" + attachmentPath + "', '" + _clsEntity_AttachmentLines_ServiceLayer[i].FileName + "' ");
								stringBuilder.Append(", '" + _clsEntity_AttachmentLines_ServiceLayer[i].FileExtension + "', '" + date + "', " + userId + ", 'Y','N' ");
								stringBuilder.Append(",'N', 'N','N') ");
								GetRecordValue(stringBuilder.ToString(), System.Data.CommandType.Text, out outMessage);
							}
							UpdateAttachmentEntry_AgainstDocument(res, serviceLayerObject, docEntry, labsEntry.ToString());
						}
						//}
					}
				}
				else
				{
					rc.endPoint = ConfigManager.GetServiceLayerURL() + "Attachments2(" + attachmentEntry + ")";
					rc.httpMethod = httpVerb.PATCH;
					result = rc.patchRequest(out message);
					if (result == true)
					{
						responseModel.ResponseStatus = true;
					}
					else
					{
						var jobject = JsonConvert.DeserializeObject<JObject>(message);
						string jsonMessage = jobject["error"].ToString();
						jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
						jsonMessage = jobject["message"].ToString();
						jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
						jsonMessage = jobject["value"].ToString();
						responseModel.ResponseStatus = false;
						responseModel.ResponseText = jsonMessage;

						string date = DateTime.Now.Date.ToString("yyyyMMdd");
						string outMessage = "";
						string query = "DELETE FROM " + ConfigManager.GetSAPDatabase() + ".ATC1 WHERE \"AbsEntry\" = " + attachmentEntry + "";
						GetRecordValue(query, System.Data.CommandType.Text, out outMessage);

						for (int i = 0; i < _clsEntity_AttachmentLines_ServiceLayer.Count; i++)
						{
							StringBuilder stringBuilder = new StringBuilder();
							stringBuilder.Append("INSERT INTO " + ConfigManager.GetSAPDatabase() + ".ATC1");
							stringBuilder.Append("(\"AbsEntry\",\"Line\",\"srcPath\", \"trgtPath\", \"FileName\"");
							stringBuilder.Append(", \"FileExt\", \"Date\", \"UsrID\", \"Copied\", \"Override\"");
							stringBuilder.Append(", \"CopyToTrgt\", \"CopyToProd\", \"EDocSign\")  ");
							stringBuilder.Append(" VALUES  ");

							stringBuilder.Append("(" + attachmentEntry + "," + (i + 1).ToString() + ", '" + _clsEntity_AttachmentLines_ServiceLayer[i].SourcePath + "',  '" + attachmentPath + "', '" + _clsEntity_AttachmentLines_ServiceLayer[i].FileName + "' ");
							stringBuilder.Append(", '" + _clsEntity_AttachmentLines_ServiceLayer[i].FileExtension + "', '" + date + "', " + userId + ", 'Y','N' ");
							stringBuilder.Append(",'N', 'N','N') ");
							GetRecordValue(stringBuilder.ToString(), System.Data.CommandType.Text, out outMessage);
						}
					}
				}
			}
			catch (Exception ex)
			{
				responseModel.ResponseStatus = false;
				responseModel.ResponseText = ex.Message;
			}
			return responseModel;
		}

		public ResponseModel UpdateAttachmentEntry_AgainstDocument(string res, string serviceLayerObject, string docEntry, string atcEntry)
		{
			ResponseModel responseModel = new ResponseModel();
			ServiceLayer rc = new ServiceLayer();

			DocumentModel_Update_Attachment_ServiceLayer _objServiceLayer = new DocumentModel_Update_Attachment_ServiceLayer();
			_objServiceLayer.AttachmentEntry = atcEntry;
			string main = JsonConvert.SerializeObject(_objServiceLayer, new JsonSerializerSettings()
			{
				NullValueHandling = NullValueHandling.Ignore,
			});
			if (serviceLayerObject.ToLower() == "items")
			{
				rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject + "('" + docEntry + "')";
			}
			else
			{
				rc.endPoint = ConfigManager.GetServiceLayerURL() + serviceLayerObject + "(" + docEntry + ")";
			}
			rc.patchJSON = main;
			rc.B1SESSION = res;
			rc.httpMethod = httpVerb.PATCH;
			string message = "";
			bool result = rc.patchRequest(out message);
			responseModel.ResponseStatus = result;
			if (result == true)
			{
				responseModel.ResponseText = "Operation completed successfully";
			}
			else
			{
				var jobject = JsonConvert.DeserializeObject<JObject>(message);
				string jsonMessage = jobject["error"].ToString();
				jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
				jsonMessage = jobject["message"].ToString();
				jobject = JsonConvert.DeserializeObject<JObject>(jsonMessage);
				jsonMessage = jobject["value"].ToString();
				responseModel.ResponseText = "Error occured during process: " + jsonMessage;
			}

			return responseModel;
		}


		//public static string SaveUploadedFile(IFormFileCollection files, int fileRow, string folderName)
		//{
		//    var pathToSave = System.IO.Path.Combine(System.IO.Directory.GetCurrentDirectory(), folderName);
		//    if (files.Count > 0)
		//    {
		//        if (!System.IO.Directory.Exists(pathToSave))
		//        {
		//            System.IO.Directory.CreateDirectory(pathToSave);
		//        }
		//        var file = files[fileRow];

		//        var fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
		//        var fullPath = System.IO.Path.Combine(pathToSave, fileName);
		//        var filePath = System.IO.Path.Combine(folderName, fileName);
		//        using (var stream = new System.IO.FileStream(fullPath, System.IO.FileMode.Create))
		//        {
		//            file.CopyTo(stream);
		//        }
		//        return filePath;
		//    }
		//    return "";
		//}

	}
}
