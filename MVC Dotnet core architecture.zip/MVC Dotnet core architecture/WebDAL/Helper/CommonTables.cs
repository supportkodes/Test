﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using WebDAL.Repository;

namespace WebDAL
{
    public class CommonTables
    {
        public const string WarehouseTable = "OWHS";
        public const string LocationTable = "OLCT";
        public const string ItemTable= "OITM";

        public const string DraftHeaderTable = "ODRF";
        public const string DraftRowTable = "DRF1";
        public const string DraftFreightTable = "DRF3";
        public const string DraftAddressTable = "DRF12";
        
        public const string SalesOrderHeaderTable = "ORDR";
        public const string SalesOrderRowTable = "RDR1";
		public const string SalesOrderFreightTable = "RDR3";
		public const string SalesOrderAddressTable = "RDR12";

		public const string DeliveryHeaderTable = "ODLN";
		public const string DeliveryRowTable = "DLN1";
		public const string DeliveryFreightTable = "DLN3";
		public const string DeliveryAddressTable = "DLN12";

		public const string SalesQuotationHeaderTable = "OQUT";
        public const string SalesQuotationRowTable = "QUT1";
        public const string SalesQuotationFreightTable = "QUT3";
        public const string SalesQuotationAddressTable = "QUT12";

		public const string BOMHeaderTable = "OITT";
		public const string BOMRowTable = "ITT1";
		public const string BOMStageRowTable = "ITT2";
        
        public const string FLEXOUPHeaderTable = "@AAPAFUP";
		public const string FLEXOUPRowTable = "@AAPAFUP1";

		public const string ECRHeaderTable = "@ECR";
		public const string ECRRowTable = "@ECR1";

		public const string PurchaseOrderHeaderTable = "OPOR";
		public const string PurchaseOrderRowTable = "POR1";
		public const string PurchaseOrderFreightTable = "POR3";
		public const string PurchaseOrderAddressTable = "POR12";

		public const string InventoryTransferHeaderTable = "OWTR";
		public const string InventoryTransferRowTable = "WTR1";

		public const string JobSequenceHeaderTable = "@VCJBSM";
		public const string JobSequenceRowTable = "@VCJBSD";

        public const string ShopFloorEntryHeaderTable = "@VCDPM";
        public const string ShopFloorEntryRowTable = "@VCDPD";

        public const string IssueForProdutionHeaderTable = "OIGE";
        public const string IssueForProdutionRowTable = "IGE1";

		public const string GangupHeaderTable = "@WEB_GANGUP";
		public const string GangupRowTable = "@WEB_GANGUP1";

		public const string ClientPORegisterHeaderTable = "@WEB_PO_REGISTER";
		public const string ClientPORegisterRowTable = "@WEB_PO_REGISTER1";

		public const string InventoryTransferRequestHeaderTable = "OWTQ";
		public const string InventoryTransferRequestRowTable = "WTQ1";

		public const string KLDMasterHeaderTable = "@WEB_KLD";
		public const string ShadeMasterHeaderTable = "@SHADECARDMST";
        public const string PunchMasterHeaderTable = "@WEB_Punch";

        public const string KLDHeaderTable = "@WEB_KLD";
        public const string KLDRowTable = "@WEB_KLD1";

        public const string PUNCHHeaderTable = "@WEB_PUNCH";
        public const string PUNCHRowTable = "@WEB_PUNCH1";

        public const string ContractorRateUpdateTable = "@WEB_CRU";
        public const string PPCDetailsInkTable = "@WEB_PPCDETAILS_INK";

        public const string ItemWeightCalculatorTable = "@WEB_ITEM_WEIGHT";

    }
}