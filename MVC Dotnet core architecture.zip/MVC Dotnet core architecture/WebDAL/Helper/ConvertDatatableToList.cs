﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace WebDAL.Helper
{
    public static class ConvertDatatableToList
    {
        public static List<T> ConvertToList<T>(DataTable datatable) where T : new()
        {
            List<T> Temp = new List<T>();
            try
            {
                List<string> columnsNames = new List<string>();
                foreach (DataColumn DataColumn in datatable.Columns)
                    columnsNames.Add(DataColumn.ColumnName);
                Temp = datatable.AsEnumerable().ToList().ConvertAll<T>(row => getObject<T>(row, columnsNames));
                return Temp;
            }
            catch
            {
                return Temp;
            }
        }


        public static T ConvertToEntity<T>(DataTable datatable) where T : new()
        {
            T Temp = new T();
            try
            {
                List<string> columnsNames = new List<string>();
                foreach (DataColumn DataColumn in datatable.Columns)
                    columnsNames.Add(DataColumn.ColumnName);
                Temp = datatable.AsEnumerable().ToList().ConvertAll<T>(row => getObject<T>(row, columnsNames)).FirstOrDefault();
                return Temp;
            }
            catch
            {
                return Temp;
            }
        }

        public static T getObject<T>(DataRow row, List<string> columnsName) where T : new()
        {
            T obj = new T();
            try
            {
                string columnname = "";
                string value = "";
                PropertyInfo[] Properties;
                Properties = typeof(T).GetProperties();
                foreach (PropertyInfo objProperty in Properties)
                {
                    try
                    {
                        columnname = columnsName.Find(name => name.ToLower() == objProperty.Name.ToLower());
                        if (!string.IsNullOrEmpty(columnname))
                        {
                            value = row[columnname].ToString();
                            if (!string.IsNullOrEmpty(value))
                            {
                                try
                                {
                                    if (Nullable.GetUnderlyingType(objProperty.PropertyType) != null)
                                    {
                                        value = row[columnname].ToString().Replace("$", "").Replace(",", "");
                                        objProperty.SetValue(obj, Convert.ChangeType(value, Type.GetType(Nullable.GetUnderlyingType(objProperty.PropertyType).ToString())), null);
                                    }
                                    else
                                    {
                                        value = row[columnname].ToString();
                                        objProperty.SetValue(obj, Convert.ChangeType(value, Type.GetType(objProperty.PropertyType.ToString())), null);
                                    }
                                }
                                catch { }
                            }
                        }
                    }
                    catch { }
                }
                return obj;
            }
            catch
            {
                return obj;
            }
        }

    }
}
