﻿using WebDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;

namespace WebDAL.IRepository
{
    public interface IJobSequenceRepository
	{
        List<JobSequenceModel> GetAll();
		JobSequenceModel Get(string docEntry,string userId);
        ResponseModel Add(JobSequenceModel model);
        ResponseModel Update(JobSequenceModel model);
		List<JCModel> GetJCNo(string mcode,string jobNo);
		List<JCModel> GetOPNo(string planno, string mcode);
	}
}
