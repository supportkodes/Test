﻿using WebDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.IRepository
{
    public interface IDashboardRepository
    {
        List<PendingForApprovalModel> GetPendingForApprovalSalesOrder(string userId);
        List<PendingForApprovalModel> GetPendingForApprovalSalesQuotation(string userId);
		List<PendingForApprovalItemModel> GetDraftSalesOrderItems(string docEntry);
		List<PendingForApprovalItemModel> GetDraftSalesQuatationItems(string docEntry);

		int GetOpenSOCount();
        int GetOpenSQCount();

    }
}
