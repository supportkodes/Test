﻿using WebDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;

namespace WebDAL.IRepository
{
    public interface IGangupRepository
	{
        List<GangupModel> GetAll();
		GangupModel Get(string docEntry);
        ResponseModel Add(GangupModel model);
        ResponseModel Update(GangupModel model);
		List<CopyDocumentModel> GetGangupData(string cardcode);
		List<GangupRowsModel> GetGangupSelectedData(string docEntry);
		List<ItemModel> GetAllChildItemDetails(string itemcode);
		string GetAllChildItemDetailsColor(string itemcode);
		string GetTotalNoofInk(string itemcodes);
        GangupModel GetClientPOGangupData(string docEntry, string lineNo);
    }
}
