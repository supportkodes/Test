﻿using WebDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;

namespace WebDAL.IRepository
{
    public interface IPunchMasterRepository
	{
		List<PunchMasterModel> GetAll();
		ResponseModel Add(PunchMasterModel model);
		ResponseModel AddBulkImport(PunchMasterModel model);
        PunchMasterModel Get(string code);// , string itemcode
        ResponseModel Update(PunchMasterModel model);
		//void AddBulkImport(List<PunchMasterModel> list);
	}
}
