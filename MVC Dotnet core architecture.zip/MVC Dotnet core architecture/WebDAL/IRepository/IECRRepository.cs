﻿using WebDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;

namespace WebDAL.IRepository
{
    public interface IECRRepository
	{
        List<ECRMasterModel> GetAll(string userId,string department, string status);
        string GetECRAutoNo();
		ECRMasterModel Get(string code, string userId, string department);
		DataTable GetMailDraft(string code);
		ResponseModel Add(ECRMasterModel model);
		ResponseModel Update(ECRMasterModel model);
		ResponseModel UpdateRemark(string basecode, string baseline, string remarks,string empId,string assignTo); 
		ResponseModel CloseECR(string code); 
		ResponseModel CancelECR(string code); 
		List<ECRModel_RemarkDetails> GetAllRemarkDetails(string basecode, string baseline , string empId);
	}
}
