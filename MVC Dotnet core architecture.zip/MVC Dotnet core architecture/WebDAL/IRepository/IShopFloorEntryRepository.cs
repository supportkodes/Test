﻿using WebDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;

namespace WebDAL.IRepository
{
    public interface IShopFloorEntryRepository
    {
        List<ShopFloorEntryModel> GetAll();
        ShopFloorEntryModel Get(string docEntry,string userId);
        ResponseModel Add(ShopFloorEntryModel model);
        ResponseModel Update(ShopFloorEntryModel model);
        List<PlanKeyModel> GetPlanKey(string mcode);

    }
}
