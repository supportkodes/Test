﻿using WebDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;

namespace WebDAL.IRepository
{
    public interface IIssueForProductionRepository
    {
        List<IssueForProductionModel> GetAll(string userId,string type);
        IssueForProductionModel Get(string docEntry,string userId,string type);
        ResponseModel Add(IssueForProductionModel model);
        ResponseModel Update(IssueForProductionModel model);
    }
}
