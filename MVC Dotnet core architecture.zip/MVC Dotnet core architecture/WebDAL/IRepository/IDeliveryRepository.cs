﻿using WebDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;

namespace WebDAL.IRepository
{
    public interface IDeliveryRepository
	{
        List<DeliveryModel> GetAll(string userId);
		DeliveryModel Get(string docEntry,string userId);
        ResponseModel Add(DeliveryModel model);
        ResponseModel Update(DeliveryModel model);
        ResponseModel Close(string docEntry);
        ResponseModel Cancel(string docEntry);
		DocumentModel GetSalesOrderOpenRows(string sodocEntry);
		List<JobCardModel> GetJobCardNoList(string itemcode , string baseentry);
	}
}
