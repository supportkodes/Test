﻿using WebDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.IRepository
{
    public interface ISubMasterRepository
    {
        List<PendingOrderReportModel> GetAllSubMenuMaster();
        PendingOrderReportModel GetSubMenuMaster(int SubMenuID);
        ResponseModel AddSubMenuMaster(PendingOrderReportModel SubMenuMaster);
        ResponseModel UpdateSubMenuMaster(PendingOrderReportModel SubMenuMaster);

    }
}
