﻿using WebDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using static WebDAL.Models.PrepressModel;
using static WebDAL.Models.PPCDetailsModel;

namespace WebDAL.IRepository
{
    public interface IPPCDetailsRepository
    {
        List<PPCDetailsRowModel> GetAllPPCDetails(string sono,string branch, string itemcode, out DataTable dataTable);
        List<PPCDetailsRowModel> GetMachinePlanning(string sono,string branch, string itemcode, out DataTable dataTable);
        ResponseModel UpdateDispatchDate1(string itemcode, string date);
        ResponseModel UpdateDispatchDate2(string itemcode, string date);
        ResponseModel UpdateDispatchDate3(string itemcode, string date);
        List<PPCDetailsInkDetailsModel> GetBOMInkDetails(string itemcode, string group);
        ResponseModel UpdateInkDetails(List<PPCDetailsInkDetailsModel> lists);
        ResponseModel UpdateDate(string itemcode, string columnName);
        ResponseModel UpdateConfirmationDate(string itemcode, string columnName, string date);
        ResponseModel UpdateConfirmation(string itemcode, string columnName);
        ResponseModel UpdateItemInInkDetails(string father, string itemcode);
        ResponseModel UpdateItemStatusInInkDetails(string father, string itemcode,string status);
        
    }
}