﻿using WebDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;

namespace WebDAL.IRepository
{
	public interface IBOMRepository
	{
		List<BOMMasterModel> GetAll(string bomType, out DataTable dataTable);
		BOMMasterModel Get(string Code);
		ResponseModel Add(BOMMasterModel model);
		ResponseModel Update(BOMMasterModel model);
		void UpdateBOMChildWarehouse(string itemcode, string warehouse);
	}
}
