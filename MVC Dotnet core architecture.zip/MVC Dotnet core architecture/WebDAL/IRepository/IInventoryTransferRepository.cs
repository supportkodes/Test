﻿using WebDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;

namespace WebDAL.IRepository
{
    public interface IInventoryTransferRepository
	{
        List<InventoryTransferModel> GetAll(string userId);
		InventoryTransferModel Get(string docEntry,string userId,string type);
        ResponseModel Add(InventoryTransferModel model);
        ResponseModel Update(InventoryTransferModel model);
		DocumentModel GetITROpenRows(string itdocEntry);


	}
}
