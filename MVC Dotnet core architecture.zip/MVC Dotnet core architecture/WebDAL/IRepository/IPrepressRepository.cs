﻿using WebDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using static WebDAL.Models.PrepressModel;

namespace WebDAL.IRepository
{
    public interface IPrepressRepository
    {
        List<PrepressRowsModel> GetAll(string name, string type, string itemcode);
        List<PrepressRowsModel> GetAllOpenData_WIP(string itemcode);
        List<PrepressRowsModel> GetAllOpenData_QC(string itemcode);
        List<PrepressRowsModel> GetAllOpenData_FO(string itemcode);
        ResponseModel UpdateQCApproval(string itemcode);
        ResponseModel UpdateFinalApproval(string itemcode);
        ResponseModel UpdateArtworkApproval(string itemcode);
        ResponseModel UpdateRevisedApproval(string itemcode);
        ResponseModel UpdateStartWork(string itemcode, string coulumnName, string CoulumnName2);
        ResponseModel UpdateEndWork(string itemcode, string endDate, string ColumnName2);
        ResponseModel UpdateArtworkReleaseDate(string itemcode, string date, string ColumnName2);
        ResponseModel UpdateArtworkReleaseApproveDate(string itemcode, string date, string ColumnName2);
        ResponseModel UpdateSampleSubmitDate(string itemcode, string date, string refsample);
        ResponseModel UpdatePrepressColumnData(string itemcode, string columName, string value, string CoulumnName2);
        ResponseModel UpdateRemark(string itemcode, string columName, string Remark, string CoulumnName2);

        //ResponseModel UpdateRemarkold(string itemcode, string Remark);
        ResponseModel UpdateRefSample(string itemcode, string refSampl, string CoulumnName2);
        ResponseModel ReworkLog(string itemcode);
        ResponseModel UpdateKLD(string itemcode, string KLDNo);
        ResponseModel UpdatePunch(string itemcode, string PunchNo);
        ResponseModel UpdateInkType(string itemcode, string InkType);

    }
}