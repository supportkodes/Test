﻿using WebDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;

namespace WebDAL.IRepository
{
    public interface IKLDMasterRepository
	{
		List<KLDMasterModel> GetAll(string status);
		ResponseModel Add(KLDMasterModel model);
		KLDMasterModel Get(string code);// ,string itemcode
        ResponseModel Update(KLDMasterModel model);
        void UpdateStatus(string code,string status);
	}
}
