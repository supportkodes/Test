﻿using WebDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.IRepository
{
    public interface ISalesQuotationRepository
    {
        List<DocumentModel> GetAll(string userId,string type);
        DocumentModel Get(string docEntry,string userId,string type);
        ResponseModel Add(DocumentModel model);
        ResponseModel Update(DocumentModel model);
        ResponseModel UpdateStatus(string docEntry,string status,string userId);
		ResponseModel Close(string docEntry);
		ResponseModel Cancel(string docEntry);
		ResponseModel PDF(string docEntry);
		//DocumentModel GetClientPOSQData(string docEntry);
		List<DocumentModel> GetSQClientPOData(string cardcode);
		List<CopyLineModel> GetSQSelectedData(string docEntry);
		List<CopyLineModel> GetSQItemsNotAddedInClientPO(string docEntry);
	}
}
