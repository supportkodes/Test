﻿using WebDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;

namespace WebDAL.IRepository
{
    public interface IShadeMasterRepository
	{
		List<ShadeMasterModel> GetAll();
		ResponseModel Add(ShadeMasterModel model);
		ShadeMasterModel Get(string code);
		ResponseModel Update(ShadeMasterModel model);
		void AddBulkImport(List<ShadeMasterModel> list);
	}
}
