﻿using WebDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;

namespace WebDAL.IRepository
{
    public interface IPurchaseOrderRepository
	{
        List<PurchaseOrderModel> GetAllDraft(string userId);
        List<PurchaseOrderModel> GetAllDocument(string userId);
		PurchaseOrderModel Get(string docEntry,string userId,string type);
        ResponseModel Add(PurchaseOrderModel model);
        ResponseModel Update(PurchaseOrderModel model);
		ResponseModel UpdateStatus(string docEntry, string status, string userId);
		void IsApprovalApplicable(PurchaseOrderModel model);
		ResponseModel Cancel(string docEntry);
		ResponseModel Close(string docEntry);
        ResponseModel UpdateLineStatus(string docEntry, int linenum);
        int GetOpenDocumentRowCount(string docEntry);
    }
}
