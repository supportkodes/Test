﻿using WebDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;

namespace WebDAL.IRepository
{
    public interface IClientPORegisterRepository
	{
        List<ClientPORegisterModel> GetAll();
        List<ClientPORegisterModel> GetAllClose();
		ClientPORegisterModel Get(string docEntry);
        ResponseModel Add(ClientPORegisterModel model);
        ResponseModel Update(ClientPORegisterModel model);
		DataTable GetMailDraft(string itemcode, string rate);
        string GetCreator(string docEntry);
        List<CopyDocumentModel> GetClientPORegisterData(string cardcode);
		List<ClientPORegisterRowsModel> GetClientPOSelectedData(string docEntry);
        ResponseModel AddUpdateQtyPerPO(List<ClientPORegisterQtyPerPOModel> model);
        List<ClientPORegisterQtyPerPOModel> GetQtyPerPOList(string docEntry, string lineNo);
        ClientPORegisterModel GetSQToClientPOData(string docEntry);
        DataTable GetGangUpData(string cardcode,string lineIds);
        ItemModel GetClientPOItemDetails(string itemcode);
        void UpdateMailSent(string docEntry,string lineIds);
    }
}
