﻿using WebDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.IRepository
{
    public interface IAccountRepository
    {
        ResponseModel ValidateLogin(LoginModel loginModel);
        UserModel GetUserDetails(string userId);
        ResponseModel UpdateOTP(string emailId, string otp);
		List<CommonValueModel> GetUserDeptFormList(string emailId);
        string GetEmailFromMacID(string deviceID);

    }
}
