﻿using WebDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.IRepository
{
    public interface IPurchaseDashboardRepository
    {
        List<PendingForApprovalModel> GetPendingForApprovalPurchaseOrder(string userId);
        List<PendingForApprovalItemModel> GetDraftPurchaseOrderItems(string docEntry);
    }
}
