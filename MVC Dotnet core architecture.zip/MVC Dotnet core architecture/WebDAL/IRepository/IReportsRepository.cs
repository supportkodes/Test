﻿using WebDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.IRepository
{
    public interface IReportsRepository
    {
        List<BackOrderReportModel> GetBackOrderReport(string userId,string fromDate, string toDate, string cardcode, string itemcode);
        List<SuppliedMaterialReportModel> GetSuppliedMaterialReport(string slpcode, string fromDate, string toDate);
        List<FGStockStatusReportRowsModel> GetFGStockStatusReport(string userId, string cardcode);
        List<FGStockStatusReportDetailRowsModel> GetFGStockStatusItemWiseReport(string itemcode);
		List<DispatchDetailsReportModel> GetDispatchReport(string fromDate, string toDate, string slpcode);
		List<ItemPriceReportModel> GetItemPriceReport(string itemcode);
        List<PaymentProjectionRowsModel> GetPaymentProjection(string slpcode, string fromDate,string toDate, string year,string weekNo);
		ResponseModel ConfirmProjection(string slpcode,  string year,string weekNo);
        ResponseModel AddPaymentProjection(PaymentProjectionModel model);
        ResponseModel ExportSalesQuotation(string docEntry);
        ResponseModel TestGet(string docEntry);
        List<InventoryTransferReportModel> GetInventoryTransferReport(string toDate);
		List<PORegisterReportModel> GetPORegisterReport(string fromDate, string toDate, string itmsGrpName);
		List<PendingPOReportModel> GetPendingPOReport(string fromDate, string toDate, string cardcode, string itemcode);
		List<GRPORegisterReportModel> GetGRPORegisterReport(string fromDate, string toDate, string itmsGrpName);
        ResponseModel UpdateRemarkData(string lotno, string remark);
        ResponseModel GetClientFerreroDispatchReport(string fromDate, string toDate, string cardname, string itmsGrpName, string brand, string variant);
        ResponseModel GetPSSLayoutReport(string itemcode);
        List<ItemChapterTaxCodeReportModel> GetItemChapterTaxCodeReport();
        List<ItemModel> GetItemWiseWarehouseStock(string itemcode);
    }
}