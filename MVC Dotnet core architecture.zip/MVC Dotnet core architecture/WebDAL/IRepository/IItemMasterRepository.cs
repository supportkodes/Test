﻿using WebDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.IRepository
{
    public interface IItemMasterRepository
    {
        List<ItemModel> GetAll(int noofRows,string itembrand);
        ItemMasterModel Get(string docEntry);
        ResponseModel Add(ItemMasterModel model);
        ResponseModel Update(ItemMasterModel model);
		NewItemCodeModel GetAutoItemCode(ItemMasterModel itemMasterModel);
		//ResponseModel Validate(ItemMasterModel itemMasterModel);
	}
}
