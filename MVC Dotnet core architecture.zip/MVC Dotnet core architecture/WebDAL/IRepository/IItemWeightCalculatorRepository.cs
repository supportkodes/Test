﻿using WebDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;

namespace WebDAL.IRepository
{
    public interface IItemWeightCalculatorRepository
    {
        List<ItemWeightCalculatorModel> GetAll();
        ItemWeightCalculatorModel Get(string code);
        ResponseModel Add(ItemWeightCalculatorModel model);
        ResponseModel Update(ItemWeightCalculatorModel model);
    }
}
