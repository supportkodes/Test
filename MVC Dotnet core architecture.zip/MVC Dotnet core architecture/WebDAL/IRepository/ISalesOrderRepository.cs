﻿using WebDAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using WebDAL.Helper;

namespace WebDAL.IRepository
{
    public interface ISalesOrderRepository
    {
        List<DocumentIndexModel> GetAll(string userId,string type);
        DocumentModel Get(string docEntry,string userId,string type);
        ResponseModel Add(DocumentModel model);
        ResponseModel Update(DocumentModel model);
        ResponseModel UpdateStatus(string docEntry,string status,string userId, string res);
        ResponseModel UpdateIPAApproval(string docEntry);
        ResponseModel Close(string docEntry);
        ResponseModel Cancel(string docEntry);
		DocumentModel GetSalesQuotationOpenRows(string sqdocEntry);
		DataTable GetSalesOrderReportData(string docEntry);
		ResponseModel GetPendingAdviceData(string cardcode);
		ResponseModel GetPendingInvoiceData(string cardcode);
		string GetDraftCardCode(string cardcode);
        ValidateModel GetSOItemDetails(string itemcode);
        ResponseModel UpdateLineStatus(string docEntry, int linenum);
        int GetOpenDocumentRowCount(string docEntry);
	}
}
