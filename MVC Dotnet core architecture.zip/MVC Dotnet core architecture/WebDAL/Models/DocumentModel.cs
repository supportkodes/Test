﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
	public class DocumentModel
	{
		public string EditLink { get; set; }
		public string ButtonValue { get; set; }
		public string Type { get; set; }
		public string ShowApproval { get; set; }
		public string ApprovalStatus { get; set; }
		public string IsEditable { get; set; }
		public string UserId { get; set; }
		public double? BPTolerancePercent { get; set; }
		public double? BPLowerTolerancePercent { get; set; }

		public string DocEntry { get; set; }
		public string DocNum { get; set; }
		public string AtcEntry { get; set; }
		public string DocCurrency { get; set; }
		public string DocObjectCode { get; set; }
		public string DocRate { get; set; }
		public string Series { get; set; }
		public string SeriesName { get; set; }
		public string CardCode { get; set; }
		public string CardName { get; set; }
		public string U_CRBY { get; set; }
		public string NumAtCard { get; set; }
		public string DocStatus { get; set; }
		public string BPL_IDAssignedToInvoice { get; set; }
		public string DocDate { get; set; }
		public string TaxDate { get; set; }
		public string DocDueDate { get; set; }
		public string WarehouseCode { get; set; }
		public string PayToCode { get; set; }
		public string ShipToCode { get; set; }
		public string Address { get; set; }
		public string Address2 { get; set; }
		public string TransportationCode { get; set; }
		public string SalesPersonCode { get; set; }
		public string SlpName { get; set; }
		public string DocumentsOwner { get; set; }
		public string U_IsApp { get; set; }

		public string Comments { get; set; }
		public string DutyStatus { get; set; }
		public bool boolImpORExp { get; set; }
		public string ImpORExp { get; set; }
		public string ExportType { get; set; }
		public string SOAge { get; set; }


		public string U_MdTrns { get; set; }
		public string U_PortLoad { get; set; }
		public string U_PortDischarge { get; set; }
		public string U_INCOTERMS { get; set; }


		public double? NetAmount { get; set; }
		public double? DiscountPercent { get; set; }
		public double? TotalExpns { get; set; }
		public double? TaxAmount { get; set; }
		public double? RoundingDiffAmount { get; set; }
		public double? DocumentTotal { get; set; }
		public string BillTo_State { get; set; }
		public string ShipTo_State { get; set; }
		public string DocType { get; set; }
		public string Dscription { get; set; }
		public string ItemCode { get; set; }
		public string Rate { get; set; }
		public string Quantity { get; set; }
		public double? U_CTOL { get; set; }
		public double? U_CTLOL { get; set; }
		public List<DocumentRowsModel> DocumentLines { get; set; }
		public List<DocumentModel_Attachment> Attachments2_Lines { get; set; }
		public List<DocumentModel_Expenses> DocumentAdditionalExpenses { get; set; }
		public DocumentModel_TaxExtension TaxExtension { get; set; }
		public DocumentModel_AddressExtension AddressExtension { get; set; }
	}
	public class DocumentRowsModel
	{
		public int? Index { get; set; }
		public int? LineNum { get; set; }
		public string ItemCode { get; set; }
		public string ItemName { get; set; }
		public string U_Category { get; set; }
		public string SupplierCatNum { get; set; }
		public string TaxCode { get; set; }
		public string MeasureUnit { get; set; }
		public double? Quantity { get; set; }
		public double? UnitPrice { get; set; }
		public double Total { get; set; }
		public string WarehouseCode { get; set; }
		public string BOMWarehouseCode { get; set; }
		public string FreeText { get; set; }
		public double? U_CTOL { get; set; }
		public double? U_CTLOL { get; set; }
		public double? TaxRate { get; set; }
		public string TreeType { get; set; }
		public string OnHand { get; set; }
		public string HSNName { get; set; }
		public int HSNEntry { get; set; }
		public string ShipDate { get; set; }

		public double? InStockQuantity { get; set; }
		public double? DeliveredQuantity { get; set; }
		public double? OpenQuantity { get; set; }
		public int? BaseType { get; set; }
		public int? BaseEntry { get; set; }
		public int? BaseLine { get; set; }
		public string U_Exp1 { get; set; }
		public string U_Exp2 { get; set; }
		public string LineStatus { get; set; }
		public string IsDeleted { get; set; }
		public string BOMRatio { get; set; }
		public string BaseBOMLine { get; set; }
		public string U_UnwDrctn { get; set; }
		public string U_Packng { get; set; }
		public string ManagedBy { get; set; }
		public string U_NoOfUps { get; set; }
		public string LocCode { get; set; }
		public string UomCode { get; set; }
		public string U_JobCardNo { get; set; }
		public string U_JCText { get; set; }
		public string ProPlanNo { get; set; }
		public string JobCardNo { get; set; }
		public string LocationCode { get; set; }
		public string SACEntry { get; set; }
		public string ToWhsCode { get; set; }
		public string U_KLDNo { get; set; }
	}
	public class DocumentModel_Expenses
	{
		public int? Index { get; set; }
		public int ExpenseCode { get; set; }
		public string ExpenseName { get; set; }
		public double LineTotal { get; set; }
		public string TaxCode { get; set; }
		public double? TaxSum { get; set; }
		public double? TaxPercent { get; set; }
		public double? LineGross { get; set; }
	}

	public class DocumentModel_Attachment
	{
		public string AbsEntry { get; set; }
		public int Index { get; set; }
		public string Line { get; set; }
		public string srcPath { get; set; }
		public string trgtPath { get; set; }
		public string FileName { get; set; }
		public string FileExt { get; set; }
		public string IsChanged { get; set; }
	}
	public class DocumentModel_TaxExtension
	{
		public string ImportOrExport { get; set; }
		public string ImportOrExportType { get; set; }

		public object BillOfEntryDate { get; set; }
		public object BillOfEntryNo { get; set; }
		public object BlockB { get; set; }
		public object BlockS { get; set; }
		//public int BoEValue { get; set; }
		public object Brand { get; set; }
		public string BuildingB { get; set; }
		public string BuildingS { get; set; }
		public object Carrier { get; set; }
		public string CityB { get; set; }
		public string CityS { get; set; }
		public string ClaimRefund { get; set; }
		public string CountryB { get; set; }
		public string CountryS { get; set; }
		public object County { get; set; }
		public object CountyB { get; set; }
		public object CountyS { get; set; }
		//public int DifferentialOfTaxRate { get; set; }
		//public int DocEntry { get; set; }
		public object GlobalLocationNumberB { get; set; }
		public object GlobalLocationNumberS { get; set; }
		//public int GrossWeight { get; set; }
		public object Incoterms { get; set; }
		public string IsIGSTAccount { get; set; }
		public object MainUsage { get; set; }
		//public int NetWeight { get; set; }
		public object NFRef { get; set; }
		public object OriginalBillOfEntryDate { get; set; }
		public object OriginalBillOfEntryNo { get; set; }
		public object PackDescription { get; set; }
		public object PackQuantity { get; set; }
		public object PortCode { get; set; }
		public object ShipUnitNo { get; set; }
		public string State { get; set; }
		public string StateB { get; set; }
		public string StateS { get; set; }
		public string StreetB { get; set; }
		public string StreetS { get; set; }
		public object TaxId0 { get; set; }
		public object TaxId1 { get; set; }
		public object TaxId12 { get; set; }
		public object TaxId13 { get; set; }
		public object TaxId14 { get; set; }
		public object TaxId2 { get; set; }
		public object TaxId3 { get; set; }
		public object TaxId4 { get; set; }
		public object TaxId5 { get; set; }
		public object TaxId6 { get; set; }
		public object TaxId7 { get; set; }
		public object TaxId8 { get; set; }
		public object TaxId9 { get; set; }
		public object Vehicle { get; set; }
		public object VehicleState { get; set; }
		public string ZipCodeB { get; set; }
		public string ZipCodeS { get; set; }

	}
	public class DocumentModel_Update_Attachment_ServiceLayer
	{
		public string AttachmentEntry { get; set; }
	}
	public class DocumentModel_Attachment_ServiceLayer
	{
		public List<DocumentModel_AttachmentLines_ServiceLayer> Attachments2_Lines { get; set; }
	}
	public class DocumentModel_AttachmentLines_ServiceLayer
	{
		public int? LineNum { get; set; }
		public string SourcePath { get; set; }
		public string FileName { get; set; }
		public string FileExtension { get; set; }
	}
	public class DocumentModel_SaveDraftToDocument
	{
		public DraftDocument Document { get; set; }
	}
	public class DraftDocument
	{
		public string DocEntry { get; set; }
		//public string DocDate { get; set; }
		//public string TaxDate { get; set; }
		//public string DocDueDate { get; set; }
	}

	public class DocumentModel_AddressExtension
	{
        public string ShipToStreet { get; set; }
		public string ShipToStreetNo { get; set; }
		public string ShipToBlock { get; set; }
		public string ShipToBuilding { get; set; }
		public string ShipToCity { get; set; }
		public string ShipToZipCode { get; set; }
		public string ShipToState { get; set; }
		public string ShipToCountry { get; set; }
		public string ShipToAddressType { get; set; }
		public string BillToStreet { get; set; }
		public string BillToStreetNo { get; set; }
		public string BillToBlock { get; set; }
		public string BillToBuilding { get; set; }
		public string BillToCity { get; set; }
		public string BillToZipCode { get; set; }
		public string BillToState { get; set; }
		public string BillToCountry { get; set; }
		public string BillToAddressType { get; set; }
		public string ShipToGlobalLocationNumber { get; set; }
		public string BillToGlobalLocationNumber { get; set; }
		public string ShipToAddress2 { get; set; }
		public string ShipToAddress3 { get; set; }
		public string BillToAddress2 { get; set; }
		public string BillToAddress3 { get; set; }
		public string PlaceOfSupply { get; set; }
		public string PurchasePlaceOfSupply { get; set; }
		public string U_IGSTS { get; set; }
		public string U_IGSTB { get; set; }
		public string U_TestS { get; set; }
		public string U_TestB { get; set; }
	}


	public class DocumentModel_LineStatus_Close
	{
		public List<DocumentModel_LineStatus_CloseLines> DocumentLines { get; set; }
	}

	public class DocumentModel_LineStatus_CloseLines
	{
		public int LineNum { get; set; }
		public string LineStatus { get; set; }
	}


    public class DocumentIndexModel
    {
        public string EditLink { get; set; }
        public string ButtonValue { get; set; }
        public string Type { get; set; }
        public string DocEntry { get; set; }
        public string SalesPersonCode { get; set; }
        public string DocNum { get; set; }   
        public string CardName { get; set; }   
        public string DocDate { get; set; }   
        public string DocStatus { get; set; }   
        public string NumAtCard { get; set; }   
        public string SlpName { get; set; }   
        public string Comments { get; set; }   
        public string ApprovalStatus { get; set; }   
        public string SOAge { get; set; }   
        public string ClientPONo { get; set; }   
    }
}