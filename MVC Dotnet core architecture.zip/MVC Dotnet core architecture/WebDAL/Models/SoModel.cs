﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class SoModel
	{
        public string EditLink { get; set; }
        public string DuplicateLink { get; set; }
        public string UniqueID { get; set; }
        public string DocEntry { get; set; }
        public string DocNum { get; set; }
        public string DocDate { get; set; }
        public string LineNum { get; set; }
        public string Quantity { get; set; }
        public string ItemCode { get; set; }
        public string Dscription { get; set; }
        public string DocStatus { get; set; }
     
    }
}
