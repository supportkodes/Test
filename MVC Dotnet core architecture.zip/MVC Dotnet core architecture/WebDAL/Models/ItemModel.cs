﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class ItemModel
    {
        public string EditLink { get; set; }
        public string DuplicateLink { get; set; }
        public string DocEntry { get; set; }
        public string ItemCode { get; set; }
        public string ItemName { get; set; }
        public string ItmsGrpCod { get; set; }
        public string ItmsGrpNam { get; set; }
        public string UOM { get; set; }
        public string ChapterID { get; set; }
        public string DocNum { get; set; }
        public string LineNum { get; set; }
        public string DocDate { get; set; }
        public string Dscription { get; set; }
        public string Quantity { get; set; }
        public string Rate { get; set; }
        public double? Price { get; set; }
        public double? LineTotal { get; set; }
        public double? VatSum { get; set; }
        public string DocStatus { get; set; }
        public string PriceBefDi { get; set; }
        public string VatPercent { get; set; }
        public string U_CustName { get; set; }
        public string OnHand { get; set; }
        public string validFor { get; set; }
        public string CreateDate { get; set; }
        public string U_PrintItemDesc { get; set; }
        public string U_ARTSTT { get; set; }
        public string ChapterName { get; set; }
        public string TreeType { get; set; }
        public string BOMType { get; set; }
        public string U_QChk { get; set; }
        public string TaxCode { get; set; }
        public string Weight { get; set; }
        public string ManagedBy { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string U_KLDNo { get; set; }
        public string U_NoOfUps { get; set; }
        public string U_PunchNo { get; set; }
        public string UOMName { get; set; }
        public string U_InkType { get; set; }
        public string BuyUnitMsr { get; set; }
        public string WhsCode { get; set; }
        public string U_MASTGROUP { get; set; }
        public string BPLName { get; set; }
        public string BPLId { get; set; }
    }
}
