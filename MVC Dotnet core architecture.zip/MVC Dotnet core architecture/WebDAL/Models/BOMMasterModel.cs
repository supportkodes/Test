﻿using System.Collections.Generic;

namespace WebDAL.Models
{
    public class BOMMasterModel
    {
        public string EditLink { get; set; }
        public string DuplicateLink { get; set; }
		public string ShowApproval { get; set; }
		public string ApprovalStatus { get; set; }
		public string IsEditable { get; set; }
		public string Code { get; set; }
        public string ItemName { get; set; }
        public string TreeType { get; set; }
        public string TreeType_Disabled { get; set; }
        public string TreeCode { get; set; }
        public string Quantity { get; set; }
        public string DistributionRule { get; set; }
        public string Project { get; set; }
        public string DistributionRule2 { get; set; }
        public string DistributionRule3 { get; set; }
        public string DistributionRule4 { get; set; }
        public string DistributionRule5 { get; set; }
        public string PriceList { get; set; }
        public string Warehouse { get; set; }
        public string PlanAvgProdSize { get; set; }
        public string HideBOMComponentsInPrintout { get; set; }
        public string ProductDescription { get; set; }
        public bool IsHideBOM { get; set; }
        public string U_NoOfUps { get; set; }
        public string U_CUTSIZE { get; set; }
        public string U_PrintSide { get; set; }
        public string U_BRemarks { get; set; }
        public string U_PerPckQty { get; set; }
        public string U_PackQty { get; set; }
        public string U_TthNos { get; set; }
        public string U_Rlen { get; set; }
        public string U_Wdir { get; set; }
        public string U_ArdUps { get; set; }
        public string U_AcrUps { get; set; }
        public string U_PprSz { get; set; }
        public string U_CUTSIZX { get; set; }
        public string U_CUTSIZY { get; set; }
        public string U_NoOfCuts { get; set; }
        public string U_InkType{ get; set; }

		public List<BOMMasterModelRow> ProductTreeLines { get; set; }
		public List<ProductTreeStage> ProductTreeStages { get; set; }
	}
    public class BOMMasterModelRow
    {
        public int? Index { get; set; }
        public string ChildNum { get; set; }
        public string ItemCode { get; set; }
        public string Quantity { get; set; }
        public string Warehouse { get; set; }
        public string Price { get; set; }
        public string Currency { get; set; }
        public string IssueMethod { get; set; }
        public string InventoryUOM { get; set; }
        public string Comment { get; set; }
        public string ParentItem { get; set; }
        public string PriceList { get; set; }
        public string DistributionRule { get; set; }
        public string Project { get; set; }
        public string DistributionRule2 { get; set; }
        public string DistributionRule3 { get; set; }
        public string DistributionRule4 { get; set; }
        public string DistributionRule5 { get; set; }
        public string WipAccount { get; set; }
        public string ItemType { get; set; }
        public string LineText { get; set; }
        public string AdditionalQuantity { get; set; }
        public int? StageID { get; set; }
        public string VisualOrder { get; set; }
        public string ItemName { get; set; }
        public string U_FIXVAR { get; set; }
        public string U_TRNREQ { get; set; }
        public string U_SPW { get; set; }
        public string U_LinerFlute { get; set; }
        public string U_AniloxDetail { get; set; }
        public string U_AniloxSrNo { get; set; }
        public string? IsDeleted { get; set; }
    }

	public class ProductTreeStage
	{
		public string Father { get; set; }
		public int StageID { get; set; }
		public int SequenceNumber { get; set; }
		public int StageEntry { get; set; }
		public string Name { get; set; }
		public double WaitingDays { get; set; }
	}

}
