﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
	public class ShopFloorEntryModel
    {
		public string EditLink { get; set; }
		public string ButtonValue { get; set; }
		public string Type { get; set; }
		public string IsEditable { get; set; }
		public string UserId { get; set; }
		public string DocEntry { get; set; }
		public string U_MCode { get; set; }
		public string U_MName { get; set; }
		public string U_ShftCode { get; set; }
		public string U_Shift { get; set; }
		public string DocNum { get; set; }
		public string Series { get; set; }
		public string SeriesName { get; set; }
		public string U_DocDt { get; set; }
		public string Creator { get; set; }
		public string Remark { get; set; }
		public List<ShopFloorEntryRowsModel> VCDPDCollection { get; set; }
	}
	public class ShopFloorEntryRowsModel
    {
		public string IsDeleted { get; set; }
		public int? BaseType { get; set; }
		public int? BaseEntry { get; set; }
		public int? BaseLine { get; set; }
		public int? Index { get; set; }
		public int? LineNum { get; set; }
		public string U_OpType { get; set; }
		public string U_PlanKey { get; set; }
		public string U_StrHour { get; set; }
		public string U_EndHour { get; set; }
		public string U_OName { get; set; }
		public string U_OpName { get; set; }
		public string U_OCode { get; set; }
		public string U_PlanNo { get; set; }
		public string U_Date { get; set; }
		public string U_IsSplit { get; set; }
		public string U_ICode { get; set; }
		public string U_IName { get; set; }
		public string U_AvaQty { get; set; }
		public string U_NoOfCut { get; set; }
		public string U_Qty { get; set; }
		public string U_PQty { get; set; }
		public string U_RjQty { get; set; }
		public string U_Complete { get; set; }
		public string U_Nwhrs { get; set; }
		public string U_IFP { get; set; }
		public string U_RFP { get; set; }
		public string U_JobNo { get; set; }
		public string U_JobNm { get; set; }
		
	}
}
