﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class PlanKeyModel
    {
        public string PlanKey { get; set; }
        public string PlanNo { get; set; }
        public string Qty { get; set; }
        public string Date { get; set; }
        public string Operation { get; set; }
        public string JobNo { get; set; }
        public string JobName { get; set; }
    }
}
