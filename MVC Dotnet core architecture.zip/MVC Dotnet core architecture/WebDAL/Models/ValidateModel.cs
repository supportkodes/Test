﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class ValidateModel
	{
        public string QryGrp { get; set; }
        public string Flexo { get; set; }
        public string BOMType { get; set; }
        public string GroupName { get; set; }
    }
}
