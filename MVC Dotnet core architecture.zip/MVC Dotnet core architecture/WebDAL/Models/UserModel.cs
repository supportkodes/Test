﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class UserModel
    {
        public string empID { get; set; }
        public string UserCode { get; set; }
        public string UserId { get; set; }
        public string UserName { get; set; }
        public string EmailAddress { get; set; }
        public string Role { get; set; }
        public string Department { get; set; }
        public string DepartmentId { get; set; }
        public string ResponseMessage { get; set; }
    }
}
