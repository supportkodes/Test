﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class AddressModel
    {
        public string ID { get; set; }
        public string FullAddress { get; set; }
        public string Address { get; set; }
        public string Address2 { get; set; }
        public string Address3 { get; set; }
        public string Street { get; set; }
        public string StreetNo { get; set; }

        public string Block { get; set; }
        public string City { get; set; }
        public string ZipCode { get; set; }
        public string State { get; set; }
        public string Country { get; set; }

        public string GSTIN { get; set; }
        public string StateCode { get; set; }
        public string Code { get; set; }
       
        public string Name { get; set; }
        public string Location { get; set; }
    }
}
