﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class CopyDocumentModel
	{
        public string DocEntry { get; set; }
        public string DocNum { get; set; }
        public string DocDate { get; set; }
        public string NumAtCard { get; set; }
        public string DocStatus { get; set; }
        public string U_PPDocNum { get; set; }
        public string U_JOBNAME { get; set; }
        public string U_GRPNAM { get; set; }
        //public string U_ITEMNAME { get; set; }
        public string TreeType { get; set; }
        public string ItemCode { get; set; }
        public string BaseBOMLine { get; set; }
        public string BOMRatio { get; set; }
        public string Filler { get; set; }
        public string Comments { get; set; }
		public int Index { get; set; }
		public string Code { get; set; }
		public string U_CardName { get; set; }
		public string U_ItemName { get; set; }
		public string U_Qty { get; set; }
		public string U_KLDNo { get; set; }
		public string U_NoOfUPS { get; set; }
		public string TaxDate { get; set; }
		public string DocDueDate { get; set; }
		public string U_RateSys { get; set; }
		public string CardCode { get; set; }
		public string CardName { get; set; }
		public string DocTotal { get; set; }

	}
}
