﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class WarehouseModel
    {
        public string WhsCode { get; set; }
        public string WhsName { get; set; }
        public string DflWhs { get; set; }
    }
}
