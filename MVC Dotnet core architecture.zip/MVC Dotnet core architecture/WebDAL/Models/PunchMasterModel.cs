﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
	public class PunchMasterModel
	{
		public string EditLink { get; set; }
        public string RowNo { get; set; }
        public string Code { get; set; }
		public string Name { get; set; }
		public string U_KLDNo { get; set; }
        public string U_KLDDt { get; set; }
        public string U_CardCode { get; set; }
		public string U_NoOfUps { get; set; }
		public string U_SizeX { get; set; }
		public string U_SizeY { get; set; }
		public string CardName { get; set; }
		public string U_PunchNo { get; set; }
		public string U_PunchDt { get; set; }
		public string U_PunRecDt { get; set; }
		public string U_PunSenDt { get; set; }
		public string U_ItemCode { get; set; }
		public string U_Location { get; set; }
		public string Location { get; set; }
		public string U_Remark { get; set; }
		public string ItemName { get; set; }
		public string U_Lmm { get; set; }
		public string U_Wmm { get; set; }
		public string U_Hmm { get; set; }
		public string U_CartTyp { get; set; }
		public string U_CrBy { get; set; }
		public string U_PunchTyp { get; set; }
		public string U_Emboss { get; set; }
		public string U_Striping { get; set; }
		public string U_Foil { get; set; }
		public string U_SuppCode { get; set; }
		public string SuppName { get; set; }
		public string U_NAME { get; set; }
		public bool IsEmboss { get; set; }
		public bool IsStriping { get; set; }
		public bool IsFoil { get; set; }
        public List<PunchMasterRowsModel> Rows { get; set; }
        public class PunchMasterRowsModel
        {
            public int? Index { get; set; }
            public int? LineId { get; set; }
            public string U_ItemCode { get; set; }
            public string ItemName { get; set; }
            public string IsDeleted { get; set; }
            public string U_NoofUPS { get; set; }
            public string U_KLDNo { get; set; }

        }

    }
}
