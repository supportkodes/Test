﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class CRUModel
    {
        public string EditLink { get; set; } 
        public string DuplicateLink { get; set; }
        public string Code { get; set; }
        public string DocNum { get; set; }
        public string Name { get; set; }
        public string U_CardCode { get; set; }
        public string CardName { get; set; }
        public string U_KLDNo { get; set; }
        public string U_PrcType { get; set; }
        public string U_Rate { get; set; }
        public string U_Date { get; set; }
        public string U_Remarks { get; set; }
        public string U_ConCode { get; set; }
        public string U_Status { get; set; }
    }
}
