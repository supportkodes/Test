﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
	public class JobSequenceModel
	{
		public string EditLink { get; set; }
		public string ButtonValue { get; set; }
		public string Type { get; set; }
		public string IsEditable { get; set; }
		public string UserId { get; set; }
		public string U_MCode { get; set; }
		public string DocEntry { get; set; }
		public string U_MName { get; set; }
		public string U_AMCode { get; set; }
		public string U_AMName { get; set; }
		public string DocNum { get; set; }
		public string Series { get; set; }
		public string SeriesName { get; set; }
		public string U_DocDt { get; set; }
		public string Creator { get; set; }
		public string Remark { get; set; }
		public List<JobSequenceRowsModel> VCJBSDCollection { get; set; }
	}
	public class JobSequenceRowsModel
	{
		public string IsDeleted { get; set; }
		public int? BaseType { get; set; }
		public int? BaseEntry { get; set; }
		public int? BaseLine { get; set; }
		public int? Index { get; set; }
		public int? LineNum { get; set; }
		public string U_PLANDNO { get; set; }
		public string U_PLANNO { get; set; }
		public string U_OPCode { get; set; }
		public string U_PLANQty { get; set; }
		public string U_PROCQty { get; set; }
		public string U_PENDQty { get; set; }
		public string U_ICode { get; set; }
		public string U_IName { get; set; }
		public string U_Qty { get; set; }
		public string U_IsSplit { get; set; }
		public string U_Status { get; set; }
		public string U_Cancel { get; set; }
		
	}
}
