﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
namespace WebDAL.Models
{
    public class PrepressModel
	{
		public string EditLink { get; set; }
		public string ItemCode { get; set; }
        public List<PrepressRowsModel> prepressdataModels_Open { get; set; }
        public List<PrepressRowsModel> prepressdataModels_Close { get; set; }
        public class PrepressRowsModel
		{
            public int Index { get; set; }
            public string SrNo { get; set; }
			public bool Rework { get; set; }
			public bool ArtworkApproved { get; set; }
			public string ArtworkApprovedDate { get; set; }
			public bool RevisedApproval { get; set; }
			public string Date { get; set; }
			public string DataUpdateDate { get; set; }
			public string ReferanceKLDItemid { get; set; }
			public string ReferanceColorItemid { get; set; }
			public string ReferanceSample { get; set; }
			public string U_RefSaml { get; set; }
			public string SampleSubmitDate { get; set; }
			public string ItemCode { get; set; }
			public string ItemName { get; set; }
			public string ClientName { get; set; }
			public string ArtworkCreater { get; set; }
			public string KLDno { get; set; }
			public string KLDupdatedate { get; set; }
			public string U_KLDData { get; set; }
			public string JobAssignTo { get; set; }
			public string AssignDate { get; set; }
			public string ArtworkReleaseDateForApproval { get; set; }
			public string ArtworkRecdApprovedDate { get; set; }
			public string Ageing { get; set; }
			public string PSS { get; set; }
			public string SalesEmpName { get; set; }
			public string Remarks { get; set; }
            public bool U_IsArtApp { get; set; }
            public string U_ArtAppDt { get; set; }
            public string U_IsStart { get; set; }
            public string U_StartDate { get; set; }
            public string U_StartDtQC { get; set; }
            public string U_StartDtFO { get; set; }
            public string U_IsEnd { get; set; }
            public string U_EndDate { get; set; }
            public string U_EndDtQC { get; set; }
            public string U_EndDtFO { get; set; }
            public string U_KLDUpDt { get; set; }
            public string U_DataUpDt { get; set; }
            public string U_ArtRelDt { get; set; }
            public string U_SmplSubDt { get; set; }
            public string U_IsQCApp { get; set; }
            public string U_IsFinApp { get; set; }
            public string U_JobAssTo { get; set; }
            public string U_RemarkQC { get; set; }
            public string U_RemarkFO { get; set; }
            public string WIPRemarks { get; set; }
            public string WIPQCRemarks { get; set; }
            public string U_JobAsTQC { get; set; }
            public string U_JobAsTFO { get; set; }
            public string U_UpdateDate { get; set; }
            public string U_WIPAge { get; set; }
            public string U_QCAge { get; set; }
            public string U_FOAge { get; set; }
            public string U_KLDNo { get; set; }
            public string U_PunchNo { get; set; }
            public string InkType { get; set; }
            public string InkTypeDesc { get; set; }
            public string CreateDate { get; set; }
        }
	}
}
