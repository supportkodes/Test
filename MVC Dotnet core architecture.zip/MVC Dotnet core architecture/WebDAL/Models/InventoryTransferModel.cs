﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
	public class InventoryTransferModel
	{
		public string EditLink { get; set; }
		public string ButtonValue { get; set; }
		public string Type { get; set; }
		public string IsEditable { get; set; }
		public string UserId { get; set; }
		public string CardCode { get; set; }
		public string CardName { get; set; }
		public string ShipToCode { get; set; }
		public string Address { get; set; }
		public string DocEntry { get; set; }
		public string DocNum { get; set; }
		public string Series { get; set; }
		public string DocDate { get; set; }
		public string TaxDate { get; set; }
		public string RefObjType { get; set; }
		public string RefDocNum { get; set; }
		public string Name { get; set; }
		public string BPLID { get; set; }
		public string BPL_IDAssignedToInvoice { get; set; }
		public string FromWarehouse { get; set; }
		public string ToWarehouse { get; set; }
		public string BinCode { get; set; }
		public string U_CntrCd { get; set; }
		public string U_CntrNm { get; set; }
		public string U_PPNo { get; set; }
		public string U_PPDocNum { get; set; }
		public List<InventoryTransferRowsModel> StockTransferLines { get; set; }
	}
	public class InventoryTransferRowsModel
	{
		public string IsDeleted { get; set; }
		public int? BaseType { get; set; }
		public int? BaseEntry { get; set; }
		public int? BaseLine { get; set; }
		public int? Index { get; set; }
		public int? LineNum { get; set; }
		public string ItemCode { get; set; }
		public string ItemDescription { get; set; }
		public string FromWhsCod { get; set; }
		public string WhsCode { get; set; }
		public string Quantity { get; set; }
		public string OnHand { get; set; }
		public string U_NoOfUps { get; set; }
		public string LocCode { get; set; }
		public string UoMCode { get; set; }
		public string unitMsr { get; set; }
		public string U_JCText { get; set; }
		public string U_JobCardNo { get; set; }
		public string ToBinLoc { get; set; }
		public string FromBinLoc { get; set; }
		public string AllocatedQty { get; set; }
		public string SelectedBatchQty { get; set; }
		public string ManagedBy { get; set; }
		public string MeasureUnit { get; set; }
		public List<InventoryTransferBatchNumbersModel> BatchNumbers { get; set; }
	}
    public class InventoryTransferBatchNumbersModel
    {
        public string BatchNumber { get; set; }
        public string ManufacturerSerialNumber { get; set; }
        public string InternalSerialNumber { get; set; }
        public double Quantity { get; set; }
        public int BaseLineNumber { get; set; }
        public string ItemCode { get; set; }
        public string U_NetWt { get; set; }
        public string U_GrossWt { get; set; }
        public string U_BoxType { get; set; }
        public string U_LotNo { get; set; }
        public string U_GRNNo { get; set; }
        public string U_JobCardNo { get; set; }
        public string U_JobCardName { get; set; }
        public string U_LotUDF { get; set; }
        public string U_SONo { get; set; }
        public string U_Remarks { get; set; }
        public string U_ContractorName { get; set; }
    }
}
