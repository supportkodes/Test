﻿using System.Collections.Generic;

namespace WebDAL.Models
{

	public class FLEXOUPIndexModel
	{
		public string EditLink { get; set; }
		public string DuplicateLink { get; set; }
		public string DocEntry { get; set; }
		public string DocNum { get; set; }
		public string U_CardCode { get; set; }
		public string U_CardName { get; set; }
		public string U_SlpEmpNm { get; set; }
		
		public string LogInst { get; set; }

	}
	public class FLEXOUPModel
    {
        public string EditLink { get; set; }
        public string DuplicateLink { get; set; }
		public string DocEntry	 { get; set; }
		public string LogInst { get; set; }
		public string Code	 { get; set; }
        public string DocNum	 { get; set; }
        public string U_SlsEmp	 { get; set; }
        public string U_SlpEmpNm	 { get; set; }
        public string U_CardCode	 { get; set; }
        public string U_CardName	 { get; set; }
		public List<FLEXOUPModelRow> APAFUP1Collection { get; set; }
		
	}
    public class FLEXOUPModelRow
    {
        public int? Index { get; set; }
        public string LineId	 { get; set; }
		public string U_ShpCd { get; set; }
		public string U_ShpAddr	 { get; set; }
        public string U_ItmCd	 { get; set; }
        public string U_ItmNm	 { get; set; }
        public string U_RollDrctn	 { get; set; }
        public string U_Pckng	 { get; set; }
        public string U_UpdateDate	 { get; set; }
        public string U_UpdateTime	 { get; set; }
        public string U_IsActive	 { get; set; }
        public string? IsDeleted { get; set; }
        public string? IsChanged { get; set; }
    }
}
