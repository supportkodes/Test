﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class CommonValueModel
    {
        public string ID { get; set; }
        public string Name { get; set; }
        public string RowNo { get; set; }
        public string U_KLDNo { get; set; }
        public string U_PunchNo { get; set; }
        public string U_SizeX { get; set; }
        public string U_SizeY { get; set; }
        public string U_Lmm { get; set; }
        public string U_Wmm { get; set; }
        public string U_Hmm { get; set; }
        public string U_TuckInflap { get; set; }
        public string U_DustFlap { get; set; }
        public string U_PunchTyp { get; set; }
        public string U_Remark { get; set; }
        public string U_Desc { get; set; }
    }
}
