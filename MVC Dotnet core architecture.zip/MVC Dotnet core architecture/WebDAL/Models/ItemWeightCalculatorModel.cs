﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
	public class ItemWeightCalculatorModel
	{
		public string EditLink { get; set; }
		public string DuplicateLink { get; set; }
		public string Code { get; set; }
		public string U_ItemCode { get; set; }
		public string ItemName { get; set; }
		public string U_PktWt { get; set; }
		public string U_PktQty { get; set; }
		public string U_KLDNo { get; set; }
		public string PerPcsWeight { get; set; }
		public string PerBoxQty { get; set; }
		public string BoxWeight { get; set; }

	}
}
