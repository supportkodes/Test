﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
	public class ShadeMasterModel
	{
		public string EditLink { get; set; }
		public string Code { get; set; }
		public string DocEntry { get; set; }
		public string Name { get; set; }
		public string U_CCode { get; set; }
		public string U_CName { get; set; }
		public string U_ICode { get; set; }
		public string U_IName { get; set; }
		public string Location { get; set; }
		public string U_AppBy { get; set; }
		public string U_STC { get; set; }
		public string U_SCNo { get; set; }
		public string U_SCDate { get; set; }
		public string U_CRecv { get; set; }
		public string U_CRec { get; set; }
		public string U_Status { get; set; }
		public string U_UpdateDate { get; set; }
		public string U_UpdateTime { get; set; }
		public string U_Remarks { get; set; }
		public string U_Active { get; set; }
		
		public List<ShadeMasterRowsModel> Rows { get; set; }

    }

    public class ShadeMasterRowsModel
	{
		public int Index { get; set; }
		public string Code { get; set; }
		public string ItemCode { get; set; }
		public string ItemName { get; set; }
		public string IsDeleted { get; set; }

	}
}
