﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
	public class IssueForProductionModel
    {
		public string EditLink { get; set; }
		public string ButtonValue { get; set; }
		public string Type { get; set; }
		public string IsEditable { get; set; }
		public string UserId { get; set; }
		public string U_ShpDocNm { get; set; }
		public string U_PPDocNum { get; set; }
		public string U_ContactorName { get; set; }
		public string DocNum { get; set; }
		public string Series { get; set; }
		public string DocDate { get; set; }
		public List<IssueForProductionRowsModel> DocumentLines { get; set; }
	}
	public class IssueForProductionRowsModel
    {
		public string IsDeleted { get; set; }
		public int? BaseType { get; set; }
		public int? BaseEntry { get; set; }
		public int? BaseLine { get; set; }
		public int? Index { get; set; }
		public int? LineNum { get; set; }
		public string ItemCode { get; set; }
		public string Dscription { get; set; }
		public string Quantity { get; set; }
		public string WhsCode { get; set; }
		public string U_BTCNO { get; set; }
		
		
	}
}
