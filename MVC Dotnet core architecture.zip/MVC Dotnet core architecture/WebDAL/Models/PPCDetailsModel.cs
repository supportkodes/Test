﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
namespace WebDAL.Models
{
    public class PPCDetailsModel
	{
		public string EditLink { get; set; }
		public string SONo { get; set; }
		public string Branch { get; set; }
		public string Location { get; set; }
		public string ItemCode { get; set; }
		public List<PPCDetailsRowModel> PPCDetailsDataModel { get; set; }
		public class PPCDetailsRowModel
        {	
			public int Index { get; set; }
            public string SrNo { get; set; }
			public string SONo { get; set; }
			public string SODate { get; set; }
			public string SOAddedDate { get; set; }
			public string UpperTolerance { get; set; }
			public string LowerTolerance { get; set; }
			public string DocStatus { get; set; }
			public string CustomerName { get; set; }
			public string ItemCode { get; set; }
			public string ItemName { get; set; }
			public string JobCardNo { get; set; }
			public string JobQty { get; set; }
			public string Repeat { get; set; }
			public string OrdQty { get; set; }
			public string DispatchDt1 { get; set; }
			public string DispatchDt2 { get; set; }
			public string DispatchDt3 { get; set; }
			public string DespDt { get; set; }
			public string BomStatus { get; set; }
			public string JobHoldAndRemark { get; set; }
			public string CreatedBy { get; set; }
			public string Machine { get; set; }
			public string PrintingDate { get; set; }
			public string Instruction { get; set; }
			public string KLDNo { get; set; }
			public string PunchNo { get; set; }
			public string FoilEBlock { get; set; }
			public string Ups { get; set; }
			public string ArtWrkapp { get; set; }
			public string ReqImp { get; set; }
			public string ProcessImp { get; set; }
			public string FGStock { get; set; }
			public string Category { get; set; }
			public string ShadeCard { get; set; }
			public string SizeX { get; set; }
			public string SizeY { get; set; }
			public string GangUp { get; set; }
			public string RMConfirmation { get; set; }
			public string RMConfirmationINK { get; set; }
			public string Varnish { get; set; }
			public string RMConfirmationVanish { get; set; }
			public string PaperStock { get; set; }
			public string RMDetails { get; set; }
			public string RMDate { get; set; }
			public string RMConfirmationPaper { get; set; }
			public string CutSize { get; set; }
			public string RMPackingSize { get; set; }
			public string CorrBox { get; set; }
			public string RMConfirmationBox { get; set; }
			public string LamFilm { get; set; }
			public string RMConfirmationFilm { get; set; }
			public string Remark { get; set; }
			public string LinkDate { get; set; }
			public string VarnishDate { get; set; }
			public string PaperDate { get; set; }
			public string CBoxDate { get; set; }
			public string LFilmDate { get; set; }
            public string isLink { get; set; }
            public string isVarnish { get; set; }
            public string isPaper { get; set; }
            public string isCBox { get; set; }
            public string isLFilm { get; set; }
            public string InkType { get; set; }
						  
        }

		public class PPCDetailsInkDetailsModel
		{ 
            public string Father { get; set; }
            public string ItemCode { get; set; }
            public string ItemName { get; set; }
            public string MasterGroup { get; set; }
            public string InActive { get; set; }
        }

    }
}
