﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class ItemWiseCustomerPurchaseReportModel
    {
        public string InvNo { get; set; }
        public string InvDate { get; set; }
        public string CardCode { get; set; }
        public string CardName { get; set; }
        public string ItemCode { get; set; }
        public string Dscription { get; set; }
        public string Quantity { get; set; }
        public string Rate { get; set; }
        public string LineGrossAmount { get; set; }
        public string DiscountAmount { get; set; }
        public string LineAmount { get; set; }
        public string HSNCode { get; set; }
    }
}
