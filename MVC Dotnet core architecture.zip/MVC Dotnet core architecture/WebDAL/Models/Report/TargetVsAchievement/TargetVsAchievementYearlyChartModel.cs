﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class TargetVsAchievementYearlyChartModel
    {
        public double? Target { get; set; }
        public double? Achievement { get; set; }
    }
}
