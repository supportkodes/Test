﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
	public class FGStockStatusReportModel
	{
		public string UserId { get; set; }

		public string CardCode { get; set; }
		public string SlpCode { get; set; }
		public string SlpName { get; set; }
		public List<FGStockStatusReportRowsModel> FGStatusRows { get; set; }
	}

	public class FGStockStatusReportRowsModel
	{
		public int? Index { get; set; }
		public string CardName { get; set; }
		public string CardCode { get; set; }
		public string SlpCode { get; set; }

		public string SlpName { get; set; }

		public string ItemCode { get; set; }
        public string ItemName { get; set; }
		public string FGStk { get; set; }
		public string FGStkVal { get; set; }
		public string OpenOrderQty { get; set; }

		public string U_LotNo { get; set; }
        public string U_Age { get; set; }
        public string U_TotStk { get; set; }
        public string U_Excess { get; set; }
        public string U_StkVal { get; set; }
        public string U_Remark { get; set; }
        public string APPBinItemQty { get; set; }
        public string QCBinItemQty { get; set; }
        public string RejBinItemQty { get; set; }
    }

	public class FGStockStatusReportDetailRowsModel
	{
		public string SONo { get; set; }
		public string SOStatus { get; set; }
		public string CardName { get; set; }
		public string CardCode { get; set; }
		public string ItemCode { get; set; }
		public string ItemName { get; set; } 
		public string LotNo { get; set; } 
		public string LotQty { get; set; } 
		public string Age { get; set; } 
		public string WhsCode { get; set; } 
		public string BinCode { get; set; } 
		public string SOQty { get; set; } 
		public string DelQty { get; set; } 
		public string OpenQty { get; set; } 
		public string Diff { get; set; } 
		public string Remarks { get; set; } 
	}
}
