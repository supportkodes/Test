﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class PendingPOReportModel
	{
		public string Branch { get; set; }
        public string DocDate { get; set; }
        public string TaxDate { get; set; }
        public string PONo { get; set; }
        public string DocEntry { get; set; }
        public string DocNum { get; set; }
        public string CardName { get; set; }
        public string Dscription { get; set; }
        public string ItmsGrpNam { get; set; }
        public string POQty { get; set; }
        public string POQtyInKG { get; set; }
        public string U_KgPrice { get; set; }
        public string BalanceQty { get; set; }
        public string BalQtyInKG { get; set; }
        public string DocDueDate { get; set; }
        public string TotalValue { get; set; }
        public string ItemDetails { get; set; }
        public string U_JCText { get; set; }
        public string U_JOBDTL { get; set; }
        public string U_NAME { get; set; }
        public string U_NoOfUps { get; set; }
        public string LineNum { get; set; }
    }
}
