﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class PendingOrderReportModel
    {
        public string DocNum { get; set; }
        public string CardCode { get; set; }
        public string CardName { get; set; }
        public string RefNumber { get; set; }
        public string PostingDate { get; set; }
        public string ItemCode { get; set; }
        public string Desc { get; set; }
        public string Quantity { get; set; }
        public string BalanceQuantity { get; set; }
        public string Amount { get; set; }
        public string PendingAmt { get; set; }


    }
}
