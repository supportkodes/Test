﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class SuppliedMaterialReportModel
	{
        public string DocNum { get; set; }
        public string DocDate { get; set; }
        public string SONo { get; set; }
        public string SODate { get; set; }
        public string JobNo { get; set; }
        public string CardCode { get; set; }
        public string CardName { get; set; }
        public string PO { get; set; }
        public string ARDocDate { get; set; }
        public string ItemCode { get; set; }
        public string ItemName { get; set; }
        public string Quantity { get; set; }
        public string SlpCode { get; set; }
		public string SlpName { get; set; }
	}
}
