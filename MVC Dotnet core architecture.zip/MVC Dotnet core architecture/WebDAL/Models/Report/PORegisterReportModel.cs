﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class PORegisterReportModel
	{
        public string DocType { get; set; }
        public string DocStatus { get; set; }
        public string ItmsGrpNam { get; set; }
        public string DocNum { get; set; }
        public string DocDate { get; set; }
        public string CardCode { get; set; }
        public string CardName { get; set; }
        public string ItemCode { get; set; }
        public string Dscription { get; set; }
        public string Quantity { get; set; }
        public string Price { get; set; }
        public string Weight1 { get; set; }
        public string U_KgPrice { get; set; }
        public string LineTotal { get; set; }
        public string DocTotal { get; set; }
        public string U_MISNo { get; set; }
        public string U_JCText { get; set; }
        public string Text { get; set; }
        public string U_Category { get; set; }
        public string WhsCode { get; set; }
        public string U_PriceRemark { get; set; }
        public string ItemsGroupCode { get; set; }
    }
}
