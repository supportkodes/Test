﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class InvoiceReportModel
    {
        public string InvNo { get; set; }
        public string InvDate { get; set; }
        public string CardCode { get; set; }
        public string CardName { get; set; }
        public string TotalAmount { get; set; }
        public string LRNo { get; set; }
        public string LRDate { get; set; }
        public string TransporterName { get; set; } 
    }
}
