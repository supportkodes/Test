﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class SalesAnalysis_YearlyChartModel
    {
        public double? LY { get; set; }
        public double? CY { get; set; }
        public string LYName { get; set; }
        public string CYName { get; set; }
    }
}
