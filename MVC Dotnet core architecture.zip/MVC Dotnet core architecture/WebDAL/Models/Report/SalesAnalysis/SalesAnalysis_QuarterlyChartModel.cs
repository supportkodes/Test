﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class SalesAnalysis_QuarterlyChartModel
    {
        public string Quarter { get; set; }
        public double? LY { get; set; }
        public double? CY { get; set; }
        public string LYName { get; set; }
        public string CYName { get; set; }
    }
}
