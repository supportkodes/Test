﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class PaymentProjectionModel
    {
        public string UserId { get; set; }
        public string SlpCode { get; set; }
        public string SlpName { get; set; }
        public string U_Year { get; set; }
        public string U_WeekNo { get; set; }
        public string FromDate { get; set; }
        public string ToDate { get; set; }
        public string TotalOverDue { get; set; }
        public string TotalProjection { get; set; }
        public string TotalAmountReceived { get; set; }
        public string TotalBalance { get; set; }
        public List<PaymentProjectionRowsModel> PaymentProjectionRows { get; set; }
    }

    public class PaymentProjectionRowsModel
    {
        public int Index { get; set; }
        public string SlpCode { get; set; }
        public string U_IsConfirm { get; set; }
        public string U_CardCode { get; set; }
        public string CardName { get; set; }
        public string CreditDays { get; set; }
        public string U_AccBal{ get; set; }
        public string U_OverDue { get; set; }
        public double? U_ProAmt { get; set; }
        public string U_AmtRecd { get; set; }
        public string Balance { get; set; }
        public double? CollProj { get; set; }
        public double? CollOD { get; set; }
    }
}
