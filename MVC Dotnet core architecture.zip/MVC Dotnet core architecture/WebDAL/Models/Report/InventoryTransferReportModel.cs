﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class InventoryTransferReportModel
	{
        public string ItemCode { get; set; }
        public string ItemName { get; set; }
        public string U_MNAME { get; set; }
        public string ItmsGrpNam { get; set; }
        public string U_Brand { get; set; }
        public string U_DickleSize { get; set; }
        public string U_SheetSizeX { get; set; }
        public string U_SheetSizeY { get; set; }
        public string U_PaperGSM { get; set; }
        public string U_Microns { get; set; }
        public string U_ThicknessOfFilm { get; set; }
        public string Quantity { get; set; }
        public string Rmtr { get; set; }
        public string WhsCode { get; set; }
        public string U_KgPrice { get; set; }
        public string U_JOBDTL { get; set; }
        public string U_JCText { get; set; }
        public string Text { get; set; }
        public string U_ClientName { get; set; }
        public string DocNum { get; set; }
        public string DocDate { get; set; }
        public string U_NoOfUps { get; set; }
        public string PostDate { get; set; }
        public string DocEntry { get; set; }
        public string LineNum { get; set; }
        public string CardName { get; set; }
        public string SlpName { get; set; }
        public string SuppSerial { get; set; }
        public string U_Category { get; set; }
        public string U_QChk { get; set; }
        public string QtyInkgs { get; set; }
        public string JobDetails { get; set; }
        public string JobDetails1 { get; set; }
        public string JobQuantity { get; set; }
    }
}
