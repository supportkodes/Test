﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class DispatchDetailsReportModel
	{
        public string Branch { get; set; }
        public string ARNo { get; set; }
        public string ARDate { get; set; }
        public string SONo { get; set; }
        public string SODate { get; set; }
        public string PONo { get; set; }
        public string PODate { get; set; }
        public string CardName { get; set; }
        public string ItemGroup { get; set; }
        public string ItemCode { get; set; }
        public string Dscription { get; set; }
        public string ARQty { get; set; }
        public string LRNo { get; set; }
        public string LRDate { get; set; }
        public string VehicleNo { get; set; }
        public string TransportName { get; set; }
        public string SalesEmp { get; set; }
        public string SlpCode { get; set; }
        public string SlpName { get; set; }
    }
}
