﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class NewItemCodeModel
	{
        public string ItemCode { get; set; }
        public string ItemName { get; set; }
        public string PrintItemName { get; set; }
        public bool ReturnType { get; set; }
        public string ReturnMessage { get; set; }
    }
}
