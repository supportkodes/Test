﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class BOMModel
	{
        public string ItemCode { get; set; }
        public string ItemName { get; set; }
        public string BOMType { get; set; }
        public double Comp_Quantity { get; set; }
        public string Comp_WhsCode { get; set; }
        public double Header_Quantity { get; set; }
        public double BOMRatio { get; set; }
		public string RollDirection { get; set; }
		public string Packing { get; set; }
		public string U_KLDNo { get; set; }
		public string HSNEntry { get; set; }
		public string HSNName { get; set; }
		public string ArtworkApproved { get; set; }
	}
}
