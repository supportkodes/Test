﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class JCModel
    {
        public string JobNo { get; set; }
        public string DocEntry { get; set; }
        public string JobDt { get; set; }
        public string Date { get; set; }
        public string OrderQty { get; set; }
        public string Ups { get; set; }
        public string TotalImp { get; set; }
        public string FronTImp { get; set; }
        public string BackImp { get; set; }
        public string ReqImpQty { get; set; }
        public string U_ProcNm { get; set; }
        public string MacGrpNm { get; set; }
        public string MacName { get; set; }
        public string JobStatus { get; set; }
        public string U_FGQty { get; set; }
        public string U_UPs { get; set; }
        public string U_NoOfCut { get; set; }
        public string FGQTY { get; set; }
        public string SFQTY { get; set; }
        public string FQTY { get; set; }
        public string PendingQty { get; set; }
        public string U_PONO { get; set; }
        public string U_Cancel { get; set; }
        public string U_MCode { get; set; }
        public string ProName { get; set; }
        public string U_IsSplt { get; set; }
    }
}
