﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class CurrencyModel
    {
        public string CurrCode { get; set; }
        public string CurrName { get; set; }
    }
}
