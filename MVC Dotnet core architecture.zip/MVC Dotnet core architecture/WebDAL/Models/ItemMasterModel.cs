﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class ItemMasterModel
    {
        public string DocEntry { get; set; }
        public string AtcEntry { get; set; }
        public string IsEditable { get; set; }
        public string UserId { get; set; }
        public string ItemCode { get; set; }
        public string ItemName { get; set; }
        public string ItemGroup_ItemBrand { get; set; }
        public string InventoryItem { get; set; }
        public string SalesItem { get; set; }
        public string PurchaseItem { get; set; }
        public bool IsInventoryItem { get; set; }
        public bool IsSalesItem { get; set; }
        public bool IsPurchaseItem { get; set; }
        public string ForeignName { get; set; }
        public string ItemType { get; set; }
        public string ItemType1 { get; set; }
        public string ItemsGroupCode { get; set; }
        public string UoMGroupEntry { get; set; }
        public string TDSLiable { get; set; }
        public string ManageItemBy { get; set; }
        public string DefaultWarehouse { get; set; }
        public string SWW { get; set; }
        public string ShipType { get; set; }
        public string PricingUnit { get; set; }
		public string GSTRelevnt { get; set; }
        public string SACEntry { get; set; }
        public string HSNName { get; set; }
        public string MaterialType { get; set; }
        public string GSTTaxCategory { get; set; }
        public string ChapterID { get; set; }
        public string U_HSNCode { get; set; }
        public string Valid { get; set; }
        public string U_A4SO { get; set; }
        public string FrgnName { get; set; }

        #region Purchasing
        public string PurchaseUnit { get; set; }
        public string BuyUnitMsr { get; set; }
        public string PurchaseItemsPerUnit { get; set; }
        public string PurchasePackagingUnit { get; set; }
        public string PurchaseQtyPerPackUnit { get; set; }
        public string PurchaseUnitWeight { get; set; }

        #endregion

        #region Sales
        public string SalesUnit { get; set; }
        public string SalesUnitMsr { get; set; }
        public string SalesItemsPerUnit { get; set; }
        public string SalesPackagingUnit { get; set; }
        public string SalesQtyPerPackUnit { get; set; }

        #endregion

        #region Inventory Data
        public string GLMethod { get; set; }
        public string InventoryUOM { get; set; }
        public string CostAccountingMethod { get; set; }
        public string ManageStockByWarehouse { get; set; }

        #endregion


        #region Properties
        public bool IsProperties1 { get; set; }
        public bool IsProperties2 { get; set; }

        public string Properties1 { get; set; }
        public string Properties2 { get; set; }

        #endregion


        #region UDF


        public string U_Company { get; set; }
        public string U_PaperGSM { get; set; }
        public string U_Microns { get; set; }
        public string U_Brand { get; set; }
        public string U_LamiType { get; set; }
        public string U_Finishing { get; set; }
        public string U_DickleSize { get; set; }
        public string U_Ply { get; set; }
        public string U_CartType { get; set; }
        public string U_BPName { get; set; }
        public string U_QChk { get; set; }
        public string U_MacItem { get; set; }
        public string U_ByPrd { get; set; }
        public string U_SmplPer { get; set; }
        public string U_BurStr { get; set; }
        public string U_MatType { get; set; }
        public string U_SheetSizeX { get; set; }
        public string U_SheetSizeY { get; set; }
        public string U_ItmNat { get; set; }
        public string U_Industry { get; set; }
        public string U_CustCode { get; set; }
        public string U_CustName { get; set; }
        public string U_TypeOfProduct { get; set; }
        public string U_TypeOfFlute { get; set; }
        public string U_Profile { get; set; }
        public string U_NoOfUps { get; set; }
        public string U_TypeOfSubstrate { get; set; }
        public string U_Matelized { get; set; }
        public string U_NoOfColors { get; set; }
        public string U_InkDesc { get; set; }
        public string U_PantoneNo { get; set; }
        public string U_TypeOfVarnish { get; set; }
        public string U_VarnishNo { get; set; }
        public string U_SpotVarnish { get; set; }
        public string U_VarnishGSM { get; set; }
        public string U_NoOfPasses { get; set; }
        public string U_TypeOfLami { get; set; }
        public string U_ThicknessOfLami { get; set; }
        public string U_SurfaceFinish { get; set; }
        public string U_LamiAdhesive { get; set; }
        public string U_DiePunch { get; set; }
        public string U_Embossing { get; set; }
        public string U_MCODE { get; set; }
        public string U_MNAME { get; set; }
        public string U_WinPatch { get; set; }
        public string U_TypeOfFilm { get; set; }
        public string U_ThicknessOfFilm { get; set; }
        public string U_WinPatAdhesive { get; set; }
        public string U_BoxLength { get; set; }
        public string U_BoxWidth { get; set; }
        public string U_BoxHeight { get; set; }
        public string U_PrintingSide { get; set; }
        public string U_VCode { get; set; }
        public string U_Variant { get; set; }
        public string U_SCode { get; set; }
        public string U_Size { get; set; }
        public string U_PCode { get; set; }
        public string U_Repeat { get; set; }
        public string U_OpenLength { get; set; }
        public string U_OpenWidth { get; set; }
        public string U_BCode { get; set; }
        public string U_Corr_Length { get; set; }
        public string U_Corr_Width { get; set; }
        public string U_Corr_Height { get; set; }
        public string U_AddiInfo { get; set; }
        public string U_PrintItemDesc { get; set; }
        public string U_Yield { get; set; }
        public string U_Grain { get; set; }
        public string U_DieCutting { get; set; }
        public string U_Pasting { get; set; }
        public string U_PastingInst { get; set; }
        public string U_LeafletFold { get; set; }
        public string U_VertFold { get; set; }
        public string U_HoriFold { get; set; }
        public string U_LeftletInst { get; set; }
        public string U_KLDNo { get; set; }
        public string U_Cutting { get; set; }
        public string U_VarnishInst { get; set; }
        public string U_LamiInst { get; set; }
        public string U_CuttingInst { get; set; }
        public string U_Trial { get; set; }
        public string U_MoisCont { get; set; }
        public string U_FoilStamp { get; set; }
        public string U_Perforations { get; set; }
        public string U_Shade { get; set; }
        public string U_Wettability { get; set; }
        public string U_SHDCRD { get; set; }
        public string U_weight { get; set; }
        public string U_sheets { get; set; }
        public string U_SPINPRINT { get; set; }
        public string U_SPINFOIL { get; set; }
        public string U_MICREM { get; set; }
        public string U_DEBOS { get; set; }
        public string U_FLTST { get; set; }
        public string U_CRTGSM { get; set; }
        public string U_NOPIEC { get; set; }
        public string U_QTBOX { get; set; }
        public string U_SPINPACK { get; set; }
        public string U_TaxPer { get; set; }
        public string U_PLENTRY { get; set; }
        public string U_VENDOR { get; set; }
        public string U_FrntColor { get; set; }
        public string U_BackColor { get; set; }
        public string U_Coating { get; set; }
        public string U_Braille { get; set; }
        public string U_ItemKit { get; set; }
        public string U_TestRptNo { get; set; }
        public string U_LTS { get; set; }
        public string U_PRRM { get; set; }
        public string U_PRSPRM { get; set; }
        public string U_PROTRM { get; set; }
        public string U_PRCT { get; set; }
        public string U_PRFR { get; set; }
        public string U_PRMU { get; set; }
        public string U_PRTC { get; set; }
        public string U_ARTSTT { get; set; }
        public string U_ITEMSTAT { get; set; }
        public string U_FLEXO1 { get; set; }
        public string U_CoreD { get; set; }
        public string U_CoreT { get; set; }
        public string U_CoreS { get; set; }
        public string U_Brust { get; set; }
        public string U_ItemGroup { get; set; }
        public string U_RQty { get; set; }
        public string U_RPoint { get; set; }
        public string U_WHcode { get; set; }
		public string U_InkType { get; set; }
		public string U_PSSRmrk { get; set; }

		#endregion

		public List<DocumentModel_Attachment> Attachments2_Lines { get; set; }

	}

	public class ItemMasterModel_ServiceLayer
	{
		public string ItemCode { get; set; }    
		public string ItemName { get; set; }
		public string InventoryItem { get; set; }
		public string SalesItem { get; set; }
		public string PurchaseItem { get; set; }
		public string ForeignName { get; set; }
		public string AtcEntry { get; set; }
		public string ItemType { get; set; }
		public string ItemsGroupCode { get; set; }
		public string UoMGroupEntry { get; set; }
		public string PricingUnit { get; set; }
		public string TDSLiable { get; set; }
		public string ManageItemBy { get; set; }
		public string DefaultWarehouse { get; set; }
		public string SWW { get; set; }
		public string ShipType { get; set; }

		public string GSTRelevnt { get; set; }
		public string ChapterID { get; set; }
		public string SACEntry { get; set; }
		public string HSNName { get; set; }

		public string MaterialType { get; set; }
		public string GSTTaxCategory { get; set; }
		public string Valid { get; set; }
		public string U_A4SO { get; set; }
		public string Frozen { get; set; }


		#region Purchasing
		public string PurchaseUnit { get; set; }
		public string BuyUnitMsr { get; set; }
		public string DefaultPurchasingUoMEntry { get; set; }
		public string PurchaseItemsPerUnit { get; set; }
		public string PurchasePackagingUnit { get; set; }
		public string PurchaseQtyPerPackUnit { get; set; }
		public string PurchaseUnitWeight { get; set; }

		#endregion


		#region Sales
		public string DefaultSalesUoMEntry { get; set; }
		public string SalesUnit { get; set; }
		public string SalesItemsPerUnit { get; set; }
		public string SalesPackagingUnit { get; set; }
		public string SalesQtyPerPackUnit { get; set; }

		#endregion

		#region Inventory Data
		public string GLMethod { get; set; }
		public string InventoryUOM { get; set; }
		public string CostAccountingMethod { get; set; }
		public string SRIAndBatchManageMethod { get; set; }
		public string ManageStockByWarehouse { get; set; }
		public string ManageBatchNumbers { get; set; }
		public string ManageSerialNumbers { get; set; }

        public string DefaultCountingUnit { get; set; }
        public string DefaultCountingUoMEntry { get; set; }

        #endregion


        #region Properties
        public string Properties1 { get; set; }
		public string Properties2 { get; set; }

		#endregion


		#region UDF


		public string U_Company { get; set; }
		public string U_PaperGSM { get; set; }
		public string U_Microns { get; set; }
		public string U_Brand { get; set; }
		public string U_LamiType { get; set; }
		public string U_Finishing { get; set; }
		public string U_DickleSize { get; set; }
		public string U_Ply { get; set; }
		public string U_CartType { get; set; }
		public string U_BPName { get; set; }
		public string U_QChk { get; set; }
		public string U_MacItem { get; set; }
		public string U_ByPrd { get; set; }
		public string U_SmplPer { get; set; }
		public string U_BurStr { get; set; }
		public string U_MatType { get; set; }
		public string U_SheetSizeX { get; set; }
		public string U_SheetSizeY { get; set; }
		public string U_ItmNat { get; set; }
		public string U_Industry { get; set; }
		public string U_CustCode { get; set; }
		public string U_CustName { get; set; }
		public string U_TypeOfProduct { get; set; }
		public string U_TypeOfFlute { get; set; }
		public string U_Profile { get; set; }
		public string U_NoOfUps { get; set; }
		public string U_TypeOfSubstrate { get; set; }
		public string U_Matelized { get; set; }
		public string U_NoOfColors { get; set; }
		public string U_InkDesc { get; set; }
		public string U_PantoneNo { get; set; }
		public string U_TypeOfVarnish { get; set; }
		public string U_VarnishNo { get; set; }
		public string U_SpotVarnish { get; set; }
		public string U_VarnishGSM { get; set; }
		public string U_NoOfPasses { get; set; }
		public string U_TypeOfLami { get; set; }
		public string U_ThicknessOfLami { get; set; }
		public string U_SurfaceFinish { get; set; }
		public string U_LamiAdhesive { get; set; }
		public string U_DiePunch { get; set; }
		public string U_Embossing { get; set; }
		public string U_MCODE { get; set; }
		public string U_MNAME { get; set; }
		public string U_WinPatch { get; set; }
		public string U_TypeOfFilm { get; set; }
		public string U_ThicknessOfFilm { get; set; }
		public string U_WinPatAdhesive { get; set; }
		public string U_BoxLength { get; set; }
		public string U_BoxWidth { get; set; }
		public string U_BoxHeight { get; set; }
		public string U_PrintingSide { get; set; }
		public string U_VCode { get; set; }
		public string U_Variant { get; set; }
		public string U_SCode { get; set; }
		public string U_Size { get; set; }
		public string U_PCode { get; set; }
		public string U_Repeat { get; set; }
		public string U_OpenLength { get; set; }
		public string U_OpenWidth { get; set; }
		public string U_BCode { get; set; }
		public string U_Corr_Length { get; set; }
		public string U_Corr_Width { get; set; }
		public string U_Corr_Height { get; set; }
		public string U_AddiInfo { get; set; }
		public string U_PrintItemDesc { get; set; }
		public string U_Yield { get; set; }
		public string U_Grain { get; set; }
		public string U_DieCutting { get; set; }
		public string U_Pasting { get; set; }
		public string U_PastingInst { get; set; }
		public string U_LeafletFold { get; set; }
		public string U_VertFold { get; set; }
		public string U_HoriFold { get; set; }
		public string U_LeftletInst { get; set; }
		public string U_KLDNo { get; set; }
		public string U_Cutting { get; set; }
		public string U_VarnishInst { get; set; }
		public string U_LamiInst { get; set; }
		public string U_CuttingInst { get; set; }
		public string U_Trial { get; set; }
		public string U_MoisCont { get; set; }
		public string U_FoilStamp { get; set; }
		public string U_Perforations { get; set; }
		public string U_Shade { get; set; }
		public string U_Wettability { get; set; }
		public string U_SHDCRD { get; set; }
		public string U_weight { get; set; }
		public string U_sheets { get; set; }
		public string U_SPINPRINT { get; set; }
		public string U_SPINFOIL { get; set; }
		public string U_MICREM { get; set; }
		public string U_DEBOS { get; set; }
		public string U_FLTST { get; set; }
		public string U_CRTGSM { get; set; }
		public string U_NOPIEC { get; set; }
		public string U_QTBOX { get; set; }
		public string U_SPINPACK { get; set; }
		public string U_TaxPer { get; set; }
		public string U_PLENTRY { get; set; }
		public string U_VENDOR { get; set; }
		public string U_FrntColor { get; set; }
		public string U_BackColor { get; set; }
		public string U_Coating { get; set; }
		public string U_Braille { get; set; }
		public string U_ItemKit { get; set; }
		public string U_TestRptNo { get; set; }
		public string U_LTS { get; set; }
		public string U_PRRM { get; set; }
		public string U_PRSPRM { get; set; }
		public string U_PROTRM { get; set; }
		public string U_PRCT { get; set; }
		public string U_PRFR { get; set; }
		public string U_PRMU { get; set; }
		public string U_PRTC { get; set; }
		public string U_ARTSTT { get; set; }
		public string U_ITEMSTAT { get; set; }
		public string U_FLEXO1 { get; set; }
		public string U_CoreD { get; set; }
		public string U_CoreT { get; set; }
		public string U_CoreS { get; set; }
		public string U_Brust { get; set; }
		public string U_ItemGroup { get; set; }
		public string U_RQty { get; set; }
		public string U_RPoint { get; set; }
		public string U_WHcode { get; set; }
		public string U_HSNCode { get; set; }
		public string U_InkType { get; set; }
		public string U_PSSRmrk { get; set; }


		#endregion

	}
}
