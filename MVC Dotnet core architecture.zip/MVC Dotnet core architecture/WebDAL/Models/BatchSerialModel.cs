﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class BatchSerialModel
	{
        public string DistNumber { get; set; }
        public string MnfSerial { get; set; }
        public double Stock { get; set; }
        public string U_LotNo { get; set; }
        public string InStock { get; set; }
        public string LotNumber { get; set; }
        public string BinCode { get; set; }
        public string InDate { get; set; }
        public string CostTotal { get; set; }
        public string U_NetWt { get; set; }
        public string U_GrossWt { get; set; }
        public string U_SONo { get; set; }
        public string U_Remarks { get; set; }
        public string U_ContractorName { get; set; }
    }

	public class BatchSerialAllocatedModel
	{
		public string BatchQty { get; set; }
		public double SelectedQty { get; set; }
		public double Stock { get; set; }
	}
}
