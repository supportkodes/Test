﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class ReportParameterBody
	{
		public string name { get; set; }
		public string type { get; set; }
		public List<List<string>> value { get; set; }
	}
}
