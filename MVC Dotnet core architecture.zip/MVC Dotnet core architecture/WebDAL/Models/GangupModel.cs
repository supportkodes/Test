﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
	public class GangupModel
	{
		public string EditLink { get; set; }
		public string ButtonValue { get; set; }
		public string Type { get; set; }
		public string IsEditable { get; set; }
		public string UserId { get; set; }
		public string DocNum { get; set; }
		public string Series { get; set; }
		public string SeriesName { get; set; }
		public string SlpName { get; set; }
		public string CardName { get; set; }
		public string U_SlpCode { get; set; }
		public string U_CardCode { get; set; }
		public string U_ItmGrp { get; set; }
		public double U_TNoOfSheet { get; set; }
		public double U_TNoOfUPS { get; set; }
		public double U_TotNInk { get; set; }
		public string U_DocDate { get; set; }
		public string DocEntry { get; set; }
		public List<GangupRowsModel> WEB_GANGUP1Collection { get; set; }
	}
	public class GangupRowsModel
	{
		public string IsDeleted { get; set; }
		public int? Index { get; set; }
		public int? LineId { get; set; }
		public string U_ItemCode { get; set; }
		public string U_ItemName { get; set; }
		public double U_SOQty { get; set; }
		public double U_NoOfUPS { get; set; }
		public string U_JobQty { get; set; }
		public string U_KLDNo { get; set; }
		public string U_AppArt { get; set; }
		public string U_Rate { get; set; }
		public string U_NoColor { get; set; }
		public string U_Color { get; set; }
		public string U_BaseEn { get; set; }
		public string U_BaseLine { get; set; }
	}
}
