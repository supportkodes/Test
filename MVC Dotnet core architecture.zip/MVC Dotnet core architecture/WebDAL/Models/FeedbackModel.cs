﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class FeedbackModel
    {
        public string EditLink { get; set; }
        public string Code { get; set; }
        public string U_UserId { get; set; }
        public string U_Date { get; set; }
        public string U_Title { get; set; }
        public string U_Type { get; set; }
        public string U_Status { get; set; }
        public string U_RefDN { get; set; }
        public string U_Details { get; set; }
        public string U_Response { get; set; }
    }
}
