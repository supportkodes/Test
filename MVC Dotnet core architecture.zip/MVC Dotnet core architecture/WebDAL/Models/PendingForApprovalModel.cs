﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class PendingForApprovalModel
    {
        public string EditLink { get; set; }
        public string UserId { get; set; }

        public string DocEntry { get; set; }
        public string DocNum { get; set; }
        public string DocRate { get; set; }
        public string Series { get; set; }
        public string SeriesName { get; set; }
        public string CardCode { get; set; }
        public string CardName { get; set; }
        public string NumAtCard { get; set; }
        public string DocStatus { get; set; }
        public string BPL_IDAssignedToInvoice { get; set; }
        public string DocDate { get; set; }
        public string TaxDate { get; set; }
        public string DocDueDate { get; set; }
        public string WarehouseCode { get; set; }
        public string PayToCode { get; set; }
        public string ShipToCode { get; set; }
        public string Address { get; set; }
        public string Address2 { get; set; }
        public string TransportationCode { get; set; }
        public string SalesPersonCode { get; set; }
        public string SlpName { get; set; }
        public string DocumentsOwner { get; set; }
        public string Comments { get; set; }
        public string DocTotal { get; set; }
        public string TaxAmount { get; set; }
        public string VoucherType { get; set; }
        public string AppUserId { get; set; }
        public string IsApp { get; set; }
        public string Rank { get; set; }
        public string VatSum { get; set; }
    }

	public class PendingForApprovalItemModel
	{
		public string ItemCode { get; set; }
		public string Dscription { get; set; }
		public string Quantity { get; set; }
		public string U_JCText { get; set; }
		public string Text { get; set; }
		public string U_ClientName { get; set; }
		public string ShipDate { get; set; }
		public string Price { get; set; }
		public string OnHand { get; set; }

	}
}
