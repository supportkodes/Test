﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class ClientPORegisterModel
    {
        public string EditLink { get; set; }
        public string ButtonValue { get; set; }
        public string Type { get; set; }
        public string IsEditable { get; set; }
        public string UserId { get; set; }
        public string DocNum { get; set; }
        public string DocEntry { get; set; }
        public string Series { get; set; }
        public string SeriesName { get; set; }
        public string U_CardCode { get; set; }
        public string U_CardName { get; set; }
        public string U_PORefNo { get; set; }
        public string U_DocDate { get; set; }
        public string U_PORefDt { get; set; }
        public string U_Remarks { get; set; }
        public string U_Currency { get; set; }
        public string U_DocRate { get; set; }
        public string SlpName { get; set; }
        public List<ClientPORegisterRowsModel> WEB_PO_REGISTER1Collection { get; set; }
        public List<ClientPORegisterQtyPerPOModel> WEB_PO_REGISTER2Collection { get; set; }
        public List<ClientPORegister_Attachment> WEB_PO_REGISTER3Collection { get; set; }
    }
    public class ClientPORegisterRowsModel
    {
        public string U_IsSelect { get; set; }
        public bool IsSelect { get; set; }
        public string IsDeleted { get; set; }
        public int? Index { get; set; }
        public int? LineId { get; set; }
        public string U_SrNo { get; set; }
        public string U_ItemCode { get; set; }
        public string U_ItemName { get; set; }
        public string U_Qty { get; set; }
        public string U_Rate { get; set; }
        public string U_AppArt { get; set; }
        public string U_ArtAttach { get; set; }
        public string U_RateSys { get; set; }
        public string Currency{ get; set; }
        public string U_FromDate { get; set; }
        public string U_ToDate { get; set; }
        public string U_KLDNo { get; set; }
        public string U_IsGang { get; set; }
        public bool IsGang { get; set; }
        public string U_BomType { get; set; }
        public string U_NoOfUPS { get; set; }
        public string U_RefId { get; set; }
        public string U_BaseEn { get; set; }
        public string U_BaseLine { get; set; }
        public string U_TargEn { get; set; }
        public string U_TargLine { get; set; }
        public string U_SOEn { get; set; }
        public string BOMRatio { get; set; }
        public string BaseBOMLine { get; set; }
        public string U_MailSent{ get; set; }
        public string U_ManualRate { get; set; }

    }

    public class ClientPORegisterQtyPerPOModel
    {
        public string IsDeleted { get; set; }
        public int? Index { get; set; }
        public int? LineId { get; set; }
        public int? U_BaseEn { get; set; }
        public int? U_BaseLine { get; set; }
        public string U_Qty { get; set; }
        public string U_PONo { get; set; }
    }
    public class ClientPORegister_Attachment
    {
        public int LineId { get; set; }
        public string IsChanged { get; set; }
        public string U_Attach { get; set; }
        public string U_trgtPath { get; set; }
        public string U_DocType { get; set; }
        public string IsDeleted { get; set; }
    }

}
