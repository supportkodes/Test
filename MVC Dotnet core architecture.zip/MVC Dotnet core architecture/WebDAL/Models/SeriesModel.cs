﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class SeriesModel
    {
        public string Series{ get; set; }
        public string SeriesName { get; set; }
    }
}
