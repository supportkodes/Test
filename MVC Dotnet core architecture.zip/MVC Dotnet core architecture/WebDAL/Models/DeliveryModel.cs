﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class DeliveryModel
	{
        public string EditLink { get; set; }
        public string ButtonValue { get; set; }
        public string Type { get; set; }
        public string ShowApproval { get; set; }
        public string ApprovalStatus { get; set; }
        public string IsEditable { get; set; }
        public string UserId { get; set; }
        public double? BPTolerancePercent { get; set; }
        public double? BPLowerTolerancePercent { get; set; }
        public string DocEntry { get; set; }
        public string DocNum { get; set; }
        public string AtcEntry { get; set; }
        public string DocCurrency { get; set; }
        public string DocRate { get; set; }
		public string DocObjectCode { get; set; }
		public string Series { get; set; }
		public string SeriesName { get; set; }
		public string WhsCode { get; set; }
        public string WarehouseCode { get; set; }
        public string CardCode { get; set; }
        public string CardName { get; set; }
        public string NumAtCard { get; set; }
        public string DocStatus { get; set; }
        public string BPL_IDAssignedToInvoice { get; set; }
        public string DocDate { get; set; }
        public string TaxDate { get; set; }
        public string DocDueDate { get; set; }
        public string PayToCode { get; set; }
        public string ShipToCode { get; set; }
        public string Address { get; set; }
        public string Address2 { get; set; }
        public string TransportationCode { get; set; }
        public string SalesPersonCode { get; set; }
        public string SlpName { get; set; }
        public string DocumentsOwner { get; set; }
        public string U_IsApp { get; set; }

        public string Comments { get; set; }
        public string DutyStatus { get; set; }
		public bool boolImpORExp { get; set; }
		public string ImpORExp { get; set; }
        public string ExportType { get; set; }
        public string SOAge { get; set; }
        public string U_LRNo { get; set; }
        public string U_LRDate { get; set; }
        public string U_TransCode { get; set; }
        public string U_TransName { get; set; }
        public string U_TrfVehi { get; set; }
        public string U_RemvDate { get; set; }
        public string U_RemvTime { get; set; }
        public double? NetAmount { get; set; }
        public double? DiscountPercent { get; set; }
        public double? TotalExpns { get; set; }
        public double? TaxAmount { get; set; }
        public double? RoundingDiffAmount { get; set; }
        public double? DocumentTotal { get; set; }
        public string BillTo_State { get; set; }
        public string ShipTo_State { get; set; }
        public List<DeliveryRowsModel> DocumentLines { get; set; }
        public List<DeliveryModel_Attachment> Attachments2_Lines { get; set; }
        public List<DeliveryModel_Expenses> DocumentAdditionalExpenses { get; set; }
        public DeliveryModel_TaxExtension TaxExtension { get; set; }
    }
	public class DeliveryRowsModel
	{
        public int? Index { get; set; }
        public int? LineNum { get; set; }
        public string ItemCode { get; set; }
        public string ItemName { get; set; }
        public string U_Category { get; set; }
        public string SupplierCatNum { get; set; }
        public string TaxCode { get; set; }
        public string MeasureUnit { get; set; }
        public double? Quantity { get; set; }
        public double? UnitPrice { get; set; }
        public double Total { get; set; }
        public string WarehouseCode { get; set; }
        public string FreeText { get; set; }
        public double?  U_CTOL { get; set; }
        public double?  U_CTLOL { get; set; }
        public double? TaxRate { get; set; }
        public string TreeType { get; set; }
        public string HSNName { get; set; }
        public int HSNEntry { get; set; }
        public string ShipDate { get; set; }

        public double? InStockQuantity { get; set; }
        public double? DeliveredQuantity { get; set; }
        public double? OpenQuantity { get; set; }
        public int? BaseType { get; set; }
        public int? BaseEntry { get; set; }
        public int? BaseLine { get; set; }

		public string U_Exp1 { get; set; }
		public string U_Exp2 { get; set; }
		public string LineStatus { get; set; }
        public string IsDeleted { get; set; }
        public string BOMRatio { get; set; }
        public string BaseBOMLine { get; set; }
		public string U_UnwDrctn { get; set; }
		public string U_Packng { get; set; }
		public string U_JobCardNo { get; set; }
		public string AllocatedQty { get; set; }
		public string SelectedBatchQty { get; set; }
		public string ManagedBy { get; set; }
		public string ItemWhsStock { get; set; }
		public List<DeliveryModel_BatchNumber> BatchNumbers { get; set; }
	}
	public class DeliveryModel_Expenses
	{
        public int? Index { get; set; }
        public int ExpenseCode { get; set; }
        public string ExpenseName { get; set; }
        public double LineTotal { get; set; }
        public string TaxCode { get; set; }
        public double? TaxSum { get; set; }
        public double? TaxPercent { get; set; }
        public double? LineGross { get; set; }
    }
    public class DeliveryModel_Attachment
	{
        public int Index { get; set; }
        public string Line { get; set; }
        public string trgtPath { get; set; }
        public string FileName { get; set; }
        public string FileExt { get; set; }
        public string IsChanged { get; set; }
        //public List<DocumentModel_AttachmentLines_ServiceLayer> Attachments2_Lines { get; set; }
    }
	public class DeliveryModel_TaxExtension
	{
		public string ImportOrExport { get; set; }
		public string ImportOrExportType { get; set; }
		 
	}
	public class DeliveryModel_BatchNumber
	{
		public string IsDeleted { get; set; }
		public string BatchNumber { get; set; }
		public DateTime AddmisionDate { get; set; }
		public double Quantity { get; set; }
		public int BaseLineNumber { get; set; }
		public string ItemCode { get; set; }
		public double U_NetWt { get; set; }
		public double U_GrossWt { get; set; }
		public string U_BoxType { get; set; }
		public string U_LotNo { get; set; }
		public string U_GRNNo { get; set; }
		public int U_SONo { get; set; }
		public string U_ContractorName { get; set; }
	}


}