﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class EmployeeModel
    {
        public string empID { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public string dept { get; set; }
    }
}
