﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class BrandModel
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public string U_Code { get; set; }
        public string U_Desc { get; set; }
        public string U_Btype { get; set; }
    }
}
