﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class ApprovalUsersModel
	{
        public string UserID { get; set; }
        public string USER_CODE { get; set; }
        public string U_NAME { get; set; }
        public string WtmCode { get; set; }
        public string WtmName { get; set; }
        public string Remarks { get; set; }
        public string QueryId { get; set; }
        public string QString { get; set; }
        public string U_IsApp { get; set; }
    }
}
