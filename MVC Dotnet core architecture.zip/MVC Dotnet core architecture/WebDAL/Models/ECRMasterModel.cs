﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebDAL.Models
{
    public class ECRMasterModel
    {
        //public string empId { get; set; }
        public string IsEditable { get; set; }
        public string UserCode { get; set; }
        public string UserId { get; set; }
        public string EmpId { get; set; }
        public string UserName { get; set; }
        public string EmailAddress { get; set; }
        public string DocEntry { get; set; }
        public string CreditDocEntry { get; set; }
        public string EditLink { get; set; }
        public string Role { get; set; }
        public string ResponseMessage { get; set; }
        public string Code { get; set; }
        public string Department { get; set; }
        public string U_CardCode { get; set; }
        public string U_CardName { get; set; }
        public string SlpName { get; set; }
        public string U_SlpCode { get; set; }
        public string U_Date { get; set; }
        public string U_Status { get; set; }
        public string StatusName { get; set; }
        public string U_TotRej { get; set; }
        public string U_TotTRej { get; set; }
        public string U_TotWRej { get; set; }
        public string U_AssignTo { get; set; }
        public string U_AssignDt { get; set; }
        public string U_DebNRec { get; set; }
        public string U_CreNIss { get; set; }
        public string U_ECRNo { get; set; }
        public string Canceled { get; set; }
		public string AtcEntry { get; set; }
		public string AssignTo { get; set; }
		public string DeptName { get; set; }
		public string Age { get; set; }
		public string ProcessedAge { get; set; }
		public string QCAge { get; set; }
		public string U_ComplBy { get; set; }
		public string U_Designt { get; set; }
		public string U_MOC { get; set; }
		public string DocNum { get; set; }
		public string Remark { get; set; }
		public string U_BPLId { get; set; }
		public string U_CrDocNum { get; set; }
		public string U_CDate { get; set; }
		public List<ECRRowModel> ECR1Collection { get; set; }
		public List<ECRModel_Attachment> ECR2Collection { get; set; }
		public List<ECRModel_RemarkDetails> ECR_RemarkDetails_Lines { get; set; }
	}
    public class ECRRowModel
    {
		public int? Index { get; set; }
		public string LineId { get; set; }
		public string U_InvNo { get; set; }
		public string U_InvLineId { get; set; }
		public string U_InvDt { get; set; }
		public string U_ItemCode { get; set; }
		public string U_ItemGrp { get; set; }
		public string U_ItemName { get; set; }
		public string U_InvQty { get; set; }
		public string U_Reason { get; set; }
		public string U_ValRej { get; set; }
		public string U_ValTRej { get; set; }
		public string U_ValWTRej { get; set; }
		public string IsDeleted { get; set; }
		public string U_IsWithTax { get; set; }
		public bool IsWithTax { get; set; }
		public string U_MatRern { get; set; }
		public string U_RejQty { get; set; }
		public string U_InvSts { get; set; }
		public string U_BasOfVle { get; set; }
		public string U_Rate { get; set; }
		public string U_Per { get; set; }
		public string U_Oth { get; set; }
		public string U_Rem { get; set; }
		public string U_InvTax { get; set; }
		public string U_BPLId { get; set; }
		public string BPLId { get; set; }
	}
	public class ECRModel_Attachment
	{
		public int LineId { get; set; }
		public string IsChanged { get; set; }
		public string U_Attach{ get; set; }
		public string IsDeleted { get; set; }
	}
	public class ECRModel_RemarkDetails
	{
		public string U_BaseCode { get; set; }
		public string U_BaseLine { get; set; }
		public string U_Rem { get; set; }
		public string U_RemDate { get; set; }
		public string U_UserId { get; set; }
		public string UserName { get; set; }
		public string Department { get; set; }
		public string RowNo { get; set; }
		public string AssignTo { get; set; }
		
		
	}
}